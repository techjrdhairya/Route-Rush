import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.routerush.game',
  appName: 'Route Rush 3D',
  webDir: 'dist',
  backgroundColor: '#0b0b14',
  android: {
    backgroundColor: '#0b0b14',
    allowMixedContent: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      launchAutoHide: true,
      backgroundColor: '#0b0b14',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#0b0b14',
      overlaysWebView: false,
    },
  },
};

export default config;
