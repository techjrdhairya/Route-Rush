(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))s(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const f of c.addedNodes)f.tagName==="LINK"&&f.rel==="modulepreload"&&s(f)}).observe(document,{childList:!0,subtree:!0});function i(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function s(l){if(l.ep)return;l.ep=!0;const c=i(l);fetch(l.href,c)}})();function Ib(r){return r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r}var _d={exports:{}},qo={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var vx;function zb(){if(vx)return qo;vx=1;var r=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function i(s,l,c){var f=null;if(c!==void 0&&(f=""+c),l.key!==void 0&&(f=""+l.key),"key"in l){c={};for(var p in l)p!=="key"&&(c[p]=l[p])}else c=l;return l=c.ref,{$$typeof:r,type:s,key:f,ref:l!==void 0?l:null,props:c}}return qo.Fragment=e,qo.jsx=i,qo.jsxs=i,qo}var _x;function Fb(){return _x||(_x=1,_d.exports=zb()),_d.exports}var _=Fb(),yd={exports:{}},vt={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var yx;function Bb(){if(yx)return vt;yx=1;var r=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),f=Symbol.for("react.context"),p=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),h=Symbol.for("react.memo"),v=Symbol.for("react.lazy"),x=Symbol.for("react.activity"),g=Symbol.iterator;function M(E){return E===null||typeof E!="object"?null:(E=g&&E[g]||E["@@iterator"],typeof E=="function"?E:null)}var w={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},R=Object.assign,b={};function y(E,H,ce){this.props=E,this.context=H,this.refs=b,this.updater=ce||w}y.prototype.isReactComponent={},y.prototype.setState=function(E,H){if(typeof E!="object"&&typeof E!="function"&&E!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,E,H,"setState")},y.prototype.forceUpdate=function(E){this.updater.enqueueForceUpdate(this,E,"forceUpdate")};function P(){}P.prototype=y.prototype;function O(E,H,ce){this.props=E,this.context=H,this.refs=b,this.updater=ce||w}var C=O.prototype=new P;C.constructor=O,R(C,y.prototype),C.isPureReactComponent=!0;var I=Array.isArray;function L(){}var F={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function U(E,H,ce){var Se=ce.ref;return{$$typeof:r,type:E,key:H,ref:Se!==void 0?Se:null,props:ce}}function V(E,H){return U(E.type,H,E.props)}function k(E){return typeof E=="object"&&E!==null&&E.$$typeof===r}function W(E){var H={"=":"=0",":":"=2"};return"$"+E.replace(/[=:]/g,function(ce){return H[ce]})}var re=/\/+/g;function oe(E,H){return typeof E=="object"&&E!==null&&E.key!=null?W(""+E.key):H.toString(36)}function te(E){switch(E.status){case"fulfilled":return E.value;case"rejected":throw E.reason;default:switch(typeof E.status=="string"?E.then(L,L):(E.status="pending",E.then(function(H){E.status==="pending"&&(E.status="fulfilled",E.value=H)},function(H){E.status==="pending"&&(E.status="rejected",E.reason=H)})),E.status){case"fulfilled":return E.value;case"rejected":throw E.reason}}throw E}function G(E,H,ce,Se,Ae){var K=typeof E;(K==="undefined"||K==="boolean")&&(E=null);var le=!1;if(E===null)le=!0;else switch(K){case"bigint":case"string":case"number":le=!0;break;case"object":switch(E.$$typeof){case r:case e:le=!0;break;case v:return le=E._init,G(le(E._payload),H,ce,Se,Ae)}}if(le)return Ae=Ae(E),le=Se===""?"."+oe(E,0):Se,I(Ae)?(ce="",le!=null&&(ce=le.replace(re,"$&/")+"/"),G(Ae,H,ce,"",function(Q){return Q})):Ae!=null&&(k(Ae)&&(Ae=V(Ae,ce+(Ae.key==null||E&&E.key===Ae.key?"":(""+Ae.key).replace(re,"$&/")+"/")+le)),H.push(Ae)),1;le=0;var xe=Se===""?".":Se+":";if(I(E))for(var Le=0;Le<E.length;Le++)Se=E[Le],K=xe+oe(Se,Le),le+=G(Se,H,ce,K,Ae);else if(Le=M(E),typeof Le=="function")for(E=Le.call(E),Le=0;!(Se=E.next()).done;)Se=Se.value,K=xe+oe(Se,Le++),le+=G(Se,H,ce,K,Ae);else if(K==="object"){if(typeof E.then=="function")return G(te(E),H,ce,Se,Ae);throw H=String(E),Error("Objects are not valid as a React child (found: "+(H==="[object Object]"?"object with keys {"+Object.keys(E).join(", ")+"}":H)+"). If you meant to render a collection of children, use an array instead.")}return le}function X(E,H,ce){if(E==null)return E;var Se=[],Ae=0;return G(E,Se,"","",function(K){return H.call(ce,K,Ae++)}),Se}function $(E){if(E._status===-1){var H=E._result;H=H(),H.then(function(ce){(E._status===0||E._status===-1)&&(E._status=1,E._result=ce)},function(ce){(E._status===0||E._status===-1)&&(E._status=2,E._result=ce)}),E._status===-1&&(E._status=0,E._result=H)}if(E._status===1)return E._result.default;throw E._result}var se=typeof reportError=="function"?reportError:function(E){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var H=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof E=="object"&&E!==null&&typeof E.message=="string"?String(E.message):String(E),error:E});if(!window.dispatchEvent(H))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",E);return}console.error(E)},B={map:X,forEach:function(E,H,ce){X(E,function(){H.apply(this,arguments)},ce)},count:function(E){var H=0;return X(E,function(){H++}),H},toArray:function(E){return X(E,function(H){return H})||[]},only:function(E){if(!k(E))throw Error("React.Children.only expected to receive a single React element child.");return E}};return vt.Activity=x,vt.Children=B,vt.Component=y,vt.Fragment=i,vt.Profiler=l,vt.PureComponent=O,vt.StrictMode=s,vt.Suspense=m,vt.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=F,vt.__COMPILER_RUNTIME={__proto__:null,c:function(E){return F.H.useMemoCache(E)}},vt.cache=function(E){return function(){return E.apply(null,arguments)}},vt.cacheSignal=function(){return null},vt.cloneElement=function(E,H,ce){if(E==null)throw Error("The argument must be a React element, but you passed "+E+".");var Se=R({},E.props),Ae=E.key;if(H!=null)for(K in H.key!==void 0&&(Ae=""+H.key),H)!T.call(H,K)||K==="key"||K==="__self"||K==="__source"||K==="ref"&&H.ref===void 0||(Se[K]=H[K]);var K=arguments.length-2;if(K===1)Se.children=ce;else if(1<K){for(var le=Array(K),xe=0;xe<K;xe++)le[xe]=arguments[xe+2];Se.children=le}return U(E.type,Ae,Se)},vt.createContext=function(E){return E={$$typeof:f,_currentValue:E,_currentValue2:E,_threadCount:0,Provider:null,Consumer:null},E.Provider=E,E.Consumer={$$typeof:c,_context:E},E},vt.createElement=function(E,H,ce){var Se,Ae={},K=null;if(H!=null)for(Se in H.key!==void 0&&(K=""+H.key),H)T.call(H,Se)&&Se!=="key"&&Se!=="__self"&&Se!=="__source"&&(Ae[Se]=H[Se]);var le=arguments.length-2;if(le===1)Ae.children=ce;else if(1<le){for(var xe=Array(le),Le=0;Le<le;Le++)xe[Le]=arguments[Le+2];Ae.children=xe}if(E&&E.defaultProps)for(Se in le=E.defaultProps,le)Ae[Se]===void 0&&(Ae[Se]=le[Se]);return U(E,K,Ae)},vt.createRef=function(){return{current:null}},vt.forwardRef=function(E){return{$$typeof:p,render:E}},vt.isValidElement=k,vt.lazy=function(E){return{$$typeof:v,_payload:{_status:-1,_result:E},_init:$}},vt.memo=function(E,H){return{$$typeof:h,type:E,compare:H===void 0?null:H}},vt.startTransition=function(E){var H=F.T,ce={};F.T=ce;try{var Se=E(),Ae=F.S;Ae!==null&&Ae(ce,Se),typeof Se=="object"&&Se!==null&&typeof Se.then=="function"&&Se.then(L,se)}catch(K){se(K)}finally{H!==null&&ce.types!==null&&(H.types=ce.types),F.T=H}},vt.unstable_useCacheRefresh=function(){return F.H.useCacheRefresh()},vt.use=function(E){return F.H.use(E)},vt.useActionState=function(E,H,ce){return F.H.useActionState(E,H,ce)},vt.useCallback=function(E,H){return F.H.useCallback(E,H)},vt.useContext=function(E){return F.H.useContext(E)},vt.useDebugValue=function(){},vt.useDeferredValue=function(E,H){return F.H.useDeferredValue(E,H)},vt.useEffect=function(E,H){return F.H.useEffect(E,H)},vt.useEffectEvent=function(E){return F.H.useEffectEvent(E)},vt.useId=function(){return F.H.useId()},vt.useImperativeHandle=function(E,H,ce){return F.H.useImperativeHandle(E,H,ce)},vt.useInsertionEffect=function(E,H){return F.H.useInsertionEffect(E,H)},vt.useLayoutEffect=function(E,H){return F.H.useLayoutEffect(E,H)},vt.useMemo=function(E,H){return F.H.useMemo(E,H)},vt.useOptimistic=function(E,H){return F.H.useOptimistic(E,H)},vt.useReducer=function(E,H,ce){return F.H.useReducer(E,H,ce)},vt.useRef=function(E){return F.H.useRef(E)},vt.useState=function(E){return F.H.useState(E)},vt.useSyncExternalStore=function(E,H,ce){return F.H.useSyncExternalStore(E,H,ce)},vt.useTransition=function(){return F.H.useTransition()},vt.version="19.2.8",vt}var bx;function op(){return bx||(bx=1,yd.exports=Bb()),yd.exports}var st=op();const Gb=Ib(st);var bd={exports:{}},Yo={},Sd={exports:{}},Md={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Sx;function Hb(){return Sx||(Sx=1,(function(r){function e(G,X){var $=G.length;G.push(X);e:for(;0<$;){var se=$-1>>>1,B=G[se];if(0<l(B,X))G[se]=X,G[$]=B,$=se;else break e}}function i(G){return G.length===0?null:G[0]}function s(G){if(G.length===0)return null;var X=G[0],$=G.pop();if($!==X){G[0]=$;e:for(var se=0,B=G.length,E=B>>>1;se<E;){var H=2*(se+1)-1,ce=G[H],Se=H+1,Ae=G[Se];if(0>l(ce,$))Se<B&&0>l(Ae,ce)?(G[se]=Ae,G[Se]=$,se=Se):(G[se]=ce,G[H]=$,se=H);else if(Se<B&&0>l(Ae,$))G[se]=Ae,G[Se]=$,se=Se;else break e}}return X}function l(G,X){var $=G.sortIndex-X.sortIndex;return $!==0?$:G.id-X.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;r.unstable_now=function(){return c.now()}}else{var f=Date,p=f.now();r.unstable_now=function(){return f.now()-p}}var m=[],h=[],v=1,x=null,g=3,M=!1,w=!1,R=!1,b=!1,y=typeof setTimeout=="function"?setTimeout:null,P=typeof clearTimeout=="function"?clearTimeout:null,O=typeof setImmediate<"u"?setImmediate:null;function C(G){for(var X=i(h);X!==null;){if(X.callback===null)s(h);else if(X.startTime<=G)s(h),X.sortIndex=X.expirationTime,e(m,X);else break;X=i(h)}}function I(G){if(R=!1,C(G),!w)if(i(m)!==null)w=!0,L||(L=!0,W());else{var X=i(h);X!==null&&te(I,X.startTime-G)}}var L=!1,F=-1,T=5,U=-1;function V(){return b?!0:!(r.unstable_now()-U<T)}function k(){if(b=!1,L){var G=r.unstable_now();U=G;var X=!0;try{e:{w=!1,R&&(R=!1,P(F),F=-1),M=!0;var $=g;try{t:{for(C(G),x=i(m);x!==null&&!(x.expirationTime>G&&V());){var se=x.callback;if(typeof se=="function"){x.callback=null,g=x.priorityLevel;var B=se(x.expirationTime<=G);if(G=r.unstable_now(),typeof B=="function"){x.callback=B,C(G),X=!0;break t}x===i(m)&&s(m),C(G)}else s(m);x=i(m)}if(x!==null)X=!0;else{var E=i(h);E!==null&&te(I,E.startTime-G),X=!1}}break e}finally{x=null,g=$,M=!1}X=void 0}}finally{X?W():L=!1}}}var W;if(typeof O=="function")W=function(){O(k)};else if(typeof MessageChannel<"u"){var re=new MessageChannel,oe=re.port2;re.port1.onmessage=k,W=function(){oe.postMessage(null)}}else W=function(){y(k,0)};function te(G,X){F=y(function(){G(r.unstable_now())},X)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(G){G.callback=null},r.unstable_forceFrameRate=function(G){0>G||125<G?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<G?Math.floor(1e3/G):5},r.unstable_getCurrentPriorityLevel=function(){return g},r.unstable_next=function(G){switch(g){case 1:case 2:case 3:var X=3;break;default:X=g}var $=g;g=X;try{return G()}finally{g=$}},r.unstable_requestPaint=function(){b=!0},r.unstable_runWithPriority=function(G,X){switch(G){case 1:case 2:case 3:case 4:case 5:break;default:G=3}var $=g;g=G;try{return X()}finally{g=$}},r.unstable_scheduleCallback=function(G,X,$){var se=r.unstable_now();switch(typeof $=="object"&&$!==null?($=$.delay,$=typeof $=="number"&&0<$?se+$:se):$=se,G){case 1:var B=-1;break;case 2:B=250;break;case 5:B=1073741823;break;case 4:B=1e4;break;default:B=5e3}return B=$+B,G={id:v++,callback:X,priorityLevel:G,startTime:$,expirationTime:B,sortIndex:-1},$>se?(G.sortIndex=$,e(h,G),i(m)===null&&G===i(h)&&(R?(P(F),F=-1):R=!0,te(I,$-se))):(G.sortIndex=B,e(m,G),w||M||(w=!0,L||(L=!0,W()))),G},r.unstable_shouldYield=V,r.unstable_wrapCallback=function(G){var X=g;return function(){var $=g;g=X;try{return G.apply(this,arguments)}finally{g=$}}}})(Md)),Md}var Mx;function Vb(){return Mx||(Mx=1,Sd.exports=Hb()),Sd.exports}var Ed={exports:{}},Hn={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Ex;function kb(){if(Ex)return Hn;Ex=1;var r=op();function e(m){var h="https://react.dev/errors/"+m;if(1<arguments.length){h+="?args[]="+encodeURIComponent(arguments[1]);for(var v=2;v<arguments.length;v++)h+="&args[]="+encodeURIComponent(arguments[v])}return"Minified React error #"+m+"; visit "+h+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var s={d:{f:i,r:function(){throw Error(e(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal");function c(m,h,v){var x=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:x==null?null:""+x,children:m,containerInfo:h,implementation:v}}var f=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function p(m,h){if(m==="font")return"";if(typeof h=="string")return h==="use-credentials"?h:""}return Hn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=s,Hn.createPortal=function(m,h){var v=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!h||h.nodeType!==1&&h.nodeType!==9&&h.nodeType!==11)throw Error(e(299));return c(m,h,null,v)},Hn.flushSync=function(m){var h=f.T,v=s.p;try{if(f.T=null,s.p=2,m)return m()}finally{f.T=h,s.p=v,s.d.f()}},Hn.preconnect=function(m,h){typeof m=="string"&&(h?(h=h.crossOrigin,h=typeof h=="string"?h==="use-credentials"?h:"":void 0):h=null,s.d.C(m,h))},Hn.prefetchDNS=function(m){typeof m=="string"&&s.d.D(m)},Hn.preinit=function(m,h){if(typeof m=="string"&&h&&typeof h.as=="string"){var v=h.as,x=p(v,h.crossOrigin),g=typeof h.integrity=="string"?h.integrity:void 0,M=typeof h.fetchPriority=="string"?h.fetchPriority:void 0;v==="style"?s.d.S(m,typeof h.precedence=="string"?h.precedence:void 0,{crossOrigin:x,integrity:g,fetchPriority:M}):v==="script"&&s.d.X(m,{crossOrigin:x,integrity:g,fetchPriority:M,nonce:typeof h.nonce=="string"?h.nonce:void 0})}},Hn.preinitModule=function(m,h){if(typeof m=="string")if(typeof h=="object"&&h!==null){if(h.as==null||h.as==="script"){var v=p(h.as,h.crossOrigin);s.d.M(m,{crossOrigin:v,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0})}}else h==null&&s.d.M(m)},Hn.preload=function(m,h){if(typeof m=="string"&&typeof h=="object"&&h!==null&&typeof h.as=="string"){var v=h.as,x=p(v,h.crossOrigin);s.d.L(m,v,{crossOrigin:x,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0,type:typeof h.type=="string"?h.type:void 0,fetchPriority:typeof h.fetchPriority=="string"?h.fetchPriority:void 0,referrerPolicy:typeof h.referrerPolicy=="string"?h.referrerPolicy:void 0,imageSrcSet:typeof h.imageSrcSet=="string"?h.imageSrcSet:void 0,imageSizes:typeof h.imageSizes=="string"?h.imageSizes:void 0,media:typeof h.media=="string"?h.media:void 0})}},Hn.preloadModule=function(m,h){if(typeof m=="string")if(h){var v=p(h.as,h.crossOrigin);s.d.m(m,{as:typeof h.as=="string"&&h.as!=="script"?h.as:void 0,crossOrigin:v,integrity:typeof h.integrity=="string"?h.integrity:void 0})}else s.d.m(m)},Hn.requestFormReset=function(m){s.d.r(m)},Hn.unstable_batchedUpdates=function(m,h){return m(h)},Hn.useFormState=function(m,h,v){return f.H.useFormState(m,h,v)},Hn.useFormStatus=function(){return f.H.useHostTransitionStatus()},Hn.version="19.2.8",Hn}var Tx;function jb(){if(Tx)return Ed.exports;Tx=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),Ed.exports=kb(),Ed.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Ax;function Xb(){if(Ax)return Yo;Ax=1;var r=Vb(),e=op(),i=jb();function s(t){var n="https://react.dev/errors/"+t;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var a=2;a<arguments.length;a++)n+="&args[]="+encodeURIComponent(arguments[a])}return"Minified React error #"+t+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function c(t){var n=t,a=t;if(t.alternate)for(;n.return;)n=n.return;else{t=n;do n=t,(n.flags&4098)!==0&&(a=n.return),t=n.return;while(t)}return n.tag===3?a:null}function f(t){if(t.tag===13){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function p(t){if(t.tag===31){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function m(t){if(c(t)!==t)throw Error(s(188))}function h(t){var n=t.alternate;if(!n){if(n=c(t),n===null)throw Error(s(188));return n!==t?null:t}for(var a=t,o=n;;){var u=a.return;if(u===null)break;var d=u.alternate;if(d===null){if(o=u.return,o!==null){a=o;continue}break}if(u.child===d.child){for(d=u.child;d;){if(d===a)return m(u),t;if(d===o)return m(u),n;d=d.sibling}throw Error(s(188))}if(a.return!==o.return)a=u,o=d;else{for(var S=!1,D=u.child;D;){if(D===a){S=!0,a=u,o=d;break}if(D===o){S=!0,o=u,a=d;break}D=D.sibling}if(!S){for(D=d.child;D;){if(D===a){S=!0,a=d,o=u;break}if(D===o){S=!0,o=d,a=u;break}D=D.sibling}if(!S)throw Error(s(189))}}if(a.alternate!==o)throw Error(s(190))}if(a.tag!==3)throw Error(s(188));return a.stateNode.current===a?t:n}function v(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t;for(t=t.child;t!==null;){if(n=v(t),n!==null)return n;t=t.sibling}return null}var x=Object.assign,g=Symbol.for("react.element"),M=Symbol.for("react.transitional.element"),w=Symbol.for("react.portal"),R=Symbol.for("react.fragment"),b=Symbol.for("react.strict_mode"),y=Symbol.for("react.profiler"),P=Symbol.for("react.consumer"),O=Symbol.for("react.context"),C=Symbol.for("react.forward_ref"),I=Symbol.for("react.suspense"),L=Symbol.for("react.suspense_list"),F=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),U=Symbol.for("react.activity"),V=Symbol.for("react.memo_cache_sentinel"),k=Symbol.iterator;function W(t){return t===null||typeof t!="object"?null:(t=k&&t[k]||t["@@iterator"],typeof t=="function"?t:null)}var re=Symbol.for("react.client.reference");function oe(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===re?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case R:return"Fragment";case y:return"Profiler";case b:return"StrictMode";case I:return"Suspense";case L:return"SuspenseList";case U:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case w:return"Portal";case O:return t.displayName||"Context";case P:return(t._context.displayName||"Context")+".Consumer";case C:var n=t.render;return t=t.displayName,t||(t=n.displayName||n.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case F:return n=t.displayName||null,n!==null?n:oe(t.type)||"Memo";case T:n=t._payload,t=t._init;try{return oe(t(n))}catch{}}return null}var te=Array.isArray,G=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,X=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,$={pending:!1,data:null,method:null,action:null},se=[],B=-1;function E(t){return{current:t}}function H(t){0>B||(t.current=se[B],se[B]=null,B--)}function ce(t,n){B++,se[B]=t.current,t.current=n}var Se=E(null),Ae=E(null),K=E(null),le=E(null);function xe(t,n){switch(ce(K,n),ce(Ae,t),ce(Se,null),n.nodeType){case 9:case 11:t=(t=n.documentElement)&&(t=t.namespaceURI)?Hg(t):0;break;default:if(t=n.tagName,n=n.namespaceURI)n=Hg(n),t=Vg(n,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}H(Se),ce(Se,t)}function Le(){H(Se),H(Ae),H(K)}function Q(t){t.memoizedState!==null&&ce(le,t);var n=Se.current,a=Vg(n,t.type);n!==a&&(ce(Ae,t),ce(Se,a))}function _e(t){Ae.current===t&&(H(Se),H(Ae)),le.current===t&&(H(le),ko._currentValue=$)}var Ce,Ue;function He(t){if(Ce===void 0)try{throw Error()}catch(a){var n=a.stack.trim().match(/\n( *(at )?)/);Ce=n&&n[1]||"",Ue=-1<a.stack.indexOf(`
    at`)?" (<anonymous>)":-1<a.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Ce+t+Ue}var Ye=!1;function ft(t,n){if(!t||Ye)return"";Ye=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(n){var Re=function(){throw Error()};if(Object.defineProperty(Re.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(Re,[])}catch(ve){var ge=ve}Reflect.construct(t,[],Re)}else{try{Re.call()}catch(ve){ge=ve}t.call(Re.prototype)}}else{try{throw Error()}catch(ve){ge=ve}(Re=t())&&typeof Re.catch=="function"&&Re.catch(function(){})}}catch(ve){if(ve&&ge&&typeof ve.stack=="string")return[ve.stack,ge.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var d=o.DetermineComponentFrameRoot(),S=d[0],D=d[1];if(S&&D){var j=S.split(`
`),fe=D.split(`
`);for(u=o=0;o<j.length&&!j[o].includes("DetermineComponentFrameRoot");)o++;for(;u<fe.length&&!fe[u].includes("DetermineComponentFrameRoot");)u++;if(o===j.length||u===fe.length)for(o=j.length-1,u=fe.length-1;1<=o&&0<=u&&j[o]!==fe[u];)u--;for(;1<=o&&0<=u;o--,u--)if(j[o]!==fe[u]){if(o!==1||u!==1)do if(o--,u--,0>u||j[o]!==fe[u]){var Ee=`
`+j[o].replace(" at new "," at ");return t.displayName&&Ee.includes("<anonymous>")&&(Ee=Ee.replace("<anonymous>",t.displayName)),Ee}while(1<=o&&0<=u);break}}}finally{Ye=!1,Error.prepareStackTrace=a}return(a=t?t.displayName||t.name:"")?He(a):""}function ee(t,n){switch(t.tag){case 26:case 27:case 5:return He(t.type);case 16:return He("Lazy");case 13:return t.child!==n&&n!==null?He("Suspense Fallback"):He("Suspense");case 19:return He("SuspenseList");case 0:case 15:return ft(t.type,!1);case 11:return ft(t.type.render,!1);case 1:return ft(t.type,!0);case 31:return He("Activity");default:return""}}function Pe(t){try{var n="",a=null;do n+=ee(t,a),a=t,t=t.return;while(t);return n}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Qe=Object.prototype.hasOwnProperty,Je=r.unstable_scheduleCallback,ct=r.unstable_cancelCallback,Mt=r.unstable_shouldYield,Y=r.unstable_requestPaint,Tt=r.unstable_now,Ne=r.unstable_getCurrentPriorityLevel,z=r.unstable_ImmediatePriority,A=r.unstable_UserBlockingPriority,ie=r.unstable_NormalPriority,pe=r.unstable_LowPriority,ye=r.unstable_IdlePriority,Oe=r.log,Be=r.unstable_setDisableYieldValue,be=null,Me=null;function ze(t){if(typeof Oe=="function"&&Be(t),Me&&typeof Me.setStrictMode=="function")try{Me.setStrictMode(be,t)}catch{}}var Ze=Math.clz32?Math.clz32:ut,je=Math.log,Ve=Math.LN2;function ut(t){return t>>>=0,t===0?32:31-(je(t)/Ve|0)|0}var dt=256,gt=262144,Z=4194304;function Ie(t){var n=t&42;if(n!==0)return n;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&261888;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function Te(t,n,a){var o=t.pendingLanes;if(o===0)return 0;var u=0,d=t.suspendedLanes,S=t.pingedLanes;t=t.warmLanes;var D=o&134217727;return D!==0?(o=D&~d,o!==0?u=Ie(o):(S&=D,S!==0?u=Ie(S):a||(a=D&~t,a!==0&&(u=Ie(a))))):(D=o&~d,D!==0?u=Ie(D):S!==0?u=Ie(S):a||(a=o&~t,a!==0&&(u=Ie(a)))),u===0?0:n!==0&&n!==u&&(n&d)===0&&(d=u&-u,a=n&-n,d>=a||d===32&&(a&4194048)!==0)?n:u}function Fe(t,n){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&n)===0}function qe(t,n){switch(t){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function De(){var t=Z;return Z<<=1,(Z&62914560)===0&&(Z=4194304),t}function rt(t){for(var n=[],a=0;31>a;a++)n.push(t);return n}function et(t,n){t.pendingLanes|=n,n!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function rn(t,n,a,o,u,d){var S=t.pendingLanes;t.pendingLanes=a,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=a,t.entangledLanes&=a,t.errorRecoveryDisabledLanes&=a,t.shellSuspendCounter=0;var D=t.entanglements,j=t.expirationTimes,fe=t.hiddenUpdates;for(a=S&~a;0<a;){var Ee=31-Ze(a),Re=1<<Ee;D[Ee]=0,j[Ee]=-1;var ge=fe[Ee];if(ge!==null)for(fe[Ee]=null,Ee=0;Ee<ge.length;Ee++){var ve=ge[Ee];ve!==null&&(ve.lane&=-536870913)}a&=~Re}o!==0&&Xt(t,o,0),d!==0&&u===0&&t.tag!==0&&(t.suspendedLanes|=d&~(S&~n))}function Xt(t,n,a){t.pendingLanes|=n,t.suspendedLanes&=~n;var o=31-Ze(n);t.entangledLanes|=n,t.entanglements[o]=t.entanglements[o]|1073741824|a&261930}function ai(t,n){var a=t.entangledLanes|=n;for(t=t.entanglements;a;){var o=31-Ze(a),u=1<<o;u&n|t[o]&n&&(t[o]|=n),a&=~u}}function si(t,n){var a=n&-n;return a=(a&42)!==0?1:no(a),(a&(t.suspendedLanes|n))!==0?0:a}function no(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function io(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function ao(){var t=X.p;return t!==0?t:(t=window.event,t===void 0?32:fx(t.type))}function Qs(t,n){var a=X.p;try{return X.p=t,n()}finally{X.p=a}}var Vi=Math.random().toString(36).slice(2),vn="__reactFiber$"+Vi,Un="__reactProps$"+Vi,Zn="__reactContainer$"+Vi,gs="__reactEvents$"+Vi,pl="__reactListeners$"+Vi,ml="__reactHandles$"+Vi,xs="__reactResources$"+Vi,La="__reactMarker$"+Vi;function Oa(t){delete t[vn],delete t[Un],delete t[gs],delete t[pl],delete t[ml]}function aa(t){var n=t[vn];if(n)return n;for(var a=t.parentNode;a;){if(n=a[Zn]||a[vn]){if(a=n.alternate,n.child!==null||a!==null&&a.child!==null)for(t=Zg(t);t!==null;){if(a=t[vn])return a;t=Zg(t)}return n}t=a,a=t.parentNode}return null}function sa(t){if(t=t[vn]||t[Zn]){var n=t.tag;if(n===5||n===6||n===13||n===31||n===26||n===27||n===3)return t}return null}function vs(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t.stateNode;throw Error(s(33))}function Pa(t){var n=t[xs];return n||(n=t[xs]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function _n(t){t[La]=!0}var gl=new Set,N={};function J(t,n){me(t,n),me(t+"Capture",n)}function me(t,n){for(N[t]=n,t=0;t<n.length;t++)gl.add(n[t])}var de=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),he={},Xe={};function $e(t){return Qe.call(Xe,t)?!0:Qe.call(he,t)?!1:de.test(t)?Xe[t]=!0:(he[t]=!0,!1)}function ke(t,n,a){if($e(n))if(a===null)t.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":t.removeAttribute(n);return;case"boolean":var o=n.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){t.removeAttribute(n);return}}t.setAttribute(n,""+a)}}function it(t,n,a){if(a===null)t.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(n);return}t.setAttribute(n,""+a)}}function tt(t,n,a,o){if(o===null)t.removeAttribute(a);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(a);return}t.setAttributeNS(n,a,""+o)}}function ht(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function yt(t){var n=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function lt(t,n,a){var o=Object.getOwnPropertyDescriptor(t.constructor.prototype,n);if(!t.hasOwnProperty(n)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var u=o.get,d=o.set;return Object.defineProperty(t,n,{configurable:!0,get:function(){return u.call(this)},set:function(S){a=""+S,d.call(this,S)}}),Object.defineProperty(t,n,{enumerable:o.enumerable}),{getValue:function(){return a},setValue:function(S){a=""+S},stopTracking:function(){t._valueTracker=null,delete t[n]}}}}function Gt(t){if(!t._valueTracker){var n=yt(t)?"checked":"value";t._valueTracker=lt(t,n,""+t[n])}}function on(t){if(!t)return!1;var n=t._valueTracker;if(!n)return!0;var a=n.getValue(),o="";return t&&(o=yt(t)?t.checked?"true":"false":t.value),t=o,t!==a?(n.setValue(t),!0):!1}function tn(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var Wt=/[\n"\\]/g;function qt(t){return t.replace(Wt,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function Ke(t,n,a,o,u,d,S,D){t.name="",S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"?t.type=S:t.removeAttribute("type"),n!=null?S==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+ht(n)):t.value!==""+ht(n)&&(t.value=""+ht(n)):S!=="submit"&&S!=="reset"||t.removeAttribute("value"),n!=null?Rt(t,S,ht(n)):a!=null?Rt(t,S,ht(a)):o!=null&&t.removeAttribute("value"),u==null&&d!=null&&(t.defaultChecked=!!d),u!=null&&(t.checked=u&&typeof u!="function"&&typeof u!="symbol"),D!=null&&typeof D!="function"&&typeof D!="symbol"&&typeof D!="boolean"?t.name=""+ht(D):t.removeAttribute("name")}function Gn(t,n,a,o,u,d,S,D){if(d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"&&(t.type=d),n!=null||a!=null){if(!(d!=="submit"&&d!=="reset"||n!=null)){Gt(t);return}a=a!=null?""+ht(a):"",n=n!=null?""+ht(n):a,D||n===t.value||(t.value=n),t.defaultValue=n}o=o??u,o=typeof o!="function"&&typeof o!="symbol"&&!!o,t.checked=D?t.checked:!!o,t.defaultChecked=!!o,S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"&&(t.name=S),Gt(t)}function Rt(t,n,a){n==="number"&&tn(t.ownerDocument)===t||t.defaultValue===""+a||(t.defaultValue=""+a)}function Tn(t,n,a,o){if(t=t.options,n){n={};for(var u=0;u<a.length;u++)n["$"+a[u]]=!0;for(a=0;a<t.length;a++)u=n.hasOwnProperty("$"+t[a].value),t[a].selected!==u&&(t[a].selected=u),u&&o&&(t[a].defaultSelected=!0)}else{for(a=""+ht(a),n=null,u=0;u<t.length;u++){if(t[u].value===a){t[u].selected=!0,o&&(t[u].defaultSelected=!0);return}n!==null||t[u].disabled||(n=t[u])}n!==null&&(n.selected=!0)}}function ri(t,n,a){if(n!=null&&(n=""+ht(n),n!==t.value&&(t.value=n),a==null)){t.defaultValue!==n&&(t.defaultValue=n);return}t.defaultValue=a!=null?""+ht(a):""}function Ri(t,n,a,o){if(n==null){if(o!=null){if(a!=null)throw Error(s(92));if(te(o)){if(1<o.length)throw Error(s(93));o=o[0]}a=o}a==null&&(a=""),n=a}a=ht(n),t.defaultValue=a,o=t.textContent,o===a&&o!==""&&o!==null&&(t.value=o),Gt(t)}function oi(t,n){if(n){var a=t.firstChild;if(a&&a===t.lastChild&&a.nodeType===3){a.nodeValue=n;return}}t.textContent=n}var Yt=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ln(t,n,a){var o=n.indexOf("--")===0;a==null||typeof a=="boolean"||a===""?o?t.setProperty(n,""):n==="float"?t.cssFloat="":t[n]="":o?t.setProperty(n,a):typeof a!="number"||a===0||Yt.has(n)?n==="float"?t.cssFloat=a:t[n]=(""+a).trim():t[n]=a+"px"}function Ni(t,n,a){if(n!=null&&typeof n!="object")throw Error(s(62));if(t=t.style,a!=null){for(var o in a)!a.hasOwnProperty(o)||n!=null&&n.hasOwnProperty(o)||(o.indexOf("--")===0?t.setProperty(o,""):o==="float"?t.cssFloat="":t[o]="");for(var u in n)o=n[u],n.hasOwnProperty(u)&&a[u]!==o&&ln(t,u,o)}else for(var d in n)n.hasOwnProperty(d)&&ln(t,d,n[d])}function jt(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var ki=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Ia=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function _s(t){return Ia.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function ra(){}var mu=null;function gu(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var Js=null,$s=null;function Gp(t){var n=sa(t);if(n&&(t=n.stateNode)){var a=t[Un]||null;e:switch(t=n.stateNode,n.type){case"input":if(Ke(t,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name),n=a.name,a.type==="radio"&&n!=null){for(a=t;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll('input[name="'+qt(""+n)+'"][type="radio"]'),n=0;n<a.length;n++){var o=a[n];if(o!==t&&o.form===t.form){var u=o[Un]||null;if(!u)throw Error(s(90));Ke(o,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(n=0;n<a.length;n++)o=a[n],o.form===t.form&&on(o)}break e;case"textarea":ri(t,a.value,a.defaultValue);break e;case"select":n=a.value,n!=null&&Tn(t,!!a.multiple,n,!1)}}}var xu=!1;function Hp(t,n,a){if(xu)return t(n,a);xu=!0;try{var o=t(n);return o}finally{if(xu=!1,(Js!==null||$s!==null)&&(ic(),Js&&(n=Js,t=$s,$s=Js=null,Gp(n),t)))for(n=0;n<t.length;n++)Gp(t[n])}}function so(t,n){var a=t.stateNode;if(a===null)return null;var o=a[Un]||null;if(o===null)return null;a=o[n];e:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(t=t.type,o=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!o;break e;default:t=!1}if(t)return null;if(a&&typeof a!="function")throw Error(s(231,n,typeof a));return a}var oa=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),vu=!1;if(oa)try{var ro={};Object.defineProperty(ro,"passive",{get:function(){vu=!0}}),window.addEventListener("test",ro,ro),window.removeEventListener("test",ro,ro)}catch{vu=!1}var za=null,_u=null,xl=null;function Vp(){if(xl)return xl;var t,n=_u,a=n.length,o,u="value"in za?za.value:za.textContent,d=u.length;for(t=0;t<a&&n[t]===u[t];t++);var S=a-t;for(o=1;o<=S&&n[a-o]===u[d-o];o++);return xl=u.slice(t,1<o?1-o:void 0)}function vl(t){var n=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&n===13&&(t=13)):t=n,t===10&&(t=13),32<=t||t===13?t:0}function _l(){return!0}function kp(){return!1}function Kn(t){function n(a,o,u,d,S){this._reactName=a,this._targetInst=u,this.type=o,this.nativeEvent=d,this.target=S,this.currentTarget=null;for(var D in t)t.hasOwnProperty(D)&&(a=t[D],this[D]=a?a(d):d[D]);return this.isDefaultPrevented=(d.defaultPrevented!=null?d.defaultPrevented:d.returnValue===!1)?_l:kp,this.isPropagationStopped=kp,this}return x(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=_l)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=_l)},persist:function(){},isPersistent:_l}),n}var ys={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},yl=Kn(ys),oo=x({},ys,{view:0,detail:0}),O_=Kn(oo),yu,bu,lo,bl=x({},oo,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Mu,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==lo&&(lo&&t.type==="mousemove"?(yu=t.screenX-lo.screenX,bu=t.screenY-lo.screenY):bu=yu=0,lo=t),yu)},movementY:function(t){return"movementY"in t?t.movementY:bu}}),jp=Kn(bl),P_=x({},bl,{dataTransfer:0}),I_=Kn(P_),z_=x({},oo,{relatedTarget:0}),Su=Kn(z_),F_=x({},ys,{animationName:0,elapsedTime:0,pseudoElement:0}),B_=Kn(F_),G_=x({},ys,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),H_=Kn(G_),V_=x({},ys,{data:0}),Xp=Kn(V_),k_={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},j_={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},X_={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function W_(t){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(t):(t=X_[t])?!!n[t]:!1}function Mu(){return W_}var q_=x({},oo,{key:function(t){if(t.key){var n=k_[t.key]||t.key;if(n!=="Unidentified")return n}return t.type==="keypress"?(t=vl(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?j_[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Mu,charCode:function(t){return t.type==="keypress"?vl(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?vl(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),Y_=Kn(q_),Z_=x({},bl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Wp=Kn(Z_),K_=x({},oo,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Mu}),Q_=Kn(K_),J_=x({},ys,{propertyName:0,elapsedTime:0,pseudoElement:0}),$_=Kn(J_),ey=x({},bl,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),ty=Kn(ey),ny=x({},ys,{newState:0,oldState:0}),iy=Kn(ny),ay=[9,13,27,32],Eu=oa&&"CompositionEvent"in window,co=null;oa&&"documentMode"in document&&(co=document.documentMode);var sy=oa&&"TextEvent"in window&&!co,qp=oa&&(!Eu||co&&8<co&&11>=co),Yp=" ",Zp=!1;function Kp(t,n){switch(t){case"keyup":return ay.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Qp(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var er=!1;function ry(t,n){switch(t){case"compositionend":return Qp(n);case"keypress":return n.which!==32?null:(Zp=!0,Yp);case"textInput":return t=n.data,t===Yp&&Zp?null:t;default:return null}}function oy(t,n){if(er)return t==="compositionend"||!Eu&&Kp(t,n)?(t=Vp(),xl=_u=za=null,er=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return qp&&n.locale!=="ko"?null:n.data;default:return null}}var ly={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Jp(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n==="input"?!!ly[t.type]:n==="textarea"}function $p(t,n,a,o){Js?$s?$s.push(o):$s=[o]:Js=o,n=uc(n,"onChange"),0<n.length&&(a=new yl("onChange","change",null,a,o),t.push({event:a,listeners:n}))}var uo=null,fo=null;function cy(t){Pg(t,0)}function Sl(t){var n=vs(t);if(on(n))return t}function em(t,n){if(t==="change")return n}var tm=!1;if(oa){var Tu;if(oa){var Au="oninput"in document;if(!Au){var nm=document.createElement("div");nm.setAttribute("oninput","return;"),Au=typeof nm.oninput=="function"}Tu=Au}else Tu=!1;tm=Tu&&(!document.documentMode||9<document.documentMode)}function im(){uo&&(uo.detachEvent("onpropertychange",am),fo=uo=null)}function am(t){if(t.propertyName==="value"&&Sl(fo)){var n=[];$p(n,fo,t,gu(t)),Hp(cy,n)}}function uy(t,n,a){t==="focusin"?(im(),uo=n,fo=a,uo.attachEvent("onpropertychange",am)):t==="focusout"&&im()}function fy(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return Sl(fo)}function dy(t,n){if(t==="click")return Sl(n)}function hy(t,n){if(t==="input"||t==="change")return Sl(n)}function py(t,n){return t===n&&(t!==0||1/t===1/n)||t!==t&&n!==n}var li=typeof Object.is=="function"?Object.is:py;function ho(t,n){if(li(t,n))return!0;if(typeof t!="object"||t===null||typeof n!="object"||n===null)return!1;var a=Object.keys(t),o=Object.keys(n);if(a.length!==o.length)return!1;for(o=0;o<a.length;o++){var u=a[o];if(!Qe.call(n,u)||!li(t[u],n[u]))return!1}return!0}function sm(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function rm(t,n){var a=sm(t);t=0;for(var o;a;){if(a.nodeType===3){if(o=t+a.textContent.length,t<=n&&o>=n)return{node:a,offset:n-t};t=o}e:{for(;a;){if(a.nextSibling){a=a.nextSibling;break e}a=a.parentNode}a=void 0}a=sm(a)}}function om(t,n){return t&&n?t===n?!0:t&&t.nodeType===3?!1:n&&n.nodeType===3?om(t,n.parentNode):"contains"in t?t.contains(n):t.compareDocumentPosition?!!(t.compareDocumentPosition(n)&16):!1:!1}function lm(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var n=tn(t.document);n instanceof t.HTMLIFrameElement;){try{var a=typeof n.contentWindow.location.href=="string"}catch{a=!1}if(a)t=n.contentWindow;else break;n=tn(t.document)}return n}function wu(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n&&(n==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||n==="textarea"||t.contentEditable==="true")}var my=oa&&"documentMode"in document&&11>=document.documentMode,tr=null,Cu=null,po=null,Ru=!1;function cm(t,n,a){var o=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;Ru||tr==null||tr!==tn(o)||(o=tr,"selectionStart"in o&&wu(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),po&&ho(po,o)||(po=o,o=uc(Cu,"onSelect"),0<o.length&&(n=new yl("onSelect","select",null,n,a),t.push({event:n,listeners:o}),n.target=tr)))}function bs(t,n){var a={};return a[t.toLowerCase()]=n.toLowerCase(),a["Webkit"+t]="webkit"+n,a["Moz"+t]="moz"+n,a}var nr={animationend:bs("Animation","AnimationEnd"),animationiteration:bs("Animation","AnimationIteration"),animationstart:bs("Animation","AnimationStart"),transitionrun:bs("Transition","TransitionRun"),transitionstart:bs("Transition","TransitionStart"),transitioncancel:bs("Transition","TransitionCancel"),transitionend:bs("Transition","TransitionEnd")},Nu={},um={};oa&&(um=document.createElement("div").style,"AnimationEvent"in window||(delete nr.animationend.animation,delete nr.animationiteration.animation,delete nr.animationstart.animation),"TransitionEvent"in window||delete nr.transitionend.transition);function Ss(t){if(Nu[t])return Nu[t];if(!nr[t])return t;var n=nr[t],a;for(a in n)if(n.hasOwnProperty(a)&&a in um)return Nu[t]=n[a];return t}var fm=Ss("animationend"),dm=Ss("animationiteration"),hm=Ss("animationstart"),gy=Ss("transitionrun"),xy=Ss("transitionstart"),vy=Ss("transitioncancel"),pm=Ss("transitionend"),mm=new Map,Du="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Du.push("scrollEnd");function Di(t,n){mm.set(t,n),J(n,[t])}var Ml=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},vi=[],ir=0,Uu=0;function El(){for(var t=ir,n=Uu=ir=0;n<t;){var a=vi[n];vi[n++]=null;var o=vi[n];vi[n++]=null;var u=vi[n];vi[n++]=null;var d=vi[n];if(vi[n++]=null,o!==null&&u!==null){var S=o.pending;S===null?u.next=u:(u.next=S.next,S.next=u),o.pending=u}d!==0&&gm(a,u,d)}}function Tl(t,n,a,o){vi[ir++]=t,vi[ir++]=n,vi[ir++]=a,vi[ir++]=o,Uu|=o,t.lanes|=o,t=t.alternate,t!==null&&(t.lanes|=o)}function Lu(t,n,a,o){return Tl(t,n,a,o),Al(t)}function Ms(t,n){return Tl(t,null,null,n),Al(t)}function gm(t,n,a){t.lanes|=a;var o=t.alternate;o!==null&&(o.lanes|=a);for(var u=!1,d=t.return;d!==null;)d.childLanes|=a,o=d.alternate,o!==null&&(o.childLanes|=a),d.tag===22&&(t=d.stateNode,t===null||t._visibility&1||(u=!0)),t=d,d=d.return;return t.tag===3?(d=t.stateNode,u&&n!==null&&(u=31-Ze(a),t=d.hiddenUpdates,o=t[u],o===null?t[u]=[n]:o.push(n),n.lane=a|536870912),d):null}function Al(t){if(50<Io)throw Io=0,kf=null,Error(s(185));for(var n=t.return;n!==null;)t=n,n=t.return;return t.tag===3?t.stateNode:null}var ar={};function _y(t,n,a,o){this.tag=t,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ci(t,n,a,o){return new _y(t,n,a,o)}function Ou(t){return t=t.prototype,!(!t||!t.isReactComponent)}function la(t,n){var a=t.alternate;return a===null?(a=ci(t.tag,n,t.key,t.mode),a.elementType=t.elementType,a.type=t.type,a.stateNode=t.stateNode,a.alternate=t,t.alternate=a):(a.pendingProps=n,a.type=t.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=t.flags&65011712,a.childLanes=t.childLanes,a.lanes=t.lanes,a.child=t.child,a.memoizedProps=t.memoizedProps,a.memoizedState=t.memoizedState,a.updateQueue=t.updateQueue,n=t.dependencies,a.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},a.sibling=t.sibling,a.index=t.index,a.ref=t.ref,a.refCleanup=t.refCleanup,a}function xm(t,n){t.flags&=65011714;var a=t.alternate;return a===null?(t.childLanes=0,t.lanes=n,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=a.childLanes,t.lanes=a.lanes,t.child=a.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=a.memoizedProps,t.memoizedState=a.memoizedState,t.updateQueue=a.updateQueue,t.type=a.type,n=a.dependencies,t.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),t}function wl(t,n,a,o,u,d){var S=0;if(o=t,typeof t=="function")Ou(t)&&(S=1);else if(typeof t=="string")S=Eb(t,a,Se.current)?26:t==="html"||t==="head"||t==="body"?27:5;else e:switch(t){case U:return t=ci(31,a,n,u),t.elementType=U,t.lanes=d,t;case R:return Es(a.children,u,d,n);case b:S=8,u|=24;break;case y:return t=ci(12,a,n,u|2),t.elementType=y,t.lanes=d,t;case I:return t=ci(13,a,n,u),t.elementType=I,t.lanes=d,t;case L:return t=ci(19,a,n,u),t.elementType=L,t.lanes=d,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case O:S=10;break e;case P:S=9;break e;case C:S=11;break e;case F:S=14;break e;case T:S=16,o=null;break e}S=29,a=Error(s(130,t===null?"null":typeof t,"")),o=null}return n=ci(S,a,n,u),n.elementType=t,n.type=o,n.lanes=d,n}function Es(t,n,a,o){return t=ci(7,t,o,n),t.lanes=a,t}function Pu(t,n,a){return t=ci(6,t,null,n),t.lanes=a,t}function vm(t){var n=ci(18,null,null,0);return n.stateNode=t,n}function Iu(t,n,a){return n=ci(4,t.children!==null?t.children:[],t.key,n),n.lanes=a,n.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},n}var _m=new WeakMap;function _i(t,n){if(typeof t=="object"&&t!==null){var a=_m.get(t);return a!==void 0?a:(n={value:t,source:n,stack:Pe(n)},_m.set(t,n),n)}return{value:t,source:n,stack:Pe(n)}}var sr=[],rr=0,Cl=null,mo=0,yi=[],bi=0,Fa=null,ji=1,Xi="";function ca(t,n){sr[rr++]=mo,sr[rr++]=Cl,Cl=t,mo=n}function ym(t,n,a){yi[bi++]=ji,yi[bi++]=Xi,yi[bi++]=Fa,Fa=t;var o=ji;t=Xi;var u=32-Ze(o)-1;o&=~(1<<u),a+=1;var d=32-Ze(n)+u;if(30<d){var S=u-u%5;d=(o&(1<<S)-1).toString(32),o>>=S,u-=S,ji=1<<32-Ze(n)+u|a<<u|o,Xi=d+t}else ji=1<<d|a<<u|o,Xi=t}function zu(t){t.return!==null&&(ca(t,1),ym(t,1,0))}function Fu(t){for(;t===Cl;)Cl=sr[--rr],sr[rr]=null,mo=sr[--rr],sr[rr]=null;for(;t===Fa;)Fa=yi[--bi],yi[bi]=null,Xi=yi[--bi],yi[bi]=null,ji=yi[--bi],yi[bi]=null}function bm(t,n){yi[bi++]=ji,yi[bi++]=Xi,yi[bi++]=Fa,ji=n.id,Xi=n.overflow,Fa=t}var Ln=null,an=null,Pt=!1,Ba=null,Si=!1,Bu=Error(s(519));function Ga(t){var n=Error(s(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw go(_i(n,t)),Bu}function Sm(t){var n=t.stateNode,a=t.type,o=t.memoizedProps;switch(n[vn]=t,n[Un]=o,a){case"dialog":Dt("cancel",n),Dt("close",n);break;case"iframe":case"object":case"embed":Dt("load",n);break;case"video":case"audio":for(a=0;a<Fo.length;a++)Dt(Fo[a],n);break;case"source":Dt("error",n);break;case"img":case"image":case"link":Dt("error",n),Dt("load",n);break;case"details":Dt("toggle",n);break;case"input":Dt("invalid",n),Gn(n,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":Dt("invalid",n);break;case"textarea":Dt("invalid",n),Ri(n,o.value,o.defaultValue,o.children)}a=o.children,typeof a!="string"&&typeof a!="number"&&typeof a!="bigint"||n.textContent===""+a||o.suppressHydrationWarning===!0||Bg(n.textContent,a)?(o.popover!=null&&(Dt("beforetoggle",n),Dt("toggle",n)),o.onScroll!=null&&Dt("scroll",n),o.onScrollEnd!=null&&Dt("scrollend",n),o.onClick!=null&&(n.onclick=ra),n=!0):n=!1,n||Ga(t,!0)}function Mm(t){for(Ln=t.return;Ln;)switch(Ln.tag){case 5:case 31:case 13:Si=!1;return;case 27:case 3:Si=!0;return;default:Ln=Ln.return}}function or(t){if(t!==Ln)return!1;if(!Pt)return Mm(t),Pt=!0,!1;var n=t.tag,a;if((a=n!==3&&n!==27)&&((a=n===5)&&(a=t.type,a=!(a!=="form"&&a!=="button")||ad(t.type,t.memoizedProps)),a=!a),a&&an&&Ga(t),Mm(t),n===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(317));an=Yg(t)}else if(n===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(317));an=Yg(t)}else n===27?(n=an,es(t.type)?(t=cd,cd=null,an=t):an=n):an=Ln?Ei(t.stateNode.nextSibling):null;return!0}function Ts(){an=Ln=null,Pt=!1}function Gu(){var t=Ba;return t!==null&&(ei===null?ei=t:ei.push.apply(ei,t),Ba=null),t}function go(t){Ba===null?Ba=[t]:Ba.push(t)}var Hu=E(null),As=null,ua=null;function Ha(t,n,a){ce(Hu,n._currentValue),n._currentValue=a}function fa(t){t._currentValue=Hu.current,H(Hu)}function Vu(t,n,a){for(;t!==null;){var o=t.alternate;if((t.childLanes&n)!==n?(t.childLanes|=n,o!==null&&(o.childLanes|=n)):o!==null&&(o.childLanes&n)!==n&&(o.childLanes|=n),t===a)break;t=t.return}}function ku(t,n,a,o){var u=t.child;for(u!==null&&(u.return=t);u!==null;){var d=u.dependencies;if(d!==null){var S=u.child;d=d.firstContext;e:for(;d!==null;){var D=d;d=u;for(var j=0;j<n.length;j++)if(D.context===n[j]){d.lanes|=a,D=d.alternate,D!==null&&(D.lanes|=a),Vu(d.return,a,t),o||(S=null);break e}d=D.next}}else if(u.tag===18){if(S=u.return,S===null)throw Error(s(341));S.lanes|=a,d=S.alternate,d!==null&&(d.lanes|=a),Vu(S,a,t),S=null}else S=u.child;if(S!==null)S.return=u;else for(S=u;S!==null;){if(S===t){S=null;break}if(u=S.sibling,u!==null){u.return=S.return,S=u;break}S=S.return}u=S}}function lr(t,n,a,o){t=null;for(var u=n,d=!1;u!==null;){if(!d){if((u.flags&524288)!==0)d=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var S=u.alternate;if(S===null)throw Error(s(387));if(S=S.memoizedProps,S!==null){var D=u.type;li(u.pendingProps.value,S.value)||(t!==null?t.push(D):t=[D])}}else if(u===le.current){if(S=u.alternate,S===null)throw Error(s(387));S.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(t!==null?t.push(ko):t=[ko])}u=u.return}t!==null&&ku(n,t,a,o),n.flags|=262144}function Rl(t){for(t=t.firstContext;t!==null;){if(!li(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function ws(t){As=t,ua=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function On(t){return Em(As,t)}function Nl(t,n){return As===null&&ws(t),Em(t,n)}function Em(t,n){var a=n._currentValue;if(n={context:n,memoizedValue:a,next:null},ua===null){if(t===null)throw Error(s(308));ua=n,t.dependencies={lanes:0,firstContext:n},t.flags|=524288}else ua=ua.next=n;return a}var yy=typeof AbortController<"u"?AbortController:function(){var t=[],n=this.signal={aborted:!1,addEventListener:function(a,o){t.push(o)}};this.abort=function(){n.aborted=!0,t.forEach(function(a){return a()})}},by=r.unstable_scheduleCallback,Sy=r.unstable_NormalPriority,yn={$$typeof:O,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function ju(){return{controller:new yy,data:new Map,refCount:0}}function xo(t){t.refCount--,t.refCount===0&&by(Sy,function(){t.controller.abort()})}var vo=null,Xu=0,cr=0,ur=null;function My(t,n){if(vo===null){var a=vo=[];Xu=0,cr=Zf(),ur={status:"pending",value:void 0,then:function(o){a.push(o)}}}return Xu++,n.then(Tm,Tm),n}function Tm(){if(--Xu===0&&vo!==null){ur!==null&&(ur.status="fulfilled");var t=vo;vo=null,cr=0,ur=null;for(var n=0;n<t.length;n++)(0,t[n])()}}function Ey(t,n){var a=[],o={status:"pending",value:null,reason:null,then:function(u){a.push(u)}};return t.then(function(){o.status="fulfilled",o.value=n;for(var u=0;u<a.length;u++)(0,a[u])(n)},function(u){for(o.status="rejected",o.reason=u,u=0;u<a.length;u++)(0,a[u])(void 0)}),o}var Am=G.S;G.S=function(t,n){cg=Tt(),typeof n=="object"&&n!==null&&typeof n.then=="function"&&My(t,n),Am!==null&&Am(t,n)};var Cs=E(null);function Wu(){var t=Cs.current;return t!==null?t:nn.pooledCache}function Dl(t,n){n===null?ce(Cs,Cs.current):ce(Cs,n.pool)}function wm(){var t=Wu();return t===null?null:{parent:yn._currentValue,pool:t}}var fr=Error(s(460)),qu=Error(s(474)),Ul=Error(s(542)),Ll={then:function(){}};function Cm(t){return t=t.status,t==="fulfilled"||t==="rejected"}function Rm(t,n,a){switch(a=t[a],a===void 0?t.push(n):a!==n&&(n.then(ra,ra),n=a),n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Dm(t),t;default:if(typeof n.status=="string")n.then(ra,ra);else{if(t=nn,t!==null&&100<t.shellSuspendCounter)throw Error(s(482));t=n,t.status="pending",t.then(function(o){if(n.status==="pending"){var u=n;u.status="fulfilled",u.value=o}},function(o){if(n.status==="pending"){var u=n;u.status="rejected",u.reason=o}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Dm(t),t}throw Ns=n,fr}}function Rs(t){try{var n=t._init;return n(t._payload)}catch(a){throw a!==null&&typeof a=="object"&&typeof a.then=="function"?(Ns=a,fr):a}}var Ns=null;function Nm(){if(Ns===null)throw Error(s(459));var t=Ns;return Ns=null,t}function Dm(t){if(t===fr||t===Ul)throw Error(s(483))}var dr=null,_o=0;function Ol(t){var n=_o;return _o+=1,dr===null&&(dr=[]),Rm(dr,t,n)}function yo(t,n){n=n.props.ref,t.ref=n!==void 0?n:null}function Pl(t,n){throw n.$$typeof===g?Error(s(525)):(t=Object.prototype.toString.call(n),Error(s(31,t==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":t)))}function Um(t){function n(ne,q){if(t){var ue=ne.deletions;ue===null?(ne.deletions=[q],ne.flags|=16):ue.push(q)}}function a(ne,q){if(!t)return null;for(;q!==null;)n(ne,q),q=q.sibling;return null}function o(ne){for(var q=new Map;ne!==null;)ne.key!==null?q.set(ne.key,ne):q.set(ne.index,ne),ne=ne.sibling;return q}function u(ne,q){return ne=la(ne,q),ne.index=0,ne.sibling=null,ne}function d(ne,q,ue){return ne.index=ue,t?(ue=ne.alternate,ue!==null?(ue=ue.index,ue<q?(ne.flags|=67108866,q):ue):(ne.flags|=67108866,q)):(ne.flags|=1048576,q)}function S(ne){return t&&ne.alternate===null&&(ne.flags|=67108866),ne}function D(ne,q,ue,we){return q===null||q.tag!==6?(q=Pu(ue,ne.mode,we),q.return=ne,q):(q=u(q,ue),q.return=ne,q)}function j(ne,q,ue,we){var pt=ue.type;return pt===R?Ee(ne,q,ue.props.children,we,ue.key):q!==null&&(q.elementType===pt||typeof pt=="object"&&pt!==null&&pt.$$typeof===T&&Rs(pt)===q.type)?(q=u(q,ue.props),yo(q,ue),q.return=ne,q):(q=wl(ue.type,ue.key,ue.props,null,ne.mode,we),yo(q,ue),q.return=ne,q)}function fe(ne,q,ue,we){return q===null||q.tag!==4||q.stateNode.containerInfo!==ue.containerInfo||q.stateNode.implementation!==ue.implementation?(q=Iu(ue,ne.mode,we),q.return=ne,q):(q=u(q,ue.children||[]),q.return=ne,q)}function Ee(ne,q,ue,we,pt){return q===null||q.tag!==7?(q=Es(ue,ne.mode,we,pt),q.return=ne,q):(q=u(q,ue),q.return=ne,q)}function Re(ne,q,ue){if(typeof q=="string"&&q!==""||typeof q=="number"||typeof q=="bigint")return q=Pu(""+q,ne.mode,ue),q.return=ne,q;if(typeof q=="object"&&q!==null){switch(q.$$typeof){case M:return ue=wl(q.type,q.key,q.props,null,ne.mode,ue),yo(ue,q),ue.return=ne,ue;case w:return q=Iu(q,ne.mode,ue),q.return=ne,q;case T:return q=Rs(q),Re(ne,q,ue)}if(te(q)||W(q))return q=Es(q,ne.mode,ue,null),q.return=ne,q;if(typeof q.then=="function")return Re(ne,Ol(q),ue);if(q.$$typeof===O)return Re(ne,Nl(ne,q),ue);Pl(ne,q)}return null}function ge(ne,q,ue,we){var pt=q!==null?q.key:null;if(typeof ue=="string"&&ue!==""||typeof ue=="number"||typeof ue=="bigint")return pt!==null?null:D(ne,q,""+ue,we);if(typeof ue=="object"&&ue!==null){switch(ue.$$typeof){case M:return ue.key===pt?j(ne,q,ue,we):null;case w:return ue.key===pt?fe(ne,q,ue,we):null;case T:return ue=Rs(ue),ge(ne,q,ue,we)}if(te(ue)||W(ue))return pt!==null?null:Ee(ne,q,ue,we,null);if(typeof ue.then=="function")return ge(ne,q,Ol(ue),we);if(ue.$$typeof===O)return ge(ne,q,Nl(ne,ue),we);Pl(ne,ue)}return null}function ve(ne,q,ue,we,pt){if(typeof we=="string"&&we!==""||typeof we=="number"||typeof we=="bigint")return ne=ne.get(ue)||null,D(q,ne,""+we,pt);if(typeof we=="object"&&we!==null){switch(we.$$typeof){case M:return ne=ne.get(we.key===null?ue:we.key)||null,j(q,ne,we,pt);case w:return ne=ne.get(we.key===null?ue:we.key)||null,fe(q,ne,we,pt);case T:return we=Rs(we),ve(ne,q,ue,we,pt)}if(te(we)||W(we))return ne=ne.get(ue)||null,Ee(q,ne,we,pt,null);if(typeof we.then=="function")return ve(ne,q,ue,Ol(we),pt);if(we.$$typeof===O)return ve(ne,q,ue,Nl(q,we),pt);Pl(q,we)}return null}function at(ne,q,ue,we){for(var pt=null,Ht=null,ot=q,Et=q=0,Lt=null;ot!==null&&Et<ue.length;Et++){ot.index>Et?(Lt=ot,ot=null):Lt=ot.sibling;var Vt=ge(ne,ot,ue[Et],we);if(Vt===null){ot===null&&(ot=Lt);break}t&&ot&&Vt.alternate===null&&n(ne,ot),q=d(Vt,q,Et),Ht===null?pt=Vt:Ht.sibling=Vt,Ht=Vt,ot=Lt}if(Et===ue.length)return a(ne,ot),Pt&&ca(ne,Et),pt;if(ot===null){for(;Et<ue.length;Et++)ot=Re(ne,ue[Et],we),ot!==null&&(q=d(ot,q,Et),Ht===null?pt=ot:Ht.sibling=ot,Ht=ot);return Pt&&ca(ne,Et),pt}for(ot=o(ot);Et<ue.length;Et++)Lt=ve(ot,ne,Et,ue[Et],we),Lt!==null&&(t&&Lt.alternate!==null&&ot.delete(Lt.key===null?Et:Lt.key),q=d(Lt,q,Et),Ht===null?pt=Lt:Ht.sibling=Lt,Ht=Lt);return t&&ot.forEach(function(ss){return n(ne,ss)}),Pt&&ca(ne,Et),pt}function mt(ne,q,ue,we){if(ue==null)throw Error(s(151));for(var pt=null,Ht=null,ot=q,Et=q=0,Lt=null,Vt=ue.next();ot!==null&&!Vt.done;Et++,Vt=ue.next()){ot.index>Et?(Lt=ot,ot=null):Lt=ot.sibling;var ss=ge(ne,ot,Vt.value,we);if(ss===null){ot===null&&(ot=Lt);break}t&&ot&&ss.alternate===null&&n(ne,ot),q=d(ss,q,Et),Ht===null?pt=ss:Ht.sibling=ss,Ht=ss,ot=Lt}if(Vt.done)return a(ne,ot),Pt&&ca(ne,Et),pt;if(ot===null){for(;!Vt.done;Et++,Vt=ue.next())Vt=Re(ne,Vt.value,we),Vt!==null&&(q=d(Vt,q,Et),Ht===null?pt=Vt:Ht.sibling=Vt,Ht=Vt);return Pt&&ca(ne,Et),pt}for(ot=o(ot);!Vt.done;Et++,Vt=ue.next())Vt=ve(ot,ne,Et,Vt.value,we),Vt!==null&&(t&&Vt.alternate!==null&&ot.delete(Vt.key===null?Et:Vt.key),q=d(Vt,q,Et),Ht===null?pt=Vt:Ht.sibling=Vt,Ht=Vt);return t&&ot.forEach(function(Pb){return n(ne,Pb)}),Pt&&ca(ne,Et),pt}function en(ne,q,ue,we){if(typeof ue=="object"&&ue!==null&&ue.type===R&&ue.key===null&&(ue=ue.props.children),typeof ue=="object"&&ue!==null){switch(ue.$$typeof){case M:e:{for(var pt=ue.key;q!==null;){if(q.key===pt){if(pt=ue.type,pt===R){if(q.tag===7){a(ne,q.sibling),we=u(q,ue.props.children),we.return=ne,ne=we;break e}}else if(q.elementType===pt||typeof pt=="object"&&pt!==null&&pt.$$typeof===T&&Rs(pt)===q.type){a(ne,q.sibling),we=u(q,ue.props),yo(we,ue),we.return=ne,ne=we;break e}a(ne,q);break}else n(ne,q);q=q.sibling}ue.type===R?(we=Es(ue.props.children,ne.mode,we,ue.key),we.return=ne,ne=we):(we=wl(ue.type,ue.key,ue.props,null,ne.mode,we),yo(we,ue),we.return=ne,ne=we)}return S(ne);case w:e:{for(pt=ue.key;q!==null;){if(q.key===pt)if(q.tag===4&&q.stateNode.containerInfo===ue.containerInfo&&q.stateNode.implementation===ue.implementation){a(ne,q.sibling),we=u(q,ue.children||[]),we.return=ne,ne=we;break e}else{a(ne,q);break}else n(ne,q);q=q.sibling}we=Iu(ue,ne.mode,we),we.return=ne,ne=we}return S(ne);case T:return ue=Rs(ue),en(ne,q,ue,we)}if(te(ue))return at(ne,q,ue,we);if(W(ue)){if(pt=W(ue),typeof pt!="function")throw Error(s(150));return ue=pt.call(ue),mt(ne,q,ue,we)}if(typeof ue.then=="function")return en(ne,q,Ol(ue),we);if(ue.$$typeof===O)return en(ne,q,Nl(ne,ue),we);Pl(ne,ue)}return typeof ue=="string"&&ue!==""||typeof ue=="number"||typeof ue=="bigint"?(ue=""+ue,q!==null&&q.tag===6?(a(ne,q.sibling),we=u(q,ue),we.return=ne,ne=we):(a(ne,q),we=Pu(ue,ne.mode,we),we.return=ne,ne=we),S(ne)):a(ne,q)}return function(ne,q,ue,we){try{_o=0;var pt=en(ne,q,ue,we);return dr=null,pt}catch(ot){if(ot===fr||ot===Ul)throw ot;var Ht=ci(29,ot,null,ne.mode);return Ht.lanes=we,Ht.return=ne,Ht}finally{}}}var Ds=Um(!0),Lm=Um(!1),Va=!1;function Yu(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Zu(t,n){t=t.updateQueue,n.updateQueue===t&&(n.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function ka(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function ja(t,n,a){var o=t.updateQueue;if(o===null)return null;if(o=o.shared,(kt&2)!==0){var u=o.pending;return u===null?n.next=n:(n.next=u.next,u.next=n),o.pending=n,n=Al(t),gm(t,null,a),n}return Tl(t,o,n,a),Al(t)}function bo(t,n,a){if(n=n.updateQueue,n!==null&&(n=n.shared,(a&4194048)!==0)){var o=n.lanes;o&=t.pendingLanes,a|=o,n.lanes=a,ai(t,a)}}function Ku(t,n){var a=t.updateQueue,o=t.alternate;if(o!==null&&(o=o.updateQueue,a===o)){var u=null,d=null;if(a=a.firstBaseUpdate,a!==null){do{var S={lane:a.lane,tag:a.tag,payload:a.payload,callback:null,next:null};d===null?u=d=S:d=d.next=S,a=a.next}while(a!==null);d===null?u=d=n:d=d.next=n}else u=d=n;a={baseState:o.baseState,firstBaseUpdate:u,lastBaseUpdate:d,shared:o.shared,callbacks:o.callbacks},t.updateQueue=a;return}t=a.lastBaseUpdate,t===null?a.firstBaseUpdate=n:t.next=n,a.lastBaseUpdate=n}var Qu=!1;function So(){if(Qu){var t=ur;if(t!==null)throw t}}function Mo(t,n,a,o){Qu=!1;var u=t.updateQueue;Va=!1;var d=u.firstBaseUpdate,S=u.lastBaseUpdate,D=u.shared.pending;if(D!==null){u.shared.pending=null;var j=D,fe=j.next;j.next=null,S===null?d=fe:S.next=fe,S=j;var Ee=t.alternate;Ee!==null&&(Ee=Ee.updateQueue,D=Ee.lastBaseUpdate,D!==S&&(D===null?Ee.firstBaseUpdate=fe:D.next=fe,Ee.lastBaseUpdate=j))}if(d!==null){var Re=u.baseState;S=0,Ee=fe=j=null,D=d;do{var ge=D.lane&-536870913,ve=ge!==D.lane;if(ve?(Ut&ge)===ge:(o&ge)===ge){ge!==0&&ge===cr&&(Qu=!0),Ee!==null&&(Ee=Ee.next={lane:0,tag:D.tag,payload:D.payload,callback:null,next:null});e:{var at=t,mt=D;ge=n;var en=a;switch(mt.tag){case 1:if(at=mt.payload,typeof at=="function"){Re=at.call(en,Re,ge);break e}Re=at;break e;case 3:at.flags=at.flags&-65537|128;case 0:if(at=mt.payload,ge=typeof at=="function"?at.call(en,Re,ge):at,ge==null)break e;Re=x({},Re,ge);break e;case 2:Va=!0}}ge=D.callback,ge!==null&&(t.flags|=64,ve&&(t.flags|=8192),ve=u.callbacks,ve===null?u.callbacks=[ge]:ve.push(ge))}else ve={lane:ge,tag:D.tag,payload:D.payload,callback:D.callback,next:null},Ee===null?(fe=Ee=ve,j=Re):Ee=Ee.next=ve,S|=ge;if(D=D.next,D===null){if(D=u.shared.pending,D===null)break;ve=D,D=ve.next,ve.next=null,u.lastBaseUpdate=ve,u.shared.pending=null}}while(!0);Ee===null&&(j=Re),u.baseState=j,u.firstBaseUpdate=fe,u.lastBaseUpdate=Ee,d===null&&(u.shared.lanes=0),Za|=S,t.lanes=S,t.memoizedState=Re}}function Om(t,n){if(typeof t!="function")throw Error(s(191,t));t.call(n)}function Pm(t,n){var a=t.callbacks;if(a!==null)for(t.callbacks=null,t=0;t<a.length;t++)Om(a[t],n)}var hr=E(null),Il=E(0);function Im(t,n){t=ya,ce(Il,t),ce(hr,n),ya=t|n.baseLanes}function Ju(){ce(Il,ya),ce(hr,hr.current)}function $u(){ya=Il.current,H(hr),H(Il)}var ui=E(null),Mi=null;function Xa(t){var n=t.alternate;ce(pn,pn.current&1),ce(ui,t),Mi===null&&(n===null||hr.current!==null||n.memoizedState!==null)&&(Mi=t)}function ef(t){ce(pn,pn.current),ce(ui,t),Mi===null&&(Mi=t)}function zm(t){t.tag===22?(ce(pn,pn.current),ce(ui,t),Mi===null&&(Mi=t)):Wa()}function Wa(){ce(pn,pn.current),ce(ui,ui.current)}function fi(t){H(ui),Mi===t&&(Mi=null),H(pn)}var pn=E(0);function zl(t){for(var n=t;n!==null;){if(n.tag===13){var a=n.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||od(a)||ld(a)))return n}else if(n.tag===19&&(n.memoizedProps.revealOrder==="forwards"||n.memoizedProps.revealOrder==="backwards"||n.memoizedProps.revealOrder==="unstable_legacy-backwards"||n.memoizedProps.revealOrder==="together")){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var da=0,bt=null,Jt=null,bn=null,Fl=!1,pr=!1,Us=!1,Bl=0,Eo=0,mr=null,Ty=0;function dn(){throw Error(s(321))}function tf(t,n){if(n===null)return!1;for(var a=0;a<n.length&&a<t.length;a++)if(!li(t[a],n[a]))return!1;return!0}function nf(t,n,a,o,u,d){return da=d,bt=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,G.H=t===null||t.memoizedState===null?y0:vf,Us=!1,d=a(o,u),Us=!1,pr&&(d=Bm(n,a,o,u)),Fm(t),d}function Fm(t){G.H=wo;var n=Jt!==null&&Jt.next!==null;if(da=0,bn=Jt=bt=null,Fl=!1,Eo=0,mr=null,n)throw Error(s(300));t===null||Sn||(t=t.dependencies,t!==null&&Rl(t)&&(Sn=!0))}function Bm(t,n,a,o){bt=t;var u=0;do{if(pr&&(mr=null),Eo=0,pr=!1,25<=u)throw Error(s(301));if(u+=1,bn=Jt=null,t.updateQueue!=null){var d=t.updateQueue;d.lastEffect=null,d.events=null,d.stores=null,d.memoCache!=null&&(d.memoCache.index=0)}G.H=b0,d=n(a,o)}while(pr);return d}function Ay(){var t=G.H,n=t.useState()[0];return n=typeof n.then=="function"?To(n):n,t=t.useState()[0],(Jt!==null?Jt.memoizedState:null)!==t&&(bt.flags|=1024),n}function af(){var t=Bl!==0;return Bl=0,t}function sf(t,n,a){n.updateQueue=t.updateQueue,n.flags&=-2053,t.lanes&=~a}function rf(t){if(Fl){for(t=t.memoizedState;t!==null;){var n=t.queue;n!==null&&(n.pending=null),t=t.next}Fl=!1}da=0,bn=Jt=bt=null,pr=!1,Eo=Bl=0,mr=null}function Xn(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return bn===null?bt.memoizedState=bn=t:bn=bn.next=t,bn}function mn(){if(Jt===null){var t=bt.alternate;t=t!==null?t.memoizedState:null}else t=Jt.next;var n=bn===null?bt.memoizedState:bn.next;if(n!==null)bn=n,Jt=t;else{if(t===null)throw bt.alternate===null?Error(s(467)):Error(s(310));Jt=t,t={memoizedState:Jt.memoizedState,baseState:Jt.baseState,baseQueue:Jt.baseQueue,queue:Jt.queue,next:null},bn===null?bt.memoizedState=bn=t:bn=bn.next=t}return bn}function Gl(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function To(t){var n=Eo;return Eo+=1,mr===null&&(mr=[]),t=Rm(mr,t,n),n=bt,(bn===null?n.memoizedState:bn.next)===null&&(n=n.alternate,G.H=n===null||n.memoizedState===null?y0:vf),t}function Hl(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return To(t);if(t.$$typeof===O)return On(t)}throw Error(s(438,String(t)))}function of(t){var n=null,a=bt.updateQueue;if(a!==null&&(n=a.memoCache),n==null){var o=bt.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(n={data:o.data.map(function(u){return u.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),a===null&&(a=Gl(),bt.updateQueue=a),a.memoCache=n,a=n.data[n.index],a===void 0)for(a=n.data[n.index]=Array(t),o=0;o<t;o++)a[o]=V;return n.index++,a}function ha(t,n){return typeof n=="function"?n(t):n}function Vl(t){var n=mn();return lf(n,Jt,t)}function lf(t,n,a){var o=t.queue;if(o===null)throw Error(s(311));o.lastRenderedReducer=a;var u=t.baseQueue,d=o.pending;if(d!==null){if(u!==null){var S=u.next;u.next=d.next,d.next=S}n.baseQueue=u=d,o.pending=null}if(d=t.baseState,u===null)t.memoizedState=d;else{n=u.next;var D=S=null,j=null,fe=n,Ee=!1;do{var Re=fe.lane&-536870913;if(Re!==fe.lane?(Ut&Re)===Re:(da&Re)===Re){var ge=fe.revertLane;if(ge===0)j!==null&&(j=j.next={lane:0,revertLane:0,gesture:null,action:fe.action,hasEagerState:fe.hasEagerState,eagerState:fe.eagerState,next:null}),Re===cr&&(Ee=!0);else if((da&ge)===ge){fe=fe.next,ge===cr&&(Ee=!0);continue}else Re={lane:0,revertLane:fe.revertLane,gesture:null,action:fe.action,hasEagerState:fe.hasEagerState,eagerState:fe.eagerState,next:null},j===null?(D=j=Re,S=d):j=j.next=Re,bt.lanes|=ge,Za|=ge;Re=fe.action,Us&&a(d,Re),d=fe.hasEagerState?fe.eagerState:a(d,Re)}else ge={lane:Re,revertLane:fe.revertLane,gesture:fe.gesture,action:fe.action,hasEagerState:fe.hasEagerState,eagerState:fe.eagerState,next:null},j===null?(D=j=ge,S=d):j=j.next=ge,bt.lanes|=Re,Za|=Re;fe=fe.next}while(fe!==null&&fe!==n);if(j===null?S=d:j.next=D,!li(d,t.memoizedState)&&(Sn=!0,Ee&&(a=ur,a!==null)))throw a;t.memoizedState=d,t.baseState=S,t.baseQueue=j,o.lastRenderedState=d}return u===null&&(o.lanes=0),[t.memoizedState,o.dispatch]}function cf(t){var n=mn(),a=n.queue;if(a===null)throw Error(s(311));a.lastRenderedReducer=t;var o=a.dispatch,u=a.pending,d=n.memoizedState;if(u!==null){a.pending=null;var S=u=u.next;do d=t(d,S.action),S=S.next;while(S!==u);li(d,n.memoizedState)||(Sn=!0),n.memoizedState=d,n.baseQueue===null&&(n.baseState=d),a.lastRenderedState=d}return[d,o]}function Gm(t,n,a){var o=bt,u=mn(),d=Pt;if(d){if(a===void 0)throw Error(s(407));a=a()}else a=n();var S=!li((Jt||u).memoizedState,a);if(S&&(u.memoizedState=a,Sn=!0),u=u.queue,df(km.bind(null,o,u,t),[t]),u.getSnapshot!==n||S||bn!==null&&bn.memoizedState.tag&1){if(o.flags|=2048,gr(9,{destroy:void 0},Vm.bind(null,o,u,a,n),null),nn===null)throw Error(s(349));d||(da&127)!==0||Hm(o,n,a)}return a}function Hm(t,n,a){t.flags|=16384,t={getSnapshot:n,value:a},n=bt.updateQueue,n===null?(n=Gl(),bt.updateQueue=n,n.stores=[t]):(a=n.stores,a===null?n.stores=[t]:a.push(t))}function Vm(t,n,a,o){n.value=a,n.getSnapshot=o,jm(n)&&Xm(t)}function km(t,n,a){return a(function(){jm(n)&&Xm(t)})}function jm(t){var n=t.getSnapshot;t=t.value;try{var a=n();return!li(t,a)}catch{return!0}}function Xm(t){var n=Ms(t,2);n!==null&&ti(n,t,2)}function uf(t){var n=Xn();if(typeof t=="function"){var a=t;if(t=a(),Us){ze(!0);try{a()}finally{ze(!1)}}}return n.memoizedState=n.baseState=t,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ha,lastRenderedState:t},n}function Wm(t,n,a,o){return t.baseState=a,lf(t,Jt,typeof o=="function"?o:ha)}function wy(t,n,a,o,u){if(Xl(t))throw Error(s(485));if(t=n.action,t!==null){var d={payload:u,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(S){d.listeners.push(S)}};G.T!==null?a(!0):d.isTransition=!1,o(d),a=n.pending,a===null?(d.next=n.pending=d,qm(n,d)):(d.next=a.next,n.pending=a.next=d)}}function qm(t,n){var a=n.action,o=n.payload,u=t.state;if(n.isTransition){var d=G.T,S={};G.T=S;try{var D=a(u,o),j=G.S;j!==null&&j(S,D),Ym(t,n,D)}catch(fe){ff(t,n,fe)}finally{d!==null&&S.types!==null&&(d.types=S.types),G.T=d}}else try{d=a(u,o),Ym(t,n,d)}catch(fe){ff(t,n,fe)}}function Ym(t,n,a){a!==null&&typeof a=="object"&&typeof a.then=="function"?a.then(function(o){Zm(t,n,o)},function(o){return ff(t,n,o)}):Zm(t,n,a)}function Zm(t,n,a){n.status="fulfilled",n.value=a,Km(n),t.state=a,n=t.pending,n!==null&&(a=n.next,a===n?t.pending=null:(a=a.next,n.next=a,qm(t,a)))}function ff(t,n,a){var o=t.pending;if(t.pending=null,o!==null){o=o.next;do n.status="rejected",n.reason=a,Km(n),n=n.next;while(n!==o)}t.action=null}function Km(t){t=t.listeners;for(var n=0;n<t.length;n++)(0,t[n])()}function Qm(t,n){return n}function Jm(t,n){if(Pt){var a=nn.formState;if(a!==null){e:{var o=bt;if(Pt){if(an){t:{for(var u=an,d=Si;u.nodeType!==8;){if(!d){u=null;break t}if(u=Ei(u.nextSibling),u===null){u=null;break t}}d=u.data,u=d==="F!"||d==="F"?u:null}if(u){an=Ei(u.nextSibling),o=u.data==="F!";break e}}Ga(o)}o=!1}o&&(n=a[0])}}return a=Xn(),a.memoizedState=a.baseState=n,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Qm,lastRenderedState:n},a.queue=o,a=x0.bind(null,bt,o),o.dispatch=a,o=uf(!1),d=xf.bind(null,bt,!1,o.queue),o=Xn(),u={state:n,dispatch:null,action:t,pending:null},o.queue=u,a=wy.bind(null,bt,u,d,a),u.dispatch=a,o.memoizedState=t,[n,a,!1]}function $m(t){var n=mn();return e0(n,Jt,t)}function e0(t,n,a){if(n=lf(t,n,Qm)[0],t=Vl(ha)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var o=To(n)}catch(S){throw S===fr?Ul:S}else o=n;n=mn();var u=n.queue,d=u.dispatch;return a!==n.memoizedState&&(bt.flags|=2048,gr(9,{destroy:void 0},Cy.bind(null,u,a),null)),[o,d,t]}function Cy(t,n){t.action=n}function t0(t){var n=mn(),a=Jt;if(a!==null)return e0(n,a,t);mn(),n=n.memoizedState,a=mn();var o=a.queue.dispatch;return a.memoizedState=t,[n,o,!1]}function gr(t,n,a,o){return t={tag:t,create:a,deps:o,inst:n,next:null},n=bt.updateQueue,n===null&&(n=Gl(),bt.updateQueue=n),a=n.lastEffect,a===null?n.lastEffect=t.next=t:(o=a.next,a.next=t,t.next=o,n.lastEffect=t),t}function n0(){return mn().memoizedState}function kl(t,n,a,o){var u=Xn();bt.flags|=t,u.memoizedState=gr(1|n,{destroy:void 0},a,o===void 0?null:o)}function jl(t,n,a,o){var u=mn();o=o===void 0?null:o;var d=u.memoizedState.inst;Jt!==null&&o!==null&&tf(o,Jt.memoizedState.deps)?u.memoizedState=gr(n,d,a,o):(bt.flags|=t,u.memoizedState=gr(1|n,d,a,o))}function i0(t,n){kl(8390656,8,t,n)}function df(t,n){jl(2048,8,t,n)}function Ry(t){bt.flags|=4;var n=bt.updateQueue;if(n===null)n=Gl(),bt.updateQueue=n,n.events=[t];else{var a=n.events;a===null?n.events=[t]:a.push(t)}}function a0(t){var n=mn().memoizedState;return Ry({ref:n,nextImpl:t}),function(){if((kt&2)!==0)throw Error(s(440));return n.impl.apply(void 0,arguments)}}function s0(t,n){return jl(4,2,t,n)}function r0(t,n){return jl(4,4,t,n)}function o0(t,n){if(typeof n=="function"){t=t();var a=n(t);return function(){typeof a=="function"?a():n(null)}}if(n!=null)return t=t(),n.current=t,function(){n.current=null}}function l0(t,n,a){a=a!=null?a.concat([t]):null,jl(4,4,o0.bind(null,n,t),a)}function hf(){}function c0(t,n){var a=mn();n=n===void 0?null:n;var o=a.memoizedState;return n!==null&&tf(n,o[1])?o[0]:(a.memoizedState=[t,n],t)}function u0(t,n){var a=mn();n=n===void 0?null:n;var o=a.memoizedState;if(n!==null&&tf(n,o[1]))return o[0];if(o=t(),Us){ze(!0);try{t()}finally{ze(!1)}}return a.memoizedState=[o,n],o}function pf(t,n,a){return a===void 0||(da&1073741824)!==0&&(Ut&261930)===0?t.memoizedState=n:(t.memoizedState=a,t=fg(),bt.lanes|=t,Za|=t,a)}function f0(t,n,a,o){return li(a,n)?a:hr.current!==null?(t=pf(t,a,o),li(t,n)||(Sn=!0),t):(da&42)===0||(da&1073741824)!==0&&(Ut&261930)===0?(Sn=!0,t.memoizedState=a):(t=fg(),bt.lanes|=t,Za|=t,n)}function d0(t,n,a,o,u){var d=X.p;X.p=d!==0&&8>d?d:8;var S=G.T,D={};G.T=D,xf(t,!1,n,a);try{var j=u(),fe=G.S;if(fe!==null&&fe(D,j),j!==null&&typeof j=="object"&&typeof j.then=="function"){var Ee=Ey(j,o);Ao(t,n,Ee,pi(t))}else Ao(t,n,o,pi(t))}catch(Re){Ao(t,n,{then:function(){},status:"rejected",reason:Re},pi())}finally{X.p=d,S!==null&&D.types!==null&&(S.types=D.types),G.T=S}}function Ny(){}function mf(t,n,a,o){if(t.tag!==5)throw Error(s(476));var u=h0(t).queue;d0(t,u,n,$,a===null?Ny:function(){return p0(t),a(o)})}function h0(t){var n=t.memoizedState;if(n!==null)return n;n={memoizedState:$,baseState:$,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ha,lastRenderedState:$},next:null};var a={};return n.next={memoizedState:a,baseState:a,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ha,lastRenderedState:a},next:null},t.memoizedState=n,t=t.alternate,t!==null&&(t.memoizedState=n),n}function p0(t){var n=h0(t);n.next===null&&(n=t.alternate.memoizedState),Ao(t,n.next.queue,{},pi())}function gf(){return On(ko)}function m0(){return mn().memoizedState}function g0(){return mn().memoizedState}function Dy(t){for(var n=t.return;n!==null;){switch(n.tag){case 24:case 3:var a=pi();t=ka(a);var o=ja(n,t,a);o!==null&&(ti(o,n,a),bo(o,n,a)),n={cache:ju()},t.payload=n;return}n=n.return}}function Uy(t,n,a){var o=pi();a={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},Xl(t)?v0(n,a):(a=Lu(t,n,a,o),a!==null&&(ti(a,t,o),_0(a,n,o)))}function x0(t,n,a){var o=pi();Ao(t,n,a,o)}function Ao(t,n,a,o){var u={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null};if(Xl(t))v0(n,u);else{var d=t.alternate;if(t.lanes===0&&(d===null||d.lanes===0)&&(d=n.lastRenderedReducer,d!==null))try{var S=n.lastRenderedState,D=d(S,a);if(u.hasEagerState=!0,u.eagerState=D,li(D,S))return Tl(t,n,u,0),nn===null&&El(),!1}catch{}finally{}if(a=Lu(t,n,u,o),a!==null)return ti(a,t,o),_0(a,n,o),!0}return!1}function xf(t,n,a,o){if(o={lane:2,revertLane:Zf(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Xl(t)){if(n)throw Error(s(479))}else n=Lu(t,a,o,2),n!==null&&ti(n,t,2)}function Xl(t){var n=t.alternate;return t===bt||n!==null&&n===bt}function v0(t,n){pr=Fl=!0;var a=t.pending;a===null?n.next=n:(n.next=a.next,a.next=n),t.pending=n}function _0(t,n,a){if((a&4194048)!==0){var o=n.lanes;o&=t.pendingLanes,a|=o,n.lanes=a,ai(t,a)}}var wo={readContext:On,use:Hl,useCallback:dn,useContext:dn,useEffect:dn,useImperativeHandle:dn,useLayoutEffect:dn,useInsertionEffect:dn,useMemo:dn,useReducer:dn,useRef:dn,useState:dn,useDebugValue:dn,useDeferredValue:dn,useTransition:dn,useSyncExternalStore:dn,useId:dn,useHostTransitionStatus:dn,useFormState:dn,useActionState:dn,useOptimistic:dn,useMemoCache:dn,useCacheRefresh:dn};wo.useEffectEvent=dn;var y0={readContext:On,use:Hl,useCallback:function(t,n){return Xn().memoizedState=[t,n===void 0?null:n],t},useContext:On,useEffect:i0,useImperativeHandle:function(t,n,a){a=a!=null?a.concat([t]):null,kl(4194308,4,o0.bind(null,n,t),a)},useLayoutEffect:function(t,n){return kl(4194308,4,t,n)},useInsertionEffect:function(t,n){kl(4,2,t,n)},useMemo:function(t,n){var a=Xn();n=n===void 0?null:n;var o=t();if(Us){ze(!0);try{t()}finally{ze(!1)}}return a.memoizedState=[o,n],o},useReducer:function(t,n,a){var o=Xn();if(a!==void 0){var u=a(n);if(Us){ze(!0);try{a(n)}finally{ze(!1)}}}else u=n;return o.memoizedState=o.baseState=u,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:u},o.queue=t,t=t.dispatch=Uy.bind(null,bt,t),[o.memoizedState,t]},useRef:function(t){var n=Xn();return t={current:t},n.memoizedState=t},useState:function(t){t=uf(t);var n=t.queue,a=x0.bind(null,bt,n);return n.dispatch=a,[t.memoizedState,a]},useDebugValue:hf,useDeferredValue:function(t,n){var a=Xn();return pf(a,t,n)},useTransition:function(){var t=uf(!1);return t=d0.bind(null,bt,t.queue,!0,!1),Xn().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,n,a){var o=bt,u=Xn();if(Pt){if(a===void 0)throw Error(s(407));a=a()}else{if(a=n(),nn===null)throw Error(s(349));(Ut&127)!==0||Hm(o,n,a)}u.memoizedState=a;var d={value:a,getSnapshot:n};return u.queue=d,i0(km.bind(null,o,d,t),[t]),o.flags|=2048,gr(9,{destroy:void 0},Vm.bind(null,o,d,a,n),null),a},useId:function(){var t=Xn(),n=nn.identifierPrefix;if(Pt){var a=Xi,o=ji;a=(o&~(1<<32-Ze(o)-1)).toString(32)+a,n="_"+n+"R_"+a,a=Bl++,0<a&&(n+="H"+a.toString(32)),n+="_"}else a=Ty++,n="_"+n+"r_"+a.toString(32)+"_";return t.memoizedState=n},useHostTransitionStatus:gf,useFormState:Jm,useActionState:Jm,useOptimistic:function(t){var n=Xn();n.memoizedState=n.baseState=t;var a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=a,n=xf.bind(null,bt,!0,a),a.dispatch=n,[t,n]},useMemoCache:of,useCacheRefresh:function(){return Xn().memoizedState=Dy.bind(null,bt)},useEffectEvent:function(t){var n=Xn(),a={impl:t};return n.memoizedState=a,function(){if((kt&2)!==0)throw Error(s(440));return a.impl.apply(void 0,arguments)}}},vf={readContext:On,use:Hl,useCallback:c0,useContext:On,useEffect:df,useImperativeHandle:l0,useInsertionEffect:s0,useLayoutEffect:r0,useMemo:u0,useReducer:Vl,useRef:n0,useState:function(){return Vl(ha)},useDebugValue:hf,useDeferredValue:function(t,n){var a=mn();return f0(a,Jt.memoizedState,t,n)},useTransition:function(){var t=Vl(ha)[0],n=mn().memoizedState;return[typeof t=="boolean"?t:To(t),n]},useSyncExternalStore:Gm,useId:m0,useHostTransitionStatus:gf,useFormState:$m,useActionState:$m,useOptimistic:function(t,n){var a=mn();return Wm(a,Jt,t,n)},useMemoCache:of,useCacheRefresh:g0};vf.useEffectEvent=a0;var b0={readContext:On,use:Hl,useCallback:c0,useContext:On,useEffect:df,useImperativeHandle:l0,useInsertionEffect:s0,useLayoutEffect:r0,useMemo:u0,useReducer:cf,useRef:n0,useState:function(){return cf(ha)},useDebugValue:hf,useDeferredValue:function(t,n){var a=mn();return Jt===null?pf(a,t,n):f0(a,Jt.memoizedState,t,n)},useTransition:function(){var t=cf(ha)[0],n=mn().memoizedState;return[typeof t=="boolean"?t:To(t),n]},useSyncExternalStore:Gm,useId:m0,useHostTransitionStatus:gf,useFormState:t0,useActionState:t0,useOptimistic:function(t,n){var a=mn();return Jt!==null?Wm(a,Jt,t,n):(a.baseState=t,[t,a.queue.dispatch])},useMemoCache:of,useCacheRefresh:g0};b0.useEffectEvent=a0;function _f(t,n,a,o){n=t.memoizedState,a=a(o,n),a=a==null?n:x({},n,a),t.memoizedState=a,t.lanes===0&&(t.updateQueue.baseState=a)}var yf={enqueueSetState:function(t,n,a){t=t._reactInternals;var o=pi(),u=ka(o);u.payload=n,a!=null&&(u.callback=a),n=ja(t,u,o),n!==null&&(ti(n,t,o),bo(n,t,o))},enqueueReplaceState:function(t,n,a){t=t._reactInternals;var o=pi(),u=ka(o);u.tag=1,u.payload=n,a!=null&&(u.callback=a),n=ja(t,u,o),n!==null&&(ti(n,t,o),bo(n,t,o))},enqueueForceUpdate:function(t,n){t=t._reactInternals;var a=pi(),o=ka(a);o.tag=2,n!=null&&(o.callback=n),n=ja(t,o,a),n!==null&&(ti(n,t,a),bo(n,t,a))}};function S0(t,n,a,o,u,d,S){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(o,d,S):n.prototype&&n.prototype.isPureReactComponent?!ho(a,o)||!ho(u,d):!0}function M0(t,n,a,o){t=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(a,o),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(a,o),n.state!==t&&yf.enqueueReplaceState(n,n.state,null)}function Ls(t,n){var a=n;if("ref"in n){a={};for(var o in n)o!=="ref"&&(a[o]=n[o])}if(t=t.defaultProps){a===n&&(a=x({},a));for(var u in t)a[u]===void 0&&(a[u]=t[u])}return a}function E0(t){Ml(t)}function T0(t){console.error(t)}function A0(t){Ml(t)}function Wl(t,n){try{var a=t.onUncaughtError;a(n.value,{componentStack:n.stack})}catch(o){setTimeout(function(){throw o})}}function w0(t,n,a){try{var o=t.onCaughtError;o(a.value,{componentStack:a.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function bf(t,n,a){return a=ka(a),a.tag=3,a.payload={element:null},a.callback=function(){Wl(t,n)},a}function C0(t){return t=ka(t),t.tag=3,t}function R0(t,n,a,o){var u=a.type.getDerivedStateFromError;if(typeof u=="function"){var d=o.value;t.payload=function(){return u(d)},t.callback=function(){w0(n,a,o)}}var S=a.stateNode;S!==null&&typeof S.componentDidCatch=="function"&&(t.callback=function(){w0(n,a,o),typeof u!="function"&&(Ka===null?Ka=new Set([this]):Ka.add(this));var D=o.stack;this.componentDidCatch(o.value,{componentStack:D!==null?D:""})})}function Ly(t,n,a,o,u){if(a.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(n=a.alternate,n!==null&&lr(n,a,u,!0),a=ui.current,a!==null){switch(a.tag){case 31:case 13:return Mi===null?ac():a.alternate===null&&hn===0&&(hn=3),a.flags&=-257,a.flags|=65536,a.lanes=u,o===Ll?a.flags|=16384:(n=a.updateQueue,n===null?a.updateQueue=new Set([o]):n.add(o),Wf(t,o,u)),!1;case 22:return a.flags|=65536,o===Ll?a.flags|=16384:(n=a.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([o])},a.updateQueue=n):(a=n.retryQueue,a===null?n.retryQueue=new Set([o]):a.add(o)),Wf(t,o,u)),!1}throw Error(s(435,a.tag))}return Wf(t,o,u),ac(),!1}if(Pt)return n=ui.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=u,o!==Bu&&(t=Error(s(422),{cause:o}),go(_i(t,a)))):(o!==Bu&&(n=Error(s(423),{cause:o}),go(_i(n,a))),t=t.current.alternate,t.flags|=65536,u&=-u,t.lanes|=u,o=_i(o,a),u=bf(t.stateNode,o,u),Ku(t,u),hn!==4&&(hn=2)),!1;var d=Error(s(520),{cause:o});if(d=_i(d,a),Po===null?Po=[d]:Po.push(d),hn!==4&&(hn=2),n===null)return!0;o=_i(o,a),a=n;do{switch(a.tag){case 3:return a.flags|=65536,t=u&-u,a.lanes|=t,t=bf(a.stateNode,o,t),Ku(a,t),!1;case 1:if(n=a.type,d=a.stateNode,(a.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||d!==null&&typeof d.componentDidCatch=="function"&&(Ka===null||!Ka.has(d))))return a.flags|=65536,u&=-u,a.lanes|=u,u=C0(u),R0(u,t,a,o),Ku(a,u),!1}a=a.return}while(a!==null);return!1}var Sf=Error(s(461)),Sn=!1;function Pn(t,n,a,o){n.child=t===null?Lm(n,null,a,o):Ds(n,t.child,a,o)}function N0(t,n,a,o,u){a=a.render;var d=n.ref;if("ref"in o){var S={};for(var D in o)D!=="ref"&&(S[D]=o[D])}else S=o;return ws(n),o=nf(t,n,a,S,d,u),D=af(),t!==null&&!Sn?(sf(t,n,u),pa(t,n,u)):(Pt&&D&&zu(n),n.flags|=1,Pn(t,n,o,u),n.child)}function D0(t,n,a,o,u){if(t===null){var d=a.type;return typeof d=="function"&&!Ou(d)&&d.defaultProps===void 0&&a.compare===null?(n.tag=15,n.type=d,U0(t,n,d,o,u)):(t=wl(a.type,null,o,n,n.mode,u),t.ref=n.ref,t.return=n,n.child=t)}if(d=t.child,!Nf(t,u)){var S=d.memoizedProps;if(a=a.compare,a=a!==null?a:ho,a(S,o)&&t.ref===n.ref)return pa(t,n,u)}return n.flags|=1,t=la(d,o),t.ref=n.ref,t.return=n,n.child=t}function U0(t,n,a,o,u){if(t!==null){var d=t.memoizedProps;if(ho(d,o)&&t.ref===n.ref)if(Sn=!1,n.pendingProps=o=d,Nf(t,u))(t.flags&131072)!==0&&(Sn=!0);else return n.lanes=t.lanes,pa(t,n,u)}return Mf(t,n,a,o,u)}function L0(t,n,a,o){var u=o.children,d=t!==null?t.memoizedState:null;if(t===null&&n.stateNode===null&&(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((n.flags&128)!==0){if(d=d!==null?d.baseLanes|a:a,t!==null){for(o=n.child=t.child,u=0;o!==null;)u=u|o.lanes|o.childLanes,o=o.sibling;o=u&~d}else o=0,n.child=null;return O0(t,n,d,a,o)}if((a&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},t!==null&&Dl(n,d!==null?d.cachePool:null),d!==null?Im(n,d):Ju(),zm(n);else return o=n.lanes=536870912,O0(t,n,d!==null?d.baseLanes|a:a,a,o)}else d!==null?(Dl(n,d.cachePool),Im(n,d),Wa(),n.memoizedState=null):(t!==null&&Dl(n,null),Ju(),Wa());return Pn(t,n,u,a),n.child}function Co(t,n){return t!==null&&t.tag===22||n.stateNode!==null||(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.sibling}function O0(t,n,a,o,u){var d=Wu();return d=d===null?null:{parent:yn._currentValue,pool:d},n.memoizedState={baseLanes:a,cachePool:d},t!==null&&Dl(n,null),Ju(),zm(n),t!==null&&lr(t,n,o,!0),n.childLanes=u,null}function ql(t,n){return n=Zl({mode:n.mode,children:n.children},t.mode),n.ref=t.ref,t.child=n,n.return=t,n}function P0(t,n,a){return Ds(n,t.child,null,a),t=ql(n,n.pendingProps),t.flags|=2,fi(n),n.memoizedState=null,t}function Oy(t,n,a){var o=n.pendingProps,u=(n.flags&128)!==0;if(n.flags&=-129,t===null){if(Pt){if(o.mode==="hidden")return t=ql(n,o),n.lanes=536870912,Co(null,t);if(ef(n),(t=an)?(t=qg(t,Si),t=t!==null&&t.data==="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:Fa!==null?{id:ji,overflow:Xi}:null,retryLane:536870912,hydrationErrors:null},a=vm(t),a.return=n,n.child=a,Ln=n,an=null)):t=null,t===null)throw Ga(n);return n.lanes=536870912,null}return ql(n,o)}var d=t.memoizedState;if(d!==null){var S=d.dehydrated;if(ef(n),u)if(n.flags&256)n.flags&=-257,n=P0(t,n,a);else if(n.memoizedState!==null)n.child=t.child,n.flags|=128,n=null;else throw Error(s(558));else if(Sn||lr(t,n,a,!1),u=(a&t.childLanes)!==0,Sn||u){if(o=nn,o!==null&&(S=si(o,a),S!==0&&S!==d.retryLane))throw d.retryLane=S,Ms(t,S),ti(o,t,S),Sf;ac(),n=P0(t,n,a)}else t=d.treeContext,an=Ei(S.nextSibling),Ln=n,Pt=!0,Ba=null,Si=!1,t!==null&&bm(n,t),n=ql(n,o),n.flags|=4096;return n}return t=la(t.child,{mode:o.mode,children:o.children}),t.ref=n.ref,n.child=t,t.return=n,t}function Yl(t,n){var a=n.ref;if(a===null)t!==null&&t.ref!==null&&(n.flags|=4194816);else{if(typeof a!="function"&&typeof a!="object")throw Error(s(284));(t===null||t.ref!==a)&&(n.flags|=4194816)}}function Mf(t,n,a,o,u){return ws(n),a=nf(t,n,a,o,void 0,u),o=af(),t!==null&&!Sn?(sf(t,n,u),pa(t,n,u)):(Pt&&o&&zu(n),n.flags|=1,Pn(t,n,a,u),n.child)}function I0(t,n,a,o,u,d){return ws(n),n.updateQueue=null,a=Bm(n,o,a,u),Fm(t),o=af(),t!==null&&!Sn?(sf(t,n,d),pa(t,n,d)):(Pt&&o&&zu(n),n.flags|=1,Pn(t,n,a,d),n.child)}function z0(t,n,a,o,u){if(ws(n),n.stateNode===null){var d=ar,S=a.contextType;typeof S=="object"&&S!==null&&(d=On(S)),d=new a(o,d),n.memoizedState=d.state!==null&&d.state!==void 0?d.state:null,d.updater=yf,n.stateNode=d,d._reactInternals=n,d=n.stateNode,d.props=o,d.state=n.memoizedState,d.refs={},Yu(n),S=a.contextType,d.context=typeof S=="object"&&S!==null?On(S):ar,d.state=n.memoizedState,S=a.getDerivedStateFromProps,typeof S=="function"&&(_f(n,a,S,o),d.state=n.memoizedState),typeof a.getDerivedStateFromProps=="function"||typeof d.getSnapshotBeforeUpdate=="function"||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(S=d.state,typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount(),S!==d.state&&yf.enqueueReplaceState(d,d.state,null),Mo(n,o,d,u),So(),d.state=n.memoizedState),typeof d.componentDidMount=="function"&&(n.flags|=4194308),o=!0}else if(t===null){d=n.stateNode;var D=n.memoizedProps,j=Ls(a,D);d.props=j;var fe=d.context,Ee=a.contextType;S=ar,typeof Ee=="object"&&Ee!==null&&(S=On(Ee));var Re=a.getDerivedStateFromProps;Ee=typeof Re=="function"||typeof d.getSnapshotBeforeUpdate=="function",D=n.pendingProps!==D,Ee||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(D||fe!==S)&&M0(n,d,o,S),Va=!1;var ge=n.memoizedState;d.state=ge,Mo(n,o,d,u),So(),fe=n.memoizedState,D||ge!==fe||Va?(typeof Re=="function"&&(_f(n,a,Re,o),fe=n.memoizedState),(j=Va||S0(n,a,j,o,ge,fe,S))?(Ee||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount()),typeof d.componentDidMount=="function"&&(n.flags|=4194308)):(typeof d.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=o,n.memoizedState=fe),d.props=o,d.state=fe,d.context=S,o=j):(typeof d.componentDidMount=="function"&&(n.flags|=4194308),o=!1)}else{d=n.stateNode,Zu(t,n),S=n.memoizedProps,Ee=Ls(a,S),d.props=Ee,Re=n.pendingProps,ge=d.context,fe=a.contextType,j=ar,typeof fe=="object"&&fe!==null&&(j=On(fe)),D=a.getDerivedStateFromProps,(fe=typeof D=="function"||typeof d.getSnapshotBeforeUpdate=="function")||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(S!==Re||ge!==j)&&M0(n,d,o,j),Va=!1,ge=n.memoizedState,d.state=ge,Mo(n,o,d,u),So();var ve=n.memoizedState;S!==Re||ge!==ve||Va||t!==null&&t.dependencies!==null&&Rl(t.dependencies)?(typeof D=="function"&&(_f(n,a,D,o),ve=n.memoizedState),(Ee=Va||S0(n,a,Ee,o,ge,ve,j)||t!==null&&t.dependencies!==null&&Rl(t.dependencies))?(fe||typeof d.UNSAFE_componentWillUpdate!="function"&&typeof d.componentWillUpdate!="function"||(typeof d.componentWillUpdate=="function"&&d.componentWillUpdate(o,ve,j),typeof d.UNSAFE_componentWillUpdate=="function"&&d.UNSAFE_componentWillUpdate(o,ve,j)),typeof d.componentDidUpdate=="function"&&(n.flags|=4),typeof d.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof d.componentDidUpdate!="function"||S===t.memoizedProps&&ge===t.memoizedState||(n.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||S===t.memoizedProps&&ge===t.memoizedState||(n.flags|=1024),n.memoizedProps=o,n.memoizedState=ve),d.props=o,d.state=ve,d.context=j,o=Ee):(typeof d.componentDidUpdate!="function"||S===t.memoizedProps&&ge===t.memoizedState||(n.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||S===t.memoizedProps&&ge===t.memoizedState||(n.flags|=1024),o=!1)}return d=o,Yl(t,n),o=(n.flags&128)!==0,d||o?(d=n.stateNode,a=o&&typeof a.getDerivedStateFromError!="function"?null:d.render(),n.flags|=1,t!==null&&o?(n.child=Ds(n,t.child,null,u),n.child=Ds(n,null,a,u)):Pn(t,n,a,u),n.memoizedState=d.state,t=n.child):t=pa(t,n,u),t}function F0(t,n,a,o){return Ts(),n.flags|=256,Pn(t,n,a,o),n.child}var Ef={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Tf(t){return{baseLanes:t,cachePool:wm()}}function Af(t,n,a){return t=t!==null?t.childLanes&~a:0,n&&(t|=hi),t}function B0(t,n,a){var o=n.pendingProps,u=!1,d=(n.flags&128)!==0,S;if((S=d)||(S=t!==null&&t.memoizedState===null?!1:(pn.current&2)!==0),S&&(u=!0,n.flags&=-129),S=(n.flags&32)!==0,n.flags&=-33,t===null){if(Pt){if(u?Xa(n):Wa(),(t=an)?(t=qg(t,Si),t=t!==null&&t.data!=="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:Fa!==null?{id:ji,overflow:Xi}:null,retryLane:536870912,hydrationErrors:null},a=vm(t),a.return=n,n.child=a,Ln=n,an=null)):t=null,t===null)throw Ga(n);return ld(t)?n.lanes=32:n.lanes=536870912,null}var D=o.children;return o=o.fallback,u?(Wa(),u=n.mode,D=Zl({mode:"hidden",children:D},u),o=Es(o,u,a,null),D.return=n,o.return=n,D.sibling=o,n.child=D,o=n.child,o.memoizedState=Tf(a),o.childLanes=Af(t,S,a),n.memoizedState=Ef,Co(null,o)):(Xa(n),wf(n,D))}var j=t.memoizedState;if(j!==null&&(D=j.dehydrated,D!==null)){if(d)n.flags&256?(Xa(n),n.flags&=-257,n=Cf(t,n,a)):n.memoizedState!==null?(Wa(),n.child=t.child,n.flags|=128,n=null):(Wa(),D=o.fallback,u=n.mode,o=Zl({mode:"visible",children:o.children},u),D=Es(D,u,a,null),D.flags|=2,o.return=n,D.return=n,o.sibling=D,n.child=o,Ds(n,t.child,null,a),o=n.child,o.memoizedState=Tf(a),o.childLanes=Af(t,S,a),n.memoizedState=Ef,n=Co(null,o));else if(Xa(n),ld(D)){if(S=D.nextSibling&&D.nextSibling.dataset,S)var fe=S.dgst;S=fe,o=Error(s(419)),o.stack="",o.digest=S,go({value:o,source:null,stack:null}),n=Cf(t,n,a)}else if(Sn||lr(t,n,a,!1),S=(a&t.childLanes)!==0,Sn||S){if(S=nn,S!==null&&(o=si(S,a),o!==0&&o!==j.retryLane))throw j.retryLane=o,Ms(t,o),ti(S,t,o),Sf;od(D)||ac(),n=Cf(t,n,a)}else od(D)?(n.flags|=192,n.child=t.child,n=null):(t=j.treeContext,an=Ei(D.nextSibling),Ln=n,Pt=!0,Ba=null,Si=!1,t!==null&&bm(n,t),n=wf(n,o.children),n.flags|=4096);return n}return u?(Wa(),D=o.fallback,u=n.mode,j=t.child,fe=j.sibling,o=la(j,{mode:"hidden",children:o.children}),o.subtreeFlags=j.subtreeFlags&65011712,fe!==null?D=la(fe,D):(D=Es(D,u,a,null),D.flags|=2),D.return=n,o.return=n,o.sibling=D,n.child=o,Co(null,o),o=n.child,D=t.child.memoizedState,D===null?D=Tf(a):(u=D.cachePool,u!==null?(j=yn._currentValue,u=u.parent!==j?{parent:j,pool:j}:u):u=wm(),D={baseLanes:D.baseLanes|a,cachePool:u}),o.memoizedState=D,o.childLanes=Af(t,S,a),n.memoizedState=Ef,Co(t.child,o)):(Xa(n),a=t.child,t=a.sibling,a=la(a,{mode:"visible",children:o.children}),a.return=n,a.sibling=null,t!==null&&(S=n.deletions,S===null?(n.deletions=[t],n.flags|=16):S.push(t)),n.child=a,n.memoizedState=null,a)}function wf(t,n){return n=Zl({mode:"visible",children:n},t.mode),n.return=t,t.child=n}function Zl(t,n){return t=ci(22,t,null,n),t.lanes=0,t}function Cf(t,n,a){return Ds(n,t.child,null,a),t=wf(n,n.pendingProps.children),t.flags|=2,n.memoizedState=null,t}function G0(t,n,a){t.lanes|=n;var o=t.alternate;o!==null&&(o.lanes|=n),Vu(t.return,n,a)}function Rf(t,n,a,o,u,d){var S=t.memoizedState;S===null?t.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:o,tail:a,tailMode:u,treeForkCount:d}:(S.isBackwards=n,S.rendering=null,S.renderingStartTime=0,S.last=o,S.tail=a,S.tailMode=u,S.treeForkCount=d)}function H0(t,n,a){var o=n.pendingProps,u=o.revealOrder,d=o.tail;o=o.children;var S=pn.current,D=(S&2)!==0;if(D?(S=S&1|2,n.flags|=128):S&=1,ce(pn,S),Pn(t,n,o,a),o=Pt?mo:0,!D&&t!==null&&(t.flags&128)!==0)e:for(t=n.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&G0(t,a,n);else if(t.tag===19)G0(t,a,n);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===n)break e;for(;t.sibling===null;){if(t.return===null||t.return===n)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(u){case"forwards":for(a=n.child,u=null;a!==null;)t=a.alternate,t!==null&&zl(t)===null&&(u=a),a=a.sibling;a=u,a===null?(u=n.child,n.child=null):(u=a.sibling,a.sibling=null),Rf(n,!1,u,a,d,o);break;case"backwards":case"unstable_legacy-backwards":for(a=null,u=n.child,n.child=null;u!==null;){if(t=u.alternate,t!==null&&zl(t)===null){n.child=u;break}t=u.sibling,u.sibling=a,a=u,u=t}Rf(n,!0,a,null,d,o);break;case"together":Rf(n,!1,null,null,void 0,o);break;default:n.memoizedState=null}return n.child}function pa(t,n,a){if(t!==null&&(n.dependencies=t.dependencies),Za|=n.lanes,(a&n.childLanes)===0)if(t!==null){if(lr(t,n,a,!1),(a&n.childLanes)===0)return null}else return null;if(t!==null&&n.child!==t.child)throw Error(s(153));if(n.child!==null){for(t=n.child,a=la(t,t.pendingProps),n.child=a,a.return=n;t.sibling!==null;)t=t.sibling,a=a.sibling=la(t,t.pendingProps),a.return=n;a.sibling=null}return n.child}function Nf(t,n){return(t.lanes&n)!==0?!0:(t=t.dependencies,!!(t!==null&&Rl(t)))}function Py(t,n,a){switch(n.tag){case 3:xe(n,n.stateNode.containerInfo),Ha(n,yn,t.memoizedState.cache),Ts();break;case 27:case 5:Q(n);break;case 4:xe(n,n.stateNode.containerInfo);break;case 10:Ha(n,n.type,n.memoizedProps.value);break;case 31:if(n.memoizedState!==null)return n.flags|=128,ef(n),null;break;case 13:var o=n.memoizedState;if(o!==null)return o.dehydrated!==null?(Xa(n),n.flags|=128,null):(a&n.child.childLanes)!==0?B0(t,n,a):(Xa(n),t=pa(t,n,a),t!==null?t.sibling:null);Xa(n);break;case 19:var u=(t.flags&128)!==0;if(o=(a&n.childLanes)!==0,o||(lr(t,n,a,!1),o=(a&n.childLanes)!==0),u){if(o)return H0(t,n,a);n.flags|=128}if(u=n.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),ce(pn,pn.current),o)break;return null;case 22:return n.lanes=0,L0(t,n,a,n.pendingProps);case 24:Ha(n,yn,t.memoizedState.cache)}return pa(t,n,a)}function V0(t,n,a){if(t!==null)if(t.memoizedProps!==n.pendingProps)Sn=!0;else{if(!Nf(t,a)&&(n.flags&128)===0)return Sn=!1,Py(t,n,a);Sn=(t.flags&131072)!==0}else Sn=!1,Pt&&(n.flags&1048576)!==0&&ym(n,mo,n.index);switch(n.lanes=0,n.tag){case 16:e:{var o=n.pendingProps;if(t=Rs(n.elementType),n.type=t,typeof t=="function")Ou(t)?(o=Ls(t,o),n.tag=1,n=z0(null,n,t,o,a)):(n.tag=0,n=Mf(null,n,t,o,a));else{if(t!=null){var u=t.$$typeof;if(u===C){n.tag=11,n=N0(null,n,t,o,a);break e}else if(u===F){n.tag=14,n=D0(null,n,t,o,a);break e}}throw n=oe(t)||t,Error(s(306,n,""))}}return n;case 0:return Mf(t,n,n.type,n.pendingProps,a);case 1:return o=n.type,u=Ls(o,n.pendingProps),z0(t,n,o,u,a);case 3:e:{if(xe(n,n.stateNode.containerInfo),t===null)throw Error(s(387));o=n.pendingProps;var d=n.memoizedState;u=d.element,Zu(t,n),Mo(n,o,null,a);var S=n.memoizedState;if(o=S.cache,Ha(n,yn,o),o!==d.cache&&ku(n,[yn],a,!0),So(),o=S.element,d.isDehydrated)if(d={element:o,isDehydrated:!1,cache:S.cache},n.updateQueue.baseState=d,n.memoizedState=d,n.flags&256){n=F0(t,n,o,a);break e}else if(o!==u){u=_i(Error(s(424)),n),go(u),n=F0(t,n,o,a);break e}else{switch(t=n.stateNode.containerInfo,t.nodeType){case 9:t=t.body;break;default:t=t.nodeName==="HTML"?t.ownerDocument.body:t}for(an=Ei(t.firstChild),Ln=n,Pt=!0,Ba=null,Si=!0,a=Lm(n,null,o,a),n.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling}else{if(Ts(),o===u){n=pa(t,n,a);break e}Pn(t,n,o,a)}n=n.child}return n;case 26:return Yl(t,n),t===null?(a=$g(n.type,null,n.pendingProps,null))?n.memoizedState=a:Pt||(a=n.type,t=n.pendingProps,o=fc(K.current).createElement(a),o[vn]=n,o[Un]=t,In(o,a,t),_n(o),n.stateNode=o):n.memoizedState=$g(n.type,t.memoizedProps,n.pendingProps,t.memoizedState),null;case 27:return Q(n),t===null&&Pt&&(o=n.stateNode=Kg(n.type,n.pendingProps,K.current),Ln=n,Si=!0,u=an,es(n.type)?(cd=u,an=Ei(o.firstChild)):an=u),Pn(t,n,n.pendingProps.children,a),Yl(t,n),t===null&&(n.flags|=4194304),n.child;case 5:return t===null&&Pt&&((u=o=an)&&(o=fb(o,n.type,n.pendingProps,Si),o!==null?(n.stateNode=o,Ln=n,an=Ei(o.firstChild),Si=!1,u=!0):u=!1),u||Ga(n)),Q(n),u=n.type,d=n.pendingProps,S=t!==null?t.memoizedProps:null,o=d.children,ad(u,d)?o=null:S!==null&&ad(u,S)&&(n.flags|=32),n.memoizedState!==null&&(u=nf(t,n,Ay,null,null,a),ko._currentValue=u),Yl(t,n),Pn(t,n,o,a),n.child;case 6:return t===null&&Pt&&((t=a=an)&&(a=db(a,n.pendingProps,Si),a!==null?(n.stateNode=a,Ln=n,an=null,t=!0):t=!1),t||Ga(n)),null;case 13:return B0(t,n,a);case 4:return xe(n,n.stateNode.containerInfo),o=n.pendingProps,t===null?n.child=Ds(n,null,o,a):Pn(t,n,o,a),n.child;case 11:return N0(t,n,n.type,n.pendingProps,a);case 7:return Pn(t,n,n.pendingProps,a),n.child;case 8:return Pn(t,n,n.pendingProps.children,a),n.child;case 12:return Pn(t,n,n.pendingProps.children,a),n.child;case 10:return o=n.pendingProps,Ha(n,n.type,o.value),Pn(t,n,o.children,a),n.child;case 9:return u=n.type._context,o=n.pendingProps.children,ws(n),u=On(u),o=o(u),n.flags|=1,Pn(t,n,o,a),n.child;case 14:return D0(t,n,n.type,n.pendingProps,a);case 15:return U0(t,n,n.type,n.pendingProps,a);case 19:return H0(t,n,a);case 31:return Oy(t,n,a);case 22:return L0(t,n,a,n.pendingProps);case 24:return ws(n),o=On(yn),t===null?(u=Wu(),u===null&&(u=nn,d=ju(),u.pooledCache=d,d.refCount++,d!==null&&(u.pooledCacheLanes|=a),u=d),n.memoizedState={parent:o,cache:u},Yu(n),Ha(n,yn,u)):((t.lanes&a)!==0&&(Zu(t,n),Mo(n,null,null,a),So()),u=t.memoizedState,d=n.memoizedState,u.parent!==o?(u={parent:o,cache:o},n.memoizedState=u,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=u),Ha(n,yn,o)):(o=d.cache,Ha(n,yn,o),o!==u.cache&&ku(n,[yn],a,!0))),Pn(t,n,n.pendingProps.children,a),n.child;case 29:throw n.pendingProps}throw Error(s(156,n.tag))}function ma(t){t.flags|=4}function Df(t,n,a,o,u){if((n=(t.mode&32)!==0)&&(n=!1),n){if(t.flags|=16777216,(u&335544128)===u)if(t.stateNode.complete)t.flags|=8192;else if(mg())t.flags|=8192;else throw Ns=Ll,qu}else t.flags&=-16777217}function k0(t,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!ax(n))if(mg())t.flags|=8192;else throw Ns=Ll,qu}function Kl(t,n){n!==null&&(t.flags|=4),t.flags&16384&&(n=t.tag!==22?De():536870912,t.lanes|=n,yr|=n)}function Ro(t,n){if(!Pt)switch(t.tailMode){case"hidden":n=t.tail;for(var a=null;n!==null;)n.alternate!==null&&(a=n),n=n.sibling;a===null?t.tail=null:a.sibling=null;break;case"collapsed":a=t.tail;for(var o=null;a!==null;)a.alternate!==null&&(o=a),a=a.sibling;o===null?n||t.tail===null?t.tail=null:t.tail.sibling=null:o.sibling=null}}function sn(t){var n=t.alternate!==null&&t.alternate.child===t.child,a=0,o=0;if(n)for(var u=t.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags&65011712,o|=u.flags&65011712,u.return=t,u=u.sibling;else for(u=t.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags,o|=u.flags,u.return=t,u=u.sibling;return t.subtreeFlags|=o,t.childLanes=a,n}function Iy(t,n,a){var o=n.pendingProps;switch(Fu(n),n.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return sn(n),null;case 1:return sn(n),null;case 3:return a=n.stateNode,o=null,t!==null&&(o=t.memoizedState.cache),n.memoizedState.cache!==o&&(n.flags|=2048),fa(yn),Le(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(t===null||t.child===null)&&(or(n)?ma(n):t===null||t.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Gu())),sn(n),null;case 26:var u=n.type,d=n.memoizedState;return t===null?(ma(n),d!==null?(sn(n),k0(n,d)):(sn(n),Df(n,u,null,o,a))):d?d!==t.memoizedState?(ma(n),sn(n),k0(n,d)):(sn(n),n.flags&=-16777217):(t=t.memoizedProps,t!==o&&ma(n),sn(n),Df(n,u,t,o,a)),null;case 27:if(_e(n),a=K.current,u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==o&&ma(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return sn(n),null}t=Se.current,or(n)?Sm(n):(t=Kg(u,o,a),n.stateNode=t,ma(n))}return sn(n),null;case 5:if(_e(n),u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==o&&ma(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return sn(n),null}if(d=Se.current,or(n))Sm(n);else{var S=fc(K.current);switch(d){case 1:d=S.createElementNS("http://www.w3.org/2000/svg",u);break;case 2:d=S.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;default:switch(u){case"svg":d=S.createElementNS("http://www.w3.org/2000/svg",u);break;case"math":d=S.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;case"script":d=S.createElement("div"),d.innerHTML="<script><\/script>",d=d.removeChild(d.firstChild);break;case"select":d=typeof o.is=="string"?S.createElement("select",{is:o.is}):S.createElement("select"),o.multiple?d.multiple=!0:o.size&&(d.size=o.size);break;default:d=typeof o.is=="string"?S.createElement(u,{is:o.is}):S.createElement(u)}}d[vn]=n,d[Un]=o;e:for(S=n.child;S!==null;){if(S.tag===5||S.tag===6)d.appendChild(S.stateNode);else if(S.tag!==4&&S.tag!==27&&S.child!==null){S.child.return=S,S=S.child;continue}if(S===n)break e;for(;S.sibling===null;){if(S.return===null||S.return===n)break e;S=S.return}S.sibling.return=S.return,S=S.sibling}n.stateNode=d;e:switch(In(d,u,o),u){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&ma(n)}}return sn(n),Df(n,n.type,t===null?null:t.memoizedProps,n.pendingProps,a),null;case 6:if(t&&n.stateNode!=null)t.memoizedProps!==o&&ma(n);else{if(typeof o!="string"&&n.stateNode===null)throw Error(s(166));if(t=K.current,or(n)){if(t=n.stateNode,a=n.memoizedProps,o=null,u=Ln,u!==null)switch(u.tag){case 27:case 5:o=u.memoizedProps}t[vn]=n,t=!!(t.nodeValue===a||o!==null&&o.suppressHydrationWarning===!0||Bg(t.nodeValue,a)),t||Ga(n,!0)}else t=fc(t).createTextNode(o),t[vn]=n,n.stateNode=t}return sn(n),null;case 31:if(a=n.memoizedState,t===null||t.memoizedState!==null){if(o=or(n),a!==null){if(t===null){if(!o)throw Error(s(318));if(t=n.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(s(557));t[vn]=n}else Ts(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;sn(n),t=!1}else a=Gu(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=a),t=!0;if(!t)return n.flags&256?(fi(n),n):(fi(n),null);if((n.flags&128)!==0)throw Error(s(558))}return sn(n),null;case 13:if(o=n.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(u=or(n),o!==null&&o.dehydrated!==null){if(t===null){if(!u)throw Error(s(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(s(317));u[vn]=n}else Ts(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;sn(n),u=!1}else u=Gu(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=u),u=!0;if(!u)return n.flags&256?(fi(n),n):(fi(n),null)}return fi(n),(n.flags&128)!==0?(n.lanes=a,n):(a=o!==null,t=t!==null&&t.memoizedState!==null,a&&(o=n.child,u=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(u=o.alternate.memoizedState.cachePool.pool),d=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(d=o.memoizedState.cachePool.pool),d!==u&&(o.flags|=2048)),a!==t&&a&&(n.child.flags|=8192),Kl(n,n.updateQueue),sn(n),null);case 4:return Le(),t===null&&$f(n.stateNode.containerInfo),sn(n),null;case 10:return fa(n.type),sn(n),null;case 19:if(H(pn),o=n.memoizedState,o===null)return sn(n),null;if(u=(n.flags&128)!==0,d=o.rendering,d===null)if(u)Ro(o,!1);else{if(hn!==0||t!==null&&(t.flags&128)!==0)for(t=n.child;t!==null;){if(d=zl(t),d!==null){for(n.flags|=128,Ro(o,!1),t=d.updateQueue,n.updateQueue=t,Kl(n,t),n.subtreeFlags=0,t=a,a=n.child;a!==null;)xm(a,t),a=a.sibling;return ce(pn,pn.current&1|2),Pt&&ca(n,o.treeForkCount),n.child}t=t.sibling}o.tail!==null&&Tt()>tc&&(n.flags|=128,u=!0,Ro(o,!1),n.lanes=4194304)}else{if(!u)if(t=zl(d),t!==null){if(n.flags|=128,u=!0,t=t.updateQueue,n.updateQueue=t,Kl(n,t),Ro(o,!0),o.tail===null&&o.tailMode==="hidden"&&!d.alternate&&!Pt)return sn(n),null}else 2*Tt()-o.renderingStartTime>tc&&a!==536870912&&(n.flags|=128,u=!0,Ro(o,!1),n.lanes=4194304);o.isBackwards?(d.sibling=n.child,n.child=d):(t=o.last,t!==null?t.sibling=d:n.child=d,o.last=d)}return o.tail!==null?(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=Tt(),t.sibling=null,a=pn.current,ce(pn,u?a&1|2:a&1),Pt&&ca(n,o.treeForkCount),t):(sn(n),null);case 22:case 23:return fi(n),$u(),o=n.memoizedState!==null,t!==null?t.memoizedState!==null!==o&&(n.flags|=8192):o&&(n.flags|=8192),o?(a&536870912)!==0&&(n.flags&128)===0&&(sn(n),n.subtreeFlags&6&&(n.flags|=8192)):sn(n),a=n.updateQueue,a!==null&&Kl(n,a.retryQueue),a=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(a=t.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==a&&(n.flags|=2048),t!==null&&H(Cs),null;case 24:return a=null,t!==null&&(a=t.memoizedState.cache),n.memoizedState.cache!==a&&(n.flags|=2048),fa(yn),sn(n),null;case 25:return null;case 30:return null}throw Error(s(156,n.tag))}function zy(t,n){switch(Fu(n),n.tag){case 1:return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 3:return fa(yn),Le(),t=n.flags,(t&65536)!==0&&(t&128)===0?(n.flags=t&-65537|128,n):null;case 26:case 27:case 5:return _e(n),null;case 31:if(n.memoizedState!==null){if(fi(n),n.alternate===null)throw Error(s(340));Ts()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 13:if(fi(n),t=n.memoizedState,t!==null&&t.dehydrated!==null){if(n.alternate===null)throw Error(s(340));Ts()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 19:return H(pn),null;case 4:return Le(),null;case 10:return fa(n.type),null;case 22:case 23:return fi(n),$u(),t!==null&&H(Cs),t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 24:return fa(yn),null;case 25:return null;default:return null}}function j0(t,n){switch(Fu(n),n.tag){case 3:fa(yn),Le();break;case 26:case 27:case 5:_e(n);break;case 4:Le();break;case 31:n.memoizedState!==null&&fi(n);break;case 13:fi(n);break;case 19:H(pn);break;case 10:fa(n.type);break;case 22:case 23:fi(n),$u(),t!==null&&H(Cs);break;case 24:fa(yn)}}function No(t,n){try{var a=n.updateQueue,o=a!==null?a.lastEffect:null;if(o!==null){var u=o.next;a=u;do{if((a.tag&t)===t){o=void 0;var d=a.create,S=a.inst;o=d(),S.destroy=o}a=a.next}while(a!==u)}}catch(D){Kt(n,n.return,D)}}function qa(t,n,a){try{var o=n.updateQueue,u=o!==null?o.lastEffect:null;if(u!==null){var d=u.next;o=d;do{if((o.tag&t)===t){var S=o.inst,D=S.destroy;if(D!==void 0){S.destroy=void 0,u=n;var j=a,fe=D;try{fe()}catch(Ee){Kt(u,j,Ee)}}}o=o.next}while(o!==d)}}catch(Ee){Kt(n,n.return,Ee)}}function X0(t){var n=t.updateQueue;if(n!==null){var a=t.stateNode;try{Pm(n,a)}catch(o){Kt(t,t.return,o)}}}function W0(t,n,a){a.props=Ls(t.type,t.memoizedProps),a.state=t.memoizedState;try{a.componentWillUnmount()}catch(o){Kt(t,n,o)}}function Do(t,n){try{var a=t.ref;if(a!==null){switch(t.tag){case 26:case 27:case 5:var o=t.stateNode;break;case 30:o=t.stateNode;break;default:o=t.stateNode}typeof a=="function"?t.refCleanup=a(o):a.current=o}}catch(u){Kt(t,n,u)}}function Wi(t,n){var a=t.ref,o=t.refCleanup;if(a!==null)if(typeof o=="function")try{o()}catch(u){Kt(t,n,u)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof a=="function")try{a(null)}catch(u){Kt(t,n,u)}else a.current=null}function q0(t){var n=t.type,a=t.memoizedProps,o=t.stateNode;try{e:switch(n){case"button":case"input":case"select":case"textarea":a.autoFocus&&o.focus();break e;case"img":a.src?o.src=a.src:a.srcSet&&(o.srcset=a.srcSet)}}catch(u){Kt(t,t.return,u)}}function Uf(t,n,a){try{var o=t.stateNode;sb(o,t.type,a,n),o[Un]=n}catch(u){Kt(t,t.return,u)}}function Y0(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&es(t.type)||t.tag===4}function Lf(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||Y0(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&es(t.type)||t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function Of(t,n,a){var o=t.tag;if(o===5||o===6)t=t.stateNode,n?(a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a).insertBefore(t,n):(n=a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a,n.appendChild(t),a=a._reactRootContainer,a!=null||n.onclick!==null||(n.onclick=ra));else if(o!==4&&(o===27&&es(t.type)&&(a=t.stateNode,n=null),t=t.child,t!==null))for(Of(t,n,a),t=t.sibling;t!==null;)Of(t,n,a),t=t.sibling}function Ql(t,n,a){var o=t.tag;if(o===5||o===6)t=t.stateNode,n?a.insertBefore(t,n):a.appendChild(t);else if(o!==4&&(o===27&&es(t.type)&&(a=t.stateNode),t=t.child,t!==null))for(Ql(t,n,a),t=t.sibling;t!==null;)Ql(t,n,a),t=t.sibling}function Z0(t){var n=t.stateNode,a=t.memoizedProps;try{for(var o=t.type,u=n.attributes;u.length;)n.removeAttributeNode(u[0]);In(n,o,a),n[vn]=t,n[Un]=a}catch(d){Kt(t,t.return,d)}}var ga=!1,Mn=!1,Pf=!1,K0=typeof WeakSet=="function"?WeakSet:Set,Rn=null;function Fy(t,n){if(t=t.containerInfo,nd=vc,t=lm(t),wu(t)){if("selectionStart"in t)var a={start:t.selectionStart,end:t.selectionEnd};else e:{a=(a=t.ownerDocument)&&a.defaultView||window;var o=a.getSelection&&a.getSelection();if(o&&o.rangeCount!==0){a=o.anchorNode;var u=o.anchorOffset,d=o.focusNode;o=o.focusOffset;try{a.nodeType,d.nodeType}catch{a=null;break e}var S=0,D=-1,j=-1,fe=0,Ee=0,Re=t,ge=null;t:for(;;){for(var ve;Re!==a||u!==0&&Re.nodeType!==3||(D=S+u),Re!==d||o!==0&&Re.nodeType!==3||(j=S+o),Re.nodeType===3&&(S+=Re.nodeValue.length),(ve=Re.firstChild)!==null;)ge=Re,Re=ve;for(;;){if(Re===t)break t;if(ge===a&&++fe===u&&(D=S),ge===d&&++Ee===o&&(j=S),(ve=Re.nextSibling)!==null)break;Re=ge,ge=Re.parentNode}Re=ve}a=D===-1||j===-1?null:{start:D,end:j}}else a=null}a=a||{start:0,end:0}}else a=null;for(id={focusedElem:t,selectionRange:a},vc=!1,Rn=n;Rn!==null;)if(n=Rn,t=n.child,(n.subtreeFlags&1028)!==0&&t!==null)t.return=n,Rn=t;else for(;Rn!==null;){switch(n=Rn,d=n.alternate,t=n.flags,n.tag){case 0:if((t&4)!==0&&(t=n.updateQueue,t=t!==null?t.events:null,t!==null))for(a=0;a<t.length;a++)u=t[a],u.ref.impl=u.nextImpl;break;case 11:case 15:break;case 1:if((t&1024)!==0&&d!==null){t=void 0,a=n,u=d.memoizedProps,d=d.memoizedState,o=a.stateNode;try{var at=Ls(a.type,u);t=o.getSnapshotBeforeUpdate(at,d),o.__reactInternalSnapshotBeforeUpdate=t}catch(mt){Kt(a,a.return,mt)}}break;case 3:if((t&1024)!==0){if(t=n.stateNode.containerInfo,a=t.nodeType,a===9)rd(t);else if(a===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":rd(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(s(163))}if(t=n.sibling,t!==null){t.return=n.return,Rn=t;break}Rn=n.return}}function Q0(t,n,a){var o=a.flags;switch(a.tag){case 0:case 11:case 15:va(t,a),o&4&&No(5,a);break;case 1:if(va(t,a),o&4)if(t=a.stateNode,n===null)try{t.componentDidMount()}catch(S){Kt(a,a.return,S)}else{var u=Ls(a.type,n.memoizedProps);n=n.memoizedState;try{t.componentDidUpdate(u,n,t.__reactInternalSnapshotBeforeUpdate)}catch(S){Kt(a,a.return,S)}}o&64&&X0(a),o&512&&Do(a,a.return);break;case 3:if(va(t,a),o&64&&(t=a.updateQueue,t!==null)){if(n=null,a.child!==null)switch(a.child.tag){case 27:case 5:n=a.child.stateNode;break;case 1:n=a.child.stateNode}try{Pm(t,n)}catch(S){Kt(a,a.return,S)}}break;case 27:n===null&&o&4&&Z0(a);case 26:case 5:va(t,a),n===null&&o&4&&q0(a),o&512&&Do(a,a.return);break;case 12:va(t,a);break;case 31:va(t,a),o&4&&eg(t,a);break;case 13:va(t,a),o&4&&tg(t,a),o&64&&(t=a.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(a=qy.bind(null,a),hb(t,a))));break;case 22:if(o=a.memoizedState!==null||ga,!o){n=n!==null&&n.memoizedState!==null||Mn,u=ga;var d=Mn;ga=o,(Mn=n)&&!d?_a(t,a,(a.subtreeFlags&8772)!==0):va(t,a),ga=u,Mn=d}break;case 30:break;default:va(t,a)}}function J0(t){var n=t.alternate;n!==null&&(t.alternate=null,J0(n)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(n=t.stateNode,n!==null&&Oa(n)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var cn=null,Qn=!1;function xa(t,n,a){for(a=a.child;a!==null;)$0(t,n,a),a=a.sibling}function $0(t,n,a){if(Me&&typeof Me.onCommitFiberUnmount=="function")try{Me.onCommitFiberUnmount(be,a)}catch{}switch(a.tag){case 26:Mn||Wi(a,n),xa(t,n,a),a.memoizedState?a.memoizedState.count--:a.stateNode&&(a=a.stateNode,a.parentNode.removeChild(a));break;case 27:Mn||Wi(a,n);var o=cn,u=Qn;es(a.type)&&(cn=a.stateNode,Qn=!1),xa(t,n,a),Go(a.stateNode),cn=o,Qn=u;break;case 5:Mn||Wi(a,n);case 6:if(o=cn,u=Qn,cn=null,xa(t,n,a),cn=o,Qn=u,cn!==null)if(Qn)try{(cn.nodeType===9?cn.body:cn.nodeName==="HTML"?cn.ownerDocument.body:cn).removeChild(a.stateNode)}catch(d){Kt(a,n,d)}else try{cn.removeChild(a.stateNode)}catch(d){Kt(a,n,d)}break;case 18:cn!==null&&(Qn?(t=cn,Xg(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,a.stateNode),Cr(t)):Xg(cn,a.stateNode));break;case 4:o=cn,u=Qn,cn=a.stateNode.containerInfo,Qn=!0,xa(t,n,a),cn=o,Qn=u;break;case 0:case 11:case 14:case 15:qa(2,a,n),Mn||qa(4,a,n),xa(t,n,a);break;case 1:Mn||(Wi(a,n),o=a.stateNode,typeof o.componentWillUnmount=="function"&&W0(a,n,o)),xa(t,n,a);break;case 21:xa(t,n,a);break;case 22:Mn=(o=Mn)||a.memoizedState!==null,xa(t,n,a),Mn=o;break;default:xa(t,n,a)}}function eg(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{Cr(t)}catch(a){Kt(n,n.return,a)}}}function tg(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Cr(t)}catch(a){Kt(n,n.return,a)}}function By(t){switch(t.tag){case 31:case 13:case 19:var n=t.stateNode;return n===null&&(n=t.stateNode=new K0),n;case 22:return t=t.stateNode,n=t._retryCache,n===null&&(n=t._retryCache=new K0),n;default:throw Error(s(435,t.tag))}}function Jl(t,n){var a=By(t);n.forEach(function(o){if(!a.has(o)){a.add(o);var u=Yy.bind(null,t,o);o.then(u,u)}})}function Jn(t,n){var a=n.deletions;if(a!==null)for(var o=0;o<a.length;o++){var u=a[o],d=t,S=n,D=S;e:for(;D!==null;){switch(D.tag){case 27:if(es(D.type)){cn=D.stateNode,Qn=!1;break e}break;case 5:cn=D.stateNode,Qn=!1;break e;case 3:case 4:cn=D.stateNode.containerInfo,Qn=!0;break e}D=D.return}if(cn===null)throw Error(s(160));$0(d,S,u),cn=null,Qn=!1,d=u.alternate,d!==null&&(d.return=null),u.return=null}if(n.subtreeFlags&13886)for(n=n.child;n!==null;)ng(n,t),n=n.sibling}var Ui=null;function ng(t,n){var a=t.alternate,o=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Jn(n,t),$n(t),o&4&&(qa(3,t,t.return),No(3,t),qa(5,t,t.return));break;case 1:Jn(n,t),$n(t),o&512&&(Mn||a===null||Wi(a,a.return)),o&64&&ga&&(t=t.updateQueue,t!==null&&(o=t.callbacks,o!==null&&(a=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=a===null?o:a.concat(o))));break;case 26:var u=Ui;if(Jn(n,t),$n(t),o&512&&(Mn||a===null||Wi(a,a.return)),o&4){var d=a!==null?a.memoizedState:null;if(o=t.memoizedState,a===null)if(o===null)if(t.stateNode===null){e:{o=t.type,a=t.memoizedProps,u=u.ownerDocument||u;t:switch(o){case"title":d=u.getElementsByTagName("title")[0],(!d||d[La]||d[vn]||d.namespaceURI==="http://www.w3.org/2000/svg"||d.hasAttribute("itemprop"))&&(d=u.createElement(o),u.head.insertBefore(d,u.querySelector("head > title"))),In(d,o,a),d[vn]=t,_n(d),o=d;break e;case"link":var S=nx("link","href",u).get(o+(a.href||""));if(S){for(var D=0;D<S.length;D++)if(d=S[D],d.getAttribute("href")===(a.href==null||a.href===""?null:a.href)&&d.getAttribute("rel")===(a.rel==null?null:a.rel)&&d.getAttribute("title")===(a.title==null?null:a.title)&&d.getAttribute("crossorigin")===(a.crossOrigin==null?null:a.crossOrigin)){S.splice(D,1);break t}}d=u.createElement(o),In(d,o,a),u.head.appendChild(d);break;case"meta":if(S=nx("meta","content",u).get(o+(a.content||""))){for(D=0;D<S.length;D++)if(d=S[D],d.getAttribute("content")===(a.content==null?null:""+a.content)&&d.getAttribute("name")===(a.name==null?null:a.name)&&d.getAttribute("property")===(a.property==null?null:a.property)&&d.getAttribute("http-equiv")===(a.httpEquiv==null?null:a.httpEquiv)&&d.getAttribute("charset")===(a.charSet==null?null:a.charSet)){S.splice(D,1);break t}}d=u.createElement(o),In(d,o,a),u.head.appendChild(d);break;default:throw Error(s(468,o))}d[vn]=t,_n(d),o=d}t.stateNode=o}else ix(u,t.type,t.stateNode);else t.stateNode=tx(u,o,t.memoizedProps);else d!==o?(d===null?a.stateNode!==null&&(a=a.stateNode,a.parentNode.removeChild(a)):d.count--,o===null?ix(u,t.type,t.stateNode):tx(u,o,t.memoizedProps)):o===null&&t.stateNode!==null&&Uf(t,t.memoizedProps,a.memoizedProps)}break;case 27:Jn(n,t),$n(t),o&512&&(Mn||a===null||Wi(a,a.return)),a!==null&&o&4&&Uf(t,t.memoizedProps,a.memoizedProps);break;case 5:if(Jn(n,t),$n(t),o&512&&(Mn||a===null||Wi(a,a.return)),t.flags&32){u=t.stateNode;try{oi(u,"")}catch(at){Kt(t,t.return,at)}}o&4&&t.stateNode!=null&&(u=t.memoizedProps,Uf(t,u,a!==null?a.memoizedProps:u)),o&1024&&(Pf=!0);break;case 6:if(Jn(n,t),$n(t),o&4){if(t.stateNode===null)throw Error(s(162));o=t.memoizedProps,a=t.stateNode;try{a.nodeValue=o}catch(at){Kt(t,t.return,at)}}break;case 3:if(pc=null,u=Ui,Ui=dc(n.containerInfo),Jn(n,t),Ui=u,$n(t),o&4&&a!==null&&a.memoizedState.isDehydrated)try{Cr(n.containerInfo)}catch(at){Kt(t,t.return,at)}Pf&&(Pf=!1,ig(t));break;case 4:o=Ui,Ui=dc(t.stateNode.containerInfo),Jn(n,t),$n(t),Ui=o;break;case 12:Jn(n,t),$n(t);break;case 31:Jn(n,t),$n(t),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,Jl(t,o)));break;case 13:Jn(n,t),$n(t),t.child.flags&8192&&t.memoizedState!==null!=(a!==null&&a.memoizedState!==null)&&(ec=Tt()),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,Jl(t,o)));break;case 22:u=t.memoizedState!==null;var j=a!==null&&a.memoizedState!==null,fe=ga,Ee=Mn;if(ga=fe||u,Mn=Ee||j,Jn(n,t),Mn=Ee,ga=fe,$n(t),o&8192)e:for(n=t.stateNode,n._visibility=u?n._visibility&-2:n._visibility|1,u&&(a===null||j||ga||Mn||Os(t)),a=null,n=t;;){if(n.tag===5||n.tag===26){if(a===null){j=a=n;try{if(d=j.stateNode,u)S=d.style,typeof S.setProperty=="function"?S.setProperty("display","none","important"):S.display="none";else{D=j.stateNode;var Re=j.memoizedProps.style,ge=Re!=null&&Re.hasOwnProperty("display")?Re.display:null;D.style.display=ge==null||typeof ge=="boolean"?"":(""+ge).trim()}}catch(at){Kt(j,j.return,at)}}}else if(n.tag===6){if(a===null){j=n;try{j.stateNode.nodeValue=u?"":j.memoizedProps}catch(at){Kt(j,j.return,at)}}}else if(n.tag===18){if(a===null){j=n;try{var ve=j.stateNode;u?Wg(ve,!0):Wg(j.stateNode,!1)}catch(at){Kt(j,j.return,at)}}}else if((n.tag!==22&&n.tag!==23||n.memoizedState===null||n===t)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break e;for(;n.sibling===null;){if(n.return===null||n.return===t)break e;a===n&&(a=null),n=n.return}a===n&&(a=null),n.sibling.return=n.return,n=n.sibling}o&4&&(o=t.updateQueue,o!==null&&(a=o.retryQueue,a!==null&&(o.retryQueue=null,Jl(t,a))));break;case 19:Jn(n,t),$n(t),o&4&&(o=t.updateQueue,o!==null&&(t.updateQueue=null,Jl(t,o)));break;case 30:break;case 21:break;default:Jn(n,t),$n(t)}}function $n(t){var n=t.flags;if(n&2){try{for(var a,o=t.return;o!==null;){if(Y0(o)){a=o;break}o=o.return}if(a==null)throw Error(s(160));switch(a.tag){case 27:var u=a.stateNode,d=Lf(t);Ql(t,d,u);break;case 5:var S=a.stateNode;a.flags&32&&(oi(S,""),a.flags&=-33);var D=Lf(t);Ql(t,D,S);break;case 3:case 4:var j=a.stateNode.containerInfo,fe=Lf(t);Of(t,fe,j);break;default:throw Error(s(161))}}catch(Ee){Kt(t,t.return,Ee)}t.flags&=-3}n&4096&&(t.flags&=-4097)}function ig(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var n=t;ig(n),n.tag===5&&n.flags&1024&&n.stateNode.reset(),t=t.sibling}}function va(t,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)Q0(t,n.alternate,n),n=n.sibling}function Os(t){for(t=t.child;t!==null;){var n=t;switch(n.tag){case 0:case 11:case 14:case 15:qa(4,n,n.return),Os(n);break;case 1:Wi(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&W0(n,n.return,a),Os(n);break;case 27:Go(n.stateNode);case 26:case 5:Wi(n,n.return),Os(n);break;case 22:n.memoizedState===null&&Os(n);break;case 30:Os(n);break;default:Os(n)}t=t.sibling}}function _a(t,n,a){for(a=a&&(n.subtreeFlags&8772)!==0,n=n.child;n!==null;){var o=n.alternate,u=t,d=n,S=d.flags;switch(d.tag){case 0:case 11:case 15:_a(u,d,a),No(4,d);break;case 1:if(_a(u,d,a),o=d,u=o.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(fe){Kt(o,o.return,fe)}if(o=d,u=o.updateQueue,u!==null){var D=o.stateNode;try{var j=u.shared.hiddenCallbacks;if(j!==null)for(u.shared.hiddenCallbacks=null,u=0;u<j.length;u++)Om(j[u],D)}catch(fe){Kt(o,o.return,fe)}}a&&S&64&&X0(d),Do(d,d.return);break;case 27:Z0(d);case 26:case 5:_a(u,d,a),a&&o===null&&S&4&&q0(d),Do(d,d.return);break;case 12:_a(u,d,a);break;case 31:_a(u,d,a),a&&S&4&&eg(u,d);break;case 13:_a(u,d,a),a&&S&4&&tg(u,d);break;case 22:d.memoizedState===null&&_a(u,d,a),Do(d,d.return);break;case 30:break;default:_a(u,d,a)}n=n.sibling}}function If(t,n){var a=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(a=t.memoizedState.cachePool.pool),t=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),t!==a&&(t!=null&&t.refCount++,a!=null&&xo(a))}function zf(t,n){t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&xo(t))}function Li(t,n,a,o){if(n.subtreeFlags&10256)for(n=n.child;n!==null;)ag(t,n,a,o),n=n.sibling}function ag(t,n,a,o){var u=n.flags;switch(n.tag){case 0:case 11:case 15:Li(t,n,a,o),u&2048&&No(9,n);break;case 1:Li(t,n,a,o);break;case 3:Li(t,n,a,o),u&2048&&(t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&xo(t)));break;case 12:if(u&2048){Li(t,n,a,o),t=n.stateNode;try{var d=n.memoizedProps,S=d.id,D=d.onPostCommit;typeof D=="function"&&D(S,n.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(j){Kt(n,n.return,j)}}else Li(t,n,a,o);break;case 31:Li(t,n,a,o);break;case 13:Li(t,n,a,o);break;case 23:break;case 22:d=n.stateNode,S=n.alternate,n.memoizedState!==null?d._visibility&2?Li(t,n,a,o):Uo(t,n):d._visibility&2?Li(t,n,a,o):(d._visibility|=2,xr(t,n,a,o,(n.subtreeFlags&10256)!==0||!1)),u&2048&&If(S,n);break;case 24:Li(t,n,a,o),u&2048&&zf(n.alternate,n);break;default:Li(t,n,a,o)}}function xr(t,n,a,o,u){for(u=u&&((n.subtreeFlags&10256)!==0||!1),n=n.child;n!==null;){var d=t,S=n,D=a,j=o,fe=S.flags;switch(S.tag){case 0:case 11:case 15:xr(d,S,D,j,u),No(8,S);break;case 23:break;case 22:var Ee=S.stateNode;S.memoizedState!==null?Ee._visibility&2?xr(d,S,D,j,u):Uo(d,S):(Ee._visibility|=2,xr(d,S,D,j,u)),u&&fe&2048&&If(S.alternate,S);break;case 24:xr(d,S,D,j,u),u&&fe&2048&&zf(S.alternate,S);break;default:xr(d,S,D,j,u)}n=n.sibling}}function Uo(t,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var a=t,o=n,u=o.flags;switch(o.tag){case 22:Uo(a,o),u&2048&&If(o.alternate,o);break;case 24:Uo(a,o),u&2048&&zf(o.alternate,o);break;default:Uo(a,o)}n=n.sibling}}var Lo=8192;function vr(t,n,a){if(t.subtreeFlags&Lo)for(t=t.child;t!==null;)sg(t,n,a),t=t.sibling}function sg(t,n,a){switch(t.tag){case 26:vr(t,n,a),t.flags&Lo&&t.memoizedState!==null&&Tb(a,Ui,t.memoizedState,t.memoizedProps);break;case 5:vr(t,n,a);break;case 3:case 4:var o=Ui;Ui=dc(t.stateNode.containerInfo),vr(t,n,a),Ui=o;break;case 22:t.memoizedState===null&&(o=t.alternate,o!==null&&o.memoizedState!==null?(o=Lo,Lo=16777216,vr(t,n,a),Lo=o):vr(t,n,a));break;default:vr(t,n,a)}}function rg(t){var n=t.alternate;if(n!==null&&(t=n.child,t!==null)){n.child=null;do n=t.sibling,t.sibling=null,t=n;while(t!==null)}}function Oo(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];Rn=o,lg(o,t)}rg(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)og(t),t=t.sibling}function og(t){switch(t.tag){case 0:case 11:case 15:Oo(t),t.flags&2048&&qa(9,t,t.return);break;case 3:Oo(t);break;case 12:Oo(t);break;case 22:var n=t.stateNode;t.memoizedState!==null&&n._visibility&2&&(t.return===null||t.return.tag!==13)?(n._visibility&=-3,$l(t)):Oo(t);break;default:Oo(t)}}function $l(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];Rn=o,lg(o,t)}rg(t)}for(t=t.child;t!==null;){switch(n=t,n.tag){case 0:case 11:case 15:qa(8,n,n.return),$l(n);break;case 22:a=n.stateNode,a._visibility&2&&(a._visibility&=-3,$l(n));break;default:$l(n)}t=t.sibling}}function lg(t,n){for(;Rn!==null;){var a=Rn;switch(a.tag){case 0:case 11:case 15:qa(8,a,n);break;case 23:case 22:if(a.memoizedState!==null&&a.memoizedState.cachePool!==null){var o=a.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:xo(a.memoizedState.cache)}if(o=a.child,o!==null)o.return=a,Rn=o;else e:for(a=t;Rn!==null;){o=Rn;var u=o.sibling,d=o.return;if(J0(o),o===a){Rn=null;break e}if(u!==null){u.return=d,Rn=u;break e}Rn=d}}}var Gy={getCacheForType:function(t){var n=On(yn),a=n.data.get(t);return a===void 0&&(a=t(),n.data.set(t,a)),a},cacheSignal:function(){return On(yn).controller.signal}},Hy=typeof WeakMap=="function"?WeakMap:Map,kt=0,nn=null,Nt=null,Ut=0,Zt=0,di=null,Ya=!1,_r=!1,Ff=!1,ya=0,hn=0,Za=0,Ps=0,Bf=0,hi=0,yr=0,Po=null,ei=null,Gf=!1,ec=0,cg=0,tc=1/0,nc=null,Ka=null,An=0,Qa=null,br=null,ba=0,Hf=0,Vf=null,ug=null,Io=0,kf=null;function pi(){return(kt&2)!==0&&Ut!==0?Ut&-Ut:G.T!==null?Zf():ao()}function fg(){if(hi===0)if((Ut&536870912)===0||Pt){var t=gt;gt<<=1,(gt&3932160)===0&&(gt=262144),hi=t}else hi=536870912;return t=ui.current,t!==null&&(t.flags|=32),hi}function ti(t,n,a){(t===nn&&(Zt===2||Zt===9)||t.cancelPendingCommit!==null)&&(Sr(t,0),Ja(t,Ut,hi,!1)),et(t,a),((kt&2)===0||t!==nn)&&(t===nn&&((kt&2)===0&&(Ps|=a),hn===4&&Ja(t,Ut,hi,!1)),qi(t))}function dg(t,n,a){if((kt&6)!==0)throw Error(s(327));var o=!a&&(n&127)===0&&(n&t.expiredLanes)===0||Fe(t,n),u=o?jy(t,n):Xf(t,n,!0),d=o;do{if(u===0){_r&&!o&&Ja(t,n,0,!1);break}else{if(a=t.current.alternate,d&&!Vy(a)){u=Xf(t,n,!1),d=!1;continue}if(u===2){if(d=n,t.errorRecoveryDisabledLanes&d)var S=0;else S=t.pendingLanes&-536870913,S=S!==0?S:S&536870912?536870912:0;if(S!==0){n=S;e:{var D=t;u=Po;var j=D.current.memoizedState.isDehydrated;if(j&&(Sr(D,S).flags|=256),S=Xf(D,S,!1),S!==2){if(Ff&&!j){D.errorRecoveryDisabledLanes|=d,Ps|=d,u=4;break e}d=ei,ei=u,d!==null&&(ei===null?ei=d:ei.push.apply(ei,d))}u=S}if(d=!1,u!==2)continue}}if(u===1){Sr(t,0),Ja(t,n,0,!0);break}e:{switch(o=t,d=u,d){case 0:case 1:throw Error(s(345));case 4:if((n&4194048)!==n)break;case 6:Ja(o,n,hi,!Ya);break e;case 2:ei=null;break;case 3:case 5:break;default:throw Error(s(329))}if((n&62914560)===n&&(u=ec+300-Tt(),10<u)){if(Ja(o,n,hi,!Ya),Te(o,0,!0)!==0)break e;ba=n,o.timeoutHandle=kg(hg.bind(null,o,a,ei,nc,Gf,n,hi,Ps,yr,Ya,d,"Throttled",-0,0),u);break e}hg(o,a,ei,nc,Gf,n,hi,Ps,yr,Ya,d,null,-0,0)}}break}while(!0);qi(t)}function hg(t,n,a,o,u,d,S,D,j,fe,Ee,Re,ge,ve){if(t.timeoutHandle=-1,Re=n.subtreeFlags,Re&8192||(Re&16785408)===16785408){Re={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:ra},sg(n,d,Re);var at=(d&62914560)===d?ec-Tt():(d&4194048)===d?cg-Tt():0;if(at=Ab(Re,at),at!==null){ba=d,t.cancelPendingCommit=at(bg.bind(null,t,n,d,a,o,u,S,D,j,Ee,Re,null,ge,ve)),Ja(t,d,S,!fe);return}}bg(t,n,d,a,o,u,S,D,j)}function Vy(t){for(var n=t;;){var a=n.tag;if((a===0||a===11||a===15)&&n.flags&16384&&(a=n.updateQueue,a!==null&&(a=a.stores,a!==null)))for(var o=0;o<a.length;o++){var u=a[o],d=u.getSnapshot;u=u.value;try{if(!li(d(),u))return!1}catch{return!1}}if(a=n.child,n.subtreeFlags&16384&&a!==null)a.return=n,n=a;else{if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function Ja(t,n,a,o){n&=~Bf,n&=~Ps,t.suspendedLanes|=n,t.pingedLanes&=~n,o&&(t.warmLanes|=n),o=t.expirationTimes;for(var u=n;0<u;){var d=31-Ze(u),S=1<<d;o[d]=-1,u&=~S}a!==0&&Xt(t,a,n)}function ic(){return(kt&6)===0?(zo(0),!1):!0}function jf(){if(Nt!==null){if(Zt===0)var t=Nt.return;else t=Nt,ua=As=null,rf(t),dr=null,_o=0,t=Nt;for(;t!==null;)j0(t.alternate,t),t=t.return;Nt=null}}function Sr(t,n){var a=t.timeoutHandle;a!==-1&&(t.timeoutHandle=-1,lb(a)),a=t.cancelPendingCommit,a!==null&&(t.cancelPendingCommit=null,a()),ba=0,jf(),nn=t,Nt=a=la(t.current,null),Ut=n,Zt=0,di=null,Ya=!1,_r=Fe(t,n),Ff=!1,yr=hi=Bf=Ps=Za=hn=0,ei=Po=null,Gf=!1,(n&8)!==0&&(n|=n&32);var o=t.entangledLanes;if(o!==0)for(t=t.entanglements,o&=n;0<o;){var u=31-Ze(o),d=1<<u;n|=t[u],o&=~d}return ya=n,El(),a}function pg(t,n){bt=null,G.H=wo,n===fr||n===Ul?(n=Nm(),Zt=3):n===qu?(n=Nm(),Zt=4):Zt=n===Sf?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,di=n,Nt===null&&(hn=1,Wl(t,_i(n,t.current)))}function mg(){var t=ui.current;return t===null?!0:(Ut&4194048)===Ut?Mi===null:(Ut&62914560)===Ut||(Ut&536870912)!==0?t===Mi:!1}function gg(){var t=G.H;return G.H=wo,t===null?wo:t}function xg(){var t=G.A;return G.A=Gy,t}function ac(){hn=4,Ya||(Ut&4194048)!==Ut&&ui.current!==null||(_r=!0),(Za&134217727)===0&&(Ps&134217727)===0||nn===null||Ja(nn,Ut,hi,!1)}function Xf(t,n,a){var o=kt;kt|=2;var u=gg(),d=xg();(nn!==t||Ut!==n)&&(nc=null,Sr(t,n)),n=!1;var S=hn;e:do try{if(Zt!==0&&Nt!==null){var D=Nt,j=di;switch(Zt){case 8:jf(),S=6;break e;case 3:case 2:case 9:case 6:ui.current===null&&(n=!0);var fe=Zt;if(Zt=0,di=null,Mr(t,D,j,fe),a&&_r){S=0;break e}break;default:fe=Zt,Zt=0,di=null,Mr(t,D,j,fe)}}ky(),S=hn;break}catch(Ee){pg(t,Ee)}while(!0);return n&&t.shellSuspendCounter++,ua=As=null,kt=o,G.H=u,G.A=d,Nt===null&&(nn=null,Ut=0,El()),S}function ky(){for(;Nt!==null;)vg(Nt)}function jy(t,n){var a=kt;kt|=2;var o=gg(),u=xg();nn!==t||Ut!==n?(nc=null,tc=Tt()+500,Sr(t,n)):_r=Fe(t,n);e:do try{if(Zt!==0&&Nt!==null){n=Nt;var d=di;t:switch(Zt){case 1:Zt=0,di=null,Mr(t,n,d,1);break;case 2:case 9:if(Cm(d)){Zt=0,di=null,_g(n);break}n=function(){Zt!==2&&Zt!==9||nn!==t||(Zt=7),qi(t)},d.then(n,n);break e;case 3:Zt=7;break e;case 4:Zt=5;break e;case 7:Cm(d)?(Zt=0,di=null,_g(n)):(Zt=0,di=null,Mr(t,n,d,7));break;case 5:var S=null;switch(Nt.tag){case 26:S=Nt.memoizedState;case 5:case 27:var D=Nt;if(S?ax(S):D.stateNode.complete){Zt=0,di=null;var j=D.sibling;if(j!==null)Nt=j;else{var fe=D.return;fe!==null?(Nt=fe,sc(fe)):Nt=null}break t}}Zt=0,di=null,Mr(t,n,d,5);break;case 6:Zt=0,di=null,Mr(t,n,d,6);break;case 8:jf(),hn=6;break e;default:throw Error(s(462))}}Xy();break}catch(Ee){pg(t,Ee)}while(!0);return ua=As=null,G.H=o,G.A=u,kt=a,Nt!==null?0:(nn=null,Ut=0,El(),hn)}function Xy(){for(;Nt!==null&&!Mt();)vg(Nt)}function vg(t){var n=V0(t.alternate,t,ya);t.memoizedProps=t.pendingProps,n===null?sc(t):Nt=n}function _g(t){var n=t,a=n.alternate;switch(n.tag){case 15:case 0:n=I0(a,n,n.pendingProps,n.type,void 0,Ut);break;case 11:n=I0(a,n,n.pendingProps,n.type.render,n.ref,Ut);break;case 5:rf(n);default:j0(a,n),n=Nt=xm(n,ya),n=V0(a,n,ya)}t.memoizedProps=t.pendingProps,n===null?sc(t):Nt=n}function Mr(t,n,a,o){ua=As=null,rf(n),dr=null,_o=0;var u=n.return;try{if(Ly(t,u,n,a,Ut)){hn=1,Wl(t,_i(a,t.current)),Nt=null;return}}catch(d){if(u!==null)throw Nt=u,d;hn=1,Wl(t,_i(a,t.current)),Nt=null;return}n.flags&32768?(Pt||o===1?t=!0:_r||(Ut&536870912)!==0?t=!1:(Ya=t=!0,(o===2||o===9||o===3||o===6)&&(o=ui.current,o!==null&&o.tag===13&&(o.flags|=16384))),yg(n,t)):sc(n)}function sc(t){var n=t;do{if((n.flags&32768)!==0){yg(n,Ya);return}t=n.return;var a=Iy(n.alternate,n,ya);if(a!==null){Nt=a;return}if(n=n.sibling,n!==null){Nt=n;return}Nt=n=t}while(n!==null);hn===0&&(hn=5)}function yg(t,n){do{var a=zy(t.alternate,t);if(a!==null){a.flags&=32767,Nt=a;return}if(a=t.return,a!==null&&(a.flags|=32768,a.subtreeFlags=0,a.deletions=null),!n&&(t=t.sibling,t!==null)){Nt=t;return}Nt=t=a}while(t!==null);hn=6,Nt=null}function bg(t,n,a,o,u,d,S,D,j){t.cancelPendingCommit=null;do rc();while(An!==0);if((kt&6)!==0)throw Error(s(327));if(n!==null){if(n===t.current)throw Error(s(177));if(d=n.lanes|n.childLanes,d|=Uu,rn(t,a,d,S,D,j),t===nn&&(Nt=nn=null,Ut=0),br=n,Qa=t,ba=a,Hf=d,Vf=u,ug=o,(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,Zy(ie,function(){return Ag(),null})):(t.callbackNode=null,t.callbackPriority=0),o=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||o){o=G.T,G.T=null,u=X.p,X.p=2,S=kt,kt|=4;try{Fy(t,n,a)}finally{kt=S,X.p=u,G.T=o}}An=1,Sg(),Mg(),Eg()}}function Sg(){if(An===1){An=0;var t=Qa,n=br,a=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||a){a=G.T,G.T=null;var o=X.p;X.p=2;var u=kt;kt|=4;try{ng(n,t);var d=id,S=lm(t.containerInfo),D=d.focusedElem,j=d.selectionRange;if(S!==D&&D&&D.ownerDocument&&om(D.ownerDocument.documentElement,D)){if(j!==null&&wu(D)){var fe=j.start,Ee=j.end;if(Ee===void 0&&(Ee=fe),"selectionStart"in D)D.selectionStart=fe,D.selectionEnd=Math.min(Ee,D.value.length);else{var Re=D.ownerDocument||document,ge=Re&&Re.defaultView||window;if(ge.getSelection){var ve=ge.getSelection(),at=D.textContent.length,mt=Math.min(j.start,at),en=j.end===void 0?mt:Math.min(j.end,at);!ve.extend&&mt>en&&(S=en,en=mt,mt=S);var ne=rm(D,mt),q=rm(D,en);if(ne&&q&&(ve.rangeCount!==1||ve.anchorNode!==ne.node||ve.anchorOffset!==ne.offset||ve.focusNode!==q.node||ve.focusOffset!==q.offset)){var ue=Re.createRange();ue.setStart(ne.node,ne.offset),ve.removeAllRanges(),mt>en?(ve.addRange(ue),ve.extend(q.node,q.offset)):(ue.setEnd(q.node,q.offset),ve.addRange(ue))}}}}for(Re=[],ve=D;ve=ve.parentNode;)ve.nodeType===1&&Re.push({element:ve,left:ve.scrollLeft,top:ve.scrollTop});for(typeof D.focus=="function"&&D.focus(),D=0;D<Re.length;D++){var we=Re[D];we.element.scrollLeft=we.left,we.element.scrollTop=we.top}}vc=!!nd,id=nd=null}finally{kt=u,X.p=o,G.T=a}}t.current=n,An=2}}function Mg(){if(An===2){An=0;var t=Qa,n=br,a=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||a){a=G.T,G.T=null;var o=X.p;X.p=2;var u=kt;kt|=4;try{Q0(t,n.alternate,n)}finally{kt=u,X.p=o,G.T=a}}An=3}}function Eg(){if(An===4||An===3){An=0,Y();var t=Qa,n=br,a=ba,o=ug;(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?An=5:(An=0,br=Qa=null,Tg(t,t.pendingLanes));var u=t.pendingLanes;if(u===0&&(Ka=null),io(a),n=n.stateNode,Me&&typeof Me.onCommitFiberRoot=="function")try{Me.onCommitFiberRoot(be,n,void 0,(n.current.flags&128)===128)}catch{}if(o!==null){n=G.T,u=X.p,X.p=2,G.T=null;try{for(var d=t.onRecoverableError,S=0;S<o.length;S++){var D=o[S];d(D.value,{componentStack:D.stack})}}finally{G.T=n,X.p=u}}(ba&3)!==0&&rc(),qi(t),u=t.pendingLanes,(a&261930)!==0&&(u&42)!==0?t===kf?Io++:(Io=0,kf=t):Io=0,zo(0)}}function Tg(t,n){(t.pooledCacheLanes&=n)===0&&(n=t.pooledCache,n!=null&&(t.pooledCache=null,xo(n)))}function rc(){return Sg(),Mg(),Eg(),Ag()}function Ag(){if(An!==5)return!1;var t=Qa,n=Hf;Hf=0;var a=io(ba),o=G.T,u=X.p;try{X.p=32>a?32:a,G.T=null,a=Vf,Vf=null;var d=Qa,S=ba;if(An=0,br=Qa=null,ba=0,(kt&6)!==0)throw Error(s(331));var D=kt;if(kt|=4,og(d.current),ag(d,d.current,S,a),kt=D,zo(0,!1),Me&&typeof Me.onPostCommitFiberRoot=="function")try{Me.onPostCommitFiberRoot(be,d)}catch{}return!0}finally{X.p=u,G.T=o,Tg(t,n)}}function wg(t,n,a){n=_i(a,n),n=bf(t.stateNode,n,2),t=ja(t,n,2),t!==null&&(et(t,2),qi(t))}function Kt(t,n,a){if(t.tag===3)wg(t,t,a);else for(;n!==null;){if(n.tag===3){wg(n,t,a);break}else if(n.tag===1){var o=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Ka===null||!Ka.has(o))){t=_i(a,t),a=C0(2),o=ja(n,a,2),o!==null&&(R0(a,o,n,t),et(o,2),qi(o));break}}n=n.return}}function Wf(t,n,a){var o=t.pingCache;if(o===null){o=t.pingCache=new Hy;var u=new Set;o.set(n,u)}else u=o.get(n),u===void 0&&(u=new Set,o.set(n,u));u.has(a)||(Ff=!0,u.add(a),t=Wy.bind(null,t,n,a),n.then(t,t))}function Wy(t,n,a){var o=t.pingCache;o!==null&&o.delete(n),t.pingedLanes|=t.suspendedLanes&a,t.warmLanes&=~a,nn===t&&(Ut&a)===a&&(hn===4||hn===3&&(Ut&62914560)===Ut&&300>Tt()-ec?(kt&2)===0&&Sr(t,0):Bf|=a,yr===Ut&&(yr=0)),qi(t)}function Cg(t,n){n===0&&(n=De()),t=Ms(t,n),t!==null&&(et(t,n),qi(t))}function qy(t){var n=t.memoizedState,a=0;n!==null&&(a=n.retryLane),Cg(t,a)}function Yy(t,n){var a=0;switch(t.tag){case 31:case 13:var o=t.stateNode,u=t.memoizedState;u!==null&&(a=u.retryLane);break;case 19:o=t.stateNode;break;case 22:o=t.stateNode._retryCache;break;default:throw Error(s(314))}o!==null&&o.delete(n),Cg(t,a)}function Zy(t,n){return Je(t,n)}var oc=null,Er=null,qf=!1,lc=!1,Yf=!1,$a=0;function qi(t){t!==Er&&t.next===null&&(Er===null?oc=Er=t:Er=Er.next=t),lc=!0,qf||(qf=!0,Qy())}function zo(t,n){if(!Yf&&lc){Yf=!0;do for(var a=!1,o=oc;o!==null;){if(t!==0){var u=o.pendingLanes;if(u===0)var d=0;else{var S=o.suspendedLanes,D=o.pingedLanes;d=(1<<31-Ze(42|t)+1)-1,d&=u&~(S&~D),d=d&201326741?d&201326741|1:d?d|2:0}d!==0&&(a=!0,Ug(o,d))}else d=Ut,d=Te(o,o===nn?d:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(d&3)===0||Fe(o,d)||(a=!0,Ug(o,d));o=o.next}while(a);Yf=!1}}function Ky(){Rg()}function Rg(){lc=qf=!1;var t=0;$a!==0&&ob()&&(t=$a);for(var n=Tt(),a=null,o=oc;o!==null;){var u=o.next,d=Ng(o,n);d===0?(o.next=null,a===null?oc=u:a.next=u,u===null&&(Er=a)):(a=o,(t!==0||(d&3)!==0)&&(lc=!0)),o=u}An!==0&&An!==5||zo(t),$a!==0&&($a=0)}function Ng(t,n){for(var a=t.suspendedLanes,o=t.pingedLanes,u=t.expirationTimes,d=t.pendingLanes&-62914561;0<d;){var S=31-Ze(d),D=1<<S,j=u[S];j===-1?((D&a)===0||(D&o)!==0)&&(u[S]=qe(D,n)):j<=n&&(t.expiredLanes|=D),d&=~D}if(n=nn,a=Ut,a=Te(t,t===n?a:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),o=t.callbackNode,a===0||t===n&&(Zt===2||Zt===9)||t.cancelPendingCommit!==null)return o!==null&&o!==null&&ct(o),t.callbackNode=null,t.callbackPriority=0;if((a&3)===0||Fe(t,a)){if(n=a&-a,n===t.callbackPriority)return n;switch(o!==null&&ct(o),io(a)){case 2:case 8:a=A;break;case 32:a=ie;break;case 268435456:a=ye;break;default:a=ie}return o=Dg.bind(null,t),a=Je(a,o),t.callbackPriority=n,t.callbackNode=a,n}return o!==null&&o!==null&&ct(o),t.callbackPriority=2,t.callbackNode=null,2}function Dg(t,n){if(An!==0&&An!==5)return t.callbackNode=null,t.callbackPriority=0,null;var a=t.callbackNode;if(rc()&&t.callbackNode!==a)return null;var o=Ut;return o=Te(t,t===nn?o:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),o===0?null:(dg(t,o,n),Ng(t,Tt()),t.callbackNode!=null&&t.callbackNode===a?Dg.bind(null,t):null)}function Ug(t,n){if(rc())return null;dg(t,n,!0)}function Qy(){cb(function(){(kt&6)!==0?Je(z,Ky):Rg()})}function Zf(){if($a===0){var t=cr;t===0&&(t=dt,dt<<=1,(dt&261888)===0&&(dt=256)),$a=t}return $a}function Lg(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:_s(""+t)}function Og(t,n){var a=n.ownerDocument.createElement("input");return a.name=n.name,a.value=n.value,t.id&&a.setAttribute("form",t.id),n.parentNode.insertBefore(a,n),t=new FormData(t),a.parentNode.removeChild(a),t}function Jy(t,n,a,o,u){if(n==="submit"&&a&&a.stateNode===u){var d=Lg((u[Un]||null).action),S=o.submitter;S&&(n=(n=S[Un]||null)?Lg(n.formAction):S.getAttribute("formAction"),n!==null&&(d=n,S=null));var D=new yl("action","action",null,o,u);t.push({event:D,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if($a!==0){var j=S?Og(u,S):new FormData(u);mf(a,{pending:!0,data:j,method:u.method,action:d},null,j)}}else typeof d=="function"&&(D.preventDefault(),j=S?Og(u,S):new FormData(u),mf(a,{pending:!0,data:j,method:u.method,action:d},d,j))},currentTarget:u}]})}}for(var Kf=0;Kf<Du.length;Kf++){var Qf=Du[Kf],$y=Qf.toLowerCase(),eb=Qf[0].toUpperCase()+Qf.slice(1);Di($y,"on"+eb)}Di(fm,"onAnimationEnd"),Di(dm,"onAnimationIteration"),Di(hm,"onAnimationStart"),Di("dblclick","onDoubleClick"),Di("focusin","onFocus"),Di("focusout","onBlur"),Di(gy,"onTransitionRun"),Di(xy,"onTransitionStart"),Di(vy,"onTransitionCancel"),Di(pm,"onTransitionEnd"),me("onMouseEnter",["mouseout","mouseover"]),me("onMouseLeave",["mouseout","mouseover"]),me("onPointerEnter",["pointerout","pointerover"]),me("onPointerLeave",["pointerout","pointerover"]),J("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),J("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),J("onBeforeInput",["compositionend","keypress","textInput","paste"]),J("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),J("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),J("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Fo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),tb=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Fo));function Pg(t,n){n=(n&4)!==0;for(var a=0;a<t.length;a++){var o=t[a],u=o.event;o=o.listeners;e:{var d=void 0;if(n)for(var S=o.length-1;0<=S;S--){var D=o[S],j=D.instance,fe=D.currentTarget;if(D=D.listener,j!==d&&u.isPropagationStopped())break e;d=D,u.currentTarget=fe;try{d(u)}catch(Ee){Ml(Ee)}u.currentTarget=null,d=j}else for(S=0;S<o.length;S++){if(D=o[S],j=D.instance,fe=D.currentTarget,D=D.listener,j!==d&&u.isPropagationStopped())break e;d=D,u.currentTarget=fe;try{d(u)}catch(Ee){Ml(Ee)}u.currentTarget=null,d=j}}}}function Dt(t,n){var a=n[gs];a===void 0&&(a=n[gs]=new Set);var o=t+"__bubble";a.has(o)||(Ig(n,t,2,!1),a.add(o))}function Jf(t,n,a){var o=0;n&&(o|=4),Ig(a,t,o,n)}var cc="_reactListening"+Math.random().toString(36).slice(2);function $f(t){if(!t[cc]){t[cc]=!0,gl.forEach(function(a){a!=="selectionchange"&&(tb.has(a)||Jf(a,!1,t),Jf(a,!0,t))});var n=t.nodeType===9?t:t.ownerDocument;n===null||n[cc]||(n[cc]=!0,Jf("selectionchange",!1,n))}}function Ig(t,n,a,o){switch(fx(n)){case 2:var u=Rb;break;case 8:u=Nb;break;default:u=pd}a=u.bind(null,n,a,t),u=void 0,!vu||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(u=!0),o?u!==void 0?t.addEventListener(n,a,{capture:!0,passive:u}):t.addEventListener(n,a,!0):u!==void 0?t.addEventListener(n,a,{passive:u}):t.addEventListener(n,a,!1)}function ed(t,n,a,o,u){var d=o;if((n&1)===0&&(n&2)===0&&o!==null)e:for(;;){if(o===null)return;var S=o.tag;if(S===3||S===4){var D=o.stateNode.containerInfo;if(D===u)break;if(S===4)for(S=o.return;S!==null;){var j=S.tag;if((j===3||j===4)&&S.stateNode.containerInfo===u)return;S=S.return}for(;D!==null;){if(S=aa(D),S===null)return;if(j=S.tag,j===5||j===6||j===26||j===27){o=d=S;continue e}D=D.parentNode}}o=o.return}Hp(function(){var fe=d,Ee=gu(a),Re=[];e:{var ge=mm.get(t);if(ge!==void 0){var ve=yl,at=t;switch(t){case"keypress":if(vl(a)===0)break e;case"keydown":case"keyup":ve=Y_;break;case"focusin":at="focus",ve=Su;break;case"focusout":at="blur",ve=Su;break;case"beforeblur":case"afterblur":ve=Su;break;case"click":if(a.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":ve=jp;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":ve=I_;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":ve=Q_;break;case fm:case dm:case hm:ve=B_;break;case pm:ve=$_;break;case"scroll":case"scrollend":ve=O_;break;case"wheel":ve=ty;break;case"copy":case"cut":case"paste":ve=H_;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":ve=Wp;break;case"toggle":case"beforetoggle":ve=iy}var mt=(n&4)!==0,en=!mt&&(t==="scroll"||t==="scrollend"),ne=mt?ge!==null?ge+"Capture":null:ge;mt=[];for(var q=fe,ue;q!==null;){var we=q;if(ue=we.stateNode,we=we.tag,we!==5&&we!==26&&we!==27||ue===null||ne===null||(we=so(q,ne),we!=null&&mt.push(Bo(q,we,ue))),en)break;q=q.return}0<mt.length&&(ge=new ve(ge,at,null,a,Ee),Re.push({event:ge,listeners:mt}))}}if((n&7)===0){e:{if(ge=t==="mouseover"||t==="pointerover",ve=t==="mouseout"||t==="pointerout",ge&&a!==mu&&(at=a.relatedTarget||a.fromElement)&&(aa(at)||at[Zn]))break e;if((ve||ge)&&(ge=Ee.window===Ee?Ee:(ge=Ee.ownerDocument)?ge.defaultView||ge.parentWindow:window,ve?(at=a.relatedTarget||a.toElement,ve=fe,at=at?aa(at):null,at!==null&&(en=c(at),mt=at.tag,at!==en||mt!==5&&mt!==27&&mt!==6)&&(at=null)):(ve=null,at=fe),ve!==at)){if(mt=jp,we="onMouseLeave",ne="onMouseEnter",q="mouse",(t==="pointerout"||t==="pointerover")&&(mt=Wp,we="onPointerLeave",ne="onPointerEnter",q="pointer"),en=ve==null?ge:vs(ve),ue=at==null?ge:vs(at),ge=new mt(we,q+"leave",ve,a,Ee),ge.target=en,ge.relatedTarget=ue,we=null,aa(Ee)===fe&&(mt=new mt(ne,q+"enter",at,a,Ee),mt.target=ue,mt.relatedTarget=en,we=mt),en=we,ve&&at)t:{for(mt=nb,ne=ve,q=at,ue=0,we=ne;we;we=mt(we))ue++;we=0;for(var pt=q;pt;pt=mt(pt))we++;for(;0<ue-we;)ne=mt(ne),ue--;for(;0<we-ue;)q=mt(q),we--;for(;ue--;){if(ne===q||q!==null&&ne===q.alternate){mt=ne;break t}ne=mt(ne),q=mt(q)}mt=null}else mt=null;ve!==null&&zg(Re,ge,ve,mt,!1),at!==null&&en!==null&&zg(Re,en,at,mt,!0)}}e:{if(ge=fe?vs(fe):window,ve=ge.nodeName&&ge.nodeName.toLowerCase(),ve==="select"||ve==="input"&&ge.type==="file")var Ht=em;else if(Jp(ge))if(tm)Ht=hy;else{Ht=fy;var ot=uy}else ve=ge.nodeName,!ve||ve.toLowerCase()!=="input"||ge.type!=="checkbox"&&ge.type!=="radio"?fe&&jt(fe.elementType)&&(Ht=em):Ht=dy;if(Ht&&(Ht=Ht(t,fe))){$p(Re,Ht,a,Ee);break e}ot&&ot(t,ge,fe),t==="focusout"&&fe&&ge.type==="number"&&fe.memoizedProps.value!=null&&Rt(ge,"number",ge.value)}switch(ot=fe?vs(fe):window,t){case"focusin":(Jp(ot)||ot.contentEditable==="true")&&(tr=ot,Cu=fe,po=null);break;case"focusout":po=Cu=tr=null;break;case"mousedown":Ru=!0;break;case"contextmenu":case"mouseup":case"dragend":Ru=!1,cm(Re,a,Ee);break;case"selectionchange":if(my)break;case"keydown":case"keyup":cm(Re,a,Ee)}var Et;if(Eu)e:{switch(t){case"compositionstart":var Lt="onCompositionStart";break e;case"compositionend":Lt="onCompositionEnd";break e;case"compositionupdate":Lt="onCompositionUpdate";break e}Lt=void 0}else er?Kp(t,a)&&(Lt="onCompositionEnd"):t==="keydown"&&a.keyCode===229&&(Lt="onCompositionStart");Lt&&(qp&&a.locale!=="ko"&&(er||Lt!=="onCompositionStart"?Lt==="onCompositionEnd"&&er&&(Et=Vp()):(za=Ee,_u="value"in za?za.value:za.textContent,er=!0)),ot=uc(fe,Lt),0<ot.length&&(Lt=new Xp(Lt,t,null,a,Ee),Re.push({event:Lt,listeners:ot}),Et?Lt.data=Et:(Et=Qp(a),Et!==null&&(Lt.data=Et)))),(Et=sy?ry(t,a):oy(t,a))&&(Lt=uc(fe,"onBeforeInput"),0<Lt.length&&(ot=new Xp("onBeforeInput","beforeinput",null,a,Ee),Re.push({event:ot,listeners:Lt}),ot.data=Et)),Jy(Re,t,fe,a,Ee)}Pg(Re,n)})}function Bo(t,n,a){return{instance:t,listener:n,currentTarget:a}}function uc(t,n){for(var a=n+"Capture",o=[];t!==null;){var u=t,d=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||d===null||(u=so(t,a),u!=null&&o.unshift(Bo(t,u,d)),u=so(t,n),u!=null&&o.push(Bo(t,u,d))),t.tag===3)return o;t=t.return}return[]}function nb(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function zg(t,n,a,o,u){for(var d=n._reactName,S=[];a!==null&&a!==o;){var D=a,j=D.alternate,fe=D.stateNode;if(D=D.tag,j!==null&&j===o)break;D!==5&&D!==26&&D!==27||fe===null||(j=fe,u?(fe=so(a,d),fe!=null&&S.unshift(Bo(a,fe,j))):u||(fe=so(a,d),fe!=null&&S.push(Bo(a,fe,j)))),a=a.return}S.length!==0&&t.push({event:n,listeners:S})}var ib=/\r\n?/g,ab=/\u0000|\uFFFD/g;function Fg(t){return(typeof t=="string"?t:""+t).replace(ib,`
`).replace(ab,"")}function Bg(t,n){return n=Fg(n),Fg(t)===n}function $t(t,n,a,o,u,d){switch(a){case"children":typeof o=="string"?n==="body"||n==="textarea"&&o===""||oi(t,o):(typeof o=="number"||typeof o=="bigint")&&n!=="body"&&oi(t,""+o);break;case"className":it(t,"class",o);break;case"tabIndex":it(t,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":it(t,a,o);break;case"style":Ni(t,o,d);break;case"data":if(n!=="object"){it(t,"data",o);break}case"src":case"href":if(o===""&&(n!=="a"||a!=="href")){t.removeAttribute(a);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){t.removeAttribute(a);break}o=_s(""+o),t.setAttribute(a,o);break;case"action":case"formAction":if(typeof o=="function"){t.setAttribute(a,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof d=="function"&&(a==="formAction"?(n!=="input"&&$t(t,n,"name",u.name,u,null),$t(t,n,"formEncType",u.formEncType,u,null),$t(t,n,"formMethod",u.formMethod,u,null),$t(t,n,"formTarget",u.formTarget,u,null)):($t(t,n,"encType",u.encType,u,null),$t(t,n,"method",u.method,u,null),$t(t,n,"target",u.target,u,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){t.removeAttribute(a);break}o=_s(""+o),t.setAttribute(a,o);break;case"onClick":o!=null&&(t.onclick=ra);break;case"onScroll":o!=null&&Dt("scroll",t);break;case"onScrollEnd":o!=null&&Dt("scrollend",t);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));t.innerHTML=a}}break;case"multiple":t.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":t.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){t.removeAttribute("xlink:href");break}a=_s(""+o),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",a);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(a,""+o):t.removeAttribute(a);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(a,""):t.removeAttribute(a);break;case"capture":case"download":o===!0?t.setAttribute(a,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?t.setAttribute(a,o):t.removeAttribute(a);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?t.setAttribute(a,o):t.removeAttribute(a);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?t.removeAttribute(a):t.setAttribute(a,o);break;case"popover":Dt("beforetoggle",t),Dt("toggle",t),ke(t,"popover",o);break;case"xlinkActuate":tt(t,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":tt(t,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":tt(t,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":tt(t,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":tt(t,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":tt(t,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":tt(t,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":tt(t,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":tt(t,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":ke(t,"is",o);break;case"innerText":case"textContent":break;default:(!(2<a.length)||a[0]!=="o"&&a[0]!=="O"||a[1]!=="n"&&a[1]!=="N")&&(a=ki.get(a)||a,ke(t,a,o))}}function td(t,n,a,o,u,d){switch(a){case"style":Ni(t,o,d);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));t.innerHTML=a}}break;case"children":typeof o=="string"?oi(t,o):(typeof o=="number"||typeof o=="bigint")&&oi(t,""+o);break;case"onScroll":o!=null&&Dt("scroll",t);break;case"onScrollEnd":o!=null&&Dt("scrollend",t);break;case"onClick":o!=null&&(t.onclick=ra);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!N.hasOwnProperty(a))e:{if(a[0]==="o"&&a[1]==="n"&&(u=a.endsWith("Capture"),n=a.slice(2,u?a.length-7:void 0),d=t[Un]||null,d=d!=null?d[a]:null,typeof d=="function"&&t.removeEventListener(n,d,u),typeof o=="function")){typeof d!="function"&&d!==null&&(a in t?t[a]=null:t.hasAttribute(a)&&t.removeAttribute(a)),t.addEventListener(n,o,u);break e}a in t?t[a]=o:o===!0?t.setAttribute(a,""):ke(t,a,o)}}}function In(t,n,a){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Dt("error",t),Dt("load",t);var o=!1,u=!1,d;for(d in a)if(a.hasOwnProperty(d)){var S=a[d];if(S!=null)switch(d){case"src":o=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:$t(t,n,d,S,a,null)}}u&&$t(t,n,"srcSet",a.srcSet,a,null),o&&$t(t,n,"src",a.src,a,null);return;case"input":Dt("invalid",t);var D=d=S=u=null,j=null,fe=null;for(o in a)if(a.hasOwnProperty(o)){var Ee=a[o];if(Ee!=null)switch(o){case"name":u=Ee;break;case"type":S=Ee;break;case"checked":j=Ee;break;case"defaultChecked":fe=Ee;break;case"value":d=Ee;break;case"defaultValue":D=Ee;break;case"children":case"dangerouslySetInnerHTML":if(Ee!=null)throw Error(s(137,n));break;default:$t(t,n,o,Ee,a,null)}}Gn(t,d,D,j,fe,S,u,!1);return;case"select":Dt("invalid",t),o=S=d=null;for(u in a)if(a.hasOwnProperty(u)&&(D=a[u],D!=null))switch(u){case"value":d=D;break;case"defaultValue":S=D;break;case"multiple":o=D;default:$t(t,n,u,D,a,null)}n=d,a=S,t.multiple=!!o,n!=null?Tn(t,!!o,n,!1):a!=null&&Tn(t,!!o,a,!0);return;case"textarea":Dt("invalid",t),d=u=o=null;for(S in a)if(a.hasOwnProperty(S)&&(D=a[S],D!=null))switch(S){case"value":o=D;break;case"defaultValue":u=D;break;case"children":d=D;break;case"dangerouslySetInnerHTML":if(D!=null)throw Error(s(91));break;default:$t(t,n,S,D,a,null)}Ri(t,o,u,d);return;case"option":for(j in a)if(a.hasOwnProperty(j)&&(o=a[j],o!=null))switch(j){case"selected":t.selected=o&&typeof o!="function"&&typeof o!="symbol";break;default:$t(t,n,j,o,a,null)}return;case"dialog":Dt("beforetoggle",t),Dt("toggle",t),Dt("cancel",t),Dt("close",t);break;case"iframe":case"object":Dt("load",t);break;case"video":case"audio":for(o=0;o<Fo.length;o++)Dt(Fo[o],t);break;case"image":Dt("error",t),Dt("load",t);break;case"details":Dt("toggle",t);break;case"embed":case"source":case"link":Dt("error",t),Dt("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(fe in a)if(a.hasOwnProperty(fe)&&(o=a[fe],o!=null))switch(fe){case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:$t(t,n,fe,o,a,null)}return;default:if(jt(n)){for(Ee in a)a.hasOwnProperty(Ee)&&(o=a[Ee],o!==void 0&&td(t,n,Ee,o,a,void 0));return}}for(D in a)a.hasOwnProperty(D)&&(o=a[D],o!=null&&$t(t,n,D,o,a,null))}function sb(t,n,a,o){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,d=null,S=null,D=null,j=null,fe=null,Ee=null;for(ve in a){var Re=a[ve];if(a.hasOwnProperty(ve)&&Re!=null)switch(ve){case"checked":break;case"value":break;case"defaultValue":j=Re;default:o.hasOwnProperty(ve)||$t(t,n,ve,null,o,Re)}}for(var ge in o){var ve=o[ge];if(Re=a[ge],o.hasOwnProperty(ge)&&(ve!=null||Re!=null))switch(ge){case"type":d=ve;break;case"name":u=ve;break;case"checked":fe=ve;break;case"defaultChecked":Ee=ve;break;case"value":S=ve;break;case"defaultValue":D=ve;break;case"children":case"dangerouslySetInnerHTML":if(ve!=null)throw Error(s(137,n));break;default:ve!==Re&&$t(t,n,ge,ve,o,Re)}}Ke(t,S,D,j,fe,Ee,d,u);return;case"select":ve=S=D=ge=null;for(d in a)if(j=a[d],a.hasOwnProperty(d)&&j!=null)switch(d){case"value":break;case"multiple":ve=j;default:o.hasOwnProperty(d)||$t(t,n,d,null,o,j)}for(u in o)if(d=o[u],j=a[u],o.hasOwnProperty(u)&&(d!=null||j!=null))switch(u){case"value":ge=d;break;case"defaultValue":D=d;break;case"multiple":S=d;default:d!==j&&$t(t,n,u,d,o,j)}n=D,a=S,o=ve,ge!=null?Tn(t,!!a,ge,!1):!!o!=!!a&&(n!=null?Tn(t,!!a,n,!0):Tn(t,!!a,a?[]:"",!1));return;case"textarea":ve=ge=null;for(D in a)if(u=a[D],a.hasOwnProperty(D)&&u!=null&&!o.hasOwnProperty(D))switch(D){case"value":break;case"children":break;default:$t(t,n,D,null,o,u)}for(S in o)if(u=o[S],d=a[S],o.hasOwnProperty(S)&&(u!=null||d!=null))switch(S){case"value":ge=u;break;case"defaultValue":ve=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(s(91));break;default:u!==d&&$t(t,n,S,u,o,d)}ri(t,ge,ve);return;case"option":for(var at in a)if(ge=a[at],a.hasOwnProperty(at)&&ge!=null&&!o.hasOwnProperty(at))switch(at){case"selected":t.selected=!1;break;default:$t(t,n,at,null,o,ge)}for(j in o)if(ge=o[j],ve=a[j],o.hasOwnProperty(j)&&ge!==ve&&(ge!=null||ve!=null))switch(j){case"selected":t.selected=ge&&typeof ge!="function"&&typeof ge!="symbol";break;default:$t(t,n,j,ge,o,ve)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var mt in a)ge=a[mt],a.hasOwnProperty(mt)&&ge!=null&&!o.hasOwnProperty(mt)&&$t(t,n,mt,null,o,ge);for(fe in o)if(ge=o[fe],ve=a[fe],o.hasOwnProperty(fe)&&ge!==ve&&(ge!=null||ve!=null))switch(fe){case"children":case"dangerouslySetInnerHTML":if(ge!=null)throw Error(s(137,n));break;default:$t(t,n,fe,ge,o,ve)}return;default:if(jt(n)){for(var en in a)ge=a[en],a.hasOwnProperty(en)&&ge!==void 0&&!o.hasOwnProperty(en)&&td(t,n,en,void 0,o,ge);for(Ee in o)ge=o[Ee],ve=a[Ee],!o.hasOwnProperty(Ee)||ge===ve||ge===void 0&&ve===void 0||td(t,n,Ee,ge,o,ve);return}}for(var ne in a)ge=a[ne],a.hasOwnProperty(ne)&&ge!=null&&!o.hasOwnProperty(ne)&&$t(t,n,ne,null,o,ge);for(Re in o)ge=o[Re],ve=a[Re],!o.hasOwnProperty(Re)||ge===ve||ge==null&&ve==null||$t(t,n,Re,ge,o,ve)}function Gg(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function rb(){if(typeof performance.getEntriesByType=="function"){for(var t=0,n=0,a=performance.getEntriesByType("resource"),o=0;o<a.length;o++){var u=a[o],d=u.transferSize,S=u.initiatorType,D=u.duration;if(d&&D&&Gg(S)){for(S=0,D=u.responseEnd,o+=1;o<a.length;o++){var j=a[o],fe=j.startTime;if(fe>D)break;var Ee=j.transferSize,Re=j.initiatorType;Ee&&Gg(Re)&&(j=j.responseEnd,S+=Ee*(j<D?1:(D-fe)/(j-fe)))}if(--o,n+=8*(d+S)/(u.duration/1e3),t++,10<t)break}}if(0<t)return n/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var nd=null,id=null;function fc(t){return t.nodeType===9?t:t.ownerDocument}function Hg(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Vg(t,n){if(t===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&n==="foreignObject"?0:t}function ad(t,n){return t==="textarea"||t==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var sd=null;function ob(){var t=window.event;return t&&t.type==="popstate"?t===sd?!1:(sd=t,!0):(sd=null,!1)}var kg=typeof setTimeout=="function"?setTimeout:void 0,lb=typeof clearTimeout=="function"?clearTimeout:void 0,jg=typeof Promise=="function"?Promise:void 0,cb=typeof queueMicrotask=="function"?queueMicrotask:typeof jg<"u"?function(t){return jg.resolve(null).then(t).catch(ub)}:kg;function ub(t){setTimeout(function(){throw t})}function es(t){return t==="head"}function Xg(t,n){var a=n,o=0;do{var u=a.nextSibling;if(t.removeChild(a),u&&u.nodeType===8)if(a=u.data,a==="/$"||a==="/&"){if(o===0){t.removeChild(u),Cr(n);return}o--}else if(a==="$"||a==="$?"||a==="$~"||a==="$!"||a==="&")o++;else if(a==="html")Go(t.ownerDocument.documentElement);else if(a==="head"){a=t.ownerDocument.head,Go(a);for(var d=a.firstChild;d;){var S=d.nextSibling,D=d.nodeName;d[La]||D==="SCRIPT"||D==="STYLE"||D==="LINK"&&d.rel.toLowerCase()==="stylesheet"||a.removeChild(d),d=S}}else a==="body"&&Go(t.ownerDocument.body);a=u}while(a);Cr(n)}function Wg(t,n){var a=t;t=0;do{var o=a.nextSibling;if(a.nodeType===1?n?(a._stashedDisplay=a.style.display,a.style.display="none"):(a.style.display=a._stashedDisplay||"",a.getAttribute("style")===""&&a.removeAttribute("style")):a.nodeType===3&&(n?(a._stashedText=a.nodeValue,a.nodeValue=""):a.nodeValue=a._stashedText||""),o&&o.nodeType===8)if(a=o.data,a==="/$"){if(t===0)break;t--}else a!=="$"&&a!=="$?"&&a!=="$~"&&a!=="$!"||t++;a=o}while(a)}function rd(t){var n=t.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var a=n;switch(n=n.nextSibling,a.nodeName){case"HTML":case"HEAD":case"BODY":rd(a),Oa(a);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(a.rel.toLowerCase()==="stylesheet")continue}t.removeChild(a)}}function fb(t,n,a,o){for(;t.nodeType===1;){var u=a;if(t.nodeName.toLowerCase()!==n.toLowerCase()){if(!o&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(o){if(!t[La])switch(n){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(d=t.getAttribute("rel"),d==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(d!==u.rel||t.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||t.getAttribute("title")!==(u.title==null?null:u.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(d=t.getAttribute("src"),(d!==(u.src==null?null:u.src)||t.getAttribute("type")!==(u.type==null?null:u.type)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&d&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(n==="input"&&t.type==="hidden"){var d=u.name==null?null:""+u.name;if(u.type==="hidden"&&t.getAttribute("name")===d)return t}else return t;if(t=Ei(t.nextSibling),t===null)break}return null}function db(t,n,a){if(n==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!a||(t=Ei(t.nextSibling),t===null))return null;return t}function qg(t,n){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!n||(t=Ei(t.nextSibling),t===null))return null;return t}function od(t){return t.data==="$?"||t.data==="$~"}function ld(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function hb(t,n){var a=t.ownerDocument;if(t.data==="$~")t._reactRetry=n;else if(t.data!=="$?"||a.readyState!=="loading")n();else{var o=function(){n(),a.removeEventListener("DOMContentLoaded",o)};a.addEventListener("DOMContentLoaded",o),t._reactRetry=o}}function Ei(t){for(;t!=null;t=t.nextSibling){var n=t.nodeType;if(n===1||n===3)break;if(n===8){if(n=t.data,n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"||n==="F!"||n==="F")break;if(n==="/$"||n==="/&")return null}}return t}var cd=null;function Yg(t){t=t.nextSibling;for(var n=0;t;){if(t.nodeType===8){var a=t.data;if(a==="/$"||a==="/&"){if(n===0)return Ei(t.nextSibling);n--}else a!=="$"&&a!=="$!"&&a!=="$?"&&a!=="$~"&&a!=="&"||n++}t=t.nextSibling}return null}function Zg(t){t=t.previousSibling;for(var n=0;t;){if(t.nodeType===8){var a=t.data;if(a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"){if(n===0)return t;n--}else a!=="/$"&&a!=="/&"||n++}t=t.previousSibling}return null}function Kg(t,n,a){switch(n=fc(a),t){case"html":if(t=n.documentElement,!t)throw Error(s(452));return t;case"head":if(t=n.head,!t)throw Error(s(453));return t;case"body":if(t=n.body,!t)throw Error(s(454));return t;default:throw Error(s(451))}}function Go(t){for(var n=t.attributes;n.length;)t.removeAttributeNode(n[0]);Oa(t)}var Ti=new Map,Qg=new Set;function dc(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var Sa=X.d;X.d={f:pb,r:mb,D:gb,C:xb,L:vb,m:_b,X:bb,S:yb,M:Sb};function pb(){var t=Sa.f(),n=ic();return t||n}function mb(t){var n=sa(t);n!==null&&n.tag===5&&n.type==="form"?p0(n):Sa.r(t)}var Tr=typeof document>"u"?null:document;function Jg(t,n,a){var o=Tr;if(o&&typeof n=="string"&&n){var u=qt(n);u='link[rel="'+t+'"][href="'+u+'"]',typeof a=="string"&&(u+='[crossorigin="'+a+'"]'),Qg.has(u)||(Qg.add(u),t={rel:t,crossOrigin:a,href:n},o.querySelector(u)===null&&(n=o.createElement("link"),In(n,"link",t),_n(n),o.head.appendChild(n)))}}function gb(t){Sa.D(t),Jg("dns-prefetch",t,null)}function xb(t,n){Sa.C(t,n),Jg("preconnect",t,n)}function vb(t,n,a){Sa.L(t,n,a);var o=Tr;if(o&&t&&n){var u='link[rel="preload"][as="'+qt(n)+'"]';n==="image"&&a&&a.imageSrcSet?(u+='[imagesrcset="'+qt(a.imageSrcSet)+'"]',typeof a.imageSizes=="string"&&(u+='[imagesizes="'+qt(a.imageSizes)+'"]')):u+='[href="'+qt(t)+'"]';var d=u;switch(n){case"style":d=Ar(t);break;case"script":d=wr(t)}Ti.has(d)||(t=x({rel:"preload",href:n==="image"&&a&&a.imageSrcSet?void 0:t,as:n},a),Ti.set(d,t),o.querySelector(u)!==null||n==="style"&&o.querySelector(Ho(d))||n==="script"&&o.querySelector(Vo(d))||(n=o.createElement("link"),In(n,"link",t),_n(n),o.head.appendChild(n)))}}function _b(t,n){Sa.m(t,n);var a=Tr;if(a&&t){var o=n&&typeof n.as=="string"?n.as:"script",u='link[rel="modulepreload"][as="'+qt(o)+'"][href="'+qt(t)+'"]',d=u;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":d=wr(t)}if(!Ti.has(d)&&(t=x({rel:"modulepreload",href:t},n),Ti.set(d,t),a.querySelector(u)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(a.querySelector(Vo(d)))return}o=a.createElement("link"),In(o,"link",t),_n(o),a.head.appendChild(o)}}}function yb(t,n,a){Sa.S(t,n,a);var o=Tr;if(o&&t){var u=Pa(o).hoistableStyles,d=Ar(t);n=n||"default";var S=u.get(d);if(!S){var D={loading:0,preload:null};if(S=o.querySelector(Ho(d)))D.loading=5;else{t=x({rel:"stylesheet",href:t,"data-precedence":n},a),(a=Ti.get(d))&&ud(t,a);var j=S=o.createElement("link");_n(j),In(j,"link",t),j._p=new Promise(function(fe,Ee){j.onload=fe,j.onerror=Ee}),j.addEventListener("load",function(){D.loading|=1}),j.addEventListener("error",function(){D.loading|=2}),D.loading|=4,hc(S,n,o)}S={type:"stylesheet",instance:S,count:1,state:D},u.set(d,S)}}}function bb(t,n){Sa.X(t,n);var a=Tr;if(a&&t){var o=Pa(a).hoistableScripts,u=wr(t),d=o.get(u);d||(d=a.querySelector(Vo(u)),d||(t=x({src:t,async:!0},n),(n=Ti.get(u))&&fd(t,n),d=a.createElement("script"),_n(d),In(d,"link",t),a.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},o.set(u,d))}}function Sb(t,n){Sa.M(t,n);var a=Tr;if(a&&t){var o=Pa(a).hoistableScripts,u=wr(t),d=o.get(u);d||(d=a.querySelector(Vo(u)),d||(t=x({src:t,async:!0,type:"module"},n),(n=Ti.get(u))&&fd(t,n),d=a.createElement("script"),_n(d),In(d,"link",t),a.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},o.set(u,d))}}function $g(t,n,a,o){var u=(u=K.current)?dc(u):null;if(!u)throw Error(s(446));switch(t){case"meta":case"title":return null;case"style":return typeof a.precedence=="string"&&typeof a.href=="string"?(n=Ar(a.href),a=Pa(u).hoistableStyles,o=a.get(n),o||(o={type:"style",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(a.rel==="stylesheet"&&typeof a.href=="string"&&typeof a.precedence=="string"){t=Ar(a.href);var d=Pa(u).hoistableStyles,S=d.get(t);if(S||(u=u.ownerDocument||u,S={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},d.set(t,S),(d=u.querySelector(Ho(t)))&&!d._p&&(S.instance=d,S.state.loading=5),Ti.has(t)||(a={rel:"preload",as:"style",href:a.href,crossOrigin:a.crossOrigin,integrity:a.integrity,media:a.media,hrefLang:a.hrefLang,referrerPolicy:a.referrerPolicy},Ti.set(t,a),d||Mb(u,t,a,S.state))),n&&o===null)throw Error(s(528,""));return S}if(n&&o!==null)throw Error(s(529,""));return null;case"script":return n=a.async,a=a.src,typeof a=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(n=wr(a),a=Pa(u).hoistableScripts,o=a.get(n),o||(o={type:"script",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(s(444,t))}}function Ar(t){return'href="'+qt(t)+'"'}function Ho(t){return'link[rel="stylesheet"]['+t+"]"}function ex(t){return x({},t,{"data-precedence":t.precedence,precedence:null})}function Mb(t,n,a,o){t.querySelector('link[rel="preload"][as="style"]['+n+"]")?o.loading=1:(n=t.createElement("link"),o.preload=n,n.addEventListener("load",function(){return o.loading|=1}),n.addEventListener("error",function(){return o.loading|=2}),In(n,"link",a),_n(n),t.head.appendChild(n))}function wr(t){return'[src="'+qt(t)+'"]'}function Vo(t){return"script[async]"+t}function tx(t,n,a){if(n.count++,n.instance===null)switch(n.type){case"style":var o=t.querySelector('style[data-href~="'+qt(a.href)+'"]');if(o)return n.instance=o,_n(o),o;var u=x({},a,{"data-href":a.href,"data-precedence":a.precedence,href:null,precedence:null});return o=(t.ownerDocument||t).createElement("style"),_n(o),In(o,"style",u),hc(o,a.precedence,t),n.instance=o;case"stylesheet":u=Ar(a.href);var d=t.querySelector(Ho(u));if(d)return n.state.loading|=4,n.instance=d,_n(d),d;o=ex(a),(u=Ti.get(u))&&ud(o,u),d=(t.ownerDocument||t).createElement("link"),_n(d);var S=d;return S._p=new Promise(function(D,j){S.onload=D,S.onerror=j}),In(d,"link",o),n.state.loading|=4,hc(d,a.precedence,t),n.instance=d;case"script":return d=wr(a.src),(u=t.querySelector(Vo(d)))?(n.instance=u,_n(u),u):(o=a,(u=Ti.get(d))&&(o=x({},a),fd(o,u)),t=t.ownerDocument||t,u=t.createElement("script"),_n(u),In(u,"link",o),t.head.appendChild(u),n.instance=u);case"void":return null;default:throw Error(s(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(o=n.instance,n.state.loading|=4,hc(o,a.precedence,t));return n.instance}function hc(t,n,a){for(var o=a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=o.length?o[o.length-1]:null,d=u,S=0;S<o.length;S++){var D=o[S];if(D.dataset.precedence===n)d=D;else if(d!==u)break}d?d.parentNode.insertBefore(t,d.nextSibling):(n=a.nodeType===9?a.head:a,n.insertBefore(t,n.firstChild))}function ud(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.title==null&&(t.title=n.title)}function fd(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.integrity==null&&(t.integrity=n.integrity)}var pc=null;function nx(t,n,a){if(pc===null){var o=new Map,u=pc=new Map;u.set(a,o)}else u=pc,o=u.get(a),o||(o=new Map,u.set(a,o));if(o.has(t))return o;for(o.set(t,null),a=a.getElementsByTagName(t),u=0;u<a.length;u++){var d=a[u];if(!(d[La]||d[vn]||t==="link"&&d.getAttribute("rel")==="stylesheet")&&d.namespaceURI!=="http://www.w3.org/2000/svg"){var S=d.getAttribute(n)||"";S=t+S;var D=o.get(S);D?D.push(d):o.set(S,[d])}}return o}function ix(t,n,a){t=t.ownerDocument||t,t.head.insertBefore(a,n==="title"?t.querySelector("head > title"):null)}function Eb(t,n,a){if(a===1||n.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;switch(n.rel){case"stylesheet":return t=n.disabled,typeof n.precedence=="string"&&t==null;default:return!0}case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function ax(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function Tb(t,n,a,o){if(a.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(a.state.loading&4)===0){if(a.instance===null){var u=Ar(o.href),d=n.querySelector(Ho(u));if(d){n=d._p,n!==null&&typeof n=="object"&&typeof n.then=="function"&&(t.count++,t=mc.bind(t),n.then(t,t)),a.state.loading|=4,a.instance=d,_n(d);return}d=n.ownerDocument||n,o=ex(o),(u=Ti.get(u))&&ud(o,u),d=d.createElement("link"),_n(d);var S=d;S._p=new Promise(function(D,j){S.onload=D,S.onerror=j}),In(d,"link",o),a.instance=d}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(a,n),(n=a.state.preload)&&(a.state.loading&3)===0&&(t.count++,a=mc.bind(t),n.addEventListener("load",a),n.addEventListener("error",a))}}var dd=0;function Ab(t,n){return t.stylesheets&&t.count===0&&xc(t,t.stylesheets),0<t.count||0<t.imgCount?function(a){var o=setTimeout(function(){if(t.stylesheets&&xc(t,t.stylesheets),t.unsuspend){var d=t.unsuspend;t.unsuspend=null,d()}},6e4+n);0<t.imgBytes&&dd===0&&(dd=62500*rb());var u=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&xc(t,t.stylesheets),t.unsuspend)){var d=t.unsuspend;t.unsuspend=null,d()}},(t.imgBytes>dd?50:800)+n);return t.unsuspend=a,function(){t.unsuspend=null,clearTimeout(o),clearTimeout(u)}}:null}function mc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)xc(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var gc=null;function xc(t,n){t.stylesheets=null,t.unsuspend!==null&&(t.count++,gc=new Map,n.forEach(wb,t),gc=null,mc.call(t))}function wb(t,n){if(!(n.state.loading&4)){var a=gc.get(t);if(a)var o=a.get(null);else{a=new Map,gc.set(t,a);for(var u=t.querySelectorAll("link[data-precedence],style[data-precedence]"),d=0;d<u.length;d++){var S=u[d];(S.nodeName==="LINK"||S.getAttribute("media")!=="not all")&&(a.set(S.dataset.precedence,S),o=S)}o&&a.set(null,o)}u=n.instance,S=u.getAttribute("data-precedence"),d=a.get(S)||o,d===o&&a.set(null,u),a.set(S,u),this.count++,o=mc.bind(this),u.addEventListener("load",o),u.addEventListener("error",o),d?d.parentNode.insertBefore(u,d.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(u,t.firstChild)),n.state.loading|=4}}var ko={$$typeof:O,Provider:null,Consumer:null,_currentValue:$,_currentValue2:$,_threadCount:0};function Cb(t,n,a,o,u,d,S,D,j){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=rt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=rt(0),this.hiddenUpdates=rt(null),this.identifierPrefix=o,this.onUncaughtError=u,this.onCaughtError=d,this.onRecoverableError=S,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=j,this.incompleteTransitions=new Map}function sx(t,n,a,o,u,d,S,D,j,fe,Ee,Re){return t=new Cb(t,n,a,S,j,fe,Ee,Re,D),n=1,d===!0&&(n|=24),d=ci(3,null,null,n),t.current=d,d.stateNode=t,n=ju(),n.refCount++,t.pooledCache=n,n.refCount++,d.memoizedState={element:o,isDehydrated:a,cache:n},Yu(d),t}function rx(t){return t?(t=ar,t):ar}function ox(t,n,a,o,u,d){u=rx(u),o.context===null?o.context=u:o.pendingContext=u,o=ka(n),o.payload={element:a},d=d===void 0?null:d,d!==null&&(o.callback=d),a=ja(t,o,n),a!==null&&(ti(a,t,n),bo(a,t,n))}function lx(t,n){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var a=t.retryLane;t.retryLane=a!==0&&a<n?a:n}}function hd(t,n){lx(t,n),(t=t.alternate)&&lx(t,n)}function cx(t){if(t.tag===13||t.tag===31){var n=Ms(t,67108864);n!==null&&ti(n,t,67108864),hd(t,67108864)}}function ux(t){if(t.tag===13||t.tag===31){var n=pi();n=no(n);var a=Ms(t,n);a!==null&&ti(a,t,n),hd(t,n)}}var vc=!0;function Rb(t,n,a,o){var u=G.T;G.T=null;var d=X.p;try{X.p=2,pd(t,n,a,o)}finally{X.p=d,G.T=u}}function Nb(t,n,a,o){var u=G.T;G.T=null;var d=X.p;try{X.p=8,pd(t,n,a,o)}finally{X.p=d,G.T=u}}function pd(t,n,a,o){if(vc){var u=md(o);if(u===null)ed(t,n,o,_c,a),dx(t,o);else if(Ub(u,t,n,a,o))o.stopPropagation();else if(dx(t,o),n&4&&-1<Db.indexOf(t)){for(;u!==null;){var d=sa(u);if(d!==null)switch(d.tag){case 3:if(d=d.stateNode,d.current.memoizedState.isDehydrated){var S=Ie(d.pendingLanes);if(S!==0){var D=d;for(D.pendingLanes|=2,D.entangledLanes|=2;S;){var j=1<<31-Ze(S);D.entanglements[1]|=j,S&=~j}qi(d),(kt&6)===0&&(tc=Tt()+500,zo(0))}}break;case 31:case 13:D=Ms(d,2),D!==null&&ti(D,d,2),ic(),hd(d,2)}if(d=md(o),d===null&&ed(t,n,o,_c,a),d===u)break;u=d}u!==null&&o.stopPropagation()}else ed(t,n,o,null,a)}}function md(t){return t=gu(t),gd(t)}var _c=null;function gd(t){if(_c=null,t=aa(t),t!==null){var n=c(t);if(n===null)t=null;else{var a=n.tag;if(a===13){if(t=f(n),t!==null)return t;t=null}else if(a===31){if(t=p(n),t!==null)return t;t=null}else if(a===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;t=null}else n!==t&&(t=null)}}return _c=t,null}function fx(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Ne()){case z:return 2;case A:return 8;case ie:case pe:return 32;case ye:return 268435456;default:return 32}default:return 32}}var xd=!1,ts=null,ns=null,is=null,jo=new Map,Xo=new Map,as=[],Db="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function dx(t,n){switch(t){case"focusin":case"focusout":ts=null;break;case"dragenter":case"dragleave":ns=null;break;case"mouseover":case"mouseout":is=null;break;case"pointerover":case"pointerout":jo.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":Xo.delete(n.pointerId)}}function Wo(t,n,a,o,u,d){return t===null||t.nativeEvent!==d?(t={blockedOn:n,domEventName:a,eventSystemFlags:o,nativeEvent:d,targetContainers:[u]},n!==null&&(n=sa(n),n!==null&&cx(n)),t):(t.eventSystemFlags|=o,n=t.targetContainers,u!==null&&n.indexOf(u)===-1&&n.push(u),t)}function Ub(t,n,a,o,u){switch(n){case"focusin":return ts=Wo(ts,t,n,a,o,u),!0;case"dragenter":return ns=Wo(ns,t,n,a,o,u),!0;case"mouseover":return is=Wo(is,t,n,a,o,u),!0;case"pointerover":var d=u.pointerId;return jo.set(d,Wo(jo.get(d)||null,t,n,a,o,u)),!0;case"gotpointercapture":return d=u.pointerId,Xo.set(d,Wo(Xo.get(d)||null,t,n,a,o,u)),!0}return!1}function hx(t){var n=aa(t.target);if(n!==null){var a=c(n);if(a!==null){if(n=a.tag,n===13){if(n=f(a),n!==null){t.blockedOn=n,Qs(t.priority,function(){ux(a)});return}}else if(n===31){if(n=p(a),n!==null){t.blockedOn=n,Qs(t.priority,function(){ux(a)});return}}else if(n===3&&a.stateNode.current.memoizedState.isDehydrated){t.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}t.blockedOn=null}function yc(t){if(t.blockedOn!==null)return!1;for(var n=t.targetContainers;0<n.length;){var a=md(t.nativeEvent);if(a===null){a=t.nativeEvent;var o=new a.constructor(a.type,a);mu=o,a.target.dispatchEvent(o),mu=null}else return n=sa(a),n!==null&&cx(n),t.blockedOn=a,!1;n.shift()}return!0}function px(t,n,a){yc(t)&&a.delete(n)}function Lb(){xd=!1,ts!==null&&yc(ts)&&(ts=null),ns!==null&&yc(ns)&&(ns=null),is!==null&&yc(is)&&(is=null),jo.forEach(px),Xo.forEach(px)}function bc(t,n){t.blockedOn===n&&(t.blockedOn=null,xd||(xd=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Lb)))}var Sc=null;function mx(t){Sc!==t&&(Sc=t,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){Sc===t&&(Sc=null);for(var n=0;n<t.length;n+=3){var a=t[n],o=t[n+1],u=t[n+2];if(typeof o!="function"){if(gd(o||a)===null)continue;break}var d=sa(a);d!==null&&(t.splice(n,3),n-=3,mf(d,{pending:!0,data:u,method:a.method,action:o},o,u))}}))}function Cr(t){function n(j){return bc(j,t)}ts!==null&&bc(ts,t),ns!==null&&bc(ns,t),is!==null&&bc(is,t),jo.forEach(n),Xo.forEach(n);for(var a=0;a<as.length;a++){var o=as[a];o.blockedOn===t&&(o.blockedOn=null)}for(;0<as.length&&(a=as[0],a.blockedOn===null);)hx(a),a.blockedOn===null&&as.shift();if(a=(t.ownerDocument||t).$$reactFormReplay,a!=null)for(o=0;o<a.length;o+=3){var u=a[o],d=a[o+1],S=u[Un]||null;if(typeof d=="function")S||mx(a);else if(S){var D=null;if(d&&d.hasAttribute("formAction")){if(u=d,S=d[Un]||null)D=S.formAction;else if(gd(u)!==null)continue}else D=S.action;typeof D=="function"?a[o+1]=D:(a.splice(o,3),o-=3),mx(a)}}}function gx(){function t(d){d.canIntercept&&d.info==="react-transition"&&d.intercept({handler:function(){return new Promise(function(S){return u=S})},focusReset:"manual",scroll:"manual"})}function n(){u!==null&&(u(),u=null),o||setTimeout(a,20)}function a(){if(!o&&!navigation.transition){var d=navigation.currentEntry;d&&d.url!=null&&navigation.navigate(d.url,{state:d.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,u=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",n),navigation.addEventListener("navigateerror",n),setTimeout(a,100),function(){o=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",n),navigation.removeEventListener("navigateerror",n),u!==null&&(u(),u=null)}}}function vd(t){this._internalRoot=t}Mc.prototype.render=vd.prototype.render=function(t){var n=this._internalRoot;if(n===null)throw Error(s(409));var a=n.current,o=pi();ox(a,o,t,n,null,null)},Mc.prototype.unmount=vd.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var n=t.containerInfo;ox(t.current,2,null,t,null,null),ic(),n[Zn]=null}};function Mc(t){this._internalRoot=t}Mc.prototype.unstable_scheduleHydration=function(t){if(t){var n=ao();t={blockedOn:null,target:t,priority:n};for(var a=0;a<as.length&&n!==0&&n<as[a].priority;a++);as.splice(a,0,t),a===0&&hx(t)}};var xx=e.version;if(xx!=="19.2.8")throw Error(s(527,xx,"19.2.8"));X.findDOMNode=function(t){var n=t._reactInternals;if(n===void 0)throw typeof t.render=="function"?Error(s(188)):(t=Object.keys(t).join(","),Error(s(268,t)));return t=h(n),t=t!==null?v(t):null,t=t===null?null:t.stateNode,t};var Ob={bundleType:0,version:"19.2.8",rendererPackageName:"react-dom",currentDispatcherRef:G,reconcilerVersion:"19.2.8"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Ec=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Ec.isDisabled&&Ec.supportsFiber)try{be=Ec.inject(Ob),Me=Ec}catch{}}return Yo.createRoot=function(t,n){if(!l(t))throw Error(s(299));var a=!1,o="",u=E0,d=T0,S=A0;return n!=null&&(n.unstable_strictMode===!0&&(a=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onUncaughtError!==void 0&&(u=n.onUncaughtError),n.onCaughtError!==void 0&&(d=n.onCaughtError),n.onRecoverableError!==void 0&&(S=n.onRecoverableError)),n=sx(t,1,!1,null,null,a,o,null,u,d,S,gx),t[Zn]=n.current,$f(t),new vd(n)},Yo.hydrateRoot=function(t,n,a){if(!l(t))throw Error(s(299));var o=!1,u="",d=E0,S=T0,D=A0,j=null;return a!=null&&(a.unstable_strictMode===!0&&(o=!0),a.identifierPrefix!==void 0&&(u=a.identifierPrefix),a.onUncaughtError!==void 0&&(d=a.onUncaughtError),a.onCaughtError!==void 0&&(S=a.onCaughtError),a.onRecoverableError!==void 0&&(D=a.onRecoverableError),a.formState!==void 0&&(j=a.formState)),n=sx(t,1,!0,n,a??null,o,u,j,d,S,D,gx),n.context=rx(null),a=n.current,o=pi(),o=no(o),u=ka(o),u.callback=null,ja(a,u,o),a=o,n.current.lanes=a,et(n,a),qi(n),t[Zn]=n.current,$f(t),new Mc(n)},Yo.version="19.2.8",Yo}var wx;function Wb(){if(wx)return bd.exports;wx=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),bd.exports=Xb(),bd.exports}var qb=Wb();const Yb="modulepreload",Zb=function(r){return"/"+r},Cx={},lp=function(e,i,s){let l=Promise.resolve();if(i&&i.length>0){let f=function(h){return Promise.all(h.map(v=>Promise.resolve(v).then(x=>({status:"fulfilled",value:x}),x=>({status:"rejected",reason:x}))))};document.getElementsByTagName("link");const p=document.querySelector("meta[property=csp-nonce]"),m=(p==null?void 0:p.nonce)||(p==null?void 0:p.getAttribute("nonce"));l=f(i.map(h=>{if(h=Zb(h),h in Cx)return;Cx[h]=!0;const v=h.endsWith(".css"),x=v?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${h}"]${x}`))return;const g=document.createElement("link");if(g.rel=v?"stylesheet":Yb,v||(g.as="script"),g.crossOrigin="",g.href=h,m&&g.setAttribute("nonce",m),document.head.appendChild(g),v)return new Promise((M,w)=>{g.addEventListener("load",M),g.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${h}`)))})}))}function c(f){const p=new Event("vite:preloadError",{cancelable:!0});if(p.payload=f,window.dispatchEvent(p),!p.defaultPrevented)throw f}return l.then(f=>{for(const p of f||[])p.status==="rejected"&&c(p.reason);return e().catch(c)})};/*! Capacitor: https://capacitorjs.com/ - MIT License */var qr;(function(r){r.Unimplemented="UNIMPLEMENTED",r.Unavailable="UNAVAILABLE"})(qr||(qr={}));class Td extends Error{constructor(e,i,s){super(e),this.message=e,this.code=i,this.data=s}}const Kb=r=>{var e,i;return r!=null&&r.androidBridge?"android":!((i=(e=r==null?void 0:r.webkit)===null||e===void 0?void 0:e.messageHandlers)===null||i===void 0)&&i.bridge?"ios":"web"},Qb=r=>{const e=r.CapacitorCustomPlatform||null,i=r.Capacitor||{},s=i.Plugins=i.Plugins||{},l=()=>e!==null?e.name:Kb(r),c=()=>l()!=="web",f=x=>{const g=h.get(x);return!!(g!=null&&g.platforms.has(l())||p(x))},p=x=>{var g;return(g=i.PluginHeaders)===null||g===void 0?void 0:g.find(M=>M.name===x)},m=x=>r.console.error(x),h=new Map,v=(x,g={})=>{const M=h.get(x);if(M)return console.warn(`Capacitor plugin "${x}" already registered. Cannot register plugins twice.`),M.proxy;const w=l(),R=p(x);let b;const y=async()=>(!b&&w in g?b=typeof g[w]=="function"?b=await g[w]():b=g[w]:e!==null&&!b&&"web"in g&&(b=typeof g.web=="function"?b=await g.web():b=g.web),b),P=(T,U)=>{var V,k;if(R){const W=R==null?void 0:R.methods.find(re=>U===re.name);if(W)return W.rtype==="promise"?re=>i.nativePromise(x,U.toString(),re):(re,oe)=>i.nativeCallback(x,U.toString(),re,oe);if(T)return(V=T[U])===null||V===void 0?void 0:V.bind(T)}else{if(T)return(k=T[U])===null||k===void 0?void 0:k.bind(T);throw new Td(`"${x}" plugin is not implemented on ${w}`,qr.Unimplemented)}},O=T=>{let U;const V=(...k)=>{const W=y().then(re=>{const oe=P(re,T);if(oe){const te=oe(...k);return U=te==null?void 0:te.remove,te}else throw new Td(`"${x}.${T}()" is not implemented on ${w}`,qr.Unimplemented)});return T==="addListener"&&(W.remove=async()=>U()),W};return V.toString=()=>`${T.toString()}() { [capacitor code] }`,Object.defineProperty(V,"name",{value:T,writable:!1,configurable:!1}),V},C=O("addListener"),I=O("removeListener"),L=(T,U)=>{const V=C({eventName:T},U),k=async()=>{const re=await V;I({eventName:T,callbackId:re},U)},W=new Promise(re=>V.then(()=>re({remove:k})));return W.remove=async()=>{console.warn("Using addListener() without 'await' is deprecated."),await k()},W},F=new Proxy({},{get(T,U){switch(U){case"$$typeof":return;case"toJSON":return()=>({});case"addListener":return R?L:C;case"removeListener":return I;default:return O(U)}}});return s[x]=F,h.set(x,{name:x,proxy:F,platforms:new Set([...Object.keys(g),...R?[w]:[]])}),F};return i.convertFileSrc||(i.convertFileSrc=x=>x),i.getPlatform=l,i.handleError=m,i.isNativePlatform=c,i.isPluginAvailable=f,i.registerPlugin=v,i.Exception=Td,i.DEBUG=!!i.DEBUG,i.isLoggingEnabled=!!i.isLoggingEnabled,i},Jb=r=>r.Capacitor=Qb(r),oh=Jb(typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{}),Ys=oh.registerPlugin;class cp{constructor(){this.listeners={},this.retainedEventArguments={},this.windowListeners={}}addListener(e,i){let s=!1;this.listeners[e]||(this.listeners[e]=[],s=!0),this.listeners[e].push(i);const c=this.windowListeners[e];c&&!c.registered&&this.addWindowListener(c),s&&this.sendRetainedArgumentsForEvent(e);const f=async()=>this.removeListener(e,i);return Promise.resolve({remove:f})}async removeAllListeners(){this.listeners={};for(const e in this.windowListeners)this.removeWindowListener(this.windowListeners[e]);this.windowListeners={}}notifyListeners(e,i,s){const l=this.listeners[e];if(!l){if(s){let c=this.retainedEventArguments[e];c||(c=[]),c.push(i),this.retainedEventArguments[e]=c}return}l.forEach(c=>c(i))}hasListeners(e){var i;return!!(!((i=this.listeners[e])===null||i===void 0)&&i.length)}registerWindowListener(e,i){this.windowListeners[i]={registered:!1,windowEventName:e,pluginEventName:i,handler:s=>{this.notifyListeners(i,s)}}}unimplemented(e="not implemented"){return new oh.Exception(e,qr.Unimplemented)}unavailable(e="not available"){return new oh.Exception(e,qr.Unavailable)}async removeListener(e,i){const s=this.listeners[e];if(!s)return;const l=s.indexOf(i);this.listeners[e].splice(l,1),this.listeners[e].length||this.removeWindowListener(this.windowListeners[e])}addWindowListener(e){window.addEventListener(e.windowEventName,e.handler),e.registered=!0}removeWindowListener(e){e&&(window.removeEventListener(e.windowEventName,e.handler),e.registered=!1)}sendRetainedArgumentsForEvent(e){const i=this.retainedEventArguments[e];i&&(delete this.retainedEventArguments[e],i.forEach(s=>{this.notifyListeners(e,s)}))}}const Rx=r=>encodeURIComponent(r).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape),Nx=r=>r.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);class $b extends cp{async getCookies(){const e=document.cookie,i={};return e.split(";").forEach(s=>{if(s.length<=0)return;let[l,c]=s.replace(/=/,"CAP_COOKIE").split("CAP_COOKIE");l=Nx(l).trim(),c=Nx(c).trim(),i[l]=c}),i}async setCookie(e){try{const i=Rx(e.key),s=Rx(e.value),l=e.expires?`; expires=${e.expires.replace("expires=","")}`:"",c=(e.path||"/").replace("path=",""),f=e.url!=null&&e.url.length>0?`domain=${e.url}`:"";document.cookie=`${i}=${s||""}${l}; path=${c}; ${f};`}catch(i){return Promise.reject(i)}}async deleteCookie(e){try{document.cookie=`${e.key}=; Max-Age=0`}catch(i){return Promise.reject(i)}}async clearCookies(){try{const e=document.cookie.split(";")||[];for(const i of e)document.cookie=i.replace(/^ +/,"").replace(/=.*/,`=;expires=${new Date().toUTCString()};path=/`)}catch(e){return Promise.reject(e)}}async clearAllCookies(){try{await this.clearCookies()}catch(e){return Promise.reject(e)}}}Ys("CapacitorCookies",{web:()=>new $b});const eS=async r=>new Promise((e,i)=>{const s=new FileReader;s.onload=()=>{const l=s.result;e(l.indexOf(",")>=0?l.split(",")[1]:l)},s.onerror=l=>i(l),s.readAsDataURL(r)}),tS=(r={})=>{const e=Object.keys(r);return Object.keys(r).map(l=>l.toLocaleLowerCase()).reduce((l,c,f)=>(l[c]=r[e[f]],l),{})},nS=(r,e=!0)=>r?Object.entries(r).reduce((s,l)=>{const[c,f]=l;let p,m;return Array.isArray(f)?(m="",f.forEach(h=>{p=e?encodeURIComponent(h):h,m+=`${c}=${p}&`}),m.slice(0,-1)):(p=e?encodeURIComponent(f):f,m=`${c}=${p}`),`${s}&${m}`},"").substr(1):null,iS=(r,e={})=>{const i=Object.assign({method:r.method||"GET",headers:r.headers},e),l=tS(r.headers)["content-type"]||"";if(typeof r.data=="string")i.body=r.data;else if(l.includes("application/x-www-form-urlencoded")){const c=new URLSearchParams;for(const[f,p]of Object.entries(r.data||{}))c.set(f,p);i.body=c.toString()}else if(l.includes("multipart/form-data")||r.data instanceof FormData){const c=new FormData;if(r.data instanceof FormData)r.data.forEach((p,m)=>{c.append(m,p)});else for(const p of Object.keys(r.data))c.append(p,r.data[p]);i.body=c;const f=new Headers(i.headers);f.delete("content-type"),i.headers=f}else(l.includes("application/json")||typeof r.data=="object")&&(i.body=JSON.stringify(r.data));return i};class aS extends cp{async request(e){const i=iS(e,e.webFetchExtra),s=nS(e.params,e.shouldEncodeUrlParams),l=s?`${e.url}?${s}`:e.url,c=await fetch(l,i),f=c.headers.get("content-type")||"";let{responseType:p="text"}=c.ok?e:{};f.includes("application/json")&&(p="json");let m,h;switch(p){case"arraybuffer":case"blob":h=await c.blob(),m=await eS(h);break;case"json":m=await c.json();break;case"document":case"text":default:m=await c.text()}const v={};return c.headers.forEach((x,g)=>{v[g]=x}),{data:m,headers:v,status:c.status,url:c.url}}async get(e){return this.request(Object.assign(Object.assign({},e),{method:"GET"}))}async post(e){return this.request(Object.assign(Object.assign({},e),{method:"POST"}))}async put(e){return this.request(Object.assign(Object.assign({},e),{method:"PUT"}))}async patch(e){return this.request(Object.assign(Object.assign({},e),{method:"PATCH"}))}async delete(e){return this.request(Object.assign(Object.assign({},e),{method:"DELETE"}))}}Ys("CapacitorHttp",{web:()=>new aS});var Dx;(function(r){r.Dark="DARK",r.Light="LIGHT",r.Default="DEFAULT"})(Dx||(Dx={}));var Ux;(function(r){r.StatusBar="StatusBar",r.NavigationBar="NavigationBar"})(Ux||(Ux={}));class sS extends cp{async setStyle(){this.unavailable("not available for web")}async setAnimation(){this.unavailable("not available for web")}async show(){this.unavailable("not available for web")}async hide(){this.unavailable("not available for web")}}Ys("SystemBars",{web:()=>new sS});const Lx=Ys("App",{web:()=>lp(()=>import("./web-CetN9fkf.js"),[]).then(r=>new r.AppWeb)}),rS=Ys("SplashScreen",{web:()=>lp(()=>import("./web-MTAsnlfk.js"),[]).then(r=>new r.SplashScreenWeb)});var lh;(function(r){r.Dark="DARK",r.Light="LIGHT",r.Default="DEFAULT"})(lh||(lh={}));var Ox;(function(r){r.None="NONE",r.Slide="SLIDE",r.Fade="FADE"})(Ox||(Ox={}));const Px=Ys("StatusBar"),Ix=[{id:1,name:"Green Valley",description:"Lush rolling hills, wooden arches, and sunlit roads.",minLevel:1,maxLevel:50,skyColor:"#38bdf8",groundColor:"#15803d",fogColor:"#bfe0ff",accentColor:"#22c55e",obstacleType:"wooden-fences-trains",bgMusicTrack:"upbeat-grassland",weather:"clear",timeOfDay:"day",iconName:"Trees"},{id:2,name:"Modern City",description:"Towering skyscrapers, neon signs, moving buses, and traffic lights.",minLevel:51,maxLevel:100,skyColor:"#1e1b4b",groundColor:"#334155",fogColor:"#312e81",accentColor:"#818cf8",obstacleType:"buses-barriers-traffic",bgMusicTrack:"city-groove",weather:"clear",timeOfDay:"neon-night",iconName:"Building2"},{id:3,name:"Snow Mountain",description:"Icy cliffs, falling avalanches, slippery bends, and snowmen.",minLevel:101,maxLevel:150,skyColor:"#e0f2fe",groundColor:"#f1f5f9",fogColor:"#cbd5e1",accentColor:"#38bdf8",obstacleType:"ice-blocks-avalanches",bgMusicTrack:"winter-drive",weather:"snow",timeOfDay:"day",iconName:"Snowflake"},{id:4,name:"Golden Desert",description:"Ancient pyramids, towering cacti, dunes, and sandstorms.",minLevel:151,maxLevel:200,skyColor:"#fde047",groundColor:"#d97706",fogColor:"#f59e0b",accentColor:"#eab308",obstacleType:"cactus-sand-ruins",bgMusicTrack:"desert-heat",weather:"sandstorm",timeOfDay:"sunset",iconName:"Sun"},{id:5,name:"Jungle Canopy",description:"Thick foliage, ancient stone traps, wooden suspension bridges.",minLevel:201,maxLevel:250,skyColor:"#14532d",groundColor:"#166534",fogColor:"#052e16",accentColor:"#4ade80",obstacleType:"vines-falling-logs-temples",bgMusicTrack:"jungle-beat",weather:"rain",timeOfDay:"day",iconName:"Palmtree"},{id:6,name:"Volcano Core",description:"Lava streams, molten rock hazards, glowing brimstone clouds.",minLevel:251,maxLevel:300,skyColor:"#450a0a",groundColor:"#1c1917",fogColor:"#7f1d1d",accentColor:"#ef4444",obstacleType:"lava-pits-falling-meteors",bgMusicTrack:"volcano-fury",weather:"clear",timeOfDay:"night",iconName:"Flame"},{id:7,name:"Sky Islands",description:"Floating clouds, rainbow laser paths, sky currents.",minLevel:301,maxLevel:350,skyColor:"#a5f3fc",groundColor:"#a855f7",fogColor:"#e0e7ff",accentColor:"#06b6d4",obstacleType:"cloud-barriers-laser-bridges",bgMusicTrack:"heavenly-glide",weather:"clear",timeOfDay:"day",iconName:"Cloud"},{id:8,name:"Space Highway",description:"Zero-G gravity tracks, floating orbital meteors, planetary horizons.",minLevel:351,maxLevel:400,skyColor:"#09090b",groundColor:"#18181b",fogColor:"#27272a",accentColor:"#ec4899",obstacleType:"space-debris-laser-gates",bgMusicTrack:"space-odyssey",weather:"clear",timeOfDay:"night",iconName:"Rocket"},{id:9,name:"Neon Cyber City",description:"Synthwave highways, holographic barriers, speed boosts.",minLevel:401,maxLevel:500,skyColor:"#2e1065",groundColor:"#0284c7",fogColor:"#581c87",accentColor:"#f43f5e",obstacleType:"holo-walls-cyber-drones",bgMusicTrack:"synth-surge",weather:"cyber-fog",timeOfDay:"neon-night",iconName:"Zap"},{id:10,name:"Crystal World",description:"Prismatic crystal caves, glowing geometry, glass bridges.",minLevel:501,maxLevel:650,skyColor:"#312e81",groundColor:"#4338ca",fogColor:"#4f46e5",accentColor:"#c084fc",obstacleType:"crystal-spikes-light-barriers",bgMusicTrack:"crystal-chimes",weather:"clear",timeOfDay:"day",iconName:"Gem"},{id:11,name:"Mystic Temple",description:"Ancient ruins, swinging pendulums, boulder traps.",minLevel:651,maxLevel:800,skyColor:"#78350f",groundColor:"#451a03",fogColor:"#92400e",accentColor:"#f59e0b",obstacleType:"stone-pendulums-spikes",bgMusicTrack:"mystic-rhythm",weather:"clear",timeOfDay:"sunset",iconName:"Shield"},{id:12,name:"Ocean Bridge",description:"Suspension bridge across crashing ocean waves, speed ramps.",minLevel:801,maxLevel:1e3,skyColor:"#0284c7",groundColor:"#0369a1",fogColor:"#7dd3fc",accentColor:"#38bdf8",obstacleType:"wave-splashes-roadblocks",bgMusicTrack:"ocean-drive",weather:"clear",timeOfDay:"day",iconName:"Waves"}],sl=[{id:"char-explorer",name:"Alex Explorer",title:"Trailblazer",rarity:"common",description:"Agile runner with balanced agility and steady speed.",price:0,currency:"coins",perk:"+10% Coin Magnet Radius",perkStat:{type:"magnetRadius",value:1.1},baseSpeed:12,jumpForce:15,dashCooldown:5,avatarUrl:"🏃‍♂️",color:"#3b82f6",accentColor:"#60a5fa",skins:[{id:"default",name:"Classic Blue",color:"#3b82f6",price:0},{id:"crimson",name:"Crimson Explorer",color:"#ef4444",price:1e3},{id:"stealth",name:"Midnight Stealth",color:"#1e293b",price:2500}]},{id:"char-cyber",name:"Kira Cyber",title:"Neon Runner",rarity:"rare",description:"Enhanced with cybernetic legs for hyper jumps and fast dash.",price:5e3,currency:"coins",perk:"+20% Jetpack Duration",perkStat:{type:"jetpackDuration",value:1.2},baseSpeed:14,jumpForce:17,dashCooldown:4,avatarUrl:"⚡",color:"#a855f7",accentColor:"#c084fc",skins:[{id:"default",name:"Neon Purple",color:"#a855f7",price:0},{id:"gold",name:"Cyber Gold",color:"#eab308",price:3e3}]},{id:"char-ninja",name:"Shadow Ninja",title:"Silent Dash",rarity:"rare",description:"Master of double jumping and wall jumps with quick recovery.",price:12e3,currency:"coins",perk:"Extra Double Jump",perkStat:{type:"extraJump",value:1},baseSpeed:15,jumpForce:18,dashCooldown:3.5,avatarUrl:"🥷",color:"#0f172a",accentColor:"#38bdf8",skins:[{id:"default",name:"Shadow Black",color:"#0f172a",price:0},{id:"blood",name:"Blood Moon",color:"#dc2626",price:4e3}]},{id:"char-robot",name:"Mecha V-8",title:"Steel Titan",rarity:"epic",description:"Heavy armored robot that starts every level with an active Shield.",price:150,currency:"gems",perk:"Free Shield at Level Start",perkStat:{type:"freeShield",value:1},baseSpeed:13,jumpForce:16,dashCooldown:4,avatarUrl:"🤖",color:"#64748b",accentColor:"#06b6d4",skins:[{id:"default",name:"Titanium Steel",color:"#64748b",price:0},{id:"chrome",name:"Ultra Chrome",color:"#f8fafc",price:50}]},{id:"char-astronaut",name:"Cosmic Nova",title:"Star Surfer",rarity:"epic",description:"Low-gravity suit allows floaty jumps and double coin drops.",price:25e3,currency:"coins",perk:"+25% Coin Multiplier",perkStat:{type:"coinMultiplier",value:1.25},baseSpeed:14,jumpForce:19,dashCooldown:4.5,avatarUrl:"👨‍🚀",color:"#0284c7",accentColor:"#e0f2fe",skins:[{id:"default",name:"Apollo Suit",color:"#0284c7",price:0},{id:"nebula",name:"Nebula Glow",color:"#f43f5e",price:6e3}]},{id:"char-pirate",name:"Cap’n Skull",title:"Treasure Hunter",rarity:"legendary",description:"Finds Mystery Boxes 2x more often and unearths bonus keys!",price:300,currency:"gems",perk:"+100% Mystery Box Chance",perkStat:{type:"mysteryBoxBonus",value:2},baseSpeed:15,jumpForce:17,dashCooldown:3,avatarUrl:"🏴‍☠️",color:"#854d0e",accentColor:"#fef08a",skins:[{id:"default",name:"Golden Buccaneer",color:"#854d0e",price:0}]},{id:"char-ghost",name:"Phantom Void",title:"Spectral Entity",rarity:"mythic",description:"Passes directly through barriers during dash phase.",price:500,currency:"gems",perk:"Invulnerable Dash",perkStat:{type:"dashInvulnerability",value:1},baseSpeed:16,jumpForce:20,dashCooldown:2.5,avatarUrl:"👻",color:"#c084fc",accentColor:"#f43f5e",skins:[{id:"default",name:"Ethereal Glow",color:"#c084fc",price:0}]}],rl=[{id:"car-sports",name:"Velocity GT",type:"Sports Coupe",rarity:"common",description:"Nimble sports car with swift acceleration and responsive handling.",price:0,currency:"coins",topSpeed:65,acceleration:70,handling:75,nitroDuration:60,bodyColor:"#ef4444",secondaryColor:"#1e293b",unlockedByDefault:!0},{id:"car-suv",name:"Mammoth 4x4",type:"Heavy SUV",rarity:"common",description:"Rugged terrain vehicle that withstands minor traffic collisions.",price:8e3,currency:"coins",topSpeed:60,acceleration:60,handling:65,nitroDuration:75,bodyColor:"#15803d",secondaryColor:"#f59e0b"},{id:"car-electric",name:"Volt Hyper EV",type:"Electric Supercar",rarity:"rare",description:"Instant torque and silent electric nitro boost.",price:18e3,currency:"coins",topSpeed:82,acceleration:92,handling:80,nitroDuration:70,bodyColor:"#0ea5e9",secondaryColor:"#38bdf8"},{id:"car-formula",name:"Apex F1 Racer",type:"Formula Racer",rarity:"epic",description:"Extreme downforce for precision drifting at maximum speed.",price:150,currency:"gems",topSpeed:95,acceleration:88,handling:90,nitroDuration:80,bodyColor:"#eab308",secondaryColor:"#0f172a"},{id:"car-monster",name:"Crusher Truck",type:"Monster Truck",rarity:"epic",description:"Giant wheels roll over small obstacles without slowing down.",price:35e3,currency:"coins",topSpeed:70,acceleration:75,handling:60,nitroDuration:85,bodyColor:"#a855f7",secondaryColor:"#22c55e"},{id:"car-hover",name:"Zenith Hover",type:"Hovercraft",rarity:"legendary",description:"Floats above track hazards with smooth magnetic drift.",price:350,currency:"gems",topSpeed:98,acceleration:95,handling:95,nitroDuration:90,bodyColor:"#06b6d4",secondaryColor:"#ec4899"},{id:"car-cyber",name:"Cyber Blade 2099",type:"Cyber Racer",rarity:"mythic",description:"Fires plasma trails and features infinite nitro regeneration.",price:600,currency:"gems",topSpeed:100,acceleration:100,handling:98,nitroDuration:100,bodyColor:"#f43f5e",secondaryColor:"#c084fc"}],ch=[{id:"m-1",type:"daily",title:"Coin Collector",description:"Collect 250 coins in any game mode.",target:250,current:0,rewardType:"coins",rewardAmount:500,completed:!1,claimed:!1},{id:"m-2",type:"daily",title:"High Jumper",description:"Perform 20 jumps in Runner Mode.",target:20,current:0,rewardType:"coins",rewardAmount:350,completed:!1,claimed:!1},{id:"m-3",type:"daily",title:"Road Warrior",description:"Drive 2000 meters in Car Mode.",target:2e3,current:0,rewardType:"gems",rewardAmount:15,completed:!1,claimed:!1},{id:"m-4",type:"weekly",title:"World Explorer",description:"Complete 10 levels with 3 stars.",target:10,current:0,rewardType:"gems",rewardAmount:50,completed:!1,claimed:!1},{id:"m-5",type:"weekly",title:"Speed Demon",description:"Activate Nitro boost 15 times in Car Mode.",target:15,current:0,rewardType:"keys",rewardAmount:3,completed:!1,claimed:!1},{id:"m-6",type:"seasonal",title:"Route Rush Champion",description:"Reach Level 50 in world progression.",target:50,current:1,rewardType:"gems",rewardAmount:200,completed:!1,claimed:!1}],uh=[{id:"ach-1",title:"First Rush",description:"Complete your first level in Route Rush.",category:"levels",target:1,current:0,rewardType:"coins",rewardAmount:1e3,completed:!1,claimed:!1,icon:"Trophy"},{id:"ach-2",title:"Coin Hoarder",description:"Collect 10,000 total coins across all games.",category:"economy",target:1e4,current:0,rewardType:"gems",rewardAmount:50,completed:!1,claimed:!1,icon:"Coins"},{id:"ach-3",title:"Garage Master",description:"Unlock 3 different cars.",category:"collection",target:3,current:1,rewardType:"keys",rewardAmount:5,completed:!1,claimed:!1,icon:"Car"},{id:"ach-4",title:"World Traveler",description:"Unlock 5 different worlds.",category:"levels",target:5,current:1,rewardType:"gems",rewardAmount:100,completed:!1,claimed:!1,icon:"Globe"},{id:"ach-5",title:"Sky High Jumper",description:"Perform 100 jumps in Runner Mode.",category:"runner",target:100,current:0,rewardType:"coins",rewardAmount:2500,completed:!1,claimed:!1,icon:"Activity"},{id:"ach-6",title:"Drift Legend",description:"Drive 50,000 total meters in Car Mode.",category:"racer",target:5e4,current:0,rewardType:"gems",rewardAmount:150,completed:!1,claimed:!1,icon:"Flame"}],oS=[{id:"shop-char-cyber",name:"Kira Cyber",category:"character",rarity:"rare",price:5e3,currency:"coins",icon:"⚡",description:"Agile cybernetic runner with enhanced jump capabilities.",featured:!0,itemRefId:"char-cyber"},{id:"shop-car-electric",name:"Volt Hyper EV",category:"car",rarity:"rare",price:18e3,currency:"coins",icon:"🏎️",description:"Instant electric acceleration and smooth handling.",featured:!0,itemRefId:"car-electric"},{id:"shop-car-formula",name:"Apex F1 Racer",category:"car",rarity:"epic",price:150,currency:"gems",icon:"🏎️",description:"Extreme speed and high downforce drifting.",featured:!0,itemRefId:"car-formula"},{id:"shop-gems-100",name:"Handful of Gems",category:"gems",rarity:"common",price:1e4,currency:"coins",amount:100,icon:"💎",description:"Exchange 10,000 coins for 100 sparkling Gems."},{id:"shop-gems-500",name:"Gem Chest",category:"gems",rarity:"epic",price:45e3,currency:"coins",amount:500,icon:"💎",discount:10,description:"Exchange 45,000 coins for 500 Gems (10% Bonus!).",featured:!0},{id:"shop-coins-50k",name:"Bag of Gold",category:"coins",rarity:"rare",price:100,currency:"gems",amount:5e4,icon:"💰",description:"Get 50,000 Coins using 100 Gems."},{id:"shop-bundle-starter",name:"Starter Super Bundle",category:"bundle",rarity:"legendary",price:200,currency:"gems",icon:"🎁",description:"Includes 20,000 Coins, 5 Keys, and 2 Rare Mystery Boxes!",discount:50,featured:!0}],up="route_rush_player_profile",fp="route_rush_game_settings",dp="route_rush_missions",hp="route_rush_achievements",pp="route_rush_notifications",fh={id:"guest_"+Math.random().toString(36).substring(2,9),isGuest:!0,username:"RacerGuest",avatar:"🏃‍♂️",level:1,xp:0,maxXp:500,coins:1e3,gems:20,keys:1,eventTokens:0,energy:50,maxEnergy:50,selectedCharacterId:"char-explorer",selectedCarId:"car-sports",unlockedCharacters:["char-explorer"],unlockedCars:["car-sports"],characterSkins:{"char-explorer":"default"},carPaints:{"car-sports":"#ef4444"},carNeon:{"car-sports":"#00f0ff"},carUpgrades:{"car-sports":{engine:1,nitro:1,handling:1,brakes:1,suspension:1}},equippedPets:{},equippedTrails:{},completedLevels:{},currentLevel:1,highScoreRunner:0,highScoreRacer:0,totalCoinsCollected:0,totalDistanceDriven:0,totalJumps:0,totalLevelsCompleted:0,dailyStreak:1,lastLoginDate:new Date().toISOString().split("T")[0],savedAt:new Date().toISOString()};function Rr(r="RacerGuest"){return{...fh,id:"guest_"+Math.random().toString(36).substring(2,9),username:r,energy:50,maxEnergy:50,coins:1e3,gems:20,keys:1,level:1,xp:0,maxXp:500,selectedCharacterId:"char-explorer",selectedCarId:"car-sports",unlockedCharacters:["char-explorer"],unlockedCars:["car-sports"],carPaints:{"car-sports":"#ef4444"},carNeon:{"car-sports":"#00f0ff"},carUpgrades:{"car-sports":{engine:1,nitro:1,handling:1,brakes:1,suspension:1}},completedLevels:{},currentLevel:1,highScoreRunner:0,highScoreRacer:0,totalCoinsCollected:0,totalDistanceDriven:0,totalJumps:0,totalLevelsCompleted:0,dailyStreak:1,savedAt:new Date().toISOString()}}function zx(){try{localStorage.removeItem(up),localStorage.removeItem(fp),localStorage.removeItem(dp),localStorage.removeItem(hp),localStorage.removeItem(pp),localStorage.removeItem("route_rush_launched"),localStorage.clear()}catch(r){console.warn("Failed to reset storage:",r)}}const eu={musicVolume:.5,sfxVolume:.8,graphicsQuality:"high",fpsLimit:60,controlsMode:"touch",language:"en",deviceFrame:!1,vibration:!0,cloudSync:!0},dh=[{id:"n-1",title:"Daily Welcome Bonus!",message:"Claim 500 Coins & 10 Gems for logging in today!",time:"Just now",type:"reward",read:!1,claimableReward:{type:"coins",amount:500}},{id:"n-2",title:"Seasonal Event Live: Cyber Rush!",message:"Participate in the Neon Cyber City tournament for exclusive rewards.",time:"2 hours ago",type:"event",read:!1},{id:"n-3",title:"Level 5 Milestone Unlocked!",message:"You have unlocked World 1 Green Valley challenges.",time:"1 day ago",type:"system",read:!0}];function lS(){try{const r=localStorage.getItem(up);if(r){const e=JSON.parse(r);return(!e.maxEnergy||e.maxEnergy<50)&&(e.maxEnergy=50),(typeof e.energy!="number"||e.energy<50)&&(e.energy=50),{...fh,...e}}}catch(r){console.warn("Failed to load profile from storage:",r)}return{...fh,energy:50,maxEnergy:50}}function Zo(r){try{const e={...r,savedAt:new Date().toISOString()};localStorage.setItem(up,JSON.stringify(e))}catch(e){console.warn("Failed to save profile:",e)}}function cS(){try{const r=localStorage.getItem(fp);if(r)return{...eu,...JSON.parse(r)}}catch(r){console.warn("Failed to load settings:",r)}return eu}function Fx(r){try{localStorage.setItem(fp,JSON.stringify(r))}catch(e){console.warn("Failed to save settings:",e)}}function uS(){try{const r=localStorage.getItem(dp);if(r)return JSON.parse(r)}catch(r){console.warn("Failed to load missions:",r)}return ch}function Bx(r){try{localStorage.setItem(dp,JSON.stringify(r))}catch(e){console.warn("Failed to save missions:",e)}}function fS(){try{const r=localStorage.getItem(hp);if(r)return JSON.parse(r)}catch(r){console.warn("Failed to load achievements:",r)}return uh}function Gx(r){try{localStorage.setItem(hp,JSON.stringify(r))}catch(e){console.warn("Failed to save achievements:",e)}}function dS(){try{const r=localStorage.getItem(pp);if(r)return JSON.parse(r)}catch(r){console.warn("Failed to load notifications:",r)}return dh}function Hx(r){try{localStorage.setItem(pp,JSON.stringify(r))}catch(e){console.warn("Failed to save notifications:",e)}}function mp(r){const e=Math.min(Math.floor((r-1)/50),Ix.length-1);return Ix[e]}function jv(r,e){const i=mp(r),s=e||(r%2===1?"runner":"racer"),l=300+r*15,c=20+Math.floor(r*1.5),f=1+r*.005,p=Math.min(.2+r*.001,.85),m=Math.min(1+r*.002,2.2),h=100+Math.floor(r*8),v=50+Math.floor(r*4),x=r%5===0?Math.min(5+Math.floor(r/10),50):void 0;return{levelNumber:r,worldId:i.id,mode:s,targetDistance:Math.round(l),targetCoins:c,difficultyMultiplier:f,obstacleDensity:p,speedMultiplier:m,rewardCoins:h,rewardXp:v,rewardGems:x}}/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hS=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),pS=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,i,s)=>s?s.toUpperCase():i.toLowerCase()),Vx=r=>{const e=pS(r);return e.charAt(0).toUpperCase()+e.slice(1)},Xv=(...r)=>r.filter((e,i,s)=>!!e&&e.trim()!==""&&s.indexOf(e)===i).join(" ").trim(),mS=r=>{for(const e in r)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var gS={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xS=st.forwardRef(({color:r="currentColor",size:e=24,strokeWidth:i=2,absoluteStrokeWidth:s,className:l="",children:c,iconNode:f,...p},m)=>st.createElement("svg",{ref:m,...gS,width:e,height:e,stroke:r,strokeWidth:s?Number(i)*24/Number(e):i,className:Xv("lucide",l),...!c&&!mS(p)&&{"aria-hidden":"true"},...p},[...f.map(([h,v])=>st.createElement(h,v)),...Array.isArray(c)?c:[c]]));/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wt=(r,e)=>{const i=st.forwardRef(({className:s,...l},c)=>st.createElement(xS,{ref:c,iconNode:e,className:Xv(`lucide-${hS(Vx(r))}`,`lucide-${r}`,s),...l}));return i.displayName=Vx(r),i};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vS=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],_S=wt("arrow-down",vS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yS=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],bS=wt("arrow-left",yS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const SS=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],MS=wt("arrow-right",SS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ES=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],TS=wt("arrow-up",ES);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const AS=[["path",{d:"M 22 14 L 22 10",key:"nqc4tb"}],["rect",{x:"2",y:"6",width:"16",height:"12",rx:"2",key:"13zb55"}]],wS=wt("battery",AS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const CS=[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]],Wv=wt("bell",CS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const RS=[["path",{d:"M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",key:"5owen"}],["circle",{cx:"7",cy:"17",r:"2",key:"u2ysq9"}],["path",{d:"M9 17h6",key:"r8uit2"}],["circle",{cx:"17",cy:"17",r:"2",key:"axvx0g"}]],NS=wt("car",RS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const DS=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],gp=wt("check",DS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const US=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],LS=wt("circle-check",US);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const OS=[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],PS=wt("clock",OS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const IS=[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",key:"p7xjir"}]],zS=wt("cloud",IS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const FS=[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]],Zs=wt("coins",FS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const BS=[["path",{d:"M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",key:"1slcih"}]],GS=wt("flame",BS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const HS=[["path",{d:"M10.5 3 8 9l4 13 4-13-2.5-6",key:"b3dvk1"}],["path",{d:"M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z",key:"7w4byz"}],["path",{d:"M2 9h20",key:"16fsjt"}]],Jr=wt("gem",HS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const VS=[["rect",{x:"3",y:"8",width:"18",height:"4",rx:"1",key:"bkv52"}],["path",{d:"M12 8v13",key:"1c76mn"}],["path",{d:"M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7",key:"6wjy6b"}],["path",{d:"M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5",key:"1ihvrl"}]],hh=wt("gift",VS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kS=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]],qv=wt("house",kS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jS=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],XS=wt("key-round",jS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const WS=[["path",{d:"m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4",key:"g0fldk"}],["path",{d:"m21 2-9.6 9.6",key:"1j0ho8"}],["circle",{cx:"7.5",cy:"15.5",r:"5.5",key:"yqb3hr"}]],qS=wt("key",WS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const YS=[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]],ZS=wt("lock",YS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const KS=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],QS=wt("log-out",KS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const JS=[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]],$S=wt("monitor",JS);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const eM=[["rect",{x:"14",y:"3",width:"5",height:"18",rx:"1",key:"kaeet6"}],["rect",{x:"5",y:"3",width:"5",height:"18",rx:"1",key:"1wsw3u"}]],tM=wt("pause",eM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nM=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],xp=wt("play",nM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const iM=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],aM=wt("rotate-ccw",iM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sM=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],rM=wt("settings",sM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const oM=[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]],Yv=wt("shopping-bag",oM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lM=[["path",{d:"M2 20h.01",key:"4haj6o"}],["path",{d:"M7 20v-4",key:"j294jx"}],["path",{d:"M12 20v-8",key:"i3yub9"}],["path",{d:"M17 20V8",key:"1tkaf5"}],["path",{d:"M22 4v16",key:"sih9yq"}]],cM=wt("signal",lM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const uM=[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]],fM=wt("smartphone",uM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dM=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],fl=wt("sparkles",dM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hM=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]],Zv=wt("target",hM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pM=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],mM=wt("triangle-alert",pM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gM=[["path",{d:"M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978",key:"1n3hpd"}],["path",{d:"M14 14.66v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978",key:"rfe1zi"}],["path",{d:"M18 9h1.5a1 1 0 0 0 0-5H18",key:"7xy6bh"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z",key:"1mhfuq"}],["path",{d:"M6 9H4.5a1 1 0 0 1 0-5H6",key:"tex48p"}]],tu=wt("trophy",gM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xM=[["path",{d:"m16 11 2 2 4-4",key:"9rsbq5"}],["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],vM=wt("user-check",xM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _M=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],yM=wt("user",_M);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const bM=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],SM=wt("users",bM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const MM=[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]],EM=wt("volume-2",MM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const TM=[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M2 8.82a15 15 0 0 1 20 0",key:"dnpr2z"}],["path",{d:"M5 12.859a10 10 0 0 1 14 0",key:"1x1e6c"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}]],AM=wt("wifi",TM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wM=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Kv=wt("x",wM);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const CM=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],cu=wt("zap",CM);class RM{constructor(){this.ctx=null,this.musicGain=null,this.sfxGain=null,this.isMuted=!1,this.musicVolume=.5,this.sfxVolume=.8,this.activeMusicOsc=null,this.musicInterval=null}initCtx(){if(!this.ctx){const e=window.AudioContext||window.webkitAudioContext;this.ctx=new e,this.musicGain=this.ctx.createGain(),this.sfxGain=this.ctx.createGain(),this.musicGain.gain.value=this.musicVolume,this.sfxGain.gain.value=this.sfxVolume,this.musicGain.connect(this.ctx.destination),this.sfxGain.connect(this.ctx.destination)}this.ctx.state==="suspended"&&this.ctx.resume()}setVolumes(e,i){this.musicVolume=e,this.sfxVolume=i,this.musicGain&&(this.musicGain.gain.value=e),this.sfxGain&&(this.sfxGain.gain.value=i)}playClick(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=this.ctx.createOscillator(),i=this.ctx.createGain();e.type="sine",e.frequency.setValueAtTime(600,this.ctx.currentTime),e.frequency.exponentialRampToValueAtTime(800,this.ctx.currentTime+.05),i.gain.setValueAtTime(.3*this.sfxVolume,this.ctx.currentTime),i.gain.exponentialRampToValueAtTime(.01,this.ctx.currentTime+.05),e.connect(i),i.connect(this.sfxGain),e.start(),e.stop(this.ctx.currentTime+.05)}playCoin(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=this.ctx.createOscillator(),i=this.ctx.createGain();e.type="sine",e.frequency.setValueAtTime(987.77,this.ctx.currentTime),e.frequency.setValueAtTime(1318.51,this.ctx.currentTime+.06),i.gain.setValueAtTime(.25*this.sfxVolume,this.ctx.currentTime),i.gain.exponentialRampToValueAtTime(.01,this.ctx.currentTime+.15),e.connect(i),i.connect(this.sfxGain),e.start(),e.stop(this.ctx.currentTime+.15)}playGem(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=this.ctx.currentTime;[1046.5,1318.51,1567.98,2093].forEach((i,s)=>{if(!this.ctx||!this.sfxGain)return;const l=this.ctx.createOscillator(),c=this.ctx.createGain();l.type="triangle",l.frequency.setValueAtTime(i,e+s*.04),c.gain.setValueAtTime(.2*this.sfxVolume,e+s*.04),c.gain.exponentialRampToValueAtTime(.01,e+s*.04+.1),l.connect(c),c.connect(this.sfxGain),l.start(e+s*.04),l.stop(e+s*.04+.1)})}playJump(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=this.ctx.createOscillator(),i=this.ctx.createGain();e.type="square",e.frequency.setValueAtTime(200,this.ctx.currentTime),e.frequency.exponentialRampToValueAtTime(600,this.ctx.currentTime+.12),i.gain.setValueAtTime(.2*this.sfxVolume,this.ctx.currentTime),i.gain.exponentialRampToValueAtTime(.01,this.ctx.currentTime+.12),e.connect(i),i.connect(this.sfxGain),e.start(),e.stop(this.ctx.currentTime+.12)}playDash(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=this.ctx.createOscillator(),i=this.ctx.createGain();e.type="sawtooth",e.frequency.setValueAtTime(150,this.ctx.currentTime),e.frequency.exponentialRampToValueAtTime(450,this.ctx.currentTime+.2),i.gain.setValueAtTime(.3*this.sfxVolume,this.ctx.currentTime),i.gain.exponentialRampToValueAtTime(.01,this.ctx.currentTime+.2),e.connect(i),i.connect(this.sfxGain),e.start(),e.stop(this.ctx.currentTime+.2)}playNitro(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=this.ctx.createOscillator(),i=this.ctx.createGain();e.type="sawtooth",e.frequency.setValueAtTime(100,this.ctx.currentTime),e.frequency.exponentialRampToValueAtTime(800,this.ctx.currentTime+.4),i.gain.setValueAtTime(.35*this.sfxVolume,this.ctx.currentTime),i.gain.exponentialRampToValueAtTime(.01,this.ctx.currentTime+.4),e.connect(i),i.connect(this.sfxGain),e.start(),e.stop(this.ctx.currentTime+.4)}playCrash(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=this.ctx.createOscillator(),i=this.ctx.createGain();e.type="sawtooth",e.frequency.setValueAtTime(120,this.ctx.currentTime),e.frequency.exponentialRampToValueAtTime(30,this.ctx.currentTime+.35),i.gain.setValueAtTime(.4*this.sfxVolume,this.ctx.currentTime),i.gain.exponentialRampToValueAtTime(.01,this.ctx.currentTime+.35),e.connect(i),i.connect(this.sfxGain),e.start(),e.stop(this.ctx.currentTime+.35)}playChestOpen(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=[261.63,329.63,392,523.25,659.25,783.99],i=this.ctx.currentTime;e.forEach((s,l)=>{if(!this.ctx||!this.sfxGain)return;const c=this.ctx.createOscillator(),f=this.ctx.createGain();c.type="sine",c.frequency.setValueAtTime(s,i+l*.06),f.gain.setValueAtTime(.25*this.sfxVolume,i+l*.06),f.gain.exponentialRampToValueAtTime(.01,i+l*.06+.15),c.connect(f),f.connect(this.sfxGain),c.start(i+l*.06),c.stop(i+l*.06+.15)})}playVictory(){if(this.initCtx(),!this.ctx||!this.sfxGain||this.sfxVolume===0)return;const e=[523.25,659.25,783.99,1046.5],i=this.ctx.currentTime;e.forEach((s,l)=>{if(!this.ctx||!this.sfxGain)return;const c=this.ctx.createOscillator(),f=this.ctx.createGain();c.type="triangle",c.frequency.setValueAtTime(s,i+l*.12),f.gain.setValueAtTime(.3*this.sfxVolume,i+l*.12),f.gain.exponentialRampToValueAtTime(.01,i+l*.12+.3),c.connect(f),f.connect(this.sfxGain),c.start(i+l*.12),c.stop(i+l*.12+.3)})}startBgmLoop(e){if(this.initCtx(),this.stopBgmLoop(),!this.ctx||!this.musicGain||this.musicVolume===0)return;const i=[261.63,329.63,392,440,392,329.63,293.66,349.23];let s=0;this.musicInterval=window.setInterval(()=>{if(!this.ctx||!this.musicGain||this.musicVolume===0)return;const l=this.ctx.createOscillator(),c=this.ctx.createGain();l.type="sine",l.frequency.setValueAtTime(i[s],this.ctx.currentTime),c.gain.setValueAtTime(.08*this.musicVolume,this.ctx.currentTime),c.gain.exponentialRampToValueAtTime(.001,this.ctx.currentTime+.22),l.connect(c),c.connect(this.musicGain),l.start(),l.stop(this.ctx.currentTime+.22),s=(s+1)%i.length},250)}stopBgmLoop(){this.musicInterval!==null&&(clearInterval(this.musicInterval),this.musicInterval=null)}}const nt=new RM,NM=({profile:r,unreadNotificationsCount:e,onOpenSettings:i,onOpenNotifications:s,onTabSelect:l})=>{const c=Math.min(100,Math.round(r.xp/r.maxXp*100));return _.jsx("header",{className:"sticky top-0 z-40 w-full px-3 py-2 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 text-white select-none",children:_.jsxs("div",{className:"max-w-7xl mx-auto flex items-center justify-between gap-2",children:[_.jsxs("div",{onClick:()=>{nt.playClick(),l("profile")},className:"flex items-center gap-2.5 p-1.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 cursor-pointer transition-all active:scale-95 shadow-sm",children:[_.jsxs("div",{className:"relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-2xl shadow-inner border border-white/20",children:[r.avatar,_.jsx("div",{className:"absolute -bottom-1 -right-1 flex items-center justify-center w-5 h-5 rounded-full bg-amber-500 text-[10px] font-black text-slate-950 border border-slate-900 shadow",children:r.level})]}),_.jsxs("div",{className:"hidden sm:flex flex-col min-w-[90px]",children:[_.jsxs("div",{className:"flex items-center justify-between gap-1",children:[_.jsx("span",{className:"text-xs font-bold text-slate-100 truncate max-w-[100px]",children:r.username}),r.isGuest&&_.jsx("span",{className:"text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30",children:"Guest"})]}),_.jsx("div",{className:"w-full h-1.5 mt-1 rounded-full bg-slate-950 overflow-hidden border border-slate-700/50",children:_.jsx("div",{className:"h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-300",style:{width:`${c}%`}})})]})]}),_.jsxs("div",{className:"flex items-center gap-1.5 sm:gap-2.5",children:[_.jsxs("div",{className:"flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/90 border border-slate-700/80 text-amber-400 text-xs font-black shadow-sm",children:[_.jsx(cu,{className:"w-3.5 h-3.5 fill-amber-400 text-amber-400 animate-pulse"}),_.jsxs("span",{children:[r.energy,"/",r.maxEnergy]})]}),_.jsxs("div",{onClick:()=>{nt.playClick(),l("shop")},className:"flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-amber-300 text-xs font-black cursor-pointer shadow-sm transition-transform active:scale-95",children:[_.jsx(Zs,{className:"w-3.5 h-3.5 text-amber-400"}),_.jsx("span",{children:r.coins.toLocaleString()})]}),_.jsxs("div",{onClick:()=>{nt.playClick(),l("shop")},className:"flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-cyan-300 text-xs font-black cursor-pointer shadow-sm transition-transform active:scale-95",children:[_.jsx(Jr,{className:"w-3.5 h-3.5 text-cyan-400"}),_.jsx("span",{children:r.gems.toLocaleString()})]})]}),_.jsxs("div",{className:"flex items-center gap-1.5",children:[_.jsxs("button",{onClick:()=>{nt.playClick(),s()},className:"relative p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-slate-300 hover:text-white transition-all active:scale-90",title:"Notifications",children:[_.jsx(Wv,{className:"w-4 h-4"}),e>0&&_.jsx("span",{className:"absolute -top-1 -right-1 flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-[10px] font-black text-white border-2 border-slate-900 shadow",children:e})]}),_.jsx("button",{onClick:()=>{nt.playClick(),i()},className:"p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-slate-300 hover:text-white transition-all active:scale-90",title:"Settings",children:_.jsx(rM,{className:"w-4 h-4"})})]})]})})},DM=({activeTab:r,onTabChange:e,claimableMissionsCount:i})=>{const s=[{id:"home",label:"Home",icon:qv},{id:"shop",label:"Shop",icon:Yv},{id:"garage",label:"Garage",icon:NS},{id:"characters",label:"Heroes",icon:SM},{id:"missions",label:"Missions",icon:Zv},{id:"rewards",label:"Rewards",icon:hh},{id:"profile",label:"Profile",icon:yM}];return _.jsx("nav",{className:"fixed bottom-0 left-0 right-0 z-40 px-2 py-2 bg-slate-950/90 backdrop-blur-xl border-t border-slate-800/80 text-slate-400 select-none",children:_.jsx("div",{className:"max-w-xl mx-auto flex items-center justify-around gap-1",children:s.map(l=>{const c=l.icon,f=r===l.id;return _.jsxs("button",{onClick:()=>{nt.playClick(),e(l.id)},className:`relative flex flex-col items-center justify-center py-1 px-2.5 rounded-2xl transition-all duration-200 active:scale-90 ${f?"text-cyan-400 bg-cyan-950/50 border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.2)]":"hover:text-slate-200 hover:bg-slate-900/60"}`,children:[_.jsxs("div",{className:"relative",children:[_.jsx(c,{className:`w-5 h-5 transition-transform duration-200 ${f?"scale-110 text-cyan-400":""}`}),l.id==="missions"&&i>0&&_.jsx("span",{className:"absolute -top-1 -right-2 flex items-center justify-center w-4 h-4 rounded-full bg-emerald-500 text-[9px] font-black text-slate-950 animate-bounce",children:i})]}),_.jsx("span",{className:`text-[10px] mt-0.5 font-bold tracking-tight whitespace-nowrap ${f?"text-cyan-300 font-extrabold":""}`,children:l.label}),f&&_.jsx("div",{className:"absolute -bottom-1 w-5 h-1 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]"})]},l.id)})})})},UM=({onStartAsGuest:r,onLogin:e})=>{const[i,s]=st.useState("main"),[l,c]=st.useState(""),[f,p]=st.useState(""),[m,h]=st.useState(""),v=g=>{g.preventDefault();const M=l.trim()||"RushRunner_"+Math.floor(Math.random()*899+100);nt.playVictory(),r(M)},x=g=>{g.preventDefault();const M=f.trim()||"ProRacer";nt.playVictory(),e(M)};return _.jsxs("div",{className:"fixed inset-0 z-50 flex flex-col items-center justify-center p-4 bg-gradient-to-b from-slate-950 via-indigo-950 to-slate-950 text-white overflow-hidden select-none",children:[_.jsx("div",{className:"absolute inset-0 pointer-events-none opacity-40 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-500/20 via-purple-500/10 to-transparent animate-pulse"}),_.jsxs("div",{className:"relative w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900/90 backdrop-blur-2xl border border-indigo-500/30 shadow-[0_0_50px_rgba(79,70,229,0.3)] text-center flex flex-col items-center",children:[_.jsxs("div",{className:"relative mb-6",children:[_.jsx("div",{className:"flex items-center justify-center w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-400 via-rose-500 to-indigo-600 shadow-2xl border-2 border-white/20 transform rotate-3 hover:rotate-0 transition-transform duration-300",children:_.jsx("span",{className:"text-5xl",children:"🏎️"})}),_.jsx("div",{className:"absolute -bottom-2 -right-2 p-2 rounded-2xl bg-amber-400 text-slate-950 font-black shadow-lg animate-bounce",children:_.jsx(fl,{className:"w-5 h-5"})})]}),_.jsx("h1",{className:"text-4xl sm:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-rose-400 to-indigo-300 drop-shadow-sm",children:"ROUTE RUSH"}),_.jsx("p",{className:"mt-2 text-sm font-semibold tracking-wider text-indigo-200/80 uppercase",children:"Run. Drive. Collect. Conquer."}),i==="main"&&_.jsxs("div",{className:"w-full mt-8 flex flex-col gap-3",children:[_.jsxs("button",{onClick:()=>{nt.playClick(),s("guest")},className:"w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-lg shadow-[0_0_20px_rgba(251,191,36,0.4)] flex items-center justify-center gap-3 transition-all active:scale-95",children:[_.jsx(xp,{className:"w-6 h-6 fill-slate-950"}),_.jsx("span",{children:"Continue as Guest"})]}),_.jsxs("button",{onClick:()=>{nt.playClick(),s("login")},className:"w-full py-3.5 px-6 rounded-2xl bg-indigo-900/60 hover:bg-indigo-800/80 border border-indigo-500/40 text-indigo-200 font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95",children:[_.jsx(vM,{className:"w-5 h-5 text-indigo-400"}),_.jsx("span",{children:"Login"})]}),_.jsxs("button",{onClick:()=>{nt.playClick(),s("signup")},className:"w-full py-3 px-6 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-300 font-medium text-sm flex items-center justify-center gap-2 transition-all active:scale-95",children:[_.jsx(XS,{className:"w-4 h-4 text-slate-400"}),_.jsx("span",{children:"Create Permanent Account"})]})]}),i==="guest"&&_.jsxs("form",{onSubmit:v,className:"w-full mt-6 flex flex-col gap-4 text-left",children:[_.jsxs("div",{children:[_.jsx("label",{className:"block text-xs font-bold text-amber-300 mb-1.5 uppercase tracking-wider",children:"Choose Guest Nickname"}),_.jsx("input",{type:"text",value:l,onChange:g=>c(g.target.value),placeholder:"e.g. SpeedDemon99",maxLength:18,className:"w-full px-4 py-3 rounded-xl bg-slate-950 border border-indigo-500/40 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-bold text-sm"}),_.jsx("p",{className:"mt-1 text-[11px] text-slate-400",children:"Progress saves locally. You can sync or create an account later anytime."})]}),_.jsxs("div",{className:"flex gap-2 mt-2",children:[_.jsx("button",{type:"button",onClick:()=>s("main"),className:"w-1/3 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm",children:"Back"}),_.jsx("button",{type:"submit",className:"w-2/3 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-base shadow-lg hover:brightness-110 active:scale-95",children:"Start Rush!"})]})]}),(i==="login"||i==="signup")&&_.jsxs("form",{onSubmit:x,className:"w-full mt-6 flex flex-col gap-3 text-left",children:[_.jsxs("div",{children:[_.jsx("label",{className:"block text-xs font-bold text-indigo-300 mb-1 uppercase tracking-wider",children:"Username / Email"}),_.jsx("input",{type:"text",required:!0,value:f,onChange:g=>p(g.target.value),placeholder:"Enter username",className:"w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:border-indigo-400 font-medium text-sm"})]}),_.jsxs("div",{children:[_.jsx("label",{className:"block text-xs font-bold text-indigo-300 mb-1 uppercase tracking-wider",children:"Password"}),_.jsx("input",{type:"password",required:!0,value:m,onChange:g=>h(g.target.value),placeholder:"••••••••",className:"w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:border-indigo-400 font-medium text-sm"})]}),_.jsxs("div",{className:"flex gap-2 mt-3",children:[_.jsx("button",{type:"button",onClick:()=>s("main"),className:"w-1/3 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm",children:"Back"}),_.jsx("button",{type:"submit",className:"w-2/3 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base shadow-lg active:scale-95",children:i==="login"?"Login":"Create Account"})]})]})]})]})},LM=({profile:r,selectedMode:e,onSelectMode:i,onStartGame:s,onNavigateToGarage:l,onNavigateToHeroes:c})=>{const f=mp(r.currentLevel),p=jv(r.currentLevel,e),m=sl.find(v=>v.id===r.selectedCharacterId)||sl[0],h=rl.find(v=>v.id===r.selectedCarId)||rl[0];return _.jsxs("div",{className:"flex flex-col items-center justify-between w-full min-h-[calc(100vh-120px)] p-4 max-w-4xl mx-auto text-white select-none pb-24",children:[_.jsxs("div",{className:"relative w-full p-6 rounded-3xl overflow-hidden border border-slate-700/60 shadow-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4",children:[_.jsx("div",{className:"absolute inset-0 opacity-20 pointer-events-none",style:{backgroundColor:f.accentColor}}),_.jsxs("div",{className:"relative z-10 flex flex-col text-center sm:text-left",children:[_.jsxs("div",{className:"flex items-center justify-center sm:justify-start gap-2 text-xs font-black uppercase tracking-widest text-cyan-400",children:[_.jsx(fl,{className:"w-4 h-4 text-amber-400"}),_.jsxs("span",{children:["World ",f.id," / 12"]})]}),_.jsx("h2",{className:"text-2xl sm:text-3xl font-black text-white mt-1",children:f.name}),_.jsx("p",{className:"text-xs text-slate-300 mt-1 max-w-md",children:f.description}),_.jsxs("div",{className:"flex items-center justify-center sm:justify-start gap-3 mt-3 text-xs font-bold text-slate-400",children:[_.jsxs("span",{className:"px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-amber-300",children:["Weather: ",f.weather]}),_.jsxs("span",{className:"px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-indigo-300",children:["Time: ",f.timeOfDay]})]})]}),_.jsx("div",{className:"relative z-10 flex items-center gap-3 p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 shadow-inner",children:_.jsxs("div",{className:"flex flex-col items-center min-w-[120px]",children:[_.jsx("span",{className:"text-[10px] font-black uppercase text-amber-400 tracking-widest",children:"CURRENT PROGRESS"}),_.jsxs("span",{className:"text-2xl sm:text-3xl font-black text-white mt-0.5",children:["LEVEL ",r.currentLevel]}),_.jsxs("div",{className:"flex items-center gap-2 text-[11px] font-bold text-slate-300 mt-1",children:[_.jsx(tu,{className:"w-3.5 h-3.5 text-amber-400"}),_.jsxs("span",{children:["Target: ",p.targetDistance,"m • ",p.targetCoins," Coins"]})]})]})})]}),_.jsxs("div",{className:"w-full mt-6 grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-2xl",children:[_.jsxs("button",{onClick:()=>{nt.playClick(),i("runner")},className:`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${e==="runner"?"bg-gradient-to-r from-indigo-600 to-purple-600 border-indigo-400 text-white shadow-[0_0_20px_rgba(99,102,241,0.5)] scale-105":"bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400"}`,children:[_.jsx("span",{className:"text-2xl",children:"🏃‍♂️"}),_.jsx("span",{children:"RUNNER"})]}),_.jsxs("button",{onClick:()=>{nt.playClick(),i("racer")},className:`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${e==="racer"?"bg-gradient-to-r from-rose-600 to-amber-600 border-rose-400 text-white shadow-[0_0_20px_rgba(244,63,94,0.5)] scale-105":"bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400"}`,children:[_.jsx("span",{className:"text-2xl",children:"🏎️"}),_.jsx("span",{children:"CAR DRIVER"})]}),_.jsxs("button",{onClick:()=>{nt.playClick(),i("ball")},className:`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${e==="ball"?"bg-gradient-to-r from-cyan-500 to-blue-600 border-cyan-400 text-white shadow-[0_0_20px_rgba(6,182,212,0.5)] scale-105":"bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400"}`,children:[_.jsx("span",{className:"text-2xl",children:"⚽"}),_.jsx("span",{children:"GOING BALLS"})]}),_.jsxs("button",{onClick:()=>{nt.playClick(),i("motorbike")},className:`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${e==="motorbike"?"bg-gradient-to-r from-emerald-500 to-teal-600 border-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.5)] scale-105":"bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400"}`,children:[_.jsx("span",{className:"text-2xl",children:"🏍️"}),_.jsx("span",{children:"MOTORBIKE"})]})]}),_.jsx("div",{className:"my-8 flex flex-col items-center",children:_.jsxs("button",{onClick:()=>{nt.playVictory(),s()},className:"relative group py-6 px-16 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-amber-400 hover:brightness-110 text-slate-950 font-black text-3xl tracking-wide shadow-[0_0_40px_rgba(251,191,36,0.6)] flex items-center justify-center gap-4 transition-all duration-300 active:scale-95 transform hover:-translate-y-1",children:[_.jsx(xp,{className:"w-10 h-10 fill-slate-950 group-hover:scale-110 transition-transform"}),_.jsx("span",{children:"PLAY RUSH"}),_.jsxs("div",{className:"absolute -top-3 -right-3 flex items-center gap-1 px-3 py-1 rounded-full bg-slate-950 text-amber-400 border border-amber-400 text-xs font-black shadow-lg",children:[_.jsx(cu,{className:"w-3.5 h-3.5 fill-amber-400 text-amber-400"}),_.jsx("span",{children:"-1"})]})]})}),_.jsxs("div",{className:"w-full grid grid-cols-1 sm:grid-cols-2 gap-4",children:[_.jsxs("div",{onClick:c,className:"p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 cursor-pointer flex items-center justify-between transition-all active:scale-95",children:[_.jsxs("div",{className:"flex items-center gap-3",children:[_.jsx("div",{className:"flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-950 border border-indigo-500/40 text-3xl",children:m.avatarUrl}),_.jsxs("div",{className:"flex flex-col text-left",children:[_.jsx("span",{className:"text-[10px] font-bold text-indigo-400 uppercase tracking-wider",children:"Active Hero"}),_.jsx("span",{className:"text-sm font-bold text-white",children:m.name}),_.jsx("span",{className:"text-[11px] text-slate-400",children:m.perk})]})]}),_.jsx("span",{className:"text-xs font-bold text-cyan-400 hover:underline",children:"Change >"})]}),_.jsxs("div",{onClick:l,className:"p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 cursor-pointer flex items-center justify-between transition-all active:scale-95",children:[_.jsxs("div",{className:"flex items-center gap-3",children:[_.jsx("div",{className:"flex items-center justify-center w-12 h-12 rounded-xl bg-rose-950 border border-rose-500/40 text-3xl",children:"🏎️"}),_.jsxs("div",{className:"flex flex-col text-left",children:[_.jsx("span",{className:"text-[10px] font-bold text-rose-400 uppercase tracking-wider",children:"Active Vehicle"}),_.jsx("span",{className:"text-sm font-bold text-white",children:h.name}),_.jsxs("span",{className:"text-[11px] text-slate-400",children:["Speed: ",h.topSpeed," / Handling: ",h.handling]})]})]}),_.jsx("span",{className:"text-xs font-bold text-cyan-400 hover:underline",children:"Garage >"})]})]})]})};/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const vp="185",OM=0,kx=1,PM=2,ol=1,IM=2,il=3,ps=0,ii=1,zi=2,Ra=0,jr=1,jx=2,Xx=3,Wx=4,zM=5,Hs=100,FM=101,BM=102,GM=103,HM=104,VM=200,kM=201,jM=202,XM=203,ph=204,mh=205,WM=206,qM=207,YM=208,ZM=209,KM=210,QM=211,JM=212,$M=213,e1=214,gh=0,xh=1,vh=2,Yr=3,_h=4,yh=5,bh=6,Sh=7,Qv=0,t1=1,n1=2,ea=0,Jv=1,$v=2,e_=3,t_=4,n_=5,i_=6,a_=7,s_=300,Xs=301,Zr=302,Ad=303,wd=304,uu=306,Mh=1e3,Ca=1001,Eh=1002,zn=1003,i1=1004,Tc=1005,jn=1006,Cd=1007,ks=1008,xi=1009,r_=1010,o_=1011,ll=1012,_p=1013,na=1014,Qi=1015,Da=1016,yp=1017,bp=1018,cl=1020,l_=35902,c_=35899,u_=1021,f_=1022,Bi=1023,Ua=1026,js=1027,d_=1028,Sp=1029,Ws=1030,Mp=1031,Ep=1033,Zc=33776,Kc=33777,Qc=33778,Jc=33779,Th=35840,Ah=35841,wh=35842,Ch=35843,Rh=36196,Nh=37492,Dh=37496,Uh=37488,Lh=37489,nu=37490,Oh=37491,Ph=37808,Ih=37809,zh=37810,Fh=37811,Bh=37812,Gh=37813,Hh=37814,Vh=37815,kh=37816,jh=37817,Xh=37818,Wh=37819,qh=37820,Yh=37821,Zh=36492,Kh=36494,Qh=36495,Jh=36283,$h=36284,iu=36285,ep=36286,a1=3200,tp=0,s1=1,ds="",wi="srgb",au="srgb-linear",su="linear",Qt="srgb",Nr=7680,qx=519,r1=512,o1=513,l1=514,Tp=515,c1=516,u1=517,Ap=518,f1=519,Yx=35044,Zx="300 es",Ji=2e3,ul=2001;function d1(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function ru(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function h1(){const r=ru("canvas");return r.style.display="block",r}const Kx={};function Qx(...r){const e="THREE."+r.shift();console.log(e,...r)}function h_(r){const e=r[0];if(typeof e=="string"&&e.startsWith("TSL:")){const i=r[1];i&&i.isStackTrace?r[0]+=" "+i.getLocation():r[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return r}function xt(...r){r=h_(r);const e="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.warn(i.getError(e)):console.warn(e,...r)}}function Bt(...r){r=h_(r);const e="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.error(i.getError(e)):console.error(e,...r)}}function Xr(...r){const e=r.join(" ");e in Kx||(Kx[e]=!0,xt(...r))}function p1(r,e,i){return new Promise(function(s,l){function c(){switch(r.clientWaitSync(e,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:l();break;case r.TIMEOUT_EXPIRED:setTimeout(c,i);break;default:s()}}setTimeout(c,i)})}const m1={[gh]:xh,[vh]:bh,[_h]:Sh,[Yr]:yh,[xh]:gh,[bh]:vh,[Sh]:_h,[yh]:Yr};class Ks{addEventListener(e,i){this._listeners===void 0&&(this._listeners={});const s=this._listeners;s[e]===void 0&&(s[e]=[]),s[e].indexOf(i)===-1&&s[e].push(i)}hasEventListener(e,i){const s=this._listeners;return s===void 0?!1:s[e]!==void 0&&s[e].indexOf(i)!==-1}removeEventListener(e,i){const s=this._listeners;if(s===void 0)return;const l=s[e];if(l!==void 0){const c=l.indexOf(i);c!==-1&&l.splice(c,1)}}dispatchEvent(e){const i=this._listeners;if(i===void 0)return;const s=i[e.type];if(s!==void 0){e.target=this;const l=s.slice(0);for(let c=0,f=l.length;c<f;c++)l[c].call(this,e);e.target=null}}}const Vn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Rd=Math.PI/180,np=180/Math.PI;function dl(){const r=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0,s=Math.random()*4294967295|0;return(Vn[r&255]+Vn[r>>8&255]+Vn[r>>16&255]+Vn[r>>24&255]+"-"+Vn[e&255]+Vn[e>>8&255]+"-"+Vn[e>>16&15|64]+Vn[e>>24&255]+"-"+Vn[i&63|128]+Vn[i>>8&255]+"-"+Vn[i>>16&255]+Vn[i>>24&255]+Vn[s&255]+Vn[s>>8&255]+Vn[s>>16&255]+Vn[s>>24&255]).toLowerCase()}function zt(r,e,i){return Math.max(e,Math.min(i,r))}function g1(r,e){return(r%e+e)%e}function Nd(r,e,i){return(1-i)*r+i*e}function Ko(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function ni(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const Pp=class Pp{constructor(e=0,i=0){this.x=e,this.y=i}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,i){return this.x=e,this.y=i,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const i=this.x,s=this.y,l=e.elements;return this.x=l[0]*i+l[3]*s+l[6],this.y=l[1]*i+l[4]*s+l[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,i){return this.x=zt(this.x,e.x,i.x),this.y=zt(this.y,e.y,i.y),this}clampScalar(e,i){return this.x=zt(this.x,e,i),this.y=zt(this.y,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(zt(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(e)/i;return Math.acos(zt(s,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,s=this.y-e.y;return i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this}rotateAround(e,i){const s=Math.cos(i),l=Math.sin(i),c=this.x-e.x,f=this.y-e.y;return this.x=c*s-f*l+e.x,this.y=c*l+f*s+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Pp.prototype.isVector2=!0;let Ct=Pp;class $r{constructor(e=0,i=0,s=0,l=1){this.isQuaternion=!0,this._x=e,this._y=i,this._z=s,this._w=l}static slerpFlat(e,i,s,l,c,f,p){let m=s[l+0],h=s[l+1],v=s[l+2],x=s[l+3],g=c[f+0],M=c[f+1],w=c[f+2],R=c[f+3];if(x!==R||m!==g||h!==M||v!==w){let b=m*g+h*M+v*w+x*R;b<0&&(g=-g,M=-M,w=-w,R=-R,b=-b);let y=1-p;if(b<.9995){const P=Math.acos(b),O=Math.sin(P);y=Math.sin(y*P)/O,p=Math.sin(p*P)/O,m=m*y+g*p,h=h*y+M*p,v=v*y+w*p,x=x*y+R*p}else{m=m*y+g*p,h=h*y+M*p,v=v*y+w*p,x=x*y+R*p;const P=1/Math.sqrt(m*m+h*h+v*v+x*x);m*=P,h*=P,v*=P,x*=P}}e[i]=m,e[i+1]=h,e[i+2]=v,e[i+3]=x}static multiplyQuaternionsFlat(e,i,s,l,c,f){const p=s[l],m=s[l+1],h=s[l+2],v=s[l+3],x=c[f],g=c[f+1],M=c[f+2],w=c[f+3];return e[i]=p*w+v*x+m*M-h*g,e[i+1]=m*w+v*g+h*x-p*M,e[i+2]=h*w+v*M+p*g-m*x,e[i+3]=v*w-p*x-m*g-h*M,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,i,s,l){return this._x=e,this._y=i,this._z=s,this._w=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,i=!0){const s=e._x,l=e._y,c=e._z,f=e._order,p=Math.cos,m=Math.sin,h=p(s/2),v=p(l/2),x=p(c/2),g=m(s/2),M=m(l/2),w=m(c/2);switch(f){case"XYZ":this._x=g*v*x+h*M*w,this._y=h*M*x-g*v*w,this._z=h*v*w+g*M*x,this._w=h*v*x-g*M*w;break;case"YXZ":this._x=g*v*x+h*M*w,this._y=h*M*x-g*v*w,this._z=h*v*w-g*M*x,this._w=h*v*x+g*M*w;break;case"ZXY":this._x=g*v*x-h*M*w,this._y=h*M*x+g*v*w,this._z=h*v*w+g*M*x,this._w=h*v*x-g*M*w;break;case"ZYX":this._x=g*v*x-h*M*w,this._y=h*M*x+g*v*w,this._z=h*v*w-g*M*x,this._w=h*v*x+g*M*w;break;case"YZX":this._x=g*v*x+h*M*w,this._y=h*M*x+g*v*w,this._z=h*v*w-g*M*x,this._w=h*v*x-g*M*w;break;case"XZY":this._x=g*v*x-h*M*w,this._y=h*M*x-g*v*w,this._z=h*v*w+g*M*x,this._w=h*v*x+g*M*w;break;default:xt("Quaternion: .setFromEuler() encountered an unknown order: "+f)}return i===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,i){const s=i/2,l=Math.sin(s);return this._x=e.x*l,this._y=e.y*l,this._z=e.z*l,this._w=Math.cos(s),this._onChangeCallback(),this}setFromRotationMatrix(e){const i=e.elements,s=i[0],l=i[4],c=i[8],f=i[1],p=i[5],m=i[9],h=i[2],v=i[6],x=i[10],g=s+p+x;if(g>0){const M=.5/Math.sqrt(g+1);this._w=.25/M,this._x=(v-m)*M,this._y=(c-h)*M,this._z=(f-l)*M}else if(s>p&&s>x){const M=2*Math.sqrt(1+s-p-x);this._w=(v-m)/M,this._x=.25*M,this._y=(l+f)/M,this._z=(c+h)/M}else if(p>x){const M=2*Math.sqrt(1+p-s-x);this._w=(c-h)/M,this._x=(l+f)/M,this._y=.25*M,this._z=(m+v)/M}else{const M=2*Math.sqrt(1+x-s-p);this._w=(f-l)/M,this._x=(c+h)/M,this._y=(m+v)/M,this._z=.25*M}return this._onChangeCallback(),this}setFromUnitVectors(e,i){let s=e.dot(i)+1;return s<1e-8?(s=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=s):(this._x=0,this._y=-e.z,this._z=e.y,this._w=s)):(this._x=e.y*i.z-e.z*i.y,this._y=e.z*i.x-e.x*i.z,this._z=e.x*i.y-e.y*i.x,this._w=s),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(zt(this.dot(e),-1,1)))}rotateTowards(e,i){const s=this.angleTo(e);if(s===0)return this;const l=Math.min(1,i/s);return this.slerp(e,l),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,i){const s=e._x,l=e._y,c=e._z,f=e._w,p=i._x,m=i._y,h=i._z,v=i._w;return this._x=s*v+f*p+l*h-c*m,this._y=l*v+f*m+c*p-s*h,this._z=c*v+f*h+s*m-l*p,this._w=f*v-s*p-l*m-c*h,this._onChangeCallback(),this}slerp(e,i){let s=e._x,l=e._y,c=e._z,f=e._w,p=this.dot(e);p<0&&(s=-s,l=-l,c=-c,f=-f,p=-p);let m=1-i;if(p<.9995){const h=Math.acos(p),v=Math.sin(h);m=Math.sin(m*h)/v,i=Math.sin(i*h)/v,this._x=this._x*m+s*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+f*i,this._onChangeCallback()}else this._x=this._x*m+s*i,this._y=this._y*m+l*i,this._z=this._z*m+c*i,this._w=this._w*m+f*i,this.normalize();return this}slerpQuaternions(e,i,s){return this.copy(e).slerp(i,s)}random(){const e=2*Math.PI*Math.random(),i=2*Math.PI*Math.random(),s=Math.random(),l=Math.sqrt(1-s),c=Math.sqrt(s);return this.set(l*Math.sin(e),l*Math.cos(e),c*Math.sin(i),c*Math.cos(i))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,i=0){return this._x=e[i],this._y=e[i+1],this._z=e[i+2],this._w=e[i+3],this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._w,e}fromBufferAttribute(e,i){return this._x=e.getX(i),this._y=e.getY(i),this._z=e.getZ(i),this._w=e.getW(i),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Ip=class Ip{constructor(e=0,i=0,s=0){this.x=e,this.y=i,this.z=s}set(e,i,s){return s===void 0&&(s=this.z),this.x=e,this.y=i,this.z=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,i){return this.x=e.x*i.x,this.y=e.y*i.y,this.z=e.z*i.z,this}applyEuler(e){return this.applyQuaternion(Jx.setFromEuler(e))}applyAxisAngle(e,i){return this.applyQuaternion(Jx.setFromAxisAngle(e,i))}applyMatrix3(e){const i=this.x,s=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[3]*s+c[6]*l,this.y=c[1]*i+c[4]*s+c[7]*l,this.z=c[2]*i+c[5]*s+c[8]*l,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const i=this.x,s=this.y,l=this.z,c=e.elements,f=1/(c[3]*i+c[7]*s+c[11]*l+c[15]);return this.x=(c[0]*i+c[4]*s+c[8]*l+c[12])*f,this.y=(c[1]*i+c[5]*s+c[9]*l+c[13])*f,this.z=(c[2]*i+c[6]*s+c[10]*l+c[14])*f,this}applyQuaternion(e){const i=this.x,s=this.y,l=this.z,c=e.x,f=e.y,p=e.z,m=e.w,h=2*(f*l-p*s),v=2*(p*i-c*l),x=2*(c*s-f*i);return this.x=i+m*h+f*x-p*v,this.y=s+m*v+p*h-c*x,this.z=l+m*x+c*v-f*h,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const i=this.x,s=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[4]*s+c[8]*l,this.y=c[1]*i+c[5]*s+c[9]*l,this.z=c[2]*i+c[6]*s+c[10]*l,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,i){return this.x=zt(this.x,e.x,i.x),this.y=zt(this.y,e.y,i.y),this.z=zt(this.z,e.z,i.z),this}clampScalar(e,i){return this.x=zt(this.x,e,i),this.y=zt(this.y,e,i),this.z=zt(this.z,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(zt(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this.z=e.z+(i.z-e.z)*s,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,i){const s=e.x,l=e.y,c=e.z,f=i.x,p=i.y,m=i.z;return this.x=l*m-c*p,this.y=c*f-s*m,this.z=s*p-l*f,this}projectOnVector(e){const i=e.lengthSq();if(i===0)return this.set(0,0,0);const s=e.dot(this)/i;return this.copy(e).multiplyScalar(s)}projectOnPlane(e){return Dd.copy(this).projectOnVector(e),this.sub(Dd)}reflect(e){return this.sub(Dd.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(e)/i;return Math.acos(zt(s,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,s=this.y-e.y,l=this.z-e.z;return i*i+s*s+l*l}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,i,s){const l=Math.sin(i)*e;return this.x=l*Math.sin(s),this.y=Math.cos(i)*e,this.z=l*Math.cos(s),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,i,s){return this.x=e*Math.sin(i),this.y=s,this.z=e*Math.cos(i),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this}setFromMatrixScale(e){const i=this.setFromMatrixColumn(e,0).length(),s=this.setFromMatrixColumn(e,1).length(),l=this.setFromMatrixColumn(e,2).length();return this.x=i,this.y=s,this.z=l,this}setFromMatrixColumn(e,i){return this.fromArray(e.elements,i*4)}setFromMatrix3Column(e,i){return this.fromArray(e.elements,i*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,i=Math.random()*2-1,s=Math.sqrt(1-i*i);return this.x=s*Math.cos(e),this.y=i,this.z=s*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Ip.prototype.isVector3=!0;let ae=Ip;const Dd=new ae,Jx=new $r,zp=class zp{constructor(e,i,s,l,c,f,p,m,h){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,i,s,l,c,f,p,m,h)}set(e,i,s,l,c,f,p,m,h){const v=this.elements;return v[0]=e,v[1]=l,v[2]=p,v[3]=i,v[4]=c,v[5]=m,v[6]=s,v[7]=f,v[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const i=this.elements,s=e.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],this}extractBasis(e,i,s){return e.setFromMatrix3Column(this,0),i.setFromMatrix3Column(this,1),s.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const i=e.elements;return this.set(i[0],i[4],i[8],i[1],i[5],i[9],i[2],i[6],i[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const s=e.elements,l=i.elements,c=this.elements,f=s[0],p=s[3],m=s[6],h=s[1],v=s[4],x=s[7],g=s[2],M=s[5],w=s[8],R=l[0],b=l[3],y=l[6],P=l[1],O=l[4],C=l[7],I=l[2],L=l[5],F=l[8];return c[0]=f*R+p*P+m*I,c[3]=f*b+p*O+m*L,c[6]=f*y+p*C+m*F,c[1]=h*R+v*P+x*I,c[4]=h*b+v*O+x*L,c[7]=h*y+v*C+x*F,c[2]=g*R+M*P+w*I,c[5]=g*b+M*O+w*L,c[8]=g*y+M*C+w*F,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[3]*=e,i[6]*=e,i[1]*=e,i[4]*=e,i[7]*=e,i[2]*=e,i[5]*=e,i[8]*=e,this}determinant(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],f=e[4],p=e[5],m=e[6],h=e[7],v=e[8];return i*f*v-i*p*h-s*c*v+s*p*m+l*c*h-l*f*m}invert(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],f=e[4],p=e[5],m=e[6],h=e[7],v=e[8],x=v*f-p*h,g=p*m-v*c,M=h*c-f*m,w=i*x+s*g+l*M;if(w===0)return this.set(0,0,0,0,0,0,0,0,0);const R=1/w;return e[0]=x*R,e[1]=(l*h-v*s)*R,e[2]=(p*s-l*f)*R,e[3]=g*R,e[4]=(v*i-l*m)*R,e[5]=(l*c-p*i)*R,e[6]=M*R,e[7]=(s*m-h*i)*R,e[8]=(f*i-s*c)*R,this}transpose(){let e;const i=this.elements;return e=i[1],i[1]=i[3],i[3]=e,e=i[2],i[2]=i[6],i[6]=e,e=i[5],i[5]=i[7],i[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const i=this.elements;return e[0]=i[0],e[1]=i[3],e[2]=i[6],e[3]=i[1],e[4]=i[4],e[5]=i[7],e[6]=i[2],e[7]=i[5],e[8]=i[8],this}setUvTransform(e,i,s,l,c,f,p){const m=Math.cos(c),h=Math.sin(c);return this.set(s*m,s*h,-s*(m*f+h*p)+f+e,-l*h,l*m,-l*(-h*f+m*p)+p+i,0,0,1),this}scale(e,i){return Xr("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(Ud.makeScale(e,i)),this}rotate(e){return Xr("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(Ud.makeRotation(-e)),this}translate(e,i){return Xr("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(Ud.makeTranslation(e,i)),this}makeTranslation(e,i){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,i,0,0,1),this}makeRotation(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,-s,0,s,i,0,0,0,1),this}makeScale(e,i){return this.set(e,0,0,0,i,0,0,0,1),this}equals(e){const i=this.elements,s=e.elements;for(let l=0;l<9;l++)if(i[l]!==s[l])return!1;return!0}fromArray(e,i=0){for(let s=0;s<9;s++)this.elements[s]=e[s+i];return this}toArray(e=[],i=0){const s=this.elements;return e[i]=s[0],e[i+1]=s[1],e[i+2]=s[2],e[i+3]=s[3],e[i+4]=s[4],e[i+5]=s[5],e[i+6]=s[6],e[i+7]=s[7],e[i+8]=s[8],e}clone(){return new this.constructor().fromArray(this.elements)}};zp.prototype.isMatrix3=!0;let _t=zp;const Ud=new _t,$x=new _t().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ev=new _t().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function x1(){const r={enabled:!0,workingColorSpace:au,spaces:{},convert:function(l,c,f){return this.enabled===!1||c===f||!c||!f||(this.spaces[c].transfer===Qt&&(l.r=Na(l.r),l.g=Na(l.g),l.b=Na(l.b)),this.spaces[c].primaries!==this.spaces[f].primaries&&(l.applyMatrix3(this.spaces[c].toXYZ),l.applyMatrix3(this.spaces[f].fromXYZ)),this.spaces[f].transfer===Qt&&(l.r=Wr(l.r),l.g=Wr(l.g),l.b=Wr(l.b))),l},workingToColorSpace:function(l,c){return this.convert(l,this.workingColorSpace,c)},colorSpaceToWorking:function(l,c){return this.convert(l,c,this.workingColorSpace)},getPrimaries:function(l){return this.spaces[l].primaries},getTransfer:function(l){return l===ds?su:this.spaces[l].transfer},getToneMappingMode:function(l){return this.spaces[l].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(l,c=this.workingColorSpace){return l.fromArray(this.spaces[c].luminanceCoefficients)},define:function(l){Object.assign(this.spaces,l)},_getMatrix:function(l,c,f){return l.copy(this.spaces[c].toXYZ).multiply(this.spaces[f].fromXYZ)},_getDrawingBufferColorSpace:function(l){return this.spaces[l].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(l=this.workingColorSpace){return this.spaces[l].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(l,c){return Xr("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),r.workingToColorSpace(l,c)},toWorkingColorSpace:function(l,c){return Xr("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),r.colorSpaceToWorking(l,c)}},e=[.64,.33,.3,.6,.15,.06],i=[.2126,.7152,.0722],s=[.3127,.329];return r.define({[au]:{primaries:e,whitePoint:s,transfer:su,toXYZ:$x,fromXYZ:ev,luminanceCoefficients:i,workingColorSpaceConfig:{unpackColorSpace:wi},outputColorSpaceConfig:{drawingBufferColorSpace:wi}},[wi]:{primaries:e,whitePoint:s,transfer:Qt,toXYZ:$x,fromXYZ:ev,luminanceCoefficients:i,outputColorSpaceConfig:{drawingBufferColorSpace:wi}}}),r}const It=x1();function Na(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function Wr(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Dr;class v1{static getDataURL(e,i="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let s;if(e instanceof HTMLCanvasElement)s=e;else{Dr===void 0&&(Dr=ru("canvas")),Dr.width=e.width,Dr.height=e.height;const l=Dr.getContext("2d");e instanceof ImageData?l.putImageData(e,0,0):l.drawImage(e,0,0,e.width,e.height),s=Dr}return s.toDataURL(i)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const i=ru("canvas");i.width=e.width,i.height=e.height;const s=i.getContext("2d");s.drawImage(e,0,0,e.width,e.height);const l=s.getImageData(0,0,e.width,e.height),c=l.data;for(let f=0;f<c.length;f++)c[f]=Na(c[f]/255)*255;return s.putImageData(l,0,0),i}else if(e.data){const i=e.data.slice(0);for(let s=0;s<i.length;s++)i instanceof Uint8Array||i instanceof Uint8ClampedArray?i[s]=Math.floor(Na(i[s]/255)*255):i[s]=Na(i[s]);return{data:i,width:e.width,height:e.height}}else return xt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let _1=0;class wp{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:_1++}),this.uuid=dl(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const i=this.data;return typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement?e.set(i.videoWidth,i.videoHeight,0):typeof VideoFrame<"u"&&i instanceof VideoFrame?e.set(i.displayWidth,i.displayHeight,0):i!==null?e.set(i.width,i.height,i.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const s={uuid:this.uuid,url:""},l=this.data;if(l!==null){let c;if(Array.isArray(l)){c=[];for(let f=0,p=l.length;f<p;f++)l[f].isDataTexture?c.push(Ld(l[f].image)):c.push(Ld(l[f]))}else c=Ld(l);s.url=c}return i||(e.images[this.uuid]=s),s}}function Ld(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?v1.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(xt("Texture: Unable to serialize Texture."),{})}let y1=0;const Od=new ae;class qn extends Ks{constructor(e=qn.DEFAULT_IMAGE,i=qn.DEFAULT_MAPPING,s=Ca,l=Ca,c=jn,f=ks,p=Bi,m=xi,h=qn.DEFAULT_ANISOTROPY,v=ds){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:y1++}),this.uuid=dl(),this.name="",this.source=new wp(e),this.mipmaps=[],this.mapping=i,this.channel=0,this.wrapS=s,this.wrapT=l,this.magFilter=c,this.minFilter=f,this.anisotropy=h,this.format=p,this.internalFormat=null,this.type=m,this.offset=new Ct(0,0),this.repeat=new Ct(1,1),this.center=new Ct(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new _t,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=v,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Od).x}get height(){return this.source.getSize(Od).y}get depth(){return this.source.getSize(Od).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const i in e){const s=e[i];if(s===void 0){xt(`Texture.setValues(): parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){xt(`Texture.setValues(): property '${i}' does not exist.`);continue}l&&s&&l.isVector2&&s.isVector2||l&&s&&l.isVector3&&s.isVector3||l&&s&&l.isMatrix3&&s.isMatrix3?l.copy(s):this[i]=s}}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const s={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(s.userData=this.userData),i||(e.textures[this.uuid]=s),s}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==s_)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Mh:e.x=e.x-Math.floor(e.x);break;case Ca:e.x=e.x<0?0:1;break;case Eh:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Mh:e.y=e.y-Math.floor(e.y);break;case Ca:e.y=e.y<0?0:1;break;case Eh:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}qn.DEFAULT_IMAGE=null;qn.DEFAULT_MAPPING=s_;qn.DEFAULT_ANISOTROPY=1;const Fp=class Fp{constructor(e=0,i=0,s=0,l=1){this.x=e,this.y=i,this.z=s,this.w=l}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,i,s,l){return this.x=e,this.y=i,this.z=s,this.w=l,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;case 3:this.w=i;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this.w=e.w+i.w,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this.w+=e.w*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this.w=e.w-i.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const i=this.x,s=this.y,l=this.z,c=this.w,f=e.elements;return this.x=f[0]*i+f[4]*s+f[8]*l+f[12]*c,this.y=f[1]*i+f[5]*s+f[9]*l+f[13]*c,this.z=f[2]*i+f[6]*s+f[10]*l+f[14]*c,this.w=f[3]*i+f[7]*s+f[11]*l+f[15]*c,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const i=Math.sqrt(1-e.w*e.w);return i<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/i,this.y=e.y/i,this.z=e.z/i),this}setAxisAngleFromRotationMatrix(e){let i,s,l,c;const m=e.elements,h=m[0],v=m[4],x=m[8],g=m[1],M=m[5],w=m[9],R=m[2],b=m[6],y=m[10];if(Math.abs(v-g)<.01&&Math.abs(x-R)<.01&&Math.abs(w-b)<.01){if(Math.abs(v+g)<.1&&Math.abs(x+R)<.1&&Math.abs(w+b)<.1&&Math.abs(h+M+y-3)<.1)return this.set(1,0,0,0),this;i=Math.PI;const O=(h+1)/2,C=(M+1)/2,I=(y+1)/2,L=(v+g)/4,F=(x+R)/4,T=(w+b)/4;return O>C&&O>I?O<.01?(s=0,l=.707106781,c=.707106781):(s=Math.sqrt(O),l=L/s,c=F/s):C>I?C<.01?(s=.707106781,l=0,c=.707106781):(l=Math.sqrt(C),s=L/l,c=T/l):I<.01?(s=.707106781,l=.707106781,c=0):(c=Math.sqrt(I),s=F/c,l=T/c),this.set(s,l,c,i),this}let P=Math.sqrt((b-w)*(b-w)+(x-R)*(x-R)+(g-v)*(g-v));return Math.abs(P)<.001&&(P=1),this.x=(b-w)/P,this.y=(x-R)/P,this.z=(g-v)/P,this.w=Math.acos((h+M+y-1)/2),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this.w=i[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,i){return this.x=zt(this.x,e.x,i.x),this.y=zt(this.y,e.y,i.y),this.z=zt(this.z,e.z,i.z),this.w=zt(this.w,e.w,i.w),this}clampScalar(e,i){return this.x=zt(this.x,e,i),this.y=zt(this.y,e,i),this.z=zt(this.z,e,i),this.w=zt(this.w,e,i),this}clampLength(e,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(zt(s,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this.w+=(e.w-this.w)*i,this}lerpVectors(e,i,s){return this.x=e.x+(i.x-e.x)*s,this.y=e.y+(i.y-e.y)*s,this.z=e.z+(i.z-e.z)*s,this.w=e.w+(i.w-e.w)*s,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this.w=e[i+3],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e[i+3]=this.w,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this.w=e.getW(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Fp.prototype.isVector4=!0;let un=Fp;class b1 extends Ks{constructor(e=1,i=1,s={}){super(),s=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:jn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},s),this.isRenderTarget=!0,this.width=e,this.height=i,this.depth=s.depth,this.scissor=new un(0,0,e,i),this.scissorTest=!1,this.viewport=new un(0,0,e,i),this.textures=[];const l={width:e,height:i,depth:s.depth},c=new qn(l),f=s.count;for(let p=0;p<f;p++)this.textures[p]=c.clone(),this.textures[p].isRenderTargetTexture=!0,this.textures[p].renderTarget=this;this._setTextureOptions(s),this.depthBuffer=s.depthBuffer,this.stencilBuffer=s.stencilBuffer,this.resolveDepthBuffer=s.resolveDepthBuffer,this.resolveStencilBuffer=s.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=s.depthTexture,this.samples=s.samples,this.multiview=s.multiview,this.useArrayDepthTexture=s.useArrayDepthTexture}_setTextureOptions(e={}){const i={minFilter:jn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(i.mapping=e.mapping),e.wrapS!==void 0&&(i.wrapS=e.wrapS),e.wrapT!==void 0&&(i.wrapT=e.wrapT),e.wrapR!==void 0&&(i.wrapR=e.wrapR),e.magFilter!==void 0&&(i.magFilter=e.magFilter),e.minFilter!==void 0&&(i.minFilter=e.minFilter),e.format!==void 0&&(i.format=e.format),e.type!==void 0&&(i.type=e.type),e.anisotropy!==void 0&&(i.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(i.colorSpace=e.colorSpace),e.flipY!==void 0&&(i.flipY=e.flipY),e.generateMipmaps!==void 0&&(i.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(i.internalFormat=e.internalFormat);for(let s=0;s<this.textures.length;s++)this.textures[s].setValues(i)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,i,s=1){if(this.width!==e||this.height!==i||this.depth!==s){this.width=e,this.height=i,this.depth=s;for(let l=0,c=this.textures.length;l<c;l++)this.textures[l].image.width=e,this.textures[l].image.height=i,this.textures[l].image.depth=s,this.textures[l].isData3DTexture!==!0&&(this.textures[l].isArrayTexture=this.textures[l].image.depth>1);this.dispose()}this.viewport.set(0,0,e,i),this.scissor.set(0,0,e,i)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let i=0,s=e.textures.length;i<s;i++){this.textures[i]=e.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;const l=Object.assign({},e.textures[i].image);this.textures[i].source=new wp(l)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ta extends b1{constructor(e=1,i=1,s={}){super(e,i,s),this.isWebGLRenderTarget=!0}}class p_ extends qn{constructor(e=null,i=1,s=1,l=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:i,height:s,depth:l},this.magFilter=zn,this.minFilter=zn,this.wrapR=Ca,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class S1 extends qn{constructor(e=null,i=1,s=1,l=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:i,height:s,depth:l},this.magFilter=zn,this.minFilter=zn,this.wrapR=Ca,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const lu=class lu{constructor(e,i,s,l,c,f,p,m,h,v,x,g,M,w,R,b){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,i,s,l,c,f,p,m,h,v,x,g,M,w,R,b)}set(e,i,s,l,c,f,p,m,h,v,x,g,M,w,R,b){const y=this.elements;return y[0]=e,y[4]=i,y[8]=s,y[12]=l,y[1]=c,y[5]=f,y[9]=p,y[13]=m,y[2]=h,y[6]=v,y[10]=x,y[14]=g,y[3]=M,y[7]=w,y[11]=R,y[15]=b,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new lu().fromArray(this.elements)}copy(e){const i=this.elements,s=e.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],i[9]=s[9],i[10]=s[10],i[11]=s[11],i[12]=s[12],i[13]=s[13],i[14]=s[14],i[15]=s[15],this}copyPosition(e){const i=this.elements,s=e.elements;return i[12]=s[12],i[13]=s[13],i[14]=s[14],this}setFromMatrix3(e){const i=e.elements;return this.set(i[0],i[3],i[6],0,i[1],i[4],i[7],0,i[2],i[5],i[8],0,0,0,0,1),this}extractBasis(e,i,s){return this.determinantAffine()===0?(e.set(1,0,0),i.set(0,1,0),s.set(0,0,1),this):(e.setFromMatrixColumn(this,0),i.setFromMatrixColumn(this,1),s.setFromMatrixColumn(this,2),this)}makeBasis(e,i,s){return this.set(e.x,i.x,s.x,0,e.y,i.y,s.y,0,e.z,i.z,s.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const i=this.elements,s=e.elements,l=1/Ur.setFromMatrixColumn(e,0).length(),c=1/Ur.setFromMatrixColumn(e,1).length(),f=1/Ur.setFromMatrixColumn(e,2).length();return i[0]=s[0]*l,i[1]=s[1]*l,i[2]=s[2]*l,i[3]=0,i[4]=s[4]*c,i[5]=s[5]*c,i[6]=s[6]*c,i[7]=0,i[8]=s[8]*f,i[9]=s[9]*f,i[10]=s[10]*f,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromEuler(e){const i=this.elements,s=e.x,l=e.y,c=e.z,f=Math.cos(s),p=Math.sin(s),m=Math.cos(l),h=Math.sin(l),v=Math.cos(c),x=Math.sin(c);if(e.order==="XYZ"){const g=f*v,M=f*x,w=p*v,R=p*x;i[0]=m*v,i[4]=-m*x,i[8]=h,i[1]=M+w*h,i[5]=g-R*h,i[9]=-p*m,i[2]=R-g*h,i[6]=w+M*h,i[10]=f*m}else if(e.order==="YXZ"){const g=m*v,M=m*x,w=h*v,R=h*x;i[0]=g+R*p,i[4]=w*p-M,i[8]=f*h,i[1]=f*x,i[5]=f*v,i[9]=-p,i[2]=M*p-w,i[6]=R+g*p,i[10]=f*m}else if(e.order==="ZXY"){const g=m*v,M=m*x,w=h*v,R=h*x;i[0]=g-R*p,i[4]=-f*x,i[8]=w+M*p,i[1]=M+w*p,i[5]=f*v,i[9]=R-g*p,i[2]=-f*h,i[6]=p,i[10]=f*m}else if(e.order==="ZYX"){const g=f*v,M=f*x,w=p*v,R=p*x;i[0]=m*v,i[4]=w*h-M,i[8]=g*h+R,i[1]=m*x,i[5]=R*h+g,i[9]=M*h-w,i[2]=-h,i[6]=p*m,i[10]=f*m}else if(e.order==="YZX"){const g=f*m,M=f*h,w=p*m,R=p*h;i[0]=m*v,i[4]=R-g*x,i[8]=w*x+M,i[1]=x,i[5]=f*v,i[9]=-p*v,i[2]=-h*v,i[6]=M*x+w,i[10]=g-R*x}else if(e.order==="XZY"){const g=f*m,M=f*h,w=p*m,R=p*h;i[0]=m*v,i[4]=-x,i[8]=h*v,i[1]=g*x+R,i[5]=f*v,i[9]=M*x-w,i[2]=w*x-M,i[6]=p*v,i[10]=R*x+g}return i[3]=0,i[7]=0,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromQuaternion(e){return this.compose(M1,e,E1)}lookAt(e,i,s){const l=this.elements;return mi.subVectors(e,i),mi.lengthSq()===0&&(mi.z=1),mi.normalize(),rs.crossVectors(s,mi),rs.lengthSq()===0&&(Math.abs(s.z)===1?mi.x+=1e-4:mi.z+=1e-4,mi.normalize(),rs.crossVectors(s,mi)),rs.normalize(),Ac.crossVectors(mi,rs),l[0]=rs.x,l[4]=Ac.x,l[8]=mi.x,l[1]=rs.y,l[5]=Ac.y,l[9]=mi.y,l[2]=rs.z,l[6]=Ac.z,l[10]=mi.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const s=e.elements,l=i.elements,c=this.elements,f=s[0],p=s[4],m=s[8],h=s[12],v=s[1],x=s[5],g=s[9],M=s[13],w=s[2],R=s[6],b=s[10],y=s[14],P=s[3],O=s[7],C=s[11],I=s[15],L=l[0],F=l[4],T=l[8],U=l[12],V=l[1],k=l[5],W=l[9],re=l[13],oe=l[2],te=l[6],G=l[10],X=l[14],$=l[3],se=l[7],B=l[11],E=l[15];return c[0]=f*L+p*V+m*oe+h*$,c[4]=f*F+p*k+m*te+h*se,c[8]=f*T+p*W+m*G+h*B,c[12]=f*U+p*re+m*X+h*E,c[1]=v*L+x*V+g*oe+M*$,c[5]=v*F+x*k+g*te+M*se,c[9]=v*T+x*W+g*G+M*B,c[13]=v*U+x*re+g*X+M*E,c[2]=w*L+R*V+b*oe+y*$,c[6]=w*F+R*k+b*te+y*se,c[10]=w*T+R*W+b*G+y*B,c[14]=w*U+R*re+b*X+y*E,c[3]=P*L+O*V+C*oe+I*$,c[7]=P*F+O*k+C*te+I*se,c[11]=P*T+O*W+C*G+I*B,c[15]=P*U+O*re+C*X+I*E,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[4]*=e,i[8]*=e,i[12]*=e,i[1]*=e,i[5]*=e,i[9]*=e,i[13]*=e,i[2]*=e,i[6]*=e,i[10]*=e,i[14]*=e,i[3]*=e,i[7]*=e,i[11]*=e,i[15]*=e,this}determinant(){const e=this.elements,i=e[0],s=e[4],l=e[8],c=e[12],f=e[1],p=e[5],m=e[9],h=e[13],v=e[2],x=e[6],g=e[10],M=e[14],w=e[3],R=e[7],b=e[11],y=e[15],P=m*M-h*g,O=p*M-h*x,C=p*g-m*x,I=f*M-h*v,L=f*g-m*v,F=f*x-p*v;return i*(R*P-b*O+y*C)-s*(w*P-b*I+y*L)+l*(w*O-R*I+y*F)-c*(w*C-R*L+b*F)}determinantAffine(){const e=this.elements,i=e[0],s=e[4],l=e[8],c=e[1],f=e[5],p=e[9],m=e[2],h=e[6],v=e[10];return i*(f*v-p*h)-s*(c*v-p*m)+l*(c*h-f*m)}transpose(){const e=this.elements;let i;return i=e[1],e[1]=e[4],e[4]=i,i=e[2],e[2]=e[8],e[8]=i,i=e[6],e[6]=e[9],e[9]=i,i=e[3],e[3]=e[12],e[12]=i,i=e[7],e[7]=e[13],e[13]=i,i=e[11],e[11]=e[14],e[14]=i,this}setPosition(e,i,s){const l=this.elements;return e.isVector3?(l[12]=e.x,l[13]=e.y,l[14]=e.z):(l[12]=e,l[13]=i,l[14]=s),this}invert(){const e=this.elements,i=e[0],s=e[1],l=e[2],c=e[3],f=e[4],p=e[5],m=e[6],h=e[7],v=e[8],x=e[9],g=e[10],M=e[11],w=e[12],R=e[13],b=e[14],y=e[15],P=i*p-s*f,O=i*m-l*f,C=i*h-c*f,I=s*m-l*p,L=s*h-c*p,F=l*h-c*m,T=v*R-x*w,U=v*b-g*w,V=v*y-M*w,k=x*b-g*R,W=x*y-M*R,re=g*y-M*b,oe=P*re-O*W+C*k+I*V-L*U+F*T;if(oe===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const te=1/oe;return e[0]=(p*re-m*W+h*k)*te,e[1]=(l*W-s*re-c*k)*te,e[2]=(R*F-b*L+y*I)*te,e[3]=(g*L-x*F-M*I)*te,e[4]=(m*V-f*re-h*U)*te,e[5]=(i*re-l*V+c*U)*te,e[6]=(b*C-w*F-y*O)*te,e[7]=(v*F-g*C+M*O)*te,e[8]=(f*W-p*V+h*T)*te,e[9]=(s*V-i*W-c*T)*te,e[10]=(w*L-R*C+y*P)*te,e[11]=(x*C-v*L-M*P)*te,e[12]=(p*U-f*k-m*T)*te,e[13]=(i*k-s*U+l*T)*te,e[14]=(R*O-w*I-b*P)*te,e[15]=(v*I-x*O+g*P)*te,this}scale(e){const i=this.elements,s=e.x,l=e.y,c=e.z;return i[0]*=s,i[4]*=l,i[8]*=c,i[1]*=s,i[5]*=l,i[9]*=c,i[2]*=s,i[6]*=l,i[10]*=c,i[3]*=s,i[7]*=l,i[11]*=c,this}getMaxScaleOnAxis(){const e=this.elements,i=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],s=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],l=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(i,s,l))}makeTranslation(e,i,s){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,i,0,0,1,s,0,0,0,1),this}makeRotationX(e){const i=Math.cos(e),s=Math.sin(e);return this.set(1,0,0,0,0,i,-s,0,0,s,i,0,0,0,0,1),this}makeRotationY(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,0,s,0,0,1,0,0,-s,0,i,0,0,0,0,1),this}makeRotationZ(e){const i=Math.cos(e),s=Math.sin(e);return this.set(i,-s,0,0,s,i,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,i){const s=Math.cos(i),l=Math.sin(i),c=1-s,f=e.x,p=e.y,m=e.z,h=c*f,v=c*p;return this.set(h*f+s,h*p-l*m,h*m+l*p,0,h*p+l*m,v*p+s,v*m-l*f,0,h*m-l*p,v*m+l*f,c*m*m+s,0,0,0,0,1),this}makeScale(e,i,s){return this.set(e,0,0,0,0,i,0,0,0,0,s,0,0,0,0,1),this}makeShear(e,i,s,l,c,f){return this.set(1,s,c,0,e,1,f,0,i,l,1,0,0,0,0,1),this}compose(e,i,s){const l=this.elements,c=i._x,f=i._y,p=i._z,m=i._w,h=c+c,v=f+f,x=p+p,g=c*h,M=c*v,w=c*x,R=f*v,b=f*x,y=p*x,P=m*h,O=m*v,C=m*x,I=s.x,L=s.y,F=s.z;return l[0]=(1-(R+y))*I,l[1]=(M+C)*I,l[2]=(w-O)*I,l[3]=0,l[4]=(M-C)*L,l[5]=(1-(g+y))*L,l[6]=(b+P)*L,l[7]=0,l[8]=(w+O)*F,l[9]=(b-P)*F,l[10]=(1-(g+R))*F,l[11]=0,l[12]=e.x,l[13]=e.y,l[14]=e.z,l[15]=1,this}decompose(e,i,s){const l=this.elements;e.x=l[12],e.y=l[13],e.z=l[14];const c=this.determinantAffine();if(c===0)return s.set(1,1,1),i.identity(),this;let f=Ur.set(l[0],l[1],l[2]).length();const p=Ur.set(l[4],l[5],l[6]).length(),m=Ur.set(l[8],l[9],l[10]).length();c<0&&(f=-f),Oi.copy(this);const h=1/f,v=1/p,x=1/m;return Oi.elements[0]*=h,Oi.elements[1]*=h,Oi.elements[2]*=h,Oi.elements[4]*=v,Oi.elements[5]*=v,Oi.elements[6]*=v,Oi.elements[8]*=x,Oi.elements[9]*=x,Oi.elements[10]*=x,i.setFromRotationMatrix(Oi),s.x=f,s.y=p,s.z=m,this}makePerspective(e,i,s,l,c,f,p=Ji,m=!1){const h=this.elements,v=2*c/(i-e),x=2*c/(s-l),g=(i+e)/(i-e),M=(s+l)/(s-l);let w,R;if(m)w=c/(f-c),R=f*c/(f-c);else if(p===Ji)w=-(f+c)/(f-c),R=-2*f*c/(f-c);else if(p===ul)w=-f/(f-c),R=-f*c/(f-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+p);return h[0]=v,h[4]=0,h[8]=g,h[12]=0,h[1]=0,h[5]=x,h[9]=M,h[13]=0,h[2]=0,h[6]=0,h[10]=w,h[14]=R,h[3]=0,h[7]=0,h[11]=-1,h[15]=0,this}makeOrthographic(e,i,s,l,c,f,p=Ji,m=!1){const h=this.elements,v=2/(i-e),x=2/(s-l),g=-(i+e)/(i-e),M=-(s+l)/(s-l);let w,R;if(m)w=1/(f-c),R=f/(f-c);else if(p===Ji)w=-2/(f-c),R=-(f+c)/(f-c);else if(p===ul)w=-1/(f-c),R=-c/(f-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+p);return h[0]=v,h[4]=0,h[8]=0,h[12]=g,h[1]=0,h[5]=x,h[9]=0,h[13]=M,h[2]=0,h[6]=0,h[10]=w,h[14]=R,h[3]=0,h[7]=0,h[11]=0,h[15]=1,this}equals(e){const i=this.elements,s=e.elements;for(let l=0;l<16;l++)if(i[l]!==s[l])return!1;return!0}fromArray(e,i=0){for(let s=0;s<16;s++)this.elements[s]=e[s+i];return this}toArray(e=[],i=0){const s=this.elements;return e[i]=s[0],e[i+1]=s[1],e[i+2]=s[2],e[i+3]=s[3],e[i+4]=s[4],e[i+5]=s[5],e[i+6]=s[6],e[i+7]=s[7],e[i+8]=s[8],e[i+9]=s[9],e[i+10]=s[10],e[i+11]=s[11],e[i+12]=s[12],e[i+13]=s[13],e[i+14]=s[14],e[i+15]=s[15],e}};lu.prototype.isMatrix4=!0;let fn=lu;const Ur=new ae,Oi=new fn,M1=new ae(0,0,0),E1=new ae(1,1,1),rs=new ae,Ac=new ae,mi=new ae,tv=new fn,nv=new $r;class ms{constructor(e=0,i=0,s=0,l=ms.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=i,this._z=s,this._order=l}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,i,s,l=this._order){return this._x=e,this._y=i,this._z=s,this._order=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,i=this._order,s=!0){const l=e.elements,c=l[0],f=l[4],p=l[8],m=l[1],h=l[5],v=l[9],x=l[2],g=l[6],M=l[10];switch(i){case"XYZ":this._y=Math.asin(zt(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-v,M),this._z=Math.atan2(-f,c)):(this._x=Math.atan2(g,h),this._z=0);break;case"YXZ":this._x=Math.asin(-zt(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(p,M),this._z=Math.atan2(m,h)):(this._y=Math.atan2(-x,c),this._z=0);break;case"ZXY":this._x=Math.asin(zt(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(-x,M),this._z=Math.atan2(-f,h)):(this._y=0,this._z=Math.atan2(m,c));break;case"ZYX":this._y=Math.asin(-zt(x,-1,1)),Math.abs(x)<.9999999?(this._x=Math.atan2(g,M),this._z=Math.atan2(m,c)):(this._x=0,this._z=Math.atan2(-f,h));break;case"YZX":this._z=Math.asin(zt(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(-v,h),this._y=Math.atan2(-x,c)):(this._x=0,this._y=Math.atan2(p,M));break;case"XZY":this._z=Math.asin(-zt(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(g,h),this._y=Math.atan2(p,c)):(this._x=Math.atan2(-v,M),this._y=0);break;default:xt("Euler: .setFromRotationMatrix() encountered an unknown order: "+i)}return this._order=i,s===!0&&this._onChangeCallback(),this}setFromQuaternion(e,i,s){return tv.makeRotationFromQuaternion(e),this.setFromRotationMatrix(tv,i,s)}setFromVector3(e,i=this._order){return this.set(e.x,e.y,e.z,i)}reorder(e){return nv.setFromEuler(this),this.setFromQuaternion(nv,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}ms.DEFAULT_ORDER="XYZ";class m_{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let T1=0;const iv=new ae,Lr=new $r,Ma=new fn,wc=new ae,Qo=new ae,A1=new ae,w1=new $r,av=new ae(1,0,0),sv=new ae(0,1,0),rv=new ae(0,0,1),ov={type:"added"},C1={type:"removed"},Or={type:"childadded",child:null},Pd={type:"childremoved",child:null};class Bn extends Ks{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:T1++}),this.uuid=dl(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Bn.DEFAULT_UP.clone();const e=new ae,i=new ms,s=new $r,l=new ae(1,1,1);function c(){s.setFromEuler(i,!1)}function f(){i.setFromQuaternion(s,void 0,!1)}i._onChange(c),s._onChange(f),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:i},quaternion:{configurable:!0,enumerable:!0,value:s},scale:{configurable:!0,enumerable:!0,value:l},modelViewMatrix:{value:new fn},normalMatrix:{value:new _t}}),this.matrix=new fn,this.matrixWorld=new fn,this.matrixAutoUpdate=Bn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Bn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new m_,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,i){this.quaternion.setFromAxisAngle(e,i)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,i){return Lr.setFromAxisAngle(e,i),this.quaternion.multiply(Lr),this}rotateOnWorldAxis(e,i){return Lr.setFromAxisAngle(e,i),this.quaternion.premultiply(Lr),this}rotateX(e){return this.rotateOnAxis(av,e)}rotateY(e){return this.rotateOnAxis(sv,e)}rotateZ(e){return this.rotateOnAxis(rv,e)}translateOnAxis(e,i){return iv.copy(e).applyQuaternion(this.quaternion),this.position.add(iv.multiplyScalar(i)),this}translateX(e){return this.translateOnAxis(av,e)}translateY(e){return this.translateOnAxis(sv,e)}translateZ(e){return this.translateOnAxis(rv,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Ma.copy(this.matrixWorld).invert())}lookAt(e,i,s){e.isVector3?wc.copy(e):wc.set(e,i,s);const l=this.parent;this.updateWorldMatrix(!0,!1),Qo.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Ma.lookAt(Qo,wc,this.up):Ma.lookAt(wc,Qo,this.up),this.quaternion.setFromRotationMatrix(Ma),l&&(Ma.extractRotation(l.matrixWorld),Lr.setFromRotationMatrix(Ma),this.quaternion.premultiply(Lr.invert()))}add(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.add(arguments[i]);return this}return e===this?(Bt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(ov),Or.child=e,this.dispatchEvent(Or),Or.child=null):Bt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let s=0;s<arguments.length;s++)this.remove(arguments[s]);return this}const i=this.children.indexOf(e);return i!==-1&&(e.parent=null,this.children.splice(i,1),e.dispatchEvent(C1),Pd.child=e,this.dispatchEvent(Pd),Pd.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Ma.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Ma.multiply(e.parent.matrixWorld)),e.applyMatrix4(Ma),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(ov),Or.child=e,this.dispatchEvent(Or),Or.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,i){if(this[e]===i)return this;for(let s=0,l=this.children.length;s<l;s++){const f=this.children[s].getObjectByProperty(e,i);if(f!==void 0)return f}}getObjectsByProperty(e,i,s=[]){this[e]===i&&s.push(this);const l=this.children;for(let c=0,f=l.length;c<f;c++)l[c].getObjectsByProperty(e,i,s);return s}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Qo,e,A1),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Qo,w1,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const i=this.matrixWorld.elements;return e.set(i[8],i[9],i[10]).normalize()}raycast(){}traverse(e){e(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverseVisible(e)}traverseAncestors(e){const i=this.parent;i!==null&&(e(i),i.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const i=e.x,s=e.y,l=e.z,c=this.matrix.elements;c[12]+=i-c[0]*i-c[4]*s-c[8]*l,c[13]+=s-c[1]*i-c[5]*s-c[9]*l,c[14]+=l-c[2]*i-c[6]*s-c[10]*l}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].updateMatrixWorld(e)}updateWorldMatrix(e,i,s=!1){const l=this.parent;if(e===!0&&l!==null&&l.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||s)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,s=!0),i===!0){const c=this.children;for(let f=0,p=c.length;f<p;f++)c[f].updateWorldMatrix(!1,!0,s)}}toJSON(e){const i=e===void 0||typeof e=="string",s={};i&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},s.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const l={};l.uuid=this.uuid,l.type=this.type,this.name!==""&&(l.name=this.name),this.castShadow===!0&&(l.castShadow=!0),this.receiveShadow===!0&&(l.receiveShadow=!0),this.visible===!1&&(l.visible=!1),this.frustumCulled===!1&&(l.frustumCulled=!1),this.renderOrder!==0&&(l.renderOrder=this.renderOrder),this.static!==!1&&(l.static=this.static),Object.keys(this.userData).length>0&&(l.userData=this.userData),l.layers=this.layers.mask,l.matrix=this.matrix.toArray(),l.up=this.up.toArray(),this.pivot!==null&&(l.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(l.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(l.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(l.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(l.type="InstancedMesh",l.count=this.count,l.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(l.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(l.type="BatchedMesh",l.perObjectFrustumCulled=this.perObjectFrustumCulled,l.sortObjects=this.sortObjects,l.drawRanges=this._drawRanges,l.reservedRanges=this._reservedRanges,l.geometryInfo=this._geometryInfo.map(p=>({...p,boundingBox:p.boundingBox?p.boundingBox.toJSON():void 0,boundingSphere:p.boundingSphere?p.boundingSphere.toJSON():void 0})),l.instanceInfo=this._instanceInfo.map(p=>({...p})),l.availableInstanceIds=this._availableInstanceIds.slice(),l.availableGeometryIds=this._availableGeometryIds.slice(),l.nextIndexStart=this._nextIndexStart,l.nextVertexStart=this._nextVertexStart,l.geometryCount=this._geometryCount,l.maxInstanceCount=this._maxInstanceCount,l.maxVertexCount=this._maxVertexCount,l.maxIndexCount=this._maxIndexCount,l.geometryInitialized=this._geometryInitialized,l.matricesTexture=this._matricesTexture.toJSON(e),l.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(l.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(l.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(l.boundingBox=this.boundingBox.toJSON()));function c(p,m){return p[m.uuid]===void 0&&(p[m.uuid]=m.toJSON(e)),m.uuid}if(this.isScene)this.background&&(this.background.isColor?l.background=this.background.toJSON():this.background.isTexture&&(l.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(l.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){l.geometry=c(e.geometries,this.geometry);const p=this.geometry.parameters;if(p!==void 0&&p.shapes!==void 0){const m=p.shapes;if(Array.isArray(m))for(let h=0,v=m.length;h<v;h++){const x=m[h];c(e.shapes,x)}else c(e.shapes,m)}}if(this.isSkinnedMesh&&(l.bindMode=this.bindMode,l.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(e.skeletons,this.skeleton),l.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const p=[];for(let m=0,h=this.material.length;m<h;m++)p.push(c(e.materials,this.material[m]));l.material=p}else l.material=c(e.materials,this.material);if(this.children.length>0){l.children=[];for(let p=0;p<this.children.length;p++)l.children.push(this.children[p].toJSON(e).object)}if(this.animations.length>0){l.animations=[];for(let p=0;p<this.animations.length;p++){const m=this.animations[p];l.animations.push(c(e.animations,m))}}if(i){const p=f(e.geometries),m=f(e.materials),h=f(e.textures),v=f(e.images),x=f(e.shapes),g=f(e.skeletons),M=f(e.animations),w=f(e.nodes);p.length>0&&(s.geometries=p),m.length>0&&(s.materials=m),h.length>0&&(s.textures=h),v.length>0&&(s.images=v),x.length>0&&(s.shapes=x),g.length>0&&(s.skeletons=g),M.length>0&&(s.animations=M),w.length>0&&(s.nodes=w)}return s.object=l,s;function f(p){const m=[];for(const h in p){const v=p[h];delete v.metadata,m.push(v)}return m}}clone(e){return new this.constructor().copy(this,e)}copy(e,i=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),i===!0)for(let s=0;s<e.children.length;s++){const l=e.children[s];this.add(l.clone())}return this}}Bn.DEFAULT_UP=new ae(0,1,0);Bn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Bn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class gn extends Bn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const R1={type:"move"};class Id{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new gn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new gn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new ae,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new ae),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new gn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new ae,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new ae,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const i=this._hand;if(i)for(const s of e.hand.values())this._getHandJoint(i,s)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,i,s){let l=null,c=null,f=null;const p=this._targetRay,m=this._grip,h=this._hand;if(e&&i.session.visibilityState!=="visible-blurred"){if(h&&e.hand){f=!0;for(const R of e.hand.values()){const b=i.getJointPose(R,s),y=this._getHandJoint(h,R);b!==null&&(y.matrix.fromArray(b.transform.matrix),y.matrix.decompose(y.position,y.rotation,y.scale),y.matrixWorldNeedsUpdate=!0,y.jointRadius=b.radius),y.visible=b!==null}const v=h.joints["index-finger-tip"],x=h.joints["thumb-tip"],g=v.position.distanceTo(x.position),M=.02,w=.005;h.inputState.pinching&&g>M+w?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!h.inputState.pinching&&g<=M-w&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else m!==null&&e.gripSpace&&(c=i.getPose(e.gripSpace,s),c!==null&&(m.matrix.fromArray(c.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,c.linearVelocity?(m.hasLinearVelocity=!0,m.linearVelocity.copy(c.linearVelocity)):m.hasLinearVelocity=!1,c.angularVelocity?(m.hasAngularVelocity=!0,m.angularVelocity.copy(c.angularVelocity)):m.hasAngularVelocity=!1,m.eventsEnabled&&m.dispatchEvent({type:"gripUpdated",data:e,target:this})));p!==null&&(l=i.getPose(e.targetRaySpace,s),l===null&&c!==null&&(l=c),l!==null&&(p.matrix.fromArray(l.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,l.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(l.linearVelocity)):p.hasLinearVelocity=!1,l.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(l.angularVelocity)):p.hasAngularVelocity=!1,this.dispatchEvent(R1)))}return p!==null&&(p.visible=l!==null),m!==null&&(m.visible=c!==null),h!==null&&(h.visible=f!==null),this}_getHandJoint(e,i){if(e.joints[i.jointName]===void 0){const s=new gn;s.matrixAutoUpdate=!1,s.visible=!1,e.joints[i.jointName]=s,e.add(s)}return e.joints[i.jointName]}}const g_={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},os={h:0,s:0,l:0},Cc={h:0,s:0,l:0};function zd(r,e,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?r+(e-r)*6*i:i<1/2?e:i<2/3?r+(e-r)*6*(2/3-i):r}class Ot{constructor(e,i,s){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,i,s)}set(e,i,s){if(i===void 0&&s===void 0){const l=e;l&&l.isColor?this.copy(l):typeof l=="number"?this.setHex(l):typeof l=="string"&&this.setStyle(l)}else this.setRGB(e,i,s);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,i=wi){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,It.colorSpaceToWorking(this,i),this}setRGB(e,i,s,l=It.workingColorSpace){return this.r=e,this.g=i,this.b=s,It.colorSpaceToWorking(this,l),this}setHSL(e,i,s,l=It.workingColorSpace){if(e=g1(e,1),i=zt(i,0,1),s=zt(s,0,1),i===0)this.r=this.g=this.b=s;else{const c=s<=.5?s*(1+i):s+i-s*i,f=2*s-c;this.r=zd(f,c,e+1/3),this.g=zd(f,c,e),this.b=zd(f,c,e-1/3)}return It.colorSpaceToWorking(this,l),this}setStyle(e,i=wi){function s(c){c!==void 0&&parseFloat(c)<1&&xt("Color: Alpha component of "+e+" will be ignored.")}let l;if(l=/^(\w+)\(([^\)]*)\)/.exec(e)){let c;const f=l[1],p=l[2];switch(f){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,i);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,i);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(p))return s(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,i);break;default:xt("Color: Unknown color model "+e)}}else if(l=/^\#([A-Fa-f\d]+)$/.exec(e)){const c=l[1],f=c.length;if(f===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,i);if(f===6)return this.setHex(parseInt(c,16),i);xt("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,i);return this}setColorName(e,i=wi){const s=g_[e.toLowerCase()];return s!==void 0?this.setHex(s,i):xt("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Na(e.r),this.g=Na(e.g),this.b=Na(e.b),this}copyLinearToSRGB(e){return this.r=Wr(e.r),this.g=Wr(e.g),this.b=Wr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=wi){return It.workingToColorSpace(kn.copy(this),e),Math.round(zt(kn.r*255,0,255))*65536+Math.round(zt(kn.g*255,0,255))*256+Math.round(zt(kn.b*255,0,255))}getHexString(e=wi){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,i=It.workingColorSpace){It.workingToColorSpace(kn.copy(this),i);const s=kn.r,l=kn.g,c=kn.b,f=Math.max(s,l,c),p=Math.min(s,l,c);let m,h;const v=(p+f)/2;if(p===f)m=0,h=0;else{const x=f-p;switch(h=v<=.5?x/(f+p):x/(2-f-p),f){case s:m=(l-c)/x+(l<c?6:0);break;case l:m=(c-s)/x+2;break;case c:m=(s-l)/x+4;break}m/=6}return e.h=m,e.s=h,e.l=v,e}getRGB(e,i=It.workingColorSpace){return It.workingToColorSpace(kn.copy(this),i),e.r=kn.r,e.g=kn.g,e.b=kn.b,e}getStyle(e=wi){It.workingToColorSpace(kn.copy(this),e);const i=kn.r,s=kn.g,l=kn.b;return e!==wi?`color(${e} ${i.toFixed(3)} ${s.toFixed(3)} ${l.toFixed(3)})`:`rgb(${Math.round(i*255)},${Math.round(s*255)},${Math.round(l*255)})`}offsetHSL(e,i,s){return this.getHSL(os),this.setHSL(os.h+e,os.s+i,os.l+s)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,i){return this.r=e.r+i.r,this.g=e.g+i.g,this.b=e.b+i.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,i){return this.r+=(e.r-this.r)*i,this.g+=(e.g-this.g)*i,this.b+=(e.b-this.b)*i,this}lerpColors(e,i,s){return this.r=e.r+(i.r-e.r)*s,this.g=e.g+(i.g-e.g)*s,this.b=e.b+(i.b-e.b)*s,this}lerpHSL(e,i){this.getHSL(os),e.getHSL(Cc);const s=Nd(os.h,Cc.h,i),l=Nd(os.s,Cc.s,i),c=Nd(os.l,Cc.l,i);return this.setHSL(s,l,c),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const i=this.r,s=this.g,l=this.b,c=e.elements;return this.r=c[0]*i+c[3]*s+c[6]*l,this.g=c[1]*i+c[4]*s+c[7]*l,this.b=c[2]*i+c[5]*s+c[8]*l,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,i=0){return this.r=e[i],this.g=e[i+1],this.b=e[i+2],this}toArray(e=[],i=0){return e[i]=this.r,e[i+1]=this.g,e[i+2]=this.b,e}fromBufferAttribute(e,i){return this.r=e.getX(i),this.g=e.getY(i),this.b=e.getZ(i),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const kn=new Ot;Ot.NAMES=g_;class Cp{constructor(e,i=25e-5){this.isFogExp2=!0,this.name="",this.color=new Ot(e),this.density=i}clone(){return new Cp(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class N1 extends Bn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new ms,this.environmentIntensity=1,this.environmentRotation=new ms,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,i){return super.copy(e,i),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const i=super.toJSON(e);return this.fog!==null&&(i.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(i.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(i.object.backgroundIntensity=this.backgroundIntensity),i.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(i.object.environmentIntensity=this.environmentIntensity),i.object.environmentRotation=this.environmentRotation.toArray(),i}}const Pi=new ae,Ea=new ae,Fd=new ae,Ta=new ae,Pr=new ae,Ir=new ae,lv=new ae,Bd=new ae,Gd=new ae,Hd=new ae,Vd=new un,kd=new un,jd=new un;class Fi{constructor(e=new ae,i=new ae,s=new ae){this.a=e,this.b=i,this.c=s}static getNormal(e,i,s,l){l.subVectors(s,i),Pi.subVectors(e,i),l.cross(Pi);const c=l.lengthSq();return c>0?l.multiplyScalar(1/Math.sqrt(c)):l.set(0,0,0)}static getBarycoord(e,i,s,l,c){Pi.subVectors(l,i),Ea.subVectors(s,i),Fd.subVectors(e,i);const f=Pi.dot(Pi),p=Pi.dot(Ea),m=Pi.dot(Fd),h=Ea.dot(Ea),v=Ea.dot(Fd),x=f*h-p*p;if(x===0)return c.set(0,0,0),null;const g=1/x,M=(h*m-p*v)*g,w=(f*v-p*m)*g;return c.set(1-M-w,w,M)}static containsPoint(e,i,s,l){return this.getBarycoord(e,i,s,l,Ta)===null?!1:Ta.x>=0&&Ta.y>=0&&Ta.x+Ta.y<=1}static getInterpolation(e,i,s,l,c,f,p,m){return this.getBarycoord(e,i,s,l,Ta)===null?(m.x=0,m.y=0,"z"in m&&(m.z=0),"w"in m&&(m.w=0),null):(m.setScalar(0),m.addScaledVector(c,Ta.x),m.addScaledVector(f,Ta.y),m.addScaledVector(p,Ta.z),m)}static getInterpolatedAttribute(e,i,s,l,c,f){return Vd.setScalar(0),kd.setScalar(0),jd.setScalar(0),Vd.fromBufferAttribute(e,i),kd.fromBufferAttribute(e,s),jd.fromBufferAttribute(e,l),f.setScalar(0),f.addScaledVector(Vd,c.x),f.addScaledVector(kd,c.y),f.addScaledVector(jd,c.z),f}static isFrontFacing(e,i,s,l){return Pi.subVectors(s,i),Ea.subVectors(e,i),Pi.cross(Ea).dot(l)<0}set(e,i,s){return this.a.copy(e),this.b.copy(i),this.c.copy(s),this}setFromPointsAndIndices(e,i,s,l){return this.a.copy(e[i]),this.b.copy(e[s]),this.c.copy(e[l]),this}setFromAttributeAndIndices(e,i,s,l){return this.a.fromBufferAttribute(e,i),this.b.fromBufferAttribute(e,s),this.c.fromBufferAttribute(e,l),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Pi.subVectors(this.c,this.b),Ea.subVectors(this.a,this.b),Pi.cross(Ea).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Fi.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,i){return Fi.getBarycoord(e,this.a,this.b,this.c,i)}getInterpolation(e,i,s,l,c){return Fi.getInterpolation(e,this.a,this.b,this.c,i,s,l,c)}containsPoint(e){return Fi.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Fi.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,i){const s=this.a,l=this.b,c=this.c;let f,p;Pr.subVectors(l,s),Ir.subVectors(c,s),Bd.subVectors(e,s);const m=Pr.dot(Bd),h=Ir.dot(Bd);if(m<=0&&h<=0)return i.copy(s);Gd.subVectors(e,l);const v=Pr.dot(Gd),x=Ir.dot(Gd);if(v>=0&&x<=v)return i.copy(l);const g=m*x-v*h;if(g<=0&&m>=0&&v<=0)return f=m/(m-v),i.copy(s).addScaledVector(Pr,f);Hd.subVectors(e,c);const M=Pr.dot(Hd),w=Ir.dot(Hd);if(w>=0&&M<=w)return i.copy(c);const R=M*h-m*w;if(R<=0&&h>=0&&w<=0)return p=h/(h-w),i.copy(s).addScaledVector(Ir,p);const b=v*w-M*x;if(b<=0&&x-v>=0&&M-w>=0)return lv.subVectors(c,l),p=(x-v)/(x-v+(M-w)),i.copy(l).addScaledVector(lv,p);const y=1/(b+R+g);return f=R*y,p=g*y,i.copy(s).addScaledVector(Pr,f).addScaledVector(Ir,p)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class hl{constructor(e=new ae(1/0,1/0,1/0),i=new ae(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=i}set(e,i){return this.min.copy(e),this.max.copy(i),this}setFromArray(e){this.makeEmpty();for(let i=0,s=e.length;i<s;i+=3)this.expandByPoint(Ii.fromArray(e,i));return this}setFromBufferAttribute(e){this.makeEmpty();for(let i=0,s=e.count;i<s;i++)this.expandByPoint(Ii.fromBufferAttribute(e,i));return this}setFromPoints(e){this.makeEmpty();for(let i=0,s=e.length;i<s;i++)this.expandByPoint(e[i]);return this}setFromCenterAndSize(e,i){const s=Ii.copy(i).multiplyScalar(.5);return this.min.copy(e).sub(s),this.max.copy(e).add(s),this}setFromObject(e,i=!1){return this.makeEmpty(),this.expandByObject(e,i)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,i=!1){e.updateWorldMatrix(!1,!1);const s=e.geometry;if(s!==void 0){const c=s.getAttribute("position");if(i===!0&&c!==void 0&&e.isInstancedMesh!==!0)for(let f=0,p=c.count;f<p;f++)e.isMesh===!0?e.getVertexPosition(f,Ii):Ii.fromBufferAttribute(c,f),Ii.applyMatrix4(e.matrixWorld),this.expandByPoint(Ii);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Rc.copy(e.boundingBox)):(s.boundingBox===null&&s.computeBoundingBox(),Rc.copy(s.boundingBox)),Rc.applyMatrix4(e.matrixWorld),this.union(Rc)}const l=e.children;for(let c=0,f=l.length;c<f;c++)this.expandByObject(l[c],i);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,i){return i.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Ii),Ii.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let i,s;return e.normal.x>0?(i=e.normal.x*this.min.x,s=e.normal.x*this.max.x):(i=e.normal.x*this.max.x,s=e.normal.x*this.min.x),e.normal.y>0?(i+=e.normal.y*this.min.y,s+=e.normal.y*this.max.y):(i+=e.normal.y*this.max.y,s+=e.normal.y*this.min.y),e.normal.z>0?(i+=e.normal.z*this.min.z,s+=e.normal.z*this.max.z):(i+=e.normal.z*this.max.z,s+=e.normal.z*this.min.z),i<=-e.constant&&s>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Jo),Nc.subVectors(this.max,Jo),zr.subVectors(e.a,Jo),Fr.subVectors(e.b,Jo),Br.subVectors(e.c,Jo),ls.subVectors(Fr,zr),cs.subVectors(Br,Fr),Is.subVectors(zr,Br);let i=[0,-ls.z,ls.y,0,-cs.z,cs.y,0,-Is.z,Is.y,ls.z,0,-ls.x,cs.z,0,-cs.x,Is.z,0,-Is.x,-ls.y,ls.x,0,-cs.y,cs.x,0,-Is.y,Is.x,0];return!Xd(i,zr,Fr,Br,Nc)||(i=[1,0,0,0,1,0,0,0,1],!Xd(i,zr,Fr,Br,Nc))?!1:(Dc.crossVectors(ls,cs),i=[Dc.x,Dc.y,Dc.z],Xd(i,zr,Fr,Br,Nc))}clampPoint(e,i){return i.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ii).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ii).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Aa[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Aa[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Aa[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Aa[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Aa[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Aa[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Aa[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Aa[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Aa),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Aa=[new ae,new ae,new ae,new ae,new ae,new ae,new ae,new ae],Ii=new ae,Rc=new hl,zr=new ae,Fr=new ae,Br=new ae,ls=new ae,cs=new ae,Is=new ae,Jo=new ae,Nc=new ae,Dc=new ae,zs=new ae;function Xd(r,e,i,s,l){for(let c=0,f=r.length-3;c<=f;c+=3){zs.fromArray(r,c);const p=l.x*Math.abs(zs.x)+l.y*Math.abs(zs.y)+l.z*Math.abs(zs.z),m=e.dot(zs),h=i.dot(zs),v=s.dot(zs);if(Math.max(-Math.max(m,h,v),Math.min(m,h,v))>p)return!1}return!0}const En=new ae,Uc=new Ct;let D1=0;class Hi extends Ks{constructor(e,i,s=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:D1++}),this.name="",this.array=e,this.itemSize=i,this.count=e!==void 0?e.length/i:0,this.normalized=s,this.usage=Yx,this.updateRanges=[],this.gpuType=Qi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,i,s){e*=this.itemSize,s*=i.itemSize;for(let l=0,c=this.itemSize;l<c;l++)this.array[e+l]=i.array[s+l];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let i=0,s=this.count;i<s;i++)Uc.fromBufferAttribute(this,i),Uc.applyMatrix3(e),this.setXY(i,Uc.x,Uc.y);else if(this.itemSize===3)for(let i=0,s=this.count;i<s;i++)En.fromBufferAttribute(this,i),En.applyMatrix3(e),this.setXYZ(i,En.x,En.y,En.z);return this}applyMatrix4(e){for(let i=0,s=this.count;i<s;i++)En.fromBufferAttribute(this,i),En.applyMatrix4(e),this.setXYZ(i,En.x,En.y,En.z);return this}applyNormalMatrix(e){for(let i=0,s=this.count;i<s;i++)En.fromBufferAttribute(this,i),En.applyNormalMatrix(e),this.setXYZ(i,En.x,En.y,En.z);return this}transformDirection(e){for(let i=0,s=this.count;i<s;i++)En.fromBufferAttribute(this,i),En.transformDirection(e),this.setXYZ(i,En.x,En.y,En.z);return this}set(e,i=0){return this.array.set(e,i),this}getComponent(e,i){let s=this.array[e*this.itemSize+i];return this.normalized&&(s=Ko(s,this.array)),s}setComponent(e,i,s){return this.normalized&&(s=ni(s,this.array)),this.array[e*this.itemSize+i]=s,this}getX(e){let i=this.array[e*this.itemSize];return this.normalized&&(i=Ko(i,this.array)),i}setX(e,i){return this.normalized&&(i=ni(i,this.array)),this.array[e*this.itemSize]=i,this}getY(e){let i=this.array[e*this.itemSize+1];return this.normalized&&(i=Ko(i,this.array)),i}setY(e,i){return this.normalized&&(i=ni(i,this.array)),this.array[e*this.itemSize+1]=i,this}getZ(e){let i=this.array[e*this.itemSize+2];return this.normalized&&(i=Ko(i,this.array)),i}setZ(e,i){return this.normalized&&(i=ni(i,this.array)),this.array[e*this.itemSize+2]=i,this}getW(e){let i=this.array[e*this.itemSize+3];return this.normalized&&(i=Ko(i,this.array)),i}setW(e,i){return this.normalized&&(i=ni(i,this.array)),this.array[e*this.itemSize+3]=i,this}setXY(e,i,s){return e*=this.itemSize,this.normalized&&(i=ni(i,this.array),s=ni(s,this.array)),this.array[e+0]=i,this.array[e+1]=s,this}setXYZ(e,i,s,l){return e*=this.itemSize,this.normalized&&(i=ni(i,this.array),s=ni(s,this.array),l=ni(l,this.array)),this.array[e+0]=i,this.array[e+1]=s,this.array[e+2]=l,this}setXYZW(e,i,s,l,c){return e*=this.itemSize,this.normalized&&(i=ni(i,this.array),s=ni(s,this.array),l=ni(l,this.array),c=ni(c,this.array)),this.array[e+0]=i,this.array[e+1]=s,this.array[e+2]=l,this.array[e+3]=c,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Yx&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class x_ extends Hi{constructor(e,i,s){super(new Uint16Array(e),i,s)}}class v_ extends Hi{constructor(e,i,s){super(new Uint32Array(e),i,s)}}class xn extends Hi{constructor(e,i,s){super(new Float32Array(e),i,s)}}const U1=new hl,$o=new ae,Wd=new ae;class fu{constructor(e=new ae,i=-1){this.isSphere=!0,this.center=e,this.radius=i}set(e,i){return this.center.copy(e),this.radius=i,this}setFromPoints(e,i){const s=this.center;i!==void 0?s.copy(i):U1.setFromPoints(e).getCenter(s);let l=0;for(let c=0,f=e.length;c<f;c++)l=Math.max(l,s.distanceToSquared(e[c]));return this.radius=Math.sqrt(l),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const i=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=i*i}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,i){const s=this.center.distanceToSquared(e);return i.copy(e),s>this.radius*this.radius&&(i.sub(this.center).normalize(),i.multiplyScalar(this.radius).add(this.center)),i}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;$o.subVectors(e,this.center);const i=$o.lengthSq();if(i>this.radius*this.radius){const s=Math.sqrt(i),l=(s-this.radius)*.5;this.center.addScaledVector($o,l/s),this.radius+=l}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Wd.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint($o.copy(e.center).add(Wd)),this.expandByPoint($o.copy(e.center).sub(Wd))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let L1=0;const Ai=new fn,qd=new Bn,Gr=new ae,gi=new hl,el=new hl,Nn=new ae;class Yn extends Ks{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:L1++}),this.uuid=dl(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(d1(e)?v_:x_)(e,1):this.index=e,this}setIndirect(e,i=0){return this.indirect=e,this.indirectOffset=i,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,i){return this.attributes[e]=i,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,i,s=0){this.groups.push({start:e,count:i,materialIndex:s})}clearGroups(){this.groups=[]}setDrawRange(e,i){this.drawRange.start=e,this.drawRange.count=i}applyMatrix4(e){const i=this.attributes.position;i!==void 0&&(i.applyMatrix4(e),i.needsUpdate=!0);const s=this.attributes.normal;if(s!==void 0){const c=new _t().getNormalMatrix(e);s.applyNormalMatrix(c),s.needsUpdate=!0}const l=this.attributes.tangent;return l!==void 0&&(l.transformDirection(e),l.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Ai.makeRotationFromQuaternion(e),this.applyMatrix4(Ai),this}rotateX(e){return Ai.makeRotationX(e),this.applyMatrix4(Ai),this}rotateY(e){return Ai.makeRotationY(e),this.applyMatrix4(Ai),this}rotateZ(e){return Ai.makeRotationZ(e),this.applyMatrix4(Ai),this}translate(e,i,s){return Ai.makeTranslation(e,i,s),this.applyMatrix4(Ai),this}scale(e,i,s){return Ai.makeScale(e,i,s),this.applyMatrix4(Ai),this}lookAt(e){return qd.lookAt(e),qd.updateMatrix(),this.applyMatrix4(qd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Gr).negate(),this.translate(Gr.x,Gr.y,Gr.z),this}setFromPoints(e){const i=this.getAttribute("position");if(i===void 0){const s=[];for(let l=0,c=e.length;l<c;l++){const f=e[l];s.push(f.x,f.y,f.z||0)}this.setAttribute("position",new xn(s,3))}else{const s=Math.min(e.length,i.count);for(let l=0;l<s;l++){const c=e[l];i.setXYZ(l,c.x,c.y,c.z||0)}e.length>i.count&&xt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),i.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new hl);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Bt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new ae(-1/0,-1/0,-1/0),new ae(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),i)for(let s=0,l=i.length;s<l;s++){const c=i[s];gi.setFromBufferAttribute(c),this.morphTargetsRelative?(Nn.addVectors(this.boundingBox.min,gi.min),this.boundingBox.expandByPoint(Nn),Nn.addVectors(this.boundingBox.max,gi.max),this.boundingBox.expandByPoint(Nn)):(this.boundingBox.expandByPoint(gi.min),this.boundingBox.expandByPoint(gi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Bt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new fu);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Bt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new ae,1/0);return}if(e){const s=this.boundingSphere.center;if(gi.setFromBufferAttribute(e),i)for(let c=0,f=i.length;c<f;c++){const p=i[c];el.setFromBufferAttribute(p),this.morphTargetsRelative?(Nn.addVectors(gi.min,el.min),gi.expandByPoint(Nn),Nn.addVectors(gi.max,el.max),gi.expandByPoint(Nn)):(gi.expandByPoint(el.min),gi.expandByPoint(el.max))}gi.getCenter(s);let l=0;for(let c=0,f=e.count;c<f;c++)Nn.fromBufferAttribute(e,c),l=Math.max(l,s.distanceToSquared(Nn));if(i)for(let c=0,f=i.length;c<f;c++){const p=i[c],m=this.morphTargetsRelative;for(let h=0,v=p.count;h<v;h++)Nn.fromBufferAttribute(p,h),m&&(Gr.fromBufferAttribute(e,h),Nn.add(Gr)),l=Math.max(l,s.distanceToSquared(Nn))}this.boundingSphere.radius=Math.sqrt(l),isNaN(this.boundingSphere.radius)&&Bt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,i=this.attributes;if(e===null||i.position===void 0||i.normal===void 0||i.uv===void 0){Bt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const s=i.position,l=i.normal,c=i.uv;let f=this.getAttribute("tangent");(f===void 0||f.count!==s.count)&&(f=new Hi(new Float32Array(4*s.count),4),this.setAttribute("tangent",f));const p=[],m=[];for(let T=0;T<s.count;T++)p[T]=new ae,m[T]=new ae;const h=new ae,v=new ae,x=new ae,g=new Ct,M=new Ct,w=new Ct,R=new ae,b=new ae;function y(T,U,V){h.fromBufferAttribute(s,T),v.fromBufferAttribute(s,U),x.fromBufferAttribute(s,V),g.fromBufferAttribute(c,T),M.fromBufferAttribute(c,U),w.fromBufferAttribute(c,V),v.sub(h),x.sub(h),M.sub(g),w.sub(g);const k=1/(M.x*w.y-w.x*M.y);isFinite(k)&&(R.copy(v).multiplyScalar(w.y).addScaledVector(x,-M.y).multiplyScalar(k),b.copy(x).multiplyScalar(M.x).addScaledVector(v,-w.x).multiplyScalar(k),p[T].add(R),p[U].add(R),p[V].add(R),m[T].add(b),m[U].add(b),m[V].add(b))}let P=this.groups;P.length===0&&(P=[{start:0,count:e.count}]);for(let T=0,U=P.length;T<U;++T){const V=P[T],k=V.start,W=V.count;for(let re=k,oe=k+W;re<oe;re+=3)y(e.getX(re+0),e.getX(re+1),e.getX(re+2))}const O=new ae,C=new ae,I=new ae,L=new ae;function F(T){I.fromBufferAttribute(l,T),L.copy(I);const U=p[T];O.copy(U),O.sub(I.multiplyScalar(I.dot(U))).normalize(),C.crossVectors(L,U);const k=C.dot(m[T])<0?-1:1;f.setXYZW(T,O.x,O.y,O.z,k)}for(let T=0,U=P.length;T<U;++T){const V=P[T],k=V.start,W=V.count;for(let re=k,oe=k+W;re<oe;re+=3)F(e.getX(re+0)),F(e.getX(re+1)),F(e.getX(re+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,i=this.getAttribute("position");if(i!==void 0){let s=this.getAttribute("normal");if(s===void 0||s.count!==i.count)s=new Hi(new Float32Array(i.count*3),3),this.setAttribute("normal",s);else for(let g=0,M=s.count;g<M;g++)s.setXYZ(g,0,0,0);const l=new ae,c=new ae,f=new ae,p=new ae,m=new ae,h=new ae,v=new ae,x=new ae;if(e)for(let g=0,M=e.count;g<M;g+=3){const w=e.getX(g+0),R=e.getX(g+1),b=e.getX(g+2);l.fromBufferAttribute(i,w),c.fromBufferAttribute(i,R),f.fromBufferAttribute(i,b),v.subVectors(f,c),x.subVectors(l,c),v.cross(x),p.fromBufferAttribute(s,w),m.fromBufferAttribute(s,R),h.fromBufferAttribute(s,b),p.add(v),m.add(v),h.add(v),s.setXYZ(w,p.x,p.y,p.z),s.setXYZ(R,m.x,m.y,m.z),s.setXYZ(b,h.x,h.y,h.z)}else for(let g=0,M=i.count;g<M;g+=3)l.fromBufferAttribute(i,g+0),c.fromBufferAttribute(i,g+1),f.fromBufferAttribute(i,g+2),v.subVectors(f,c),x.subVectors(l,c),v.cross(x),s.setXYZ(g+0,v.x,v.y,v.z),s.setXYZ(g+1,v.x,v.y,v.z),s.setXYZ(g+2,v.x,v.y,v.z);this.normalizeNormals(),s.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let i=0,s=e.count;i<s;i++)Nn.fromBufferAttribute(e,i),Nn.normalize(),e.setXYZ(i,Nn.x,Nn.y,Nn.z)}toNonIndexed(){function e(p,m){const h=p.array,v=p.itemSize,x=p.normalized,g=new h.constructor(m.length*v);let M=0,w=0;for(let R=0,b=m.length;R<b;R++){p.isInterleavedBufferAttribute?M=m[R]*p.data.stride+p.offset:M=m[R]*v;for(let y=0;y<v;y++)g[w++]=h[M++]}return new Hi(g,v,x)}if(this.index===null)return xt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const i=new Yn,s=this.index.array,l=this.attributes;for(const p in l){const m=l[p],h=e(m,s);i.setAttribute(p,h)}const c=this.morphAttributes;for(const p in c){const m=[],h=c[p];for(let v=0,x=h.length;v<x;v++){const g=h[v],M=e(g,s);m.push(M)}i.morphAttributes[p]=m}i.morphTargetsRelative=this.morphTargetsRelative;const f=this.groups;for(let p=0,m=f.length;p<m;p++){const h=f[p];i.addGroup(h.start,h.count,h.materialIndex)}return i}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const m=this.parameters;for(const h in m)m[h]!==void 0&&(e[h]=m[h]);return e}e.data={attributes:{}};const i=this.index;i!==null&&(e.data.index={type:i.array.constructor.name,array:Array.prototype.slice.call(i.array)});const s=this.attributes;for(const m in s){const h=s[m];e.data.attributes[m]=h.toJSON(e.data)}const l={};let c=!1;for(const m in this.morphAttributes){const h=this.morphAttributes[m],v=[];for(let x=0,g=h.length;x<g;x++){const M=h[x];v.push(M.toJSON(e.data))}v.length>0&&(l[m]=v,c=!0)}c&&(e.data.morphAttributes=l,e.data.morphTargetsRelative=this.morphTargetsRelative);const f=this.groups;f.length>0&&(e.data.groups=JSON.parse(JSON.stringify(f)));const p=this.boundingSphere;return p!==null&&(e.data.boundingSphere=p.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const i={};this.name=e.name;const s=e.index;s!==null&&this.setIndex(s.clone());const l=e.attributes;for(const h in l){const v=l[h];this.setAttribute(h,v.clone(i))}const c=e.morphAttributes;for(const h in c){const v=[],x=c[h];for(let g=0,M=x.length;g<M;g++)v.push(x[g].clone(i));this.morphAttributes[h]=v}this.morphTargetsRelative=e.morphTargetsRelative;const f=e.groups;for(let h=0,v=f.length;h<v;h++){const x=f[h];this.addGroup(x.start,x.count,x.materialIndex)}const p=e.boundingBox;p!==null&&(this.boundingBox=p.clone());const m=e.boundingSphere;return m!==null&&(this.boundingSphere=m.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}let O1=0;class eo extends Ks{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:O1++}),this.uuid=dl(),this.name="",this.type="Material",this.blending=jr,this.side=ps,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ph,this.blendDst=mh,this.blendEquation=Hs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ot(0,0,0),this.blendAlpha=0,this.depthFunc=Yr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=qx,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Nr,this.stencilZFail=Nr,this.stencilZPass=Nr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const i in e){const s=e[i];if(s===void 0){xt(`Material: parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){xt(`Material: '${i}' is not a property of THREE.${this.type}.`);continue}l&&l.isColor?l.set(s):l&&l.isVector2&&s&&s.isVector2||l&&l.isEuler&&s&&s.isEuler||l&&l.isVector3&&s&&s.isVector3?l.copy(s):this[i]=s}}toJSON(e){const i=e===void 0||typeof e=="string";i&&(e={textures:{},images:{}});const s={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.color&&this.color.isColor&&(s.color=this.color.getHex()),this.roughness!==void 0&&(s.roughness=this.roughness),this.metalness!==void 0&&(s.metalness=this.metalness),this.sheen!==void 0&&(s.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(s.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(s.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(s.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(s.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(s.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(s.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(s.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(s.shininess=this.shininess),this.clearcoat!==void 0&&(s.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(s.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(s.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(s.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(s.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,s.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(s.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(s.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(s.dispersion=this.dispersion),this.iridescence!==void 0&&(s.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(s.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(s.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(s.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(s.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(s.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(s.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(s.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(s.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(s.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(s.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(s.lightMap=this.lightMap.toJSON(e).uuid,s.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(s.aoMap=this.aoMap.toJSON(e).uuid,s.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(s.bumpMap=this.bumpMap.toJSON(e).uuid,s.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(s.normalMap=this.normalMap.toJSON(e).uuid,s.normalMapType=this.normalMapType,s.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(s.displacementMap=this.displacementMap.toJSON(e).uuid,s.displacementScale=this.displacementScale,s.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(s.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(s.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(s.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(s.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(s.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(s.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(s.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(s.combine=this.combine)),this.envMapRotation!==void 0&&(s.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(s.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(s.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(s.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(s.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(s.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(s.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(s.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(s.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(s.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(s.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(s.size=this.size),this.shadowSide!==null&&(s.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(s.sizeAttenuation=this.sizeAttenuation),this.blending!==jr&&(s.blending=this.blending),this.side!==ps&&(s.side=this.side),this.vertexColors===!0&&(s.vertexColors=!0),this.opacity<1&&(s.opacity=this.opacity),this.transparent===!0&&(s.transparent=!0),this.blendSrc!==ph&&(s.blendSrc=this.blendSrc),this.blendDst!==mh&&(s.blendDst=this.blendDst),this.blendEquation!==Hs&&(s.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(s.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(s.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(s.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(s.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(s.blendAlpha=this.blendAlpha),this.depthFunc!==Yr&&(s.depthFunc=this.depthFunc),this.depthTest===!1&&(s.depthTest=this.depthTest),this.depthWrite===!1&&(s.depthWrite=this.depthWrite),this.colorWrite===!1&&(s.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(s.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==qx&&(s.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(s.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(s.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Nr&&(s.stencilFail=this.stencilFail),this.stencilZFail!==Nr&&(s.stencilZFail=this.stencilZFail),this.stencilZPass!==Nr&&(s.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(s.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(s.rotation=this.rotation),this.polygonOffset===!0&&(s.polygonOffset=!0),this.polygonOffsetFactor!==0&&(s.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(s.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(s.linewidth=this.linewidth),this.dashSize!==void 0&&(s.dashSize=this.dashSize),this.gapSize!==void 0&&(s.gapSize=this.gapSize),this.scale!==void 0&&(s.scale=this.scale),this.dithering===!0&&(s.dithering=!0),this.alphaTest>0&&(s.alphaTest=this.alphaTest),this.alphaHash===!0&&(s.alphaHash=!0),this.alphaToCoverage===!0&&(s.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(s.premultipliedAlpha=!0),this.forceSinglePass===!0&&(s.forceSinglePass=!0),this.allowOverride===!1&&(s.allowOverride=!1),this.wireframe===!0&&(s.wireframe=!0),this.wireframeLinewidth>1&&(s.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(s.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(s.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(s.flatShading=!0),this.visible===!1&&(s.visible=!1),this.toneMapped===!1&&(s.toneMapped=!1),this.fog===!1&&(s.fog=!1),Object.keys(this.userData).length>0&&(s.userData=this.userData);function l(c){const f=[];for(const p in c){const m=c[p];delete m.metadata,f.push(m)}return f}if(i){const c=l(e.textures),f=l(e.images);c.length>0&&(s.textures=c),f.length>0&&(s.images=f)}return s}fromJSON(e,i){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Ot().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=i[e.map]||null),e.matcap!==void 0&&(this.matcap=i[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=i[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=i[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=i[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let s=e.normalScale;Array.isArray(s)===!1&&(s=[s,s]),this.normalScale=new Ct().fromArray(s)}return e.displacementMap!==void 0&&(this.displacementMap=i[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=i[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=i[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=i[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=i[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=i[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=i[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=i[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=i[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=i[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=i[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=i[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=i[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=i[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Ct().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=i[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=i[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=i[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=i[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=i[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=i[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=i[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const i=e.clippingPlanes;let s=null;if(i!==null){const l=i.length;s=new Array(l);for(let c=0;c!==l;++c)s[c]=i[c].clone()}return this.clippingPlanes=s,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const wa=new ae,Yd=new ae,Lc=new ae,us=new ae,Zd=new ae,Oc=new ae,Kd=new ae;class __{constructor(e=new ae,i=new ae(0,0,-1)){this.origin=e,this.direction=i}set(e,i){return this.origin.copy(e),this.direction.copy(i),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,i){return i.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,wa)),this}closestPointToPoint(e,i){i.subVectors(e,this.origin);const s=i.dot(this.direction);return s<0?i.copy(this.origin):i.copy(this.origin).addScaledVector(this.direction,s)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const i=wa.subVectors(e,this.origin).dot(this.direction);return i<0?this.origin.distanceToSquared(e):(wa.copy(this.origin).addScaledVector(this.direction,i),wa.distanceToSquared(e))}distanceSqToSegment(e,i,s,l){Yd.copy(e).add(i).multiplyScalar(.5),Lc.copy(i).sub(e).normalize(),us.copy(this.origin).sub(Yd);const c=e.distanceTo(i)*.5,f=-this.direction.dot(Lc),p=us.dot(this.direction),m=-us.dot(Lc),h=us.lengthSq(),v=Math.abs(1-f*f);let x,g,M,w;if(v>0)if(x=f*m-p,g=f*p-m,w=c*v,x>=0)if(g>=-w)if(g<=w){const R=1/v;x*=R,g*=R,M=x*(x+f*g+2*p)+g*(f*x+g+2*m)+h}else g=c,x=Math.max(0,-(f*g+p)),M=-x*x+g*(g+2*m)+h;else g=-c,x=Math.max(0,-(f*g+p)),M=-x*x+g*(g+2*m)+h;else g<=-w?(x=Math.max(0,-(-f*c+p)),g=x>0?-c:Math.min(Math.max(-c,-m),c),M=-x*x+g*(g+2*m)+h):g<=w?(x=0,g=Math.min(Math.max(-c,-m),c),M=g*(g+2*m)+h):(x=Math.max(0,-(f*c+p)),g=x>0?c:Math.min(Math.max(-c,-m),c),M=-x*x+g*(g+2*m)+h);else g=f>0?-c:c,x=Math.max(0,-(f*g+p)),M=-x*x+g*(g+2*m)+h;return s&&s.copy(this.origin).addScaledVector(this.direction,x),l&&l.copy(Yd).addScaledVector(Lc,g),M}intersectSphere(e,i){wa.subVectors(e.center,this.origin);const s=wa.dot(this.direction),l=wa.dot(wa)-s*s,c=e.radius*e.radius;if(l>c)return null;const f=Math.sqrt(c-l),p=s-f,m=s+f;return m<0?null:p<0?this.at(m,i):this.at(p,i)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const i=e.normal.dot(this.direction);if(i===0)return e.distanceToPoint(this.origin)===0?0:null;const s=-(this.origin.dot(e.normal)+e.constant)/i;return s>=0?s:null}intersectPlane(e,i){const s=this.distanceToPlane(e);return s===null?null:this.at(s,i)}intersectsPlane(e){const i=e.distanceToPoint(this.origin);return i===0||e.normal.dot(this.direction)*i<0}intersectBox(e,i){let s,l,c,f,p,m;const h=1/this.direction.x,v=1/this.direction.y,x=1/this.direction.z,g=this.origin;return h>=0?(s=(e.min.x-g.x)*h,l=(e.max.x-g.x)*h):(s=(e.max.x-g.x)*h,l=(e.min.x-g.x)*h),v>=0?(c=(e.min.y-g.y)*v,f=(e.max.y-g.y)*v):(c=(e.max.y-g.y)*v,f=(e.min.y-g.y)*v),s>f||c>l||((c>s||isNaN(s))&&(s=c),(f<l||isNaN(l))&&(l=f),x>=0?(p=(e.min.z-g.z)*x,m=(e.max.z-g.z)*x):(p=(e.max.z-g.z)*x,m=(e.min.z-g.z)*x),s>m||p>l)||((p>s||s!==s)&&(s=p),(m<l||l!==l)&&(l=m),l<0)?null:this.at(s>=0?s:l,i)}intersectsBox(e){return this.intersectBox(e,wa)!==null}intersectTriangle(e,i,s,l,c){Zd.subVectors(i,e),Oc.subVectors(s,e),Kd.crossVectors(Zd,Oc);let f=this.direction.dot(Kd),p;if(f>0){if(l)return null;p=1}else if(f<0)p=-1,f=-f;else return null;us.subVectors(this.origin,e);const m=p*this.direction.dot(Oc.crossVectors(us,Oc));if(m<0)return null;const h=p*this.direction.dot(Zd.cross(us));if(h<0||m+h>f)return null;const v=-p*us.dot(Kd);return v<0?null:this.at(v/f,c)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Fn extends eo{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ot(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new ms,this.combine=Qv,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const cv=new fn,Fs=new __,Pc=new fu,uv=new ae,Ic=new ae,zc=new ae,Fc=new ae,Qd=new ae,Bc=new ae,fv=new ae,Gc=new ae;class Ge extends Bn{constructor(e=new Yn,i=new Fn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,f=l.length;c<f;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}getVertexPosition(e,i){const s=this.geometry,l=s.attributes.position,c=s.morphAttributes.position,f=s.morphTargetsRelative;i.fromBufferAttribute(l,e);const p=this.morphTargetInfluences;if(c&&p){Bc.set(0,0,0);for(let m=0,h=c.length;m<h;m++){const v=p[m],x=c[m];v!==0&&(Qd.fromBufferAttribute(x,e),f?Bc.addScaledVector(Qd,v):Bc.addScaledVector(Qd.sub(i),v))}i.add(Bc)}return i}raycast(e,i){const s=this.geometry,l=this.material,c=this.matrixWorld;l!==void 0&&(s.boundingSphere===null&&s.computeBoundingSphere(),Pc.copy(s.boundingSphere),Pc.applyMatrix4(c),Fs.copy(e.ray).recast(e.near),!(Pc.containsPoint(Fs.origin)===!1&&(Fs.intersectSphere(Pc,uv)===null||Fs.origin.distanceToSquared(uv)>(e.far-e.near)**2))&&(cv.copy(c).invert(),Fs.copy(e.ray).applyMatrix4(cv),!(s.boundingBox!==null&&Fs.intersectsBox(s.boundingBox)===!1)&&this._computeIntersections(e,i,Fs)))}_computeIntersections(e,i,s){let l;const c=this.geometry,f=this.material,p=c.index,m=c.attributes.position,h=c.attributes.uv,v=c.attributes.uv1,x=c.attributes.normal,g=c.groups,M=c.drawRange;if(p!==null)if(Array.isArray(f))for(let w=0,R=g.length;w<R;w++){const b=g[w],y=f[b.materialIndex],P=Math.max(b.start,M.start),O=Math.min(p.count,Math.min(b.start+b.count,M.start+M.count));for(let C=P,I=O;C<I;C+=3){const L=p.getX(C),F=p.getX(C+1),T=p.getX(C+2);l=Hc(this,y,e,s,h,v,x,L,F,T),l&&(l.faceIndex=Math.floor(C/3),l.face.materialIndex=b.materialIndex,i.push(l))}}else{const w=Math.max(0,M.start),R=Math.min(p.count,M.start+M.count);for(let b=w,y=R;b<y;b+=3){const P=p.getX(b),O=p.getX(b+1),C=p.getX(b+2);l=Hc(this,f,e,s,h,v,x,P,O,C),l&&(l.faceIndex=Math.floor(b/3),i.push(l))}}else if(m!==void 0)if(Array.isArray(f))for(let w=0,R=g.length;w<R;w++){const b=g[w],y=f[b.materialIndex],P=Math.max(b.start,M.start),O=Math.min(m.count,Math.min(b.start+b.count,M.start+M.count));for(let C=P,I=O;C<I;C+=3){const L=C,F=C+1,T=C+2;l=Hc(this,y,e,s,h,v,x,L,F,T),l&&(l.faceIndex=Math.floor(C/3),l.face.materialIndex=b.materialIndex,i.push(l))}}else{const w=Math.max(0,M.start),R=Math.min(m.count,M.start+M.count);for(let b=w,y=R;b<y;b+=3){const P=b,O=b+1,C=b+2;l=Hc(this,f,e,s,h,v,x,P,O,C),l&&(l.faceIndex=Math.floor(b/3),i.push(l))}}}}function P1(r,e,i,s,l,c,f,p){let m;if(e.side===ii?m=s.intersectTriangle(f,c,l,!0,p):m=s.intersectTriangle(l,c,f,e.side===ps,p),m===null)return null;Gc.copy(p),Gc.applyMatrix4(r.matrixWorld);const h=i.ray.origin.distanceTo(Gc);return h<i.near||h>i.far?null:{distance:h,point:Gc.clone(),object:r}}function Hc(r,e,i,s,l,c,f,p,m,h){r.getVertexPosition(p,Ic),r.getVertexPosition(m,zc),r.getVertexPosition(h,Fc);const v=P1(r,e,i,s,Ic,zc,Fc,fv);if(v){const x=new ae;Fi.getBarycoord(fv,Ic,zc,Fc,x),l&&(v.uv=Fi.getInterpolatedAttribute(l,p,m,h,x,new Ct)),c&&(v.uv1=Fi.getInterpolatedAttribute(c,p,m,h,x,new Ct)),f&&(v.normal=Fi.getInterpolatedAttribute(f,p,m,h,x,new ae),v.normal.dot(s.direction)>0&&v.normal.multiplyScalar(-1));const g={a:p,b:m,c:h,normal:new ae,materialIndex:0};Fi.getNormal(Ic,zc,Fc,g.normal),v.face=g,v.barycoord=x}return v}class I1 extends qn{constructor(e=null,i=1,s=1,l,c,f,p,m,h=zn,v=zn,x,g){super(null,f,p,m,h,v,l,c,x,g),this.isDataTexture=!0,this.image={data:e,width:i,height:s},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Jd=new ae,z1=new ae,F1=new _t;class Gs{constructor(e=new ae(1,0,0),i=0){this.isPlane=!0,this.normal=e,this.constant=i}set(e,i){return this.normal.copy(e),this.constant=i,this}setComponents(e,i,s,l){return this.normal.set(e,i,s),this.constant=l,this}setFromNormalAndCoplanarPoint(e,i){return this.normal.copy(e),this.constant=-i.dot(this.normal),this}setFromCoplanarPoints(e,i,s){const l=Jd.subVectors(s,i).cross(z1.subVectors(e,i)).normalize();return this.setFromNormalAndCoplanarPoint(l,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,i){return i.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,i,s=!0){const l=e.delta(Jd),c=this.normal.dot(l);if(c===0)return this.distanceToPoint(e.start)===0?i.copy(e.start):null;const f=-(e.start.dot(this.normal)+this.constant)/c;return s===!0&&(f<0||f>1)?null:i.copy(e.start).addScaledVector(l,f)}intersectsLine(e){const i=this.distanceToPoint(e.start),s=this.distanceToPoint(e.end);return i<0&&s>0||s<0&&i>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,i){const s=i||F1.getNormalMatrix(e),l=this.coplanarPoint(Jd).applyMatrix4(e),c=this.normal.applyMatrix3(s).normalize();return this.constant=-l.dot(c),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Bs=new fu,B1=new Ct(.5,.5),Vc=new ae;class Rp{constructor(e=new Gs,i=new Gs,s=new Gs,l=new Gs,c=new Gs,f=new Gs){this.planes=[e,i,s,l,c,f]}set(e,i,s,l,c,f){const p=this.planes;return p[0].copy(e),p[1].copy(i),p[2].copy(s),p[3].copy(l),p[4].copy(c),p[5].copy(f),this}copy(e){const i=this.planes;for(let s=0;s<6;s++)i[s].copy(e.planes[s]);return this}setFromProjectionMatrix(e,i=Ji,s=!1){const l=this.planes,c=e.elements,f=c[0],p=c[1],m=c[2],h=c[3],v=c[4],x=c[5],g=c[6],M=c[7],w=c[8],R=c[9],b=c[10],y=c[11],P=c[12],O=c[13],C=c[14],I=c[15];if(l[0].setComponents(h-f,M-v,y-w,I-P).normalize(),l[1].setComponents(h+f,M+v,y+w,I+P).normalize(),l[2].setComponents(h+p,M+x,y+R,I+O).normalize(),l[3].setComponents(h-p,M-x,y-R,I-O).normalize(),s)l[4].setComponents(m,g,b,C).normalize(),l[5].setComponents(h-m,M-g,y-b,I-C).normalize();else if(l[4].setComponents(h-m,M-g,y-b,I-C).normalize(),i===Ji)l[5].setComponents(h+m,M+g,y+b,I+C).normalize();else if(i===ul)l[5].setComponents(m,g,b,C).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+i);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Bs.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const i=e.geometry;i.boundingSphere===null&&i.computeBoundingSphere(),Bs.copy(i.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Bs)}intersectsSprite(e){Bs.center.set(0,0,0);const i=B1.distanceTo(e.center);return Bs.radius=.7071067811865476+i,Bs.applyMatrix4(e.matrixWorld),this.intersectsSphere(Bs)}intersectsSphere(e){const i=this.planes,s=e.center,l=-e.radius;for(let c=0;c<6;c++)if(i[c].distanceToPoint(s)<l)return!1;return!0}intersectsBox(e){const i=this.planes;for(let s=0;s<6;s++){const l=i[s];if(Vc.x=l.normal.x>0?e.max.x:e.min.x,Vc.y=l.normal.y>0?e.max.y:e.min.y,Vc.z=l.normal.z>0?e.max.z:e.min.z,l.distanceToPoint(Vc)<0)return!1}return!0}containsPoint(e){const i=this.planes;for(let s=0;s<6;s++)if(i[s].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class y_ extends eo{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ot(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const dv=new fn,ip=new __,kc=new fu,jc=new ae;class G1 extends Bn{constructor(e=new Yn,i=new y_){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,i){const s=this.geometry,l=this.matrixWorld,c=e.params.Points.threshold,f=s.drawRange;if(s.boundingSphere===null&&s.computeBoundingSphere(),kc.copy(s.boundingSphere),kc.applyMatrix4(l),kc.radius+=c,e.ray.intersectsSphere(kc)===!1)return;dv.copy(l).invert(),ip.copy(e.ray).applyMatrix4(dv);const p=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=p*p,h=s.index,x=s.attributes.position;if(h!==null){const g=Math.max(0,f.start),M=Math.min(h.count,f.start+f.count);for(let w=g,R=M;w<R;w++){const b=h.getX(w);jc.fromBufferAttribute(x,b),hv(jc,b,m,l,e,i,this)}}else{const g=Math.max(0,f.start),M=Math.min(x.count,f.start+f.count);for(let w=g,R=M;w<R;w++)jc.fromBufferAttribute(x,w),hv(jc,w,m,l,e,i,this)}}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,f=l.length;c<f;c++){const p=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[p]=c}}}}}function hv(r,e,i,s,l,c,f){const p=ip.distanceSqToPoint(r);if(p<i){const m=new ae;ip.closestPointToPoint(r,m),m.applyMatrix4(s);const h=l.ray.origin.distanceTo(m);if(h<l.near||h>l.far)return;c.push({distance:h,distanceToRay:Math.sqrt(p),point:m,index:e,face:null,faceIndex:null,barycoord:null,object:f})}}class b_ extends qn{constructor(e=[],i=Xs,s,l,c,f,p,m,h,v){super(e,i,s,l,c,f,p,m,h,v),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Kr extends qn{constructor(e,i,s=na,l,c,f,p=zn,m=zn,h,v=Ua,x=1){if(v!==Ua&&v!==js)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const g={width:e,height:i,depth:x};super(g,l,c,f,p,m,v,s,h),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new wp(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const i=super.toJSON(e);return this.compareFunction!==null&&(i.compareFunction=this.compareFunction),i}}class H1 extends Kr{constructor(e,i=na,s=Xs,l,c,f=zn,p=zn,m,h=Ua){const v={width:e,height:e,depth:1},x=[v,v,v,v,v,v];super(e,e,i,s,l,c,f,p,m,h),this.image=x,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class S_ extends qn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Ft extends Yn{constructor(e=1,i=1,s=1,l=1,c=1,f=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:i,depth:s,widthSegments:l,heightSegments:c,depthSegments:f};const p=this;l=Math.floor(l),c=Math.floor(c),f=Math.floor(f);const m=[],h=[],v=[],x=[];let g=0,M=0;w("z","y","x",-1,-1,s,i,e,f,c,0),w("z","y","x",1,-1,s,i,-e,f,c,1),w("x","z","y",1,1,e,s,i,l,f,2),w("x","z","y",1,-1,e,s,-i,l,f,3),w("x","y","z",1,-1,e,i,s,l,c,4),w("x","y","z",-1,-1,e,i,-s,l,c,5),this.setIndex(m),this.setAttribute("position",new xn(h,3)),this.setAttribute("normal",new xn(v,3)),this.setAttribute("uv",new xn(x,2));function w(R,b,y,P,O,C,I,L,F,T,U){const V=C/F,k=I/T,W=C/2,re=I/2,oe=L/2,te=F+1,G=T+1;let X=0,$=0;const se=new ae;for(let B=0;B<G;B++){const E=B*k-re;for(let H=0;H<te;H++){const ce=H*V-W;se[R]=ce*P,se[b]=E*O,se[y]=oe,h.push(se.x,se.y,se.z),se[R]=0,se[b]=0,se[y]=L>0?1:-1,v.push(se.x,se.y,se.z),x.push(H/F),x.push(1-B/T),X+=1}}for(let B=0;B<T;B++)for(let E=0;E<F;E++){const H=g+E+te*B,ce=g+E+te*(B+1),Se=g+(E+1)+te*(B+1),Ae=g+(E+1)+te*B;m.push(H,ce,Ae),m.push(ce,Se,Ae),$+=6}p.addGroup(M,$,U),M+=$,g+=X}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ft(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Dn extends Yn{constructor(e=1,i=1,s=1,l=32,c=1,f=!1,p=0,m=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:i,height:s,radialSegments:l,heightSegments:c,openEnded:f,thetaStart:p,thetaLength:m};const h=this;l=Math.floor(l),c=Math.floor(c);const v=[],x=[],g=[],M=[];let w=0;const R=[],b=s/2;let y=0;P(),f===!1&&(e>0&&O(!0),i>0&&O(!1)),this.setIndex(v),this.setAttribute("position",new xn(x,3)),this.setAttribute("normal",new xn(g,3)),this.setAttribute("uv",new xn(M,2));function P(){const C=new ae,I=new ae;let L=0;const F=(i-e)/s;for(let T=0;T<=c;T++){const U=[],V=T/c,k=V*(i-e)+e;for(let W=0;W<=l;W++){const re=W/l,oe=re*m+p,te=Math.sin(oe),G=Math.cos(oe);I.x=k*te,I.y=-V*s+b,I.z=k*G,x.push(I.x,I.y,I.z),C.set(te,F,G).normalize(),g.push(C.x,C.y,C.z),M.push(re,1-V),U.push(w++)}R.push(U)}for(let T=0;T<l;T++)for(let U=0;U<c;U++){const V=R[U][T],k=R[U+1][T],W=R[U+1][T+1],re=R[U][T+1];(e>0||U!==0)&&(v.push(V,k,re),L+=3),(i>0||U!==c-1)&&(v.push(k,W,re),L+=3)}h.addGroup(y,L,0),y+=L}function O(C){const I=w,L=new Ct,F=new ae;let T=0;const U=C===!0?e:i,V=C===!0?1:-1;for(let W=1;W<=l;W++)x.push(0,b*V,0),g.push(0,V,0),M.push(.5,.5),w++;const k=w;for(let W=0;W<=l;W++){const oe=W/l*m+p,te=Math.cos(oe),G=Math.sin(oe);F.x=U*G,F.y=b*V,F.z=U*te,x.push(F.x,F.y,F.z),g.push(0,V,0),L.x=te*.5+.5,L.y=G*.5*V+.5,M.push(L.x,L.y),w++}for(let W=0;W<l;W++){const re=I+W,oe=k+W;C===!0?v.push(oe,oe+1,re):v.push(oe+1,oe,re),T+=3}h.addGroup(y,T,C===!0?1:2),y+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Dn(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Np extends Dn{constructor(e=1,i=1,s=32,l=1,c=!1,f=0,p=Math.PI*2){super(0,e,i,s,l,c,f,p),this.type="ConeGeometry",this.parameters={radius:e,height:i,radialSegments:s,heightSegments:l,openEnded:c,thetaStart:f,thetaLength:p}}static fromJSON(e){return new Np(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Dp extends Yn{constructor(e=[],i=[],s=1,l=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:i,radius:s,detail:l};const c=[],f=[];p(l),h(s),v(),this.setAttribute("position",new xn(c,3)),this.setAttribute("normal",new xn(c.slice(),3)),this.setAttribute("uv",new xn(f,2)),l===0?this.computeVertexNormals():this.normalizeNormals();function p(P){const O=new ae,C=new ae,I=new ae;for(let L=0;L<i.length;L+=3)M(i[L+0],O),M(i[L+1],C),M(i[L+2],I),m(O,C,I,P)}function m(P,O,C,I){const L=I+1,F=[];for(let T=0;T<=L;T++){F[T]=[];const U=P.clone().lerp(C,T/L),V=O.clone().lerp(C,T/L),k=L-T;for(let W=0;W<=k;W++)W===0&&T===L?F[T][W]=U:F[T][W]=U.clone().lerp(V,W/k)}for(let T=0;T<L;T++)for(let U=0;U<2*(L-T)-1;U++){const V=Math.floor(U/2);U%2===0?(g(F[T][V+1]),g(F[T+1][V]),g(F[T][V])):(g(F[T][V+1]),g(F[T+1][V+1]),g(F[T+1][V]))}}function h(P){const O=new ae;for(let C=0;C<c.length;C+=3)O.x=c[C+0],O.y=c[C+1],O.z=c[C+2],O.normalize().multiplyScalar(P),c[C+0]=O.x,c[C+1]=O.y,c[C+2]=O.z}function v(){const P=new ae;for(let O=0;O<c.length;O+=3){P.x=c[O+0],P.y=c[O+1],P.z=c[O+2];const C=b(P)/2/Math.PI+.5,I=y(P)/Math.PI+.5;f.push(C,1-I)}w(),x()}function x(){for(let P=0;P<f.length;P+=6){const O=f[P+0],C=f[P+2],I=f[P+4],L=Math.max(O,C,I),F=Math.min(O,C,I);L>.9&&F<.1&&(O<.2&&(f[P+0]+=1),C<.2&&(f[P+2]+=1),I<.2&&(f[P+4]+=1))}}function g(P){c.push(P.x,P.y,P.z)}function M(P,O){const C=P*3;O.x=e[C+0],O.y=e[C+1],O.z=e[C+2]}function w(){const P=new ae,O=new ae,C=new ae,I=new ae,L=new Ct,F=new Ct,T=new Ct;for(let U=0,V=0;U<c.length;U+=9,V+=6){P.set(c[U+0],c[U+1],c[U+2]),O.set(c[U+3],c[U+4],c[U+5]),C.set(c[U+6],c[U+7],c[U+8]),L.set(f[V+0],f[V+1]),F.set(f[V+2],f[V+3]),T.set(f[V+4],f[V+5]),I.copy(P).add(O).add(C).divideScalar(3);const k=b(I);R(L,V+0,P,k),R(F,V+2,O,k),R(T,V+4,C,k)}}function R(P,O,C,I){I<0&&P.x===1&&(f[O]=P.x-1),C.x===0&&C.z===0&&(f[O]=I/2/Math.PI+.5)}function b(P){return Math.atan2(P.z,-P.x)}function y(P){return Math.atan2(-P.y,Math.sqrt(P.x*P.x+P.z*P.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Dp(e.vertices,e.indices,e.radius,e.detail)}}class du extends Dp{constructor(e=1,i=0){const s=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],l=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(s,l,e,i),this.type="OctahedronGeometry",this.parameters={radius:e,detail:i}}static fromJSON(e){return new du(e.radius,e.detail)}}class $i extends Yn{constructor(e=1,i=1,s=1,l=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:i,widthSegments:s,heightSegments:l};const c=e/2,f=i/2,p=Math.floor(s),m=Math.floor(l),h=p+1,v=m+1,x=e/p,g=i/m,M=[],w=[],R=[],b=[];for(let y=0;y<v;y++){const P=y*g-f;for(let O=0;O<h;O++){const C=O*x-c;w.push(C,-P,0),R.push(0,0,1),b.push(O/p),b.push(1-y/m)}}for(let y=0;y<m;y++)for(let P=0;P<p;P++){const O=P+h*y,C=P+h*(y+1),I=P+1+h*(y+1),L=P+1+h*y;M.push(O,C,L),M.push(C,I,L)}this.setIndex(M),this.setAttribute("position",new xn(w,3)),this.setAttribute("normal",new xn(R,3)),this.setAttribute("uv",new xn(b,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new $i(e.width,e.height,e.widthSegments,e.heightSegments)}}class Gi extends Yn{constructor(e=1,i=32,s=16,l=0,c=Math.PI*2,f=0,p=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:i,heightSegments:s,phiStart:l,phiLength:c,thetaStart:f,thetaLength:p},i=Math.max(3,Math.floor(i)),s=Math.max(2,Math.floor(s));const m=Math.min(f+p,Math.PI);let h=0;const v=[],x=new ae,g=new ae,M=[],w=[],R=[],b=[];for(let y=0;y<=s;y++){const P=[],O=y/s,C=f+O*p,I=e*Math.cos(C),L=Math.sqrt(e*e-I*I);let F=0;y===0&&f===0?F=.5/i:y===s&&m===Math.PI&&(F=-.5/i);for(let T=0;T<=i;T++){const U=T/i,V=l+U*c;x.x=-L*Math.cos(V),x.y=I,x.z=L*Math.sin(V),w.push(x.x,x.y,x.z),g.copy(x).normalize(),R.push(g.x,g.y,g.z),b.push(U+F,1-O),P.push(h++)}v.push(P)}for(let y=0;y<s;y++)for(let P=0;P<i;P++){const O=v[y][P+1],C=v[y][P],I=v[y+1][P],L=v[y+1][P+1];(y!==0||f>0)&&M.push(O,C,L),(y!==s-1||m<Math.PI)&&M.push(C,I,L)}this.setIndex(M),this.setAttribute("position",new xn(w,3)),this.setAttribute("normal",new xn(R,3)),this.setAttribute("uv",new xn(b,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Gi(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class qs extends Yn{constructor(e=1,i=.4,s=12,l=48,c=Math.PI*2,f=0,p=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:i,radialSegments:s,tubularSegments:l,arc:c,thetaStart:f,thetaLength:p},s=Math.floor(s),l=Math.floor(l);const m=[],h=[],v=[],x=[],g=new ae,M=new ae,w=new ae;for(let R=0;R<=s;R++){const b=f+R/s*p;for(let y=0;y<=l;y++){const P=y/l*c;M.x=(e+i*Math.cos(b))*Math.cos(P),M.y=(e+i*Math.cos(b))*Math.sin(P),M.z=i*Math.sin(b),h.push(M.x,M.y,M.z),g.x=e*Math.cos(P),g.y=e*Math.sin(P),w.subVectors(M,g).normalize(),v.push(w.x,w.y,w.z),x.push(y/l),x.push(R/s)}}for(let R=1;R<=s;R++)for(let b=1;b<=l;b++){const y=(l+1)*R+b-1,P=(l+1)*(R-1)+b-1,O=(l+1)*(R-1)+b,C=(l+1)*R+b;m.push(y,P,C),m.push(P,O,C)}this.setIndex(m),this.setAttribute("position",new xn(h,3)),this.setAttribute("normal",new xn(v,3)),this.setAttribute("uv",new xn(x,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new qs(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}function Qr(r){const e={};for(const i in r){e[i]={};for(const s in r[i]){const l=r[i][s];if(pv(l))l.isRenderTargetTexture?(xt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[i][s]=null):e[i][s]=l.clone();else if(Array.isArray(l))if(pv(l[0])){const c=[];for(let f=0,p=l.length;f<p;f++)c[f]=l[f].clone();e[i][s]=c}else e[i][s]=l.slice();else e[i][s]=l}}return e}function Wn(r){const e={};for(let i=0;i<r.length;i++){const s=Qr(r[i]);for(const l in s)e[l]=s[l]}return e}function pv(r){return r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)}function V1(r){const e=[];for(let i=0;i<r.length;i++)e.push(r[i].clone());return e}function M_(r){const e=r.getRenderTarget();return e===null?r.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:It.workingColorSpace}const k1={clone:Qr,merge:Wn};var j1=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,X1=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class ia extends eo{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=j1,this.fragmentShader=X1,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Qr(e.uniforms),this.uniformsGroups=V1(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const i=super.toJSON(e);i.glslVersion=this.glslVersion,i.uniforms={};for(const l in this.uniforms){const f=this.uniforms[l].value;f&&f.isTexture?i.uniforms[l]={type:"t",value:f.toJSON(e).uuid}:f&&f.isColor?i.uniforms[l]={type:"c",value:f.getHex()}:f&&f.isVector2?i.uniforms[l]={type:"v2",value:f.toArray()}:f&&f.isVector3?i.uniforms[l]={type:"v3",value:f.toArray()}:f&&f.isVector4?i.uniforms[l]={type:"v4",value:f.toArray()}:f&&f.isMatrix3?i.uniforms[l]={type:"m3",value:f.toArray()}:f&&f.isMatrix4?i.uniforms[l]={type:"m4",value:f.toArray()}:i.uniforms[l]={value:f}}Object.keys(this.defines).length>0&&(i.defines=this.defines),i.vertexShader=this.vertexShader,i.fragmentShader=this.fragmentShader,i.lights=this.lights,i.clipping=this.clipping;const s={};for(const l in this.extensions)this.extensions[l]===!0&&(s[l]=!0);return Object.keys(s).length>0&&(i.extensions=s),i}fromJSON(e,i){if(super.fromJSON(e,i),e.uniforms!==void 0)for(const s in e.uniforms){const l=e.uniforms[s];switch(this.uniforms[s]={},l.type){case"t":this.uniforms[s].value=i[l.value]||null;break;case"c":this.uniforms[s].value=new Ot().setHex(l.value);break;case"v2":this.uniforms[s].value=new Ct().fromArray(l.value);break;case"v3":this.uniforms[s].value=new ae().fromArray(l.value);break;case"v4":this.uniforms[s].value=new un().fromArray(l.value);break;case"m3":this.uniforms[s].value=new _t().fromArray(l.value);break;case"m4":this.uniforms[s].value=new fn().fromArray(l.value);break;default:this.uniforms[s].value=l.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const s in e.extensions)this.extensions[s]=e.extensions[s];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class W1 extends ia{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class St extends eo{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Ot(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ot(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=tp,this.normalScale=new Ct(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new ms,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class q1 extends eo{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=a1,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Y1 extends eo{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class E_ extends Bn{constructor(e,i=1){super(),this.isLight=!0,this.type="Light",this.color=new Ot(e),this.intensity=i}dispose(){this.dispatchEvent({type:"dispose"})}copy(e,i){return super.copy(e,i),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const i=super.toJSON(e);return i.object.color=this.color.getHex(),i.object.intensity=this.intensity,i}}const $d=new fn,mv=new ae,gv=new ae;class Z1{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ct(512,512),this.mapType=xi,this.map=null,this.mapPass=null,this.matrix=new fn,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Rp,this._frameExtents=new Ct(1,1),this._viewportCount=1,this._viewports=[new un(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const i=this.camera,s=this.matrix;mv.setFromMatrixPosition(e.matrixWorld),i.position.copy(mv),gv.setFromMatrixPosition(e.target.matrixWorld),i.lookAt(gv),i.updateMatrixWorld(),$d.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix($d,i.coordinateSystem,i.reversedDepth),i.coordinateSystem===ul||i.reversedDepth?s.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):s.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),s.multiply($d)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Xc=new ae,Wc=new $r,Yi=new ae;class T_ extends Bn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new fn,this.projectionMatrix=new fn,this.projectionMatrixInverse=new fn,this.coordinateSystem=Ji,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,i){return super.copy(e,i),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Xc,Wc,Yi),Yi.x===1&&Yi.y===1&&Yi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Xc,Wc,Yi.set(1,1,1)).invert()}updateWorldMatrix(e,i,s=!1){super.updateWorldMatrix(e,i,s),this.matrixWorld.decompose(Xc,Wc,Yi),Yi.x===1&&Yi.y===1&&Yi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Xc,Wc,Yi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const fs=new ae,xv=new Ct,vv=new Ct;class Ci extends T_{constructor(e=50,i=1,s=.1,l=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=s,this.far=l,this.focus=10,this.aspect=i,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const i=.5*this.getFilmHeight()/e;this.fov=np*2*Math.atan(i),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Rd*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return np*2*Math.atan(Math.tan(Rd*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,i,s){fs.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(fs.x,fs.y).multiplyScalar(-e/fs.z),fs.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),s.set(fs.x,fs.y).multiplyScalar(-e/fs.z)}getViewSize(e,i){return this.getViewBounds(e,xv,vv),i.subVectors(vv,xv)}setViewOffset(e,i,s,l,c,f){this.aspect=e/i,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let i=e*Math.tan(Rd*.5*this.fov)/this.zoom,s=2*i,l=this.aspect*s,c=-.5*l;const f=this.view;if(this.view!==null&&this.view.enabled){const m=f.fullWidth,h=f.fullHeight;c+=f.offsetX*l/m,i-=f.offsetY*s/h,l*=f.width/m,s*=f.height/h}const p=this.filmOffset;p!==0&&(c+=e*p/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+l,i,i-s,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.fov=this.fov,i.object.zoom=this.zoom,i.object.near=this.near,i.object.far=this.far,i.object.focus=this.focus,i.object.aspect=this.aspect,this.view!==null&&(i.object.view=Object.assign({},this.view)),i.object.filmGauge=this.filmGauge,i.object.filmOffset=this.filmOffset,i}}class Up extends T_{constructor(e=-1,i=1,s=1,l=-1,c=.1,f=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=i,this.top=s,this.bottom=l,this.near=c,this.far=f,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,i,s,l,c,f){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),i=(this.top-this.bottom)/(2*this.zoom),s=(this.right+this.left)/2,l=(this.top+this.bottom)/2;let c=s-e,f=s+e,p=l+i,m=l-i;if(this.view!==null&&this.view.enabled){const h=(this.right-this.left)/this.view.fullWidth/this.zoom,v=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=h*this.view.offsetX,f=c+h*this.view.width,p-=v*this.view.offsetY,m=p-v*this.view.height}this.projectionMatrix.makeOrthographic(c,f,p,m,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.zoom=this.zoom,i.object.left=this.left,i.object.right=this.right,i.object.top=this.top,i.object.bottom=this.bottom,i.object.near=this.near,i.object.far=this.far,this.view!==null&&(i.object.view=Object.assign({},this.view)),i}}class K1 extends Z1{constructor(){super(new Up(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Q1 extends E_{constructor(e,i){super(e,i),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Bn.DEFAULT_UP),this.updateMatrix(),this.target=new Bn,this.shadow=new K1}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const i=super.toJSON(e);return i.object.shadow=this.shadow.toJSON(),i.object.target=this.target.uuid,i}}class J1 extends E_{constructor(e,i){super(e,i),this.isAmbientLight=!0,this.type="AmbientLight"}}const Hr=-90,Vr=1;class $1 extends Bn{constructor(e,i,s){super(),this.type="CubeCamera",this.renderTarget=s,this.coordinateSystem=null,this.activeMipmapLevel=0;const l=new Ci(Hr,Vr,e,i);l.layers=this.layers,this.add(l);const c=new Ci(Hr,Vr,e,i);c.layers=this.layers,this.add(c);const f=new Ci(Hr,Vr,e,i);f.layers=this.layers,this.add(f);const p=new Ci(Hr,Vr,e,i);p.layers=this.layers,this.add(p);const m=new Ci(Hr,Vr,e,i);m.layers=this.layers,this.add(m);const h=new Ci(Hr,Vr,e,i);h.layers=this.layers,this.add(h)}updateCoordinateSystem(){const e=this.coordinateSystem,i=this.children.concat(),[s,l,c,f,p,m]=i;for(const h of i)this.remove(h);if(e===Ji)s.up.set(0,1,0),s.lookAt(1,0,0),l.up.set(0,1,0),l.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),f.up.set(0,0,1),f.lookAt(0,-1,0),p.up.set(0,1,0),p.lookAt(0,0,1),m.up.set(0,1,0),m.lookAt(0,0,-1);else if(e===ul)s.up.set(0,-1,0),s.lookAt(-1,0,0),l.up.set(0,-1,0),l.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),f.up.set(0,0,-1),f.lookAt(0,-1,0),p.up.set(0,-1,0),p.lookAt(0,0,1),m.up.set(0,-1,0),m.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const h of i)this.add(h),h.updateMatrixWorld()}update(e,i){this.parent===null&&this.updateMatrixWorld();const{renderTarget:s,activeMipmapLevel:l}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[c,f,p,m,h,v]=this.children,x=e.getRenderTarget(),g=e.getActiveCubeFace(),M=e.getActiveMipmapLevel(),w=e.xr.enabled;e.xr.enabled=!1;const R=s.texture.generateMipmaps;s.texture.generateMipmaps=!1;let b=!1;e.isWebGLRenderer===!0?b=e.state.buffers.depth.getReversed():b=e.reversedDepthBuffer,e.setRenderTarget(s,0,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,c),e.setRenderTarget(s,1,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,f),e.setRenderTarget(s,2,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,p),e.setRenderTarget(s,3,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,m),e.setRenderTarget(s,4,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,h),s.texture.generateMipmaps=R,e.setRenderTarget(s,5,l),b&&e.autoClear===!1&&e.clearDepth(),e.render(i,v),e.setRenderTarget(x,g,M),e.xr.enabled=w,s.texture.needsPMREMUpdate=!0}}class eE extends Ci{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const Bp=class Bp{constructor(e,i,s,l){this.elements=[1,0,0,1],e!==void 0&&this.set(e,i,s,l)}identity(){return this.set(1,0,0,1),this}fromArray(e,i=0){for(let s=0;s<4;s++)this.elements[s]=e[s+i];return this}set(e,i,s,l){const c=this.elements;return c[0]=e,c[2]=i,c[1]=s,c[3]=l,this}};Bp.prototype.isMatrix2=!0;let _v=Bp;function yv(r,e,i,s){const l=tE(s);switch(i){case u_:return r*e;case d_:return r*e/l.components*l.byteLength;case Sp:return r*e/l.components*l.byteLength;case Ws:return r*e*2/l.components*l.byteLength;case Mp:return r*e*2/l.components*l.byteLength;case f_:return r*e*3/l.components*l.byteLength;case Bi:return r*e*4/l.components*l.byteLength;case Ep:return r*e*4/l.components*l.byteLength;case Zc:case Kc:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case Qc:case Jc:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Ah:case Ch:return Math.max(r,16)*Math.max(e,8)/4;case Th:case wh:return Math.max(r,8)*Math.max(e,8)/2;case Rh:case Nh:case Uh:case Lh:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case Dh:case nu:case Oh:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Ph:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Ih:return Math.floor((r+4)/5)*Math.floor((e+3)/4)*16;case zh:return Math.floor((r+4)/5)*Math.floor((e+4)/5)*16;case Fh:return Math.floor((r+5)/6)*Math.floor((e+4)/5)*16;case Bh:return Math.floor((r+5)/6)*Math.floor((e+5)/6)*16;case Gh:return Math.floor((r+7)/8)*Math.floor((e+4)/5)*16;case Hh:return Math.floor((r+7)/8)*Math.floor((e+5)/6)*16;case Vh:return Math.floor((r+7)/8)*Math.floor((e+7)/8)*16;case kh:return Math.floor((r+9)/10)*Math.floor((e+4)/5)*16;case jh:return Math.floor((r+9)/10)*Math.floor((e+5)/6)*16;case Xh:return Math.floor((r+9)/10)*Math.floor((e+7)/8)*16;case Wh:return Math.floor((r+9)/10)*Math.floor((e+9)/10)*16;case qh:return Math.floor((r+11)/12)*Math.floor((e+9)/10)*16;case Yh:return Math.floor((r+11)/12)*Math.floor((e+11)/12)*16;case Zh:case Kh:case Qh:return Math.ceil(r/4)*Math.ceil(e/4)*16;case Jh:case $h:return Math.ceil(r/4)*Math.ceil(e/4)*8;case iu:case ep:return Math.ceil(r/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${i} format.`)}function tE(r){switch(r){case xi:case r_:return{byteLength:1,components:1};case ll:case o_:case Da:return{byteLength:2,components:1};case yp:case bp:return{byteLength:2,components:4};case na:case _p:case Qi:return{byteLength:4,components:1};case l_:case c_:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:vp}}));typeof window<"u"&&(window.__THREE__?xt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=vp);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function A_(){let r=null,e=!1,i=null,s=null;function l(c,f){i(c,f),s=r.requestAnimationFrame(l)}return{start:function(){e!==!0&&i!==null&&r!==null&&(s=r.requestAnimationFrame(l),e=!0)},stop:function(){r!==null&&r.cancelAnimationFrame(s),e=!1},setAnimationLoop:function(c){i=c},setContext:function(c){r=c}}}function nE(r){const e=new WeakMap;function i(p,m){const h=p.array,v=p.usage,x=h.byteLength,g=r.createBuffer();r.bindBuffer(m,g),r.bufferData(m,h,v),p.onUploadCallback();let M;if(h instanceof Float32Array)M=r.FLOAT;else if(typeof Float16Array<"u"&&h instanceof Float16Array)M=r.HALF_FLOAT;else if(h instanceof Uint16Array)p.isFloat16BufferAttribute?M=r.HALF_FLOAT:M=r.UNSIGNED_SHORT;else if(h instanceof Int16Array)M=r.SHORT;else if(h instanceof Uint32Array)M=r.UNSIGNED_INT;else if(h instanceof Int32Array)M=r.INT;else if(h instanceof Int8Array)M=r.BYTE;else if(h instanceof Uint8Array)M=r.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)M=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:g,type:M,bytesPerElement:h.BYTES_PER_ELEMENT,version:p.version,size:x}}function s(p,m,h){const v=m.array,x=m.updateRanges;if(r.bindBuffer(h,p),x.length===0)r.bufferSubData(h,0,v);else{x.sort((M,w)=>M.start-w.start);let g=0;for(let M=1;M<x.length;M++){const w=x[g],R=x[M];R.start<=w.start+w.count+1?w.count=Math.max(w.count,R.start+R.count-w.start):(++g,x[g]=R)}x.length=g+1;for(let M=0,w=x.length;M<w;M++){const R=x[M];r.bufferSubData(h,R.start*v.BYTES_PER_ELEMENT,v,R.start,R.count)}m.clearUpdateRanges()}m.onUploadCallback()}function l(p){return p.isInterleavedBufferAttribute&&(p=p.data),e.get(p)}function c(p){p.isInterleavedBufferAttribute&&(p=p.data);const m=e.get(p);m&&(r.deleteBuffer(m.buffer),e.delete(p))}function f(p,m){if(p.isInterleavedBufferAttribute&&(p=p.data),p.isGLBufferAttribute){const v=e.get(p);(!v||v.version<p.version)&&e.set(p,{buffer:p.buffer,type:p.type,bytesPerElement:p.elementSize,version:p.version});return}const h=e.get(p);if(h===void 0)e.set(p,i(p,m));else if(h.version<p.version){if(h.size!==p.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(h.buffer,p,m),h.version=p.version}}return{get:l,remove:c,update:f}}var iE=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,aE=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,sE=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,rE=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,oE=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,lE=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,cE=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,uE=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,fE=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,dE=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,hE=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,pE=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,mE=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,gE=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,xE=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,vE=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,_E=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,yE=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,bE=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,SE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,ME=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,EE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,TE=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,AE=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,wE=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,CE=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,RE=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,NE=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,DE=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,UE=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,LE="gl_FragColor = linearToOutputTexel( gl_FragColor );",OE=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,PE=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,IE=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,zE=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,FE=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,BE=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,GE=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,HE=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,VE=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,kE=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,jE=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,XE=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,WE=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,qE=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,YE=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,ZE=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,KE=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,QE=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,JE=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,$E=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,eT=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,tT=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,nT=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,iT=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,aT=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,sT=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,rT=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,oT=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,lT=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,cT=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,uT=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,fT=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,dT=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,hT=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,pT=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,mT=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,gT=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,xT=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,vT=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,_T=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,yT=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,bT=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,ST=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,MT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ET=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,TT=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,AT=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,wT=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,CT=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,RT=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,NT=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,DT=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,UT=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,LT=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,OT=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,PT=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,IT=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,zT=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,FT=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,BT=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,GT=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,HT=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,VT=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,kT=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,jT=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,XT=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,WT=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,qT=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,YT=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,ZT=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,KT=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,QT=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,JT=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,$T=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,e2=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,t2=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,n2=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const i2=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,a2=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,s2=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,r2=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,o2=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,l2=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,c2=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,u2=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,f2=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,d2=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,h2=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,p2=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,m2=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,g2=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,x2=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,v2=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_2=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,y2=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,b2=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,S2=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,M2=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,E2=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,T2=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,A2=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,w2=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,C2=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,R2=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,N2=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,D2=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,U2=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,L2=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,O2=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,P2=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,I2=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,At={alphahash_fragment:iE,alphahash_pars_fragment:aE,alphamap_fragment:sE,alphamap_pars_fragment:rE,alphatest_fragment:oE,alphatest_pars_fragment:lE,aomap_fragment:cE,aomap_pars_fragment:uE,batching_pars_vertex:fE,batching_vertex:dE,begin_vertex:hE,beginnormal_vertex:pE,bsdfs:mE,iridescence_fragment:gE,bumpmap_pars_fragment:xE,clipping_planes_fragment:vE,clipping_planes_pars_fragment:_E,clipping_planes_pars_vertex:yE,clipping_planes_vertex:bE,color_fragment:SE,color_pars_fragment:ME,color_pars_vertex:EE,color_vertex:TE,common:AE,cube_uv_reflection_fragment:wE,defaultnormal_vertex:CE,displacementmap_pars_vertex:RE,displacementmap_vertex:NE,emissivemap_fragment:DE,emissivemap_pars_fragment:UE,colorspace_fragment:LE,colorspace_pars_fragment:OE,envmap_fragment:PE,envmap_common_pars_fragment:IE,envmap_pars_fragment:zE,envmap_pars_vertex:FE,envmap_physical_pars_fragment:ZE,envmap_vertex:BE,fog_vertex:GE,fog_pars_vertex:HE,fog_fragment:VE,fog_pars_fragment:kE,gradientmap_pars_fragment:jE,lightmap_pars_fragment:XE,lights_lambert_fragment:WE,lights_lambert_pars_fragment:qE,lights_pars_begin:YE,lights_toon_fragment:KE,lights_toon_pars_fragment:QE,lights_phong_fragment:JE,lights_phong_pars_fragment:$E,lights_physical_fragment:eT,lights_physical_pars_fragment:tT,lights_fragment_begin:nT,lights_fragment_maps:iT,lights_fragment_end:aT,lightprobes_pars_fragment:sT,logdepthbuf_fragment:rT,logdepthbuf_pars_fragment:oT,logdepthbuf_pars_vertex:lT,logdepthbuf_vertex:cT,map_fragment:uT,map_pars_fragment:fT,map_particle_fragment:dT,map_particle_pars_fragment:hT,metalnessmap_fragment:pT,metalnessmap_pars_fragment:mT,morphinstance_vertex:gT,morphcolor_vertex:xT,morphnormal_vertex:vT,morphtarget_pars_vertex:_T,morphtarget_vertex:yT,normal_fragment_begin:bT,normal_fragment_maps:ST,normal_pars_fragment:MT,normal_pars_vertex:ET,normal_vertex:TT,normalmap_pars_fragment:AT,clearcoat_normal_fragment_begin:wT,clearcoat_normal_fragment_maps:CT,clearcoat_pars_fragment:RT,iridescence_pars_fragment:NT,opaque_fragment:DT,packing:UT,premultiplied_alpha_fragment:LT,project_vertex:OT,dithering_fragment:PT,dithering_pars_fragment:IT,roughnessmap_fragment:zT,roughnessmap_pars_fragment:FT,shadowmap_pars_fragment:BT,shadowmap_pars_vertex:GT,shadowmap_vertex:HT,shadowmask_pars_fragment:VT,skinbase_vertex:kT,skinning_pars_vertex:jT,skinning_vertex:XT,skinnormal_vertex:WT,specularmap_fragment:qT,specularmap_pars_fragment:YT,tonemapping_fragment:ZT,tonemapping_pars_fragment:KT,transmission_fragment:QT,transmission_pars_fragment:JT,uv_pars_fragment:$T,uv_pars_vertex:e2,uv_vertex:t2,worldpos_vertex:n2,background_vert:i2,background_frag:a2,backgroundCube_vert:s2,backgroundCube_frag:r2,cube_vert:o2,cube_frag:l2,depth_vert:c2,depth_frag:u2,distance_vert:f2,distance_frag:d2,equirect_vert:h2,equirect_frag:p2,linedashed_vert:m2,linedashed_frag:g2,meshbasic_vert:x2,meshbasic_frag:v2,meshlambert_vert:_2,meshlambert_frag:y2,meshmatcap_vert:b2,meshmatcap_frag:S2,meshnormal_vert:M2,meshnormal_frag:E2,meshphong_vert:T2,meshphong_frag:A2,meshphysical_vert:w2,meshphysical_frag:C2,meshtoon_vert:R2,meshtoon_frag:N2,points_vert:D2,points_frag:U2,shadow_vert:L2,shadow_frag:O2,sprite_vert:P2,sprite_frag:I2},We={common:{diffuse:{value:new Ot(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new _t},alphaMap:{value:null},alphaMapTransform:{value:new _t},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new _t}},envmap:{envMap:{value:null},envMapRotation:{value:new _t},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new _t}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new _t}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new _t},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new _t},normalScale:{value:new Ct(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new _t},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new _t}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new _t}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new _t}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ot(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new ae},probesMax:{value:new ae},probesResolution:{value:new ae}},points:{diffuse:{value:new Ot(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new _t},alphaTest:{value:0},uvTransform:{value:new _t}},sprite:{diffuse:{value:new Ot(16777215)},opacity:{value:1},center:{value:new Ct(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new _t},alphaMap:{value:null},alphaMapTransform:{value:new _t},alphaTest:{value:0}}},Ki={basic:{uniforms:Wn([We.common,We.specularmap,We.envmap,We.aomap,We.lightmap,We.fog]),vertexShader:At.meshbasic_vert,fragmentShader:At.meshbasic_frag},lambert:{uniforms:Wn([We.common,We.specularmap,We.envmap,We.aomap,We.lightmap,We.emissivemap,We.bumpmap,We.normalmap,We.displacementmap,We.fog,We.lights,{emissive:{value:new Ot(0)},envMapIntensity:{value:1}}]),vertexShader:At.meshlambert_vert,fragmentShader:At.meshlambert_frag},phong:{uniforms:Wn([We.common,We.specularmap,We.envmap,We.aomap,We.lightmap,We.emissivemap,We.bumpmap,We.normalmap,We.displacementmap,We.fog,We.lights,{emissive:{value:new Ot(0)},specular:{value:new Ot(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:At.meshphong_vert,fragmentShader:At.meshphong_frag},standard:{uniforms:Wn([We.common,We.envmap,We.aomap,We.lightmap,We.emissivemap,We.bumpmap,We.normalmap,We.displacementmap,We.roughnessmap,We.metalnessmap,We.fog,We.lights,{emissive:{value:new Ot(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:At.meshphysical_vert,fragmentShader:At.meshphysical_frag},toon:{uniforms:Wn([We.common,We.aomap,We.lightmap,We.emissivemap,We.bumpmap,We.normalmap,We.displacementmap,We.gradientmap,We.fog,We.lights,{emissive:{value:new Ot(0)}}]),vertexShader:At.meshtoon_vert,fragmentShader:At.meshtoon_frag},matcap:{uniforms:Wn([We.common,We.bumpmap,We.normalmap,We.displacementmap,We.fog,{matcap:{value:null}}]),vertexShader:At.meshmatcap_vert,fragmentShader:At.meshmatcap_frag},points:{uniforms:Wn([We.points,We.fog]),vertexShader:At.points_vert,fragmentShader:At.points_frag},dashed:{uniforms:Wn([We.common,We.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:At.linedashed_vert,fragmentShader:At.linedashed_frag},depth:{uniforms:Wn([We.common,We.displacementmap]),vertexShader:At.depth_vert,fragmentShader:At.depth_frag},normal:{uniforms:Wn([We.common,We.bumpmap,We.normalmap,We.displacementmap,{opacity:{value:1}}]),vertexShader:At.meshnormal_vert,fragmentShader:At.meshnormal_frag},sprite:{uniforms:Wn([We.sprite,We.fog]),vertexShader:At.sprite_vert,fragmentShader:At.sprite_frag},background:{uniforms:{uvTransform:{value:new _t},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:At.background_vert,fragmentShader:At.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new _t}},vertexShader:At.backgroundCube_vert,fragmentShader:At.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:At.cube_vert,fragmentShader:At.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:At.equirect_vert,fragmentShader:At.equirect_frag},distance:{uniforms:Wn([We.common,We.displacementmap,{referencePosition:{value:new ae},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:At.distance_vert,fragmentShader:At.distance_frag},shadow:{uniforms:Wn([We.lights,We.fog,{color:{value:new Ot(0)},opacity:{value:1}}]),vertexShader:At.shadow_vert,fragmentShader:At.shadow_frag}};Ki.physical={uniforms:Wn([Ki.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new _t},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new _t},clearcoatNormalScale:{value:new Ct(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new _t},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new _t},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new _t},sheen:{value:0},sheenColor:{value:new Ot(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new _t},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new _t},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new _t},transmissionSamplerSize:{value:new Ct},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new _t},attenuationDistance:{value:0},attenuationColor:{value:new Ot(0)},specularColor:{value:new Ot(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new _t},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new _t},anisotropyVector:{value:new Ct},anisotropyMap:{value:null},anisotropyMapTransform:{value:new _t}}]),vertexShader:At.meshphysical_vert,fragmentShader:At.meshphysical_frag};const qc={r:0,b:0,g:0},z2=new fn,w_=new _t;w_.set(-1,0,0,0,1,0,0,0,1);function F2(r,e,i,s,l,c){const f=new Ot(0);let p=l===!0?0:1,m,h,v=null,x=0,g=null;function M(P){let O=P.isScene===!0?P.background:null;if(O&&O.isTexture){const C=P.backgroundBlurriness>0;O=e.get(O,C)}return O}function w(P){let O=!1;const C=M(P);C===null?b(f,p):C&&C.isColor&&(b(C,1),O=!0);const I=r.xr.getEnvironmentBlendMode();I==="additive"?i.buffers.color.setClear(0,0,0,1,c):I==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,c),(r.autoClear||O)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function R(P,O){const C=M(O);C&&(C.isCubeTexture||C.mapping===uu)?(h===void 0&&(h=new Ge(new Ft(1,1,1),new ia({name:"BackgroundCubeMaterial",uniforms:Qr(Ki.backgroundCube.uniforms),vertexShader:Ki.backgroundCube.vertexShader,fragmentShader:Ki.backgroundCube.fragmentShader,side:ii,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(I,L,F){this.matrixWorld.copyPosition(F.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=C,h.material.uniforms.backgroundBlurriness.value=O.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(z2.makeRotationFromEuler(O.backgroundRotation)).transpose(),C.isCubeTexture&&C.isRenderTargetTexture===!1&&h.material.uniforms.backgroundRotation.value.premultiply(w_),h.material.toneMapped=It.getTransfer(C.colorSpace)!==Qt,(v!==C||x!==C.version||g!==r.toneMapping)&&(h.material.needsUpdate=!0,v=C,x=C.version,g=r.toneMapping),h.layers.enableAll(),P.unshift(h,h.geometry,h.material,0,0,null)):C&&C.isTexture&&(m===void 0&&(m=new Ge(new $i(2,2),new ia({name:"BackgroundMaterial",uniforms:Qr(Ki.background.uniforms),vertexShader:Ki.background.vertexShader,fragmentShader:Ki.background.fragmentShader,side:ps,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),m.geometry.deleteAttribute("normal"),Object.defineProperty(m.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(m)),m.material.uniforms.t2D.value=C,m.material.uniforms.backgroundIntensity.value=O.backgroundIntensity,m.material.toneMapped=It.getTransfer(C.colorSpace)!==Qt,C.matrixAutoUpdate===!0&&C.updateMatrix(),m.material.uniforms.uvTransform.value.copy(C.matrix),(v!==C||x!==C.version||g!==r.toneMapping)&&(m.material.needsUpdate=!0,v=C,x=C.version,g=r.toneMapping),m.layers.enableAll(),P.unshift(m,m.geometry,m.material,0,0,null))}function b(P,O){P.getRGB(qc,M_(r)),i.buffers.color.setClear(qc.r,qc.g,qc.b,O,c)}function y(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),m!==void 0&&(m.geometry.dispose(),m.material.dispose(),m=void 0)}return{getClearColor:function(){return f},setClearColor:function(P,O=1){f.set(P),p=O,b(f,p)},getClearAlpha:function(){return p},setClearAlpha:function(P){p=P,b(f,p)},render:w,addToRenderList:R,dispose:y}}function B2(r,e){const i=r.getParameter(r.MAX_VERTEX_ATTRIBS),s={},l=g(null);let c=l,f=!1;function p(k,W,re,oe,te){let G=!1;const X=x(k,oe,re,W);c!==X&&(c=X,h(c.object)),G=M(k,oe,re,te),G&&w(k,oe,re,te),te!==null&&e.update(te,r.ELEMENT_ARRAY_BUFFER),(G||f)&&(f=!1,C(k,W,re,oe),te!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,e.get(te).buffer))}function m(){return r.createVertexArray()}function h(k){return r.bindVertexArray(k)}function v(k){return r.deleteVertexArray(k)}function x(k,W,re,oe){const te=oe.wireframe===!0;let G=s[W.id];G===void 0&&(G={},s[W.id]=G);const X=k.isInstancedMesh===!0?k.id:0;let $=G[X];$===void 0&&($={},G[X]=$);let se=$[re.id];se===void 0&&(se={},$[re.id]=se);let B=se[te];return B===void 0&&(B=g(m()),se[te]=B),B}function g(k){const W=[],re=[],oe=[];for(let te=0;te<i;te++)W[te]=0,re[te]=0,oe[te]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:W,enabledAttributes:re,attributeDivisors:oe,object:k,attributes:{},index:null}}function M(k,W,re,oe){const te=c.attributes,G=W.attributes;let X=0;const $=re.getAttributes();for(const se in $)if($[se].location>=0){const E=te[se];let H=G[se];if(H===void 0&&(se==="instanceMatrix"&&k.instanceMatrix&&(H=k.instanceMatrix),se==="instanceColor"&&k.instanceColor&&(H=k.instanceColor)),E===void 0||E.attribute!==H||H&&E.data!==H.data)return!0;X++}return c.attributesNum!==X||c.index!==oe}function w(k,W,re,oe){const te={},G=W.attributes;let X=0;const $=re.getAttributes();for(const se in $)if($[se].location>=0){let E=G[se];E===void 0&&(se==="instanceMatrix"&&k.instanceMatrix&&(E=k.instanceMatrix),se==="instanceColor"&&k.instanceColor&&(E=k.instanceColor));const H={};H.attribute=E,E&&E.data&&(H.data=E.data),te[se]=H,X++}c.attributes=te,c.attributesNum=X,c.index=oe}function R(){const k=c.newAttributes;for(let W=0,re=k.length;W<re;W++)k[W]=0}function b(k){y(k,0)}function y(k,W){const re=c.newAttributes,oe=c.enabledAttributes,te=c.attributeDivisors;re[k]=1,oe[k]===0&&(r.enableVertexAttribArray(k),oe[k]=1),te[k]!==W&&(r.vertexAttribDivisor(k,W),te[k]=W)}function P(){const k=c.newAttributes,W=c.enabledAttributes;for(let re=0,oe=W.length;re<oe;re++)W[re]!==k[re]&&(r.disableVertexAttribArray(re),W[re]=0)}function O(k,W,re,oe,te,G,X){X===!0?r.vertexAttribIPointer(k,W,re,te,G):r.vertexAttribPointer(k,W,re,oe,te,G)}function C(k,W,re,oe){R();const te=oe.attributes,G=re.getAttributes(),X=W.defaultAttributeValues;for(const $ in G){const se=G[$];if(se.location>=0){let B=te[$];if(B===void 0&&($==="instanceMatrix"&&k.instanceMatrix&&(B=k.instanceMatrix),$==="instanceColor"&&k.instanceColor&&(B=k.instanceColor)),B!==void 0){const E=B.normalized,H=B.itemSize,ce=e.get(B);if(ce===void 0)continue;const Se=ce.buffer,Ae=ce.type,K=ce.bytesPerElement,le=Ae===r.INT||Ae===r.UNSIGNED_INT||B.gpuType===_p;if(B.isInterleavedBufferAttribute){const xe=B.data,Le=xe.stride,Q=B.offset;if(xe.isInstancedInterleavedBuffer){for(let _e=0;_e<se.locationSize;_e++)y(se.location+_e,xe.meshPerAttribute);k.isInstancedMesh!==!0&&oe._maxInstanceCount===void 0&&(oe._maxInstanceCount=xe.meshPerAttribute*xe.count)}else for(let _e=0;_e<se.locationSize;_e++)b(se.location+_e);r.bindBuffer(r.ARRAY_BUFFER,Se);for(let _e=0;_e<se.locationSize;_e++)O(se.location+_e,H/se.locationSize,Ae,E,Le*K,(Q+H/se.locationSize*_e)*K,le)}else{if(B.isInstancedBufferAttribute){for(let xe=0;xe<se.locationSize;xe++)y(se.location+xe,B.meshPerAttribute);k.isInstancedMesh!==!0&&oe._maxInstanceCount===void 0&&(oe._maxInstanceCount=B.meshPerAttribute*B.count)}else for(let xe=0;xe<se.locationSize;xe++)b(se.location+xe);r.bindBuffer(r.ARRAY_BUFFER,Se);for(let xe=0;xe<se.locationSize;xe++)O(se.location+xe,H/se.locationSize,Ae,E,H*K,H/se.locationSize*xe*K,le)}}else if(X!==void 0){const E=X[$];if(E!==void 0)switch(E.length){case 2:r.vertexAttrib2fv(se.location,E);break;case 3:r.vertexAttrib3fv(se.location,E);break;case 4:r.vertexAttrib4fv(se.location,E);break;default:r.vertexAttrib1fv(se.location,E)}}}}P()}function I(){U();for(const k in s){const W=s[k];for(const re in W){const oe=W[re];for(const te in oe){const G=oe[te];for(const X in G)v(G[X].object),delete G[X];delete oe[te]}}delete s[k]}}function L(k){if(s[k.id]===void 0)return;const W=s[k.id];for(const re in W){const oe=W[re];for(const te in oe){const G=oe[te];for(const X in G)v(G[X].object),delete G[X];delete oe[te]}}delete s[k.id]}function F(k){for(const W in s){const re=s[W];for(const oe in re){const te=re[oe];if(te[k.id]===void 0)continue;const G=te[k.id];for(const X in G)v(G[X].object),delete G[X];delete te[k.id]}}}function T(k){for(const W in s){const re=s[W],oe=k.isInstancedMesh===!0?k.id:0,te=re[oe];if(te!==void 0){for(const G in te){const X=te[G];for(const $ in X)v(X[$].object),delete X[$];delete te[G]}delete re[oe],Object.keys(re).length===0&&delete s[W]}}}function U(){V(),f=!0,c!==l&&(c=l,h(c.object))}function V(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:p,reset:U,resetDefaultState:V,dispose:I,releaseStatesOfGeometry:L,releaseStatesOfObject:T,releaseStatesOfProgram:F,initAttributes:R,enableAttribute:b,disableUnusedAttributes:P}}function G2(r,e,i){let s;function l(m){s=m}function c(m,h){r.drawArrays(s,m,h),i.update(h,s,1)}function f(m,h,v){v!==0&&(r.drawArraysInstanced(s,m,h,v),i.update(h,s,v))}function p(m,h,v){if(v===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(s,m,0,h,0,v);let g=0;for(let M=0;M<v;M++)g+=h[M];i.update(g,s,1)}this.setMode=l,this.render=c,this.renderInstances=f,this.renderMultiDraw=p}function H2(r,e,i,s){let l;function c(){if(l!==void 0)return l;if(e.has("EXT_texture_filter_anisotropic")===!0){const F=e.get("EXT_texture_filter_anisotropic");l=r.getParameter(F.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function f(F){return!(F!==Bi&&s.convert(F)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function p(F){const T=F===Da&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(F!==xi&&s.convert(F)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&F!==Qi&&!T)}function m(F){if(F==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";F="mediump"}return F==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let h=i.precision!==void 0?i.precision:"highp";const v=m(h);v!==h&&(xt("WebGLRenderer:",h,"not supported, using",v,"instead."),h=v);const x=i.logarithmicDepthBuffer===!0,g=i.reversedDepthBuffer===!0&&e.has("EXT_clip_control");i.reversedDepthBuffer===!0&&g===!1&&xt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const M=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),w=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),R=r.getParameter(r.MAX_TEXTURE_SIZE),b=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),y=r.getParameter(r.MAX_VERTEX_ATTRIBS),P=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),O=r.getParameter(r.MAX_VARYING_VECTORS),C=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),I=r.getParameter(r.MAX_SAMPLES),L=r.getParameter(r.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:m,textureFormatReadable:f,textureTypeReadable:p,precision:h,logarithmicDepthBuffer:x,reversedDepthBuffer:g,maxTextures:M,maxVertexTextures:w,maxTextureSize:R,maxCubemapSize:b,maxAttributes:y,maxVertexUniforms:P,maxVaryings:O,maxFragmentUniforms:C,maxSamples:I,samples:L}}function V2(r){const e=this;let i=null,s=0,l=!1,c=!1;const f=new Gs,p=new _t,m={value:null,needsUpdate:!1};this.uniform=m,this.numPlanes=0,this.numIntersection=0,this.init=function(x,g){const M=x.length!==0||g||s!==0||l;return l=g,s=x.length,M},this.beginShadows=function(){c=!0,v(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(x,g){i=v(x,g,0)},this.setState=function(x,g,M){const w=x.clippingPlanes,R=x.clipIntersection,b=x.clipShadows,y=r.get(x);if(!l||w===null||w.length===0||c&&!b)c?v(null):h();else{const P=c?0:s,O=P*4;let C=y.clippingState||null;m.value=C,C=v(w,g,O,M);for(let I=0;I!==O;++I)C[I]=i[I];y.clippingState=C,this.numIntersection=R?this.numPlanes:0,this.numPlanes+=P}};function h(){m.value!==i&&(m.value=i,m.needsUpdate=s>0),e.numPlanes=s,e.numIntersection=0}function v(x,g,M,w){const R=x!==null?x.length:0;let b=null;if(R!==0){if(b=m.value,w!==!0||b===null){const y=M+R*4,P=g.matrixWorldInverse;p.getNormalMatrix(P),(b===null||b.length<y)&&(b=new Float32Array(y));for(let O=0,C=M;O!==R;++O,C+=4)f.copy(x[O]).applyMatrix4(P,p),f.normal.toArray(b,C),b[C+3]=f.constant}m.value=b,m.needsUpdate=!0}return e.numPlanes=R,e.numIntersection=0,b}}const hs=4,bv=[.125,.215,.35,.446,.526,.582],Vs=20,k2=256,tl=new Up,Sv=new Ot;let eh=null,th=0,nh=0,ih=!1;const j2=new ae;class Mv{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,i=0,s=.1,l=100,c={}){const{size:f=256,position:p=j2}=c;eh=this._renderer.getRenderTarget(),th=this._renderer.getActiveCubeFace(),nh=this._renderer.getActiveMipmapLevel(),ih=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(f);const m=this._allocateTargets();return m.depthBuffer=!0,this._sceneToCubeUV(e,s,l,m,p),i>0&&this._blur(m,0,0,i),this._applyPMREM(m),this._cleanup(m),m}fromEquirectangular(e,i=null){return this._fromTexture(e,i)}fromCubemap(e,i=null){return this._fromTexture(e,i)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Av(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Tv(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(eh,th,nh),this._renderer.xr.enabled=ih,e.scissorTest=!1,kr(e,0,0,e.width,e.height)}_fromTexture(e,i){e.mapping===Xs||e.mapping===Zr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),eh=this._renderer.getRenderTarget(),th=this._renderer.getActiveCubeFace(),nh=this._renderer.getActiveMipmapLevel(),ih=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const s=i||this._allocateTargets();return this._textureToCubeUV(e,s),this._applyPMREM(s),this._cleanup(s),s}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),i=4*this._cubeSize,s={magFilter:jn,minFilter:jn,generateMipmaps:!1,type:Da,format:Bi,colorSpace:au,depthBuffer:!1},l=Ev(e,i,s);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==i){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Ev(e,i,s);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=X2(c)),this._blurMaterial=q2(c,e,i),this._ggxMaterial=W2(c,e,i)}return l}_compileMaterial(e){const i=new Ge(new Yn,e);this._renderer.compile(i,tl)}_sceneToCubeUV(e,i,s,l,c){const m=new Ci(90,1,i,s),h=[1,-1,1,1,1,1],v=[1,1,1,-1,-1,-1],x=this._renderer,g=x.autoClear,M=x.toneMapping;x.getClearColor(Sv),x.toneMapping=ea,x.autoClear=!1,x.state.buffers.depth.getReversed()&&(x.setRenderTarget(l),x.clearDepth(),x.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Ge(new Ft,new Fn({name:"PMREM.Background",side:ii,depthWrite:!1,depthTest:!1})));const R=this._backgroundBox,b=R.material;let y=!1;const P=e.background;P?P.isColor&&(b.color.copy(P),e.background=null,y=!0):(b.color.copy(Sv),y=!0);for(let O=0;O<6;O++){const C=O%3;C===0?(m.up.set(0,h[O],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x+v[O],c.y,c.z)):C===1?(m.up.set(0,0,h[O]),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y+v[O],c.z)):(m.up.set(0,h[O],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y,c.z+v[O]));const I=this._cubeSize;kr(l,C*I,O>2?I:0,I,I),x.setRenderTarget(l),y&&x.render(R,m),x.render(e,m)}x.toneMapping=M,x.autoClear=g,e.background=P}_textureToCubeUV(e,i){const s=this._renderer,l=e.mapping===Xs||e.mapping===Zr;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=Av()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Tv());const c=l?this._cubemapMaterial:this._equirectMaterial,f=this._lodMeshes[0];f.material=c;const p=c.uniforms;p.envMap.value=e;const m=this._cubeSize;kr(i,0,0,3*m,2*m),s.setRenderTarget(i),s.render(f,tl)}_applyPMREM(e){const i=this._renderer,s=i.autoClear;i.autoClear=!1;const l=this._lodMeshes.length;for(let c=1;c<l;c++)this._applyGGXFilter(e,c-1,c);i.autoClear=s}_applyGGXFilter(e,i,s){const l=this._renderer,c=this._pingPongRenderTarget,f=this._ggxMaterial,p=this._lodMeshes[s];p.material=f;const m=f.uniforms,h=s/(this._lodMeshes.length-1),v=i/(this._lodMeshes.length-1),x=Math.sqrt(h*h-v*v),g=0+h*1.25,M=x*g,{_lodMax:w}=this,R=this._sizeLods[s],b=3*R*(s>w-hs?s-w+hs:0),y=4*(this._cubeSize-R);m.envMap.value=e.texture,m.roughness.value=M,m.mipInt.value=w-i,kr(c,b,y,3*R,2*R),l.setRenderTarget(c),l.render(p,tl),m.envMap.value=c.texture,m.roughness.value=0,m.mipInt.value=w-s,kr(e,b,y,3*R,2*R),l.setRenderTarget(e),l.render(p,tl)}_blur(e,i,s,l,c){const f=this._pingPongRenderTarget;this._halfBlur(e,f,i,s,l,"latitudinal",c),this._halfBlur(f,e,s,s,l,"longitudinal",c)}_halfBlur(e,i,s,l,c,f,p){const m=this._renderer,h=this._blurMaterial;f!=="latitudinal"&&f!=="longitudinal"&&Bt("blur direction must be either latitudinal or longitudinal!");const v=3,x=this._lodMeshes[l];x.material=h;const g=h.uniforms,M=this._sizeLods[s]-1,w=isFinite(c)?Math.PI/(2*M):2*Math.PI/(2*Vs-1),R=c/w,b=isFinite(c)?1+Math.floor(v*R):Vs;b>Vs&&xt(`sigmaRadians, ${c}, is too large and will clip, as it requested ${b} samples when the maximum is set to ${Vs}`);const y=[];let P=0;for(let F=0;F<Vs;++F){const T=F/R,U=Math.exp(-T*T/2);y.push(U),F===0?P+=U:F<b&&(P+=2*U)}for(let F=0;F<y.length;F++)y[F]=y[F]/P;g.envMap.value=e.texture,g.samples.value=b,g.weights.value=y,g.latitudinal.value=f==="latitudinal",p&&(g.poleAxis.value=p);const{_lodMax:O}=this;g.dTheta.value=w,g.mipInt.value=O-s;const C=this._sizeLods[l],I=3*C*(l>O-hs?l-O+hs:0),L=4*(this._cubeSize-C);kr(i,I,L,3*C,2*C),m.setRenderTarget(i),m.render(x,tl)}}function X2(r){const e=[],i=[],s=[];let l=r;const c=r-hs+1+bv.length;for(let f=0;f<c;f++){const p=Math.pow(2,l);e.push(p);let m=1/p;f>r-hs?m=bv[f-r+hs-1]:f===0&&(m=0),i.push(m);const h=1/(p-2),v=-h,x=1+h,g=[v,v,x,v,x,x,v,v,x,x,v,x],M=6,w=6,R=3,b=2,y=1,P=new Float32Array(R*w*M),O=new Float32Array(b*w*M),C=new Float32Array(y*w*M);for(let L=0;L<M;L++){const F=L%3*2/3-1,T=L>2?0:-1,U=[F,T,0,F+2/3,T,0,F+2/3,T+1,0,F,T,0,F+2/3,T+1,0,F,T+1,0];P.set(U,R*w*L),O.set(g,b*w*L);const V=[L,L,L,L,L,L];C.set(V,y*w*L)}const I=new Yn;I.setAttribute("position",new Hi(P,R)),I.setAttribute("uv",new Hi(O,b)),I.setAttribute("faceIndex",new Hi(C,y)),s.push(new Ge(I,null)),l>hs&&l--}return{lodMeshes:s,sizeLods:e,sigmas:i}}function Ev(r,e,i){const s=new ta(r,e,i);return s.texture.mapping=uu,s.texture.name="PMREM.cubeUv",s.scissorTest=!0,s}function kr(r,e,i,s,l){r.viewport.set(e,i,s,l),r.scissor.set(e,i,s,l)}function W2(r,e,i){return new ia({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:k2,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:hu(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ra,depthTest:!1,depthWrite:!1})}function q2(r,e,i){const s=new Float32Array(Vs),l=new ae(0,1,0);return new ia({name:"SphericalGaussianBlur",defines:{n:Vs,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:s},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:hu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ra,depthTest:!1,depthWrite:!1})}function Tv(){return new ia({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:hu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ra,depthTest:!1,depthWrite:!1})}function Av(){return new ia({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:hu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ra,depthTest:!1,depthWrite:!1})}function hu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class C_ extends ta{constructor(e=1,i={}){super(e,e,i),this.isWebGLCubeRenderTarget=!0;const s={width:e,height:e,depth:1},l=[s,s,s,s,s,s];this.texture=new b_(l),this._setTextureOptions(i),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,i){this.texture.type=i.type,this.texture.colorSpace=i.colorSpace,this.texture.generateMipmaps=i.generateMipmaps,this.texture.minFilter=i.minFilter,this.texture.magFilter=i.magFilter;const s={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},l=new Ft(5,5,5),c=new ia({name:"CubemapFromEquirect",uniforms:Qr(s.uniforms),vertexShader:s.vertexShader,fragmentShader:s.fragmentShader,side:ii,blending:Ra});c.uniforms.tEquirect.value=i;const f=new Ge(l,c),p=i.minFilter;return i.minFilter===ks&&(i.minFilter=jn),new $1(1,10,this).update(e,f),i.minFilter=p,f.geometry.dispose(),f.material.dispose(),this}clear(e,i=!0,s=!0,l=!0){const c=e.getRenderTarget();for(let f=0;f<6;f++)e.setRenderTarget(this,f),e.clear(i,s,l);e.setRenderTarget(c)}}function Y2(r){let e=new WeakMap,i=new WeakMap,s=null;function l(g,M=!1){return g==null?null:M?f(g):c(g)}function c(g){if(g&&g.isTexture){const M=g.mapping;if(M===Ad||M===wd)if(e.has(g)){const w=e.get(g).texture;return p(w,g.mapping)}else{const w=g.image;if(w&&w.height>0){const R=new C_(w.height);return R.fromEquirectangularTexture(r,g),e.set(g,R),g.addEventListener("dispose",h),p(R.texture,g.mapping)}else return null}}return g}function f(g){if(g&&g.isTexture){const M=g.mapping,w=M===Ad||M===wd,R=M===Xs||M===Zr;if(w||R){let b=i.get(g);const y=b!==void 0?b.texture.pmremVersion:0;if(g.isRenderTargetTexture&&g.pmremVersion!==y)return s===null&&(s=new Mv(r)),b=w?s.fromEquirectangular(g,b):s.fromCubemap(g,b),b.texture.pmremVersion=g.pmremVersion,i.set(g,b),b.texture;if(b!==void 0)return b.texture;{const P=g.image;return w&&P&&P.height>0||R&&P&&m(P)?(s===null&&(s=new Mv(r)),b=w?s.fromEquirectangular(g):s.fromCubemap(g),b.texture.pmremVersion=g.pmremVersion,i.set(g,b),g.addEventListener("dispose",v),b.texture):null}}}return g}function p(g,M){return M===Ad?g.mapping=Xs:M===wd&&(g.mapping=Zr),g}function m(g){let M=0;const w=6;for(let R=0;R<w;R++)g[R]!==void 0&&M++;return M===w}function h(g){const M=g.target;M.removeEventListener("dispose",h);const w=e.get(M);w!==void 0&&(e.delete(M),w.dispose())}function v(g){const M=g.target;M.removeEventListener("dispose",v);const w=i.get(M);w!==void 0&&(i.delete(M),w.dispose())}function x(){e=new WeakMap,i=new WeakMap,s!==null&&(s.dispose(),s=null)}return{get:l,dispose:x}}function Z2(r){const e={};function i(s){if(e[s]!==void 0)return e[s];const l=r.getExtension(s);return e[s]=l,l}return{has:function(s){return i(s)!==null},init:function(){i("EXT_color_buffer_float"),i("WEBGL_clip_cull_distance"),i("OES_texture_float_linear"),i("EXT_color_buffer_half_float"),i("WEBGL_multisampled_render_to_texture"),i("WEBGL_render_shared_exponent")},get:function(s){const l=i(s);return l===null&&Xr("WebGLRenderer: "+s+" extension not supported."),l}}}function K2(r,e,i,s){const l={},c=new WeakMap;function f(x){const g=x.target;g.index!==null&&e.remove(g.index);for(const w in g.attributes)e.remove(g.attributes[w]);g.removeEventListener("dispose",f),delete l[g.id];const M=c.get(g);M&&(e.remove(M),c.delete(g)),s.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,i.memory.geometries--}function p(x,g){return l[g.id]===!0||(g.addEventListener("dispose",f),l[g.id]=!0,i.memory.geometries++),g}function m(x){const g=x.attributes;for(const M in g)e.update(g[M],r.ARRAY_BUFFER)}function h(x){const g=[],M=x.index,w=x.attributes.position;let R=0;if(w===void 0)return;if(M!==null){const P=M.array;R=M.version;for(let O=0,C=P.length;O<C;O+=3){const I=P[O+0],L=P[O+1],F=P[O+2];g.push(I,L,L,F,F,I)}}else{const P=w.array;R=w.version;for(let O=0,C=P.length/3-1;O<C;O+=3){const I=O+0,L=O+1,F=O+2;g.push(I,L,L,F,F,I)}}const b=new(w.count>=65535?v_:x_)(g,1);b.version=R;const y=c.get(x);y&&e.remove(y),c.set(x,b)}function v(x){const g=c.get(x);if(g){const M=x.index;M!==null&&g.version<M.version&&h(x)}else h(x);return c.get(x)}return{get:p,update:m,getWireframeAttribute:v}}function Q2(r,e,i){let s;function l(x){s=x}let c,f;function p(x){c=x.type,f=x.bytesPerElement}function m(x,g){r.drawElements(s,g,c,x*f),i.update(g,s,1)}function h(x,g,M){M!==0&&(r.drawElementsInstanced(s,g,c,x*f,M),i.update(g,s,M))}function v(x,g,M){if(M===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(s,g,0,c,x,0,M);let R=0;for(let b=0;b<M;b++)R+=g[b];i.update(R,s,1)}this.setMode=l,this.setIndex=p,this.render=m,this.renderInstances=h,this.renderMultiDraw=v}function J2(r){const e={geometries:0,textures:0},i={frame:0,calls:0,triangles:0,points:0,lines:0};function s(c,f,p){switch(i.calls++,f){case r.TRIANGLES:i.triangles+=p*(c/3);break;case r.LINES:i.lines+=p*(c/2);break;case r.LINE_STRIP:i.lines+=p*(c-1);break;case r.LINE_LOOP:i.lines+=p*c;break;case r.POINTS:i.points+=p*c;break;default:Bt("WebGLInfo: Unknown draw mode:",f);break}}function l(){i.calls=0,i.triangles=0,i.points=0,i.lines=0}return{memory:e,render:i,programs:null,autoReset:!0,reset:l,update:s}}function $2(r,e,i){const s=new WeakMap,l=new un;function c(f,p,m){const h=f.morphTargetInfluences,v=p.morphAttributes.position||p.morphAttributes.normal||p.morphAttributes.color,x=v!==void 0?v.length:0;let g=s.get(p);if(g===void 0||g.count!==x){let U=function(){F.dispose(),s.delete(p),p.removeEventListener("dispose",U)};g!==void 0&&g.texture.dispose();const M=p.morphAttributes.position!==void 0,w=p.morphAttributes.normal!==void 0,R=p.morphAttributes.color!==void 0,b=p.morphAttributes.position||[],y=p.morphAttributes.normal||[],P=p.morphAttributes.color||[];let O=0;M===!0&&(O=1),w===!0&&(O=2),R===!0&&(O=3);let C=p.attributes.position.count*O,I=1;C>e.maxTextureSize&&(I=Math.ceil(C/e.maxTextureSize),C=e.maxTextureSize);const L=new Float32Array(C*I*4*x),F=new p_(L,C,I,x);F.type=Qi,F.needsUpdate=!0;const T=O*4;for(let V=0;V<x;V++){const k=b[V],W=y[V],re=P[V],oe=C*I*4*V;for(let te=0;te<k.count;te++){const G=te*T;M===!0&&(l.fromBufferAttribute(k,te),L[oe+G+0]=l.x,L[oe+G+1]=l.y,L[oe+G+2]=l.z,L[oe+G+3]=0),w===!0&&(l.fromBufferAttribute(W,te),L[oe+G+4]=l.x,L[oe+G+5]=l.y,L[oe+G+6]=l.z,L[oe+G+7]=0),R===!0&&(l.fromBufferAttribute(re,te),L[oe+G+8]=l.x,L[oe+G+9]=l.y,L[oe+G+10]=l.z,L[oe+G+11]=re.itemSize===4?l.w:1)}}g={count:x,texture:F,size:new Ct(C,I)},s.set(p,g),p.addEventListener("dispose",U)}if(f.isInstancedMesh===!0&&f.morphTexture!==null)m.getUniforms().setValue(r,"morphTexture",f.morphTexture,i);else{let M=0;for(let R=0;R<h.length;R++)M+=h[R];const w=p.morphTargetsRelative?1:1-M;m.getUniforms().setValue(r,"morphTargetBaseInfluence",w),m.getUniforms().setValue(r,"morphTargetInfluences",h)}m.getUniforms().setValue(r,"morphTargetsTexture",g.texture,i),m.getUniforms().setValue(r,"morphTargetsTextureSize",g.size)}return{update:c}}function eA(r,e,i,s,l){let c=new WeakMap;function f(h){const v=l.render.frame,x=h.geometry,g=e.get(h,x);if(c.get(g)!==v&&(e.update(g),c.set(g,v)),h.isInstancedMesh&&(h.hasEventListener("dispose",m)===!1&&h.addEventListener("dispose",m),c.get(h)!==v&&(i.update(h.instanceMatrix,r.ARRAY_BUFFER),h.instanceColor!==null&&i.update(h.instanceColor,r.ARRAY_BUFFER),c.set(h,v))),h.isSkinnedMesh){const M=h.skeleton;c.get(M)!==v&&(M.update(),c.set(M,v))}return g}function p(){c=new WeakMap}function m(h){const v=h.target;v.removeEventListener("dispose",m),s.releaseStatesOfObject(v),i.remove(v.instanceMatrix),v.instanceColor!==null&&i.remove(v.instanceColor)}return{update:f,dispose:p}}const tA={[Jv]:"LINEAR_TONE_MAPPING",[$v]:"REINHARD_TONE_MAPPING",[e_]:"CINEON_TONE_MAPPING",[t_]:"ACES_FILMIC_TONE_MAPPING",[i_]:"AGX_TONE_MAPPING",[a_]:"NEUTRAL_TONE_MAPPING",[n_]:"CUSTOM_TONE_MAPPING"};function nA(r,e,i,s,l,c){const f=new ta(e,i,{type:r,depthBuffer:l,stencilBuffer:c,samples:s?4:0,depthTexture:l?new Kr(e,i):void 0}),p=new ta(e,i,{type:Da,depthBuffer:!1,stencilBuffer:!1}),m=new Yn;m.setAttribute("position",new xn([-1,3,0,-1,-1,0,3,-1,0],3)),m.setAttribute("uv",new xn([0,2,0,0,2,0],2));const h=new W1({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),v=new Ge(m,h),x=new Up(-1,1,1,-1,0,1);let g=null,M=null,w=!1,R,b=null,y=[],P=!1;this.setSize=function(O,C){f.setSize(O,C),p.setSize(O,C);for(let I=0;I<y.length;I++){const L=y[I];L.setSize&&L.setSize(O,C)}},this.setEffects=function(O){y=O,P=y.length>0&&y[0].isRenderPass===!0;const C=f.width,I=f.height;for(let L=0;L<y.length;L++){const F=y[L];F.setSize&&F.setSize(C,I)}},this.begin=function(O,C){if(w||O.toneMapping===ea&&y.length===0)return!1;if(b=C,C!==null){const I=C.width,L=C.height;(f.width!==I||f.height!==L)&&this.setSize(I,L)}return P===!1&&O.setRenderTarget(f),R=O.toneMapping,O.toneMapping=ea,!0},this.hasRenderPass=function(){return P},this.end=function(O,C){O.toneMapping=R,w=!0;let I=f,L=p;for(let F=0;F<y.length;F++){const T=y[F];if(T.enabled!==!1&&(T.render(O,L,I,C),T.needsSwap!==!1)){const U=I;I=L,L=U}}if(g!==O.outputColorSpace||M!==O.toneMapping){g=O.outputColorSpace,M=O.toneMapping,h.defines={},It.getTransfer(g)===Qt&&(h.defines.SRGB_TRANSFER="");const F=tA[M];F&&(h.defines[F]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=I.texture,O.setRenderTarget(b),O.render(v,x),b=null,w=!1},this.isCompositing=function(){return w},this.dispose=function(){f.depthTexture&&f.depthTexture.dispose(),f.dispose(),p.dispose(),m.dispose(),h.dispose()}}const R_=new qn,ap=new Kr(1,1),N_=new p_,D_=new S1,U_=new b_,wv=[],Cv=[],Rv=new Float32Array(16),Nv=new Float32Array(9),Dv=new Float32Array(4);function to(r,e,i){const s=r[0];if(s<=0||s>0)return r;const l=e*i;let c=wv[l];if(c===void 0&&(c=new Float32Array(l),wv[l]=c),e!==0){s.toArray(c,0);for(let f=1,p=0;f!==e;++f)p+=i,r[f].toArray(c,p)}return c}function wn(r,e){if(r.length!==e.length)return!1;for(let i=0,s=r.length;i<s;i++)if(r[i]!==e[i])return!1;return!0}function Cn(r,e){for(let i=0,s=e.length;i<s;i++)r[i]=e[i]}function pu(r,e){let i=Cv[e];i===void 0&&(i=new Int32Array(e),Cv[e]=i);for(let s=0;s!==e;++s)i[s]=r.allocateTextureUnit();return i}function iA(r,e){const i=this.cache;i[0]!==e&&(r.uniform1f(this.addr,e),i[0]=e)}function aA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(r.uniform2f(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(wn(i,e))return;r.uniform2fv(this.addr,e),Cn(i,e)}}function sA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(r.uniform3f(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else if(e.r!==void 0)(i[0]!==e.r||i[1]!==e.g||i[2]!==e.b)&&(r.uniform3f(this.addr,e.r,e.g,e.b),i[0]=e.r,i[1]=e.g,i[2]=e.b);else{if(wn(i,e))return;r.uniform3fv(this.addr,e),Cn(i,e)}}function rA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(wn(i,e))return;r.uniform4fv(this.addr,e),Cn(i,e)}}function oA(r,e){const i=this.cache,s=e.elements;if(s===void 0){if(wn(i,e))return;r.uniformMatrix2fv(this.addr,!1,e),Cn(i,e)}else{if(wn(i,s))return;Dv.set(s),r.uniformMatrix2fv(this.addr,!1,Dv),Cn(i,s)}}function lA(r,e){const i=this.cache,s=e.elements;if(s===void 0){if(wn(i,e))return;r.uniformMatrix3fv(this.addr,!1,e),Cn(i,e)}else{if(wn(i,s))return;Nv.set(s),r.uniformMatrix3fv(this.addr,!1,Nv),Cn(i,s)}}function cA(r,e){const i=this.cache,s=e.elements;if(s===void 0){if(wn(i,e))return;r.uniformMatrix4fv(this.addr,!1,e),Cn(i,e)}else{if(wn(i,s))return;Rv.set(s),r.uniformMatrix4fv(this.addr,!1,Rv),Cn(i,s)}}function uA(r,e){const i=this.cache;i[0]!==e&&(r.uniform1i(this.addr,e),i[0]=e)}function fA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(r.uniform2i(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(wn(i,e))return;r.uniform2iv(this.addr,e),Cn(i,e)}}function dA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(r.uniform3i(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(wn(i,e))return;r.uniform3iv(this.addr,e),Cn(i,e)}}function hA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(wn(i,e))return;r.uniform4iv(this.addr,e),Cn(i,e)}}function pA(r,e){const i=this.cache;i[0]!==e&&(r.uniform1ui(this.addr,e),i[0]=e)}function mA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(r.uniform2ui(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(wn(i,e))return;r.uniform2uiv(this.addr,e),Cn(i,e)}}function gA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(r.uniform3ui(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(wn(i,e))return;r.uniform3uiv(this.addr,e),Cn(i,e)}}function xA(r,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(wn(i,e))return;r.uniform4uiv(this.addr,e),Cn(i,e)}}function vA(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l);let c;this.type===r.SAMPLER_2D_SHADOW?(ap.compareFunction=i.isReversedDepthBuffer()?Ap:Tp,c=ap):c=R_,i.setTexture2D(e||c,l)}function _A(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture3D(e||D_,l)}function yA(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTextureCube(e||U_,l)}function bA(r,e,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture2DArray(e||N_,l)}function SA(r){switch(r){case 5126:return iA;case 35664:return aA;case 35665:return sA;case 35666:return rA;case 35674:return oA;case 35675:return lA;case 35676:return cA;case 5124:case 35670:return uA;case 35667:case 35671:return fA;case 35668:case 35672:return dA;case 35669:case 35673:return hA;case 5125:return pA;case 36294:return mA;case 36295:return gA;case 36296:return xA;case 35678:case 36198:case 36298:case 36306:case 35682:return vA;case 35679:case 36299:case 36307:return _A;case 35680:case 36300:case 36308:case 36293:return yA;case 36289:case 36303:case 36311:case 36292:return bA}}function MA(r,e){r.uniform1fv(this.addr,e)}function EA(r,e){const i=to(e,this.size,2);r.uniform2fv(this.addr,i)}function TA(r,e){const i=to(e,this.size,3);r.uniform3fv(this.addr,i)}function AA(r,e){const i=to(e,this.size,4);r.uniform4fv(this.addr,i)}function wA(r,e){const i=to(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,i)}function CA(r,e){const i=to(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,i)}function RA(r,e){const i=to(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,i)}function NA(r,e){r.uniform1iv(this.addr,e)}function DA(r,e){r.uniform2iv(this.addr,e)}function UA(r,e){r.uniform3iv(this.addr,e)}function LA(r,e){r.uniform4iv(this.addr,e)}function OA(r,e){r.uniform1uiv(this.addr,e)}function PA(r,e){r.uniform2uiv(this.addr,e)}function IA(r,e){r.uniform3uiv(this.addr,e)}function zA(r,e){r.uniform4uiv(this.addr,e)}function FA(r,e,i){const s=this.cache,l=e.length,c=pu(i,l);wn(s,c)||(r.uniform1iv(this.addr,c),Cn(s,c));let f;this.type===r.SAMPLER_2D_SHADOW?f=ap:f=R_;for(let p=0;p!==l;++p)i.setTexture2D(e[p]||f,c[p])}function BA(r,e,i){const s=this.cache,l=e.length,c=pu(i,l);wn(s,c)||(r.uniform1iv(this.addr,c),Cn(s,c));for(let f=0;f!==l;++f)i.setTexture3D(e[f]||D_,c[f])}function GA(r,e,i){const s=this.cache,l=e.length,c=pu(i,l);wn(s,c)||(r.uniform1iv(this.addr,c),Cn(s,c));for(let f=0;f!==l;++f)i.setTextureCube(e[f]||U_,c[f])}function HA(r,e,i){const s=this.cache,l=e.length,c=pu(i,l);wn(s,c)||(r.uniform1iv(this.addr,c),Cn(s,c));for(let f=0;f!==l;++f)i.setTexture2DArray(e[f]||N_,c[f])}function VA(r){switch(r){case 5126:return MA;case 35664:return EA;case 35665:return TA;case 35666:return AA;case 35674:return wA;case 35675:return CA;case 35676:return RA;case 5124:case 35670:return NA;case 35667:case 35671:return DA;case 35668:case 35672:return UA;case 35669:case 35673:return LA;case 5125:return OA;case 36294:return PA;case 36295:return IA;case 36296:return zA;case 35678:case 36198:case 36298:case 36306:case 35682:return FA;case 35679:case 36299:case 36307:return BA;case 35680:case 36300:case 36308:case 36293:return GA;case 36289:case 36303:case 36311:case 36292:return HA}}class kA{constructor(e,i,s){this.id=e,this.addr=s,this.cache=[],this.type=i.type,this.setValue=SA(i.type)}}class jA{constructor(e,i,s){this.id=e,this.addr=s,this.cache=[],this.type=i.type,this.size=i.size,this.setValue=VA(i.type)}}class XA{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,i,s){const l=this.seq;for(let c=0,f=l.length;c!==f;++c){const p=l[c];p.setValue(e,i[p.id],s)}}}const ah=/(\w+)(\])?(\[|\.)?/g;function Uv(r,e){r.seq.push(e),r.map[e.id]=e}function WA(r,e,i){const s=r.name,l=s.length;for(ah.lastIndex=0;;){const c=ah.exec(s),f=ah.lastIndex;let p=c[1];const m=c[2]==="]",h=c[3];if(m&&(p=p|0),h===void 0||h==="["&&f+2===l){Uv(i,h===void 0?new kA(p,r,e):new jA(p,r,e));break}else{let x=i.map[p];x===void 0&&(x=new XA(p),Uv(i,x)),i=x}}}class $c{constructor(e,i){this.seq=[],this.map={};const s=e.getProgramParameter(i,e.ACTIVE_UNIFORMS);for(let f=0;f<s;++f){const p=e.getActiveUniform(i,f),m=e.getUniformLocation(i,p.name);WA(p,m,this)}const l=[],c=[];for(const f of this.seq)f.type===e.SAMPLER_2D_SHADOW||f.type===e.SAMPLER_CUBE_SHADOW||f.type===e.SAMPLER_2D_ARRAY_SHADOW?l.push(f):c.push(f);l.length>0&&(this.seq=l.concat(c))}setValue(e,i,s,l){const c=this.map[i];c!==void 0&&c.setValue(e,s,l)}setOptional(e,i,s){const l=i[s];l!==void 0&&this.setValue(e,s,l)}static upload(e,i,s,l){for(let c=0,f=i.length;c!==f;++c){const p=i[c],m=s[p.id];m.needsUpdate!==!1&&p.setValue(e,m.value,l)}}static seqWithValue(e,i){const s=[];for(let l=0,c=e.length;l!==c;++l){const f=e[l];f.id in i&&s.push(f)}return s}}function Lv(r,e,i){const s=r.createShader(e);return r.shaderSource(s,i),r.compileShader(s),s}const qA=37297;let YA=0;function ZA(r,e){const i=r.split(`
`),s=[],l=Math.max(e-6,0),c=Math.min(e+6,i.length);for(let f=l;f<c;f++){const p=f+1;s.push(`${p===e?">":" "} ${p}: ${i[f]}`)}return s.join(`
`)}const Ov=new _t;function KA(r){It._getMatrix(Ov,It.workingColorSpace,r);const e=`mat3( ${Ov.elements.map(i=>i.toFixed(4))} )`;switch(It.getTransfer(r)){case su:return[e,"LinearTransferOETF"];case Qt:return[e,"sRGBTransferOETF"];default:return xt("WebGLProgram: Unsupported color space: ",r),[e,"LinearTransferOETF"]}}function Pv(r,e,i){const s=r.getShaderParameter(e,r.COMPILE_STATUS),c=(r.getShaderInfoLog(e)||"").trim();if(s&&c==="")return"";const f=/ERROR: 0:(\d+)/.exec(c);if(f){const p=parseInt(f[1]);return i.toUpperCase()+`

`+c+`

`+ZA(r.getShaderSource(e),p)}else return c}function QA(r,e){const i=KA(e);return[`vec4 ${r}( vec4 value ) {`,`	return ${i[1]}( vec4( value.rgb * ${i[0]}, value.a ) );`,"}"].join(`
`)}const JA={[Jv]:"Linear",[$v]:"Reinhard",[e_]:"Cineon",[t_]:"ACESFilmic",[i_]:"AgX",[a_]:"Neutral",[n_]:"Custom"};function $A(r,e){const i=JA[e];return i===void 0?(xt("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+r+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+r+"( vec3 color ) { return "+i+"ToneMapping( color ); }"}const Yc=new ae;function ew(){It.getLuminanceCoefficients(Yc);const r=Yc.x.toFixed(4),e=Yc.y.toFixed(4),i=Yc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${e}, ${i} );`,"	return dot( weights, rgb );","}"].join(`
`)}function tw(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(al).join(`
`)}function nw(r){const e=[];for(const i in r){const s=r[i];s!==!1&&e.push("#define "+i+" "+s)}return e.join(`
`)}function iw(r,e){const i={},s=r.getProgramParameter(e,r.ACTIVE_ATTRIBUTES);for(let l=0;l<s;l++){const c=r.getActiveAttrib(e,l),f=c.name;let p=1;c.type===r.FLOAT_MAT2&&(p=2),c.type===r.FLOAT_MAT3&&(p=3),c.type===r.FLOAT_MAT4&&(p=4),i[f]={type:c.type,location:r.getAttribLocation(e,f),locationSize:p}}return i}function al(r){return r!==""}function Iv(r,e){const i=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,i).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function zv(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const aw=/^[ \t]*#include +<([\w\d./]+)>/gm;function sp(r){return r.replace(aw,rw)}const sw=new Map;function rw(r,e){let i=At[e];if(i===void 0){const s=sw.get(e);if(s!==void 0)i=At[s],xt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,s);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return sp(i)}const ow=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Fv(r){return r.replace(ow,lw)}function lw(r,e,i,s){let l="";for(let c=parseInt(e);c<parseInt(i);c++)l+=s.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return l}function Bv(r){let e=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const cw={[ol]:"SHADOWMAP_TYPE_PCF",[il]:"SHADOWMAP_TYPE_VSM"};function uw(r){return cw[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const fw={[Xs]:"ENVMAP_TYPE_CUBE",[Zr]:"ENVMAP_TYPE_CUBE",[uu]:"ENVMAP_TYPE_CUBE_UV"};function dw(r){return r.envMap===!1?"ENVMAP_TYPE_CUBE":fw[r.envMapMode]||"ENVMAP_TYPE_CUBE"}const hw={[Zr]:"ENVMAP_MODE_REFRACTION"};function pw(r){return r.envMap===!1?"ENVMAP_MODE_REFLECTION":hw[r.envMapMode]||"ENVMAP_MODE_REFLECTION"}const mw={[Qv]:"ENVMAP_BLENDING_MULTIPLY",[t1]:"ENVMAP_BLENDING_MIX",[n1]:"ENVMAP_BLENDING_ADD"};function gw(r){return r.envMap===!1?"ENVMAP_BLENDING_NONE":mw[r.combine]||"ENVMAP_BLENDING_NONE"}function xw(r){const e=r.envMapCubeUVHeight;if(e===null)return null;const i=Math.log2(e)-2,s=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,i),112)),texelHeight:s,maxMip:i}}function vw(r,e,i,s){const l=r.getContext(),c=i.defines;let f=i.vertexShader,p=i.fragmentShader;const m=uw(i),h=dw(i),v=pw(i),x=gw(i),g=xw(i),M=tw(i),w=nw(c),R=l.createProgram();let b,y,P=i.glslVersion?"#version "+i.glslVersion+`
`:"";i.isRawShaderMaterial?(b=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,w].filter(al).join(`
`),b.length>0&&(b+=`
`),y=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,w].filter(al).join(`
`),y.length>0&&(y+=`
`)):(b=[Bv(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,w,i.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",i.batching?"#define USE_BATCHING":"",i.batchingColor?"#define USE_BATCHING_COLOR":"",i.instancing?"#define USE_INSTANCING":"",i.instancingColor?"#define USE_INSTANCING_COLOR":"",i.instancingMorph?"#define USE_INSTANCING_MORPH":"",i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.map?"#define USE_MAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+v:"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.displacementMap?"#define USE_DISPLACEMENTMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.mapUv?"#define MAP_UV "+i.mapUv:"",i.alphaMapUv?"#define ALPHAMAP_UV "+i.alphaMapUv:"",i.lightMapUv?"#define LIGHTMAP_UV "+i.lightMapUv:"",i.aoMapUv?"#define AOMAP_UV "+i.aoMapUv:"",i.emissiveMapUv?"#define EMISSIVEMAP_UV "+i.emissiveMapUv:"",i.bumpMapUv?"#define BUMPMAP_UV "+i.bumpMapUv:"",i.normalMapUv?"#define NORMALMAP_UV "+i.normalMapUv:"",i.displacementMapUv?"#define DISPLACEMENTMAP_UV "+i.displacementMapUv:"",i.metalnessMapUv?"#define METALNESSMAP_UV "+i.metalnessMapUv:"",i.roughnessMapUv?"#define ROUGHNESSMAP_UV "+i.roughnessMapUv:"",i.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+i.anisotropyMapUv:"",i.clearcoatMapUv?"#define CLEARCOATMAP_UV "+i.clearcoatMapUv:"",i.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+i.clearcoatNormalMapUv:"",i.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+i.clearcoatRoughnessMapUv:"",i.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+i.iridescenceMapUv:"",i.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+i.iridescenceThicknessMapUv:"",i.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+i.sheenColorMapUv:"",i.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+i.sheenRoughnessMapUv:"",i.specularMapUv?"#define SPECULARMAP_UV "+i.specularMapUv:"",i.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+i.specularColorMapUv:"",i.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+i.specularIntensityMapUv:"",i.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+i.transmissionMapUv:"",i.thicknessMapUv?"#define THICKNESSMAP_UV "+i.thicknessMapUv:"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexNormals?"#define HAS_NORMAL":"",i.vertexColors?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.flatShading?"#define FLAT_SHADED":"",i.skinning?"#define USE_SKINNING":"",i.morphTargets?"#define USE_MORPHTARGETS":"",i.morphNormals&&i.flatShading===!1?"#define USE_MORPHNORMALS":"",i.morphColors?"#define USE_MORPHCOLORS":"",i.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+i.morphTextureStride:"",i.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+i.morphTargetsCount:"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.sizeAttenuation?"#define USE_SIZEATTENUATION":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(al).join(`
`),y=[Bv(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,w,i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",i.map?"#define USE_MAP":"",i.matcap?"#define USE_MATCAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+h:"",i.envMap?"#define "+v:"",i.envMap?"#define "+x:"",g?"#define CUBEUV_TEXEL_WIDTH "+g.texelWidth:"",g?"#define CUBEUV_TEXEL_HEIGHT "+g.texelHeight:"",g?"#define CUBEUV_MAX_MIP "+g.maxMip+".0":"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoat?"#define USE_CLEARCOAT":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.dispersion?"#define USE_DISPERSION":"",i.iridescence?"#define USE_IRIDESCENCE":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaTest?"#define USE_ALPHATEST":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.sheen?"#define USE_SHEEN":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors||i.instancingColor?"#define USE_COLOR":"",i.vertexAlphas||i.batchingColor?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.gradientMap?"#define USE_GRADIENTMAP":"",i.flatShading?"#define FLAT_SHADED":"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",i.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",i.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",i.toneMapping!==ea?"#define TONE_MAPPING":"",i.toneMapping!==ea?At.tonemapping_pars_fragment:"",i.toneMapping!==ea?$A("toneMapping",i.toneMapping):"",i.dithering?"#define DITHERING":"",i.opaque?"#define OPAQUE":"",At.colorspace_pars_fragment,QA("linearToOutputTexel",i.outputColorSpace),ew(),i.useDepthPacking?"#define DEPTH_PACKING "+i.depthPacking:"",`
`].filter(al).join(`
`)),f=sp(f),f=Iv(f,i),f=zv(f,i),p=sp(p),p=Iv(p,i),p=zv(p,i),f=Fv(f),p=Fv(p),i.isRawShaderMaterial!==!0&&(P=`#version 300 es
`,b=[M,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+b,y=["#define varying in",i.glslVersion===Zx?"":"layout(location = 0) out highp vec4 pc_fragColor;",i.glslVersion===Zx?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+y);const O=P+b+f,C=P+y+p,I=Lv(l,l.VERTEX_SHADER,O),L=Lv(l,l.FRAGMENT_SHADER,C);l.attachShader(R,I),l.attachShader(R,L),i.index0AttributeName!==void 0?l.bindAttribLocation(R,0,i.index0AttributeName):i.hasPositionAttribute===!0&&l.bindAttribLocation(R,0,"position"),l.linkProgram(R);function F(k){if(r.debug.checkShaderErrors){const W=l.getProgramInfoLog(R)||"",re=l.getShaderInfoLog(I)||"",oe=l.getShaderInfoLog(L)||"",te=W.trim(),G=re.trim(),X=oe.trim();let $=!0,se=!0;if(l.getProgramParameter(R,l.LINK_STATUS)===!1)if($=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(l,R,I,L);else{const B=Pv(l,I,"vertex"),E=Pv(l,L,"fragment");Bt("WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(R,l.VALIDATE_STATUS)+`

Material Name: `+k.name+`
Material Type: `+k.type+`

Program Info Log: `+te+`
`+B+`
`+E)}else te!==""?xt("WebGLProgram: Program Info Log:",te):(G===""||X==="")&&(se=!1);se&&(k.diagnostics={runnable:$,programLog:te,vertexShader:{log:G,prefix:b},fragmentShader:{log:X,prefix:y}})}l.deleteShader(I),l.deleteShader(L),T=new $c(l,R),U=iw(l,R)}let T;this.getUniforms=function(){return T===void 0&&F(this),T};let U;this.getAttributes=function(){return U===void 0&&F(this),U};let V=i.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return V===!1&&(V=l.getProgramParameter(R,qA)),V},this.destroy=function(){s.releaseStatesOfProgram(this),l.deleteProgram(R),this.program=void 0},this.type=i.shaderType,this.name=i.shaderName,this.id=YA++,this.cacheKey=e,this.usedTimes=1,this.program=R,this.vertexShader=I,this.fragmentShader=L,this}let _w=0;class yw{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,i,s){const l=this._getShaderCacheForMaterial(e);return l.has(i)===!1&&(l.add(i),i.usedTimes++),l.has(s)===!1&&(l.add(s),s.usedTimes++),this}remove(e){const i=this.materialCache.get(e);for(const s of i)s.usedTimes--,s.usedTimes===0&&this.shaderCache.delete(s.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const i=this.materialCache;let s=i.get(e);return s===void 0&&(s=new Set,i.set(e,s)),s}_getShaderStage(e){const i=this.shaderCache;let s=i.get(e);return s===void 0&&(s=new bw(e),i.set(e,s)),s}}class bw{constructor(e){this.id=_w++,this.code=e,this.usedTimes=0}}function Sw(r){return r===Ws||r===nu||r===iu}function Mw(r,e,i,s,l,c){const f=new m_,p=new yw,m=new Set,h=[],v=new Map,x=s.logarithmicDepthBuffer;let g=s.precision;const M={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function w(T){return m.add(T),T===0?"uv":`uv${T}`}function R(T,U,V,k,W,re){const oe=k.fog,te=W.geometry,G=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?k.environment:null,X=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,$=e.get(T.envMap||G,X),se=$&&$.mapping===uu?$.image.height:null,B=M[T.type];T.precision!==null&&(g=s.getMaxPrecision(T.precision),g!==T.precision&&xt("WebGLProgram.getParameters:",T.precision,"not supported, using",g,"instead."));const E=te.morphAttributes.position||te.morphAttributes.normal||te.morphAttributes.color,H=E!==void 0?E.length:0;let ce=0;te.morphAttributes.position!==void 0&&(ce=1),te.morphAttributes.normal!==void 0&&(ce=2),te.morphAttributes.color!==void 0&&(ce=3);let Se,Ae,K,le;if(B){const et=Ki[B];Se=et.vertexShader,Ae=et.fragmentShader}else{Se=T.vertexShader,Ae=T.fragmentShader;const et=p.getVertexShaderStage(T),rn=p.getFragmentShaderStage(T);p.update(T,et,rn),K=et.id,le=rn.id}const xe=r.getRenderTarget(),Le=r.state.buffers.depth.getReversed(),Q=W.isInstancedMesh===!0,_e=W.isBatchedMesh===!0,Ce=!!T.map,Ue=!!T.matcap,He=!!$,Ye=!!T.aoMap,ft=!!T.lightMap,ee=!!T.bumpMap&&T.wireframe===!1,Pe=!!T.normalMap,Qe=!!T.displacementMap,Je=!!T.emissiveMap,ct=!!T.metalnessMap,Mt=!!T.roughnessMap,Y=T.anisotropy>0,Tt=T.clearcoat>0,Ne=T.dispersion>0,z=T.iridescence>0,A=T.sheen>0,ie=T.transmission>0,pe=Y&&!!T.anisotropyMap,ye=Tt&&!!T.clearcoatMap,Oe=Tt&&!!T.clearcoatNormalMap,Be=Tt&&!!T.clearcoatRoughnessMap,be=z&&!!T.iridescenceMap,Me=z&&!!T.iridescenceThicknessMap,ze=A&&!!T.sheenColorMap,Ze=A&&!!T.sheenRoughnessMap,je=!!T.specularMap,Ve=!!T.specularColorMap,ut=!!T.specularIntensityMap,dt=ie&&!!T.transmissionMap,gt=ie&&!!T.thicknessMap,Z=!!T.gradientMap,Ie=!!T.alphaMap,Te=T.alphaTest>0,Fe=!!T.alphaHash,qe=!!T.extensions;let De=ea;T.toneMapped&&(xe===null||xe.isXRRenderTarget===!0)&&(De=r.toneMapping);const rt={shaderID:B,shaderType:T.type,shaderName:T.name,vertexShader:Se,fragmentShader:Ae,defines:T.defines,customVertexShaderID:K,customFragmentShaderID:le,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:g,batching:_e,batchingColor:_e&&W._colorsTexture!==null,instancing:Q,instancingColor:Q&&W.instanceColor!==null,instancingMorph:Q&&W.morphTexture!==null,outputColorSpace:xe===null?r.outputColorSpace:xe.isXRRenderTarget===!0?xe.texture.colorSpace:It.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:Ce,matcap:Ue,envMap:He,envMapMode:He&&$.mapping,envMapCubeUVHeight:se,aoMap:Ye,lightMap:ft,bumpMap:ee,normalMap:Pe,displacementMap:Qe,emissiveMap:Je,normalMapObjectSpace:Pe&&T.normalMapType===s1,normalMapTangentSpace:Pe&&T.normalMapType===tp,packedNormalMap:Pe&&T.normalMapType===tp&&Sw(T.normalMap.format),metalnessMap:ct,roughnessMap:Mt,anisotropy:Y,anisotropyMap:pe,clearcoat:Tt,clearcoatMap:ye,clearcoatNormalMap:Oe,clearcoatRoughnessMap:Be,dispersion:Ne,iridescence:z,iridescenceMap:be,iridescenceThicknessMap:Me,sheen:A,sheenColorMap:ze,sheenRoughnessMap:Ze,specularMap:je,specularColorMap:Ve,specularIntensityMap:ut,transmission:ie,transmissionMap:dt,thicknessMap:gt,gradientMap:Z,opaque:T.transparent===!1&&T.blending===jr&&T.alphaToCoverage===!1,alphaMap:Ie,alphaTest:Te,alphaHash:Fe,combine:T.combine,mapUv:Ce&&w(T.map.channel),aoMapUv:Ye&&w(T.aoMap.channel),lightMapUv:ft&&w(T.lightMap.channel),bumpMapUv:ee&&w(T.bumpMap.channel),normalMapUv:Pe&&w(T.normalMap.channel),displacementMapUv:Qe&&w(T.displacementMap.channel),emissiveMapUv:Je&&w(T.emissiveMap.channel),metalnessMapUv:ct&&w(T.metalnessMap.channel),roughnessMapUv:Mt&&w(T.roughnessMap.channel),anisotropyMapUv:pe&&w(T.anisotropyMap.channel),clearcoatMapUv:ye&&w(T.clearcoatMap.channel),clearcoatNormalMapUv:Oe&&w(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Be&&w(T.clearcoatRoughnessMap.channel),iridescenceMapUv:be&&w(T.iridescenceMap.channel),iridescenceThicknessMapUv:Me&&w(T.iridescenceThicknessMap.channel),sheenColorMapUv:ze&&w(T.sheenColorMap.channel),sheenRoughnessMapUv:Ze&&w(T.sheenRoughnessMap.channel),specularMapUv:je&&w(T.specularMap.channel),specularColorMapUv:Ve&&w(T.specularColorMap.channel),specularIntensityMapUv:ut&&w(T.specularIntensityMap.channel),transmissionMapUv:dt&&w(T.transmissionMap.channel),thicknessMapUv:gt&&w(T.thicknessMap.channel),alphaMapUv:Ie&&w(T.alphaMap.channel),vertexTangents:!!te.attributes.tangent&&(Pe||Y),vertexNormals:!!te.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!te.attributes.color&&te.attributes.color.itemSize===4,pointsUvs:W.isPoints===!0&&!!te.attributes.uv&&(Ce||Ie),fog:!!oe,useFog:T.fog===!0,fogExp2:!!oe&&oe.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||te.attributes.normal===void 0&&Pe===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:x,reversedDepthBuffer:Le,skinning:W.isSkinnedMesh===!0,hasPositionAttribute:te.attributes.position!==void 0,morphTargets:te.morphAttributes.position!==void 0,morphNormals:te.morphAttributes.normal!==void 0,morphColors:te.morphAttributes.color!==void 0,morphTargetsCount:H,morphTextureStride:ce,numDirLights:U.directional.length,numPointLights:U.point.length,numSpotLights:U.spot.length,numSpotLightMaps:U.spotLightMap.length,numRectAreaLights:U.rectArea.length,numHemiLights:U.hemi.length,numDirLightShadows:U.directionalShadowMap.length,numPointLightShadows:U.pointShadowMap.length,numSpotLightShadows:U.spotShadowMap.length,numSpotLightShadowsWithMaps:U.numSpotLightShadowsWithMaps,numLightProbes:U.numLightProbes,numLightProbeGrids:re.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:T.dithering,shadowMapEnabled:r.shadowMap.enabled&&V.length>0,shadowMapType:r.shadowMap.type,toneMapping:De,decodeVideoTexture:Ce&&T.map.isVideoTexture===!0&&It.getTransfer(T.map.colorSpace)===Qt,decodeVideoTextureEmissive:Je&&T.emissiveMap.isVideoTexture===!0&&It.getTransfer(T.emissiveMap.colorSpace)===Qt,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===zi,flipSided:T.side===ii,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:qe&&T.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(qe&&T.extensions.multiDraw===!0||_e)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return rt.vertexUv1s=m.has(1),rt.vertexUv2s=m.has(2),rt.vertexUv3s=m.has(3),m.clear(),rt}function b(T){const U=[];if(T.shaderID?U.push(T.shaderID):(U.push(T.customVertexShaderID),U.push(T.customFragmentShaderID)),T.defines!==void 0)for(const V in T.defines)U.push(V),U.push(T.defines[V]);return T.isRawShaderMaterial===!1&&(y(U,T),P(U,T),U.push(r.outputColorSpace)),U.push(T.customProgramCacheKey),U.join()}function y(T,U){T.push(U.precision),T.push(U.outputColorSpace),T.push(U.envMapMode),T.push(U.envMapCubeUVHeight),T.push(U.mapUv),T.push(U.alphaMapUv),T.push(U.lightMapUv),T.push(U.aoMapUv),T.push(U.bumpMapUv),T.push(U.normalMapUv),T.push(U.displacementMapUv),T.push(U.emissiveMapUv),T.push(U.metalnessMapUv),T.push(U.roughnessMapUv),T.push(U.anisotropyMapUv),T.push(U.clearcoatMapUv),T.push(U.clearcoatNormalMapUv),T.push(U.clearcoatRoughnessMapUv),T.push(U.iridescenceMapUv),T.push(U.iridescenceThicknessMapUv),T.push(U.sheenColorMapUv),T.push(U.sheenRoughnessMapUv),T.push(U.specularMapUv),T.push(U.specularColorMapUv),T.push(U.specularIntensityMapUv),T.push(U.transmissionMapUv),T.push(U.thicknessMapUv),T.push(U.combine),T.push(U.fogExp2),T.push(U.sizeAttenuation),T.push(U.morphTargetsCount),T.push(U.morphAttributeCount),T.push(U.numDirLights),T.push(U.numPointLights),T.push(U.numSpotLights),T.push(U.numSpotLightMaps),T.push(U.numHemiLights),T.push(U.numRectAreaLights),T.push(U.numDirLightShadows),T.push(U.numPointLightShadows),T.push(U.numSpotLightShadows),T.push(U.numSpotLightShadowsWithMaps),T.push(U.numLightProbes),T.push(U.shadowMapType),T.push(U.toneMapping),T.push(U.numClippingPlanes),T.push(U.numClipIntersection),T.push(U.depthPacking)}function P(T,U){f.disableAll(),U.instancing&&f.enable(0),U.instancingColor&&f.enable(1),U.instancingMorph&&f.enable(2),U.matcap&&f.enable(3),U.envMap&&f.enable(4),U.normalMapObjectSpace&&f.enable(5),U.normalMapTangentSpace&&f.enable(6),U.clearcoat&&f.enable(7),U.iridescence&&f.enable(8),U.alphaTest&&f.enable(9),U.vertexColors&&f.enable(10),U.vertexAlphas&&f.enable(11),U.vertexUv1s&&f.enable(12),U.vertexUv2s&&f.enable(13),U.vertexUv3s&&f.enable(14),U.vertexTangents&&f.enable(15),U.anisotropy&&f.enable(16),U.alphaHash&&f.enable(17),U.batching&&f.enable(18),U.dispersion&&f.enable(19),U.batchingColor&&f.enable(20),U.gradientMap&&f.enable(21),U.packedNormalMap&&f.enable(22),U.vertexNormals&&f.enable(23),T.push(f.mask),f.disableAll(),U.fog&&f.enable(0),U.useFog&&f.enable(1),U.flatShading&&f.enable(2),U.logarithmicDepthBuffer&&f.enable(3),U.reversedDepthBuffer&&f.enable(4),U.skinning&&f.enable(5),U.morphTargets&&f.enable(6),U.morphNormals&&f.enable(7),U.morphColors&&f.enable(8),U.premultipliedAlpha&&f.enable(9),U.shadowMapEnabled&&f.enable(10),U.doubleSided&&f.enable(11),U.flipSided&&f.enable(12),U.useDepthPacking&&f.enable(13),U.dithering&&f.enable(14),U.transmission&&f.enable(15),U.sheen&&f.enable(16),U.opaque&&f.enable(17),U.pointsUvs&&f.enable(18),U.decodeVideoTexture&&f.enable(19),U.decodeVideoTextureEmissive&&f.enable(20),U.alphaToCoverage&&f.enable(21),U.numLightProbeGrids>0&&f.enable(22),U.hasPositionAttribute&&f.enable(23),T.push(f.mask)}function O(T){const U=M[T.type];let V;if(U){const k=Ki[U];V=k1.clone(k.uniforms)}else V=T.uniforms;return V}function C(T,U){let V=v.get(U);return V!==void 0?++V.usedTimes:(V=new vw(r,U,T,l),h.push(V),v.set(U,V)),V}function I(T){if(--T.usedTimes===0){const U=h.indexOf(T);h[U]=h[h.length-1],h.pop(),v.delete(T.cacheKey),T.destroy()}}function L(T){p.remove(T)}function F(){p.dispose()}return{getParameters:R,getProgramCacheKey:b,getUniforms:O,acquireProgram:C,releaseProgram:I,releaseShaderCache:L,programs:h,dispose:F}}function Ew(){let r=new WeakMap;function e(f){return r.has(f)}function i(f){let p=r.get(f);return p===void 0&&(p={},r.set(f,p)),p}function s(f){r.delete(f)}function l(f,p,m){r.get(f)[p]=m}function c(){r=new WeakMap}return{has:e,get:i,remove:s,update:l,dispose:c}}function Tw(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.materialVariant!==e.materialVariant?r.materialVariant-e.materialVariant:r.z!==e.z?r.z-e.z:r.id-e.id}function Gv(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function Hv(){const r=[];let e=0;const i=[],s=[],l=[];function c(){e=0,i.length=0,s.length=0,l.length=0}function f(g){let M=0;return g.isInstancedMesh&&(M+=2),g.isSkinnedMesh&&(M+=1),M}function p(g,M,w,R,b,y){let P=r[e];return P===void 0?(P={id:g.id,object:g,geometry:M,material:w,materialVariant:f(g),groupOrder:R,renderOrder:g.renderOrder,z:b,group:y},r[e]=P):(P.id=g.id,P.object=g,P.geometry=M,P.material=w,P.materialVariant=f(g),P.groupOrder=R,P.renderOrder=g.renderOrder,P.z=b,P.group=y),e++,P}function m(g,M,w,R,b,y){const P=p(g,M,w,R,b,y);w.transmission>0?s.push(P):w.transparent===!0?l.push(P):i.push(P)}function h(g,M,w,R,b,y){const P=p(g,M,w,R,b,y);w.transmission>0?s.unshift(P):w.transparent===!0?l.unshift(P):i.unshift(P)}function v(g,M,w){i.length>1&&i.sort(g||Tw),s.length>1&&s.sort(M||Gv),l.length>1&&l.sort(M||Gv),w&&(i.reverse(),s.reverse(),l.reverse())}function x(){for(let g=e,M=r.length;g<M;g++){const w=r[g];if(w.id===null)break;w.id=null,w.object=null,w.geometry=null,w.material=null,w.group=null}}return{opaque:i,transmissive:s,transparent:l,init:c,push:m,unshift:h,finish:x,sort:v}}function Aw(){let r=new WeakMap;function e(s,l){const c=r.get(s);let f;return c===void 0?(f=new Hv,r.set(s,[f])):l>=c.length?(f=new Hv,c.push(f)):f=c[l],f}function i(){r=new WeakMap}return{get:e,dispose:i}}function ww(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let i;switch(e.type){case"DirectionalLight":i={direction:new ae,color:new Ot};break;case"SpotLight":i={position:new ae,direction:new ae,color:new Ot,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":i={position:new ae,color:new Ot,distance:0,decay:0};break;case"HemisphereLight":i={direction:new ae,skyColor:new Ot,groundColor:new Ot};break;case"RectAreaLight":i={color:new Ot,position:new ae,halfWidth:new ae,halfHeight:new ae};break}return r[e.id]=i,i}}}function Cw(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let i;switch(e.type){case"DirectionalLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ct};break;case"SpotLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ct};break;case"PointLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ct,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[e.id]=i,i}}}let Rw=0;function Nw(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function Dw(r){const e=new ww,i=Cw(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new ae);const l=new ae,c=new fn,f=new fn;function p(h){let v=0,x=0,g=0;for(let U=0;U<9;U++)s.probe[U].set(0,0,0);let M=0,w=0,R=0,b=0,y=0,P=0,O=0,C=0,I=0,L=0,F=0;h.sort(Nw);for(let U=0,V=h.length;U<V;U++){const k=h[U],W=k.color,re=k.intensity,oe=k.distance;let te=null;if(k.shadow&&k.shadow.map&&(k.shadow.map.texture.format===Ws?te=k.shadow.map.texture:te=k.shadow.map.depthTexture||k.shadow.map.texture),k.isAmbientLight)v+=W.r*re,x+=W.g*re,g+=W.b*re;else if(k.isLightProbe){for(let G=0;G<9;G++)s.probe[G].addScaledVector(k.sh.coefficients[G],re);F++}else if(k.isDirectionalLight){const G=e.get(k);if(G.color.copy(k.color).multiplyScalar(k.intensity),k.castShadow){const X=k.shadow,$=i.get(k);$.shadowIntensity=X.intensity,$.shadowBias=X.bias,$.shadowNormalBias=X.normalBias,$.shadowRadius=X.radius,$.shadowMapSize=X.mapSize,s.directionalShadow[M]=$,s.directionalShadowMap[M]=te,s.directionalShadowMatrix[M]=k.shadow.matrix,P++}s.directional[M]=G,M++}else if(k.isSpotLight){const G=e.get(k);G.position.setFromMatrixPosition(k.matrixWorld),G.color.copy(W).multiplyScalar(re),G.distance=oe,G.coneCos=Math.cos(k.angle),G.penumbraCos=Math.cos(k.angle*(1-k.penumbra)),G.decay=k.decay,s.spot[R]=G;const X=k.shadow;if(k.map&&(s.spotLightMap[I]=k.map,I++,X.updateMatrices(k),k.castShadow&&L++),s.spotLightMatrix[R]=X.matrix,k.castShadow){const $=i.get(k);$.shadowIntensity=X.intensity,$.shadowBias=X.bias,$.shadowNormalBias=X.normalBias,$.shadowRadius=X.radius,$.shadowMapSize=X.mapSize,s.spotShadow[R]=$,s.spotShadowMap[R]=te,C++}R++}else if(k.isRectAreaLight){const G=e.get(k);G.color.copy(W).multiplyScalar(re),G.halfWidth.set(k.width*.5,0,0),G.halfHeight.set(0,k.height*.5,0),s.rectArea[b]=G,b++}else if(k.isPointLight){const G=e.get(k);if(G.color.copy(k.color).multiplyScalar(k.intensity),G.distance=k.distance,G.decay=k.decay,k.castShadow){const X=k.shadow,$=i.get(k);$.shadowIntensity=X.intensity,$.shadowBias=X.bias,$.shadowNormalBias=X.normalBias,$.shadowRadius=X.radius,$.shadowMapSize=X.mapSize,$.shadowCameraNear=X.camera.near,$.shadowCameraFar=X.camera.far,s.pointShadow[w]=$,s.pointShadowMap[w]=te,s.pointShadowMatrix[w]=k.shadow.matrix,O++}s.point[w]=G,w++}else if(k.isHemisphereLight){const G=e.get(k);G.skyColor.copy(k.color).multiplyScalar(re),G.groundColor.copy(k.groundColor).multiplyScalar(re),s.hemi[y]=G,y++}}b>0&&(r.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=We.LTC_FLOAT_1,s.rectAreaLTC2=We.LTC_FLOAT_2):(s.rectAreaLTC1=We.LTC_HALF_1,s.rectAreaLTC2=We.LTC_HALF_2)),s.ambient[0]=v,s.ambient[1]=x,s.ambient[2]=g;const T=s.hash;(T.directionalLength!==M||T.pointLength!==w||T.spotLength!==R||T.rectAreaLength!==b||T.hemiLength!==y||T.numDirectionalShadows!==P||T.numPointShadows!==O||T.numSpotShadows!==C||T.numSpotMaps!==I||T.numLightProbes!==F)&&(s.directional.length=M,s.spot.length=R,s.rectArea.length=b,s.point.length=w,s.hemi.length=y,s.directionalShadow.length=P,s.directionalShadowMap.length=P,s.pointShadow.length=O,s.pointShadowMap.length=O,s.spotShadow.length=C,s.spotShadowMap.length=C,s.directionalShadowMatrix.length=P,s.pointShadowMatrix.length=O,s.spotLightMatrix.length=C+I-L,s.spotLightMap.length=I,s.numSpotLightShadowsWithMaps=L,s.numLightProbes=F,T.directionalLength=M,T.pointLength=w,T.spotLength=R,T.rectAreaLength=b,T.hemiLength=y,T.numDirectionalShadows=P,T.numPointShadows=O,T.numSpotShadows=C,T.numSpotMaps=I,T.numLightProbes=F,s.version=Rw++)}function m(h,v){let x=0,g=0,M=0,w=0,R=0;const b=v.matrixWorldInverse;for(let y=0,P=h.length;y<P;y++){const O=h[y];if(O.isDirectionalLight){const C=s.directional[x];C.direction.setFromMatrixPosition(O.matrixWorld),l.setFromMatrixPosition(O.target.matrixWorld),C.direction.sub(l),C.direction.transformDirection(b),x++}else if(O.isSpotLight){const C=s.spot[M];C.position.setFromMatrixPosition(O.matrixWorld),C.position.applyMatrix4(b),C.direction.setFromMatrixPosition(O.matrixWorld),l.setFromMatrixPosition(O.target.matrixWorld),C.direction.sub(l),C.direction.transformDirection(b),M++}else if(O.isRectAreaLight){const C=s.rectArea[w];C.position.setFromMatrixPosition(O.matrixWorld),C.position.applyMatrix4(b),f.identity(),c.copy(O.matrixWorld),c.premultiply(b),f.extractRotation(c),C.halfWidth.set(O.width*.5,0,0),C.halfHeight.set(0,O.height*.5,0),C.halfWidth.applyMatrix4(f),C.halfHeight.applyMatrix4(f),w++}else if(O.isPointLight){const C=s.point[g];C.position.setFromMatrixPosition(O.matrixWorld),C.position.applyMatrix4(b),g++}else if(O.isHemisphereLight){const C=s.hemi[R];C.direction.setFromMatrixPosition(O.matrixWorld),C.direction.transformDirection(b),R++}}}return{setup:p,setupView:m,state:s}}function Vv(r){const e=new Dw(r),i=[],s=[],l=[];function c(g){x.camera=g,i.length=0,s.length=0,l.length=0}function f(g){i.push(g)}function p(g){s.push(g)}function m(g){l.push(g)}function h(){e.setup(i)}function v(g){e.setupView(i,g)}const x={lightsArray:i,shadowsArray:s,lightProbeGridArray:l,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:x,setupLights:h,setupLightsView:v,pushLight:f,pushShadow:p,pushLightProbeGrid:m}}function Uw(r){let e=new WeakMap;function i(l,c=0){const f=e.get(l);let p;return f===void 0?(p=new Vv(r),e.set(l,[p])):c>=f.length?(p=new Vv(r),f.push(p)):p=f[c],p}function s(){e=new WeakMap}return{get:i,dispose:s}}const Lw=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Ow=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Pw=[new ae(1,0,0),new ae(-1,0,0),new ae(0,1,0),new ae(0,-1,0),new ae(0,0,1),new ae(0,0,-1)],Iw=[new ae(0,-1,0),new ae(0,-1,0),new ae(0,0,1),new ae(0,0,-1),new ae(0,-1,0),new ae(0,-1,0)],kv=new fn,nl=new ae,sh=new ae;function zw(r,e,i){let s=new Rp;const l=new Ct,c=new Ct,f=new un,p=new q1,m=new Y1,h={},v=i.maxTextureSize,x={[ps]:ii,[ii]:ps,[zi]:zi},g=new ia({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ct},radius:{value:4}},vertexShader:Lw,fragmentShader:Ow}),M=g.clone();M.defines.HORIZONTAL_PASS=1;const w=new Yn;w.setAttribute("position",new Hi(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const R=new Ge(w,g),b=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ol;let y=this.type;this.render=function(L,F,T){if(b.enabled===!1||b.autoUpdate===!1&&b.needsUpdate===!1||L.length===0)return;this.type===IM&&(xt("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=ol);const U=r.getRenderTarget(),V=r.getActiveCubeFace(),k=r.getActiveMipmapLevel(),W=r.state;W.setBlending(Ra),W.buffers.depth.getReversed()===!0?W.buffers.color.setClear(0,0,0,0):W.buffers.color.setClear(1,1,1,1),W.buffers.depth.setTest(!0),W.setScissorTest(!1);const re=y!==this.type;re&&F.traverse(function(oe){oe.material&&(Array.isArray(oe.material)?oe.material.forEach(te=>te.needsUpdate=!0):oe.material.needsUpdate=!0)});for(let oe=0,te=L.length;oe<te;oe++){const G=L[oe],X=G.shadow;if(X===void 0){xt("WebGLShadowMap:",G,"has no shadow.");continue}if(X.autoUpdate===!1&&X.needsUpdate===!1)continue;l.copy(X.mapSize);const $=X.getFrameExtents();l.multiply($),c.copy(X.mapSize),(l.x>v||l.y>v)&&(l.x>v&&(c.x=Math.floor(v/$.x),l.x=c.x*$.x,X.mapSize.x=c.x),l.y>v&&(c.y=Math.floor(v/$.y),l.y=c.y*$.y,X.mapSize.y=c.y));const se=r.state.buffers.depth.getReversed();if(X.camera._reversedDepth=se,X.map===null||re===!0){if(X.map!==null&&(X.map.depthTexture!==null&&(X.map.depthTexture.dispose(),X.map.depthTexture=null),X.map.dispose()),this.type===il){if(G.isPointLight){xt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}X.map=new ta(l.x,l.y,{format:Ws,type:Da,minFilter:jn,magFilter:jn,generateMipmaps:!1}),X.map.texture.name=G.name+".shadowMap",X.map.depthTexture=new Kr(l.x,l.y,Qi),X.map.depthTexture.name=G.name+".shadowMapDepth",X.map.depthTexture.format=Ua,X.map.depthTexture.compareFunction=null,X.map.depthTexture.minFilter=zn,X.map.depthTexture.magFilter=zn}else G.isPointLight?(X.map=new C_(l.x),X.map.depthTexture=new H1(l.x,na)):(X.map=new ta(l.x,l.y),X.map.depthTexture=new Kr(l.x,l.y,na)),X.map.depthTexture.name=G.name+".shadowMap",X.map.depthTexture.format=Ua,this.type===ol?(X.map.depthTexture.compareFunction=se?Ap:Tp,X.map.depthTexture.minFilter=jn,X.map.depthTexture.magFilter=jn):(X.map.depthTexture.compareFunction=null,X.map.depthTexture.minFilter=zn,X.map.depthTexture.magFilter=zn);X.camera.updateProjectionMatrix()}const B=X.map.isWebGLCubeRenderTarget?6:1;for(let E=0;E<B;E++){if(X.map.isWebGLCubeRenderTarget)r.setRenderTarget(X.map,E),r.clear();else{E===0&&(r.setRenderTarget(X.map),r.clear());const H=X.getViewport(E);f.set(c.x*H.x,c.y*H.y,c.x*H.z,c.y*H.w),W.viewport(f)}if(G.isPointLight){const H=X.camera,ce=X.matrix,Se=G.distance||H.far;Se!==H.far&&(H.far=Se,H.updateProjectionMatrix()),nl.setFromMatrixPosition(G.matrixWorld),H.position.copy(nl),sh.copy(H.position),sh.add(Pw[E]),H.up.copy(Iw[E]),H.lookAt(sh),H.updateMatrixWorld(),ce.makeTranslation(-nl.x,-nl.y,-nl.z),kv.multiplyMatrices(H.projectionMatrix,H.matrixWorldInverse),X._frustum.setFromProjectionMatrix(kv,H.coordinateSystem,H.reversedDepth)}else X.updateMatrices(G);s=X.getFrustum(),C(F,T,X.camera,G,this.type)}X.isPointLightShadow!==!0&&this.type===il&&P(X,T),X.needsUpdate=!1}y=this.type,b.needsUpdate=!1,r.setRenderTarget(U,V,k)};function P(L,F){const T=e.update(R);g.defines.VSM_SAMPLES!==L.blurSamples&&(g.defines.VSM_SAMPLES=L.blurSamples,M.defines.VSM_SAMPLES=L.blurSamples,g.needsUpdate=!0,M.needsUpdate=!0),L.mapPass===null&&(L.mapPass=new ta(l.x,l.y,{format:Ws,type:Da})),g.uniforms.shadow_pass.value=L.map.depthTexture,g.uniforms.resolution.value=L.mapSize,g.uniforms.radius.value=L.radius,r.setRenderTarget(L.mapPass),r.clear(),r.renderBufferDirect(F,null,T,g,R,null),M.uniforms.shadow_pass.value=L.mapPass.texture,M.uniforms.resolution.value=L.mapSize,M.uniforms.radius.value=L.radius,r.setRenderTarget(L.map),r.clear(),r.renderBufferDirect(F,null,T,M,R,null)}function O(L,F,T,U){let V=null;const k=T.isPointLight===!0?L.customDistanceMaterial:L.customDepthMaterial;if(k!==void 0)V=k;else if(V=T.isPointLight===!0?m:p,r.localClippingEnabled&&F.clipShadows===!0&&Array.isArray(F.clippingPlanes)&&F.clippingPlanes.length!==0||F.displacementMap&&F.displacementScale!==0||F.alphaMap&&F.alphaTest>0||F.map&&F.alphaTest>0||F.alphaToCoverage===!0){const W=V.uuid,re=F.uuid;let oe=h[W];oe===void 0&&(oe={},h[W]=oe);let te=oe[re];te===void 0&&(te=V.clone(),oe[re]=te,F.addEventListener("dispose",I)),V=te}if(V.visible=F.visible,V.wireframe=F.wireframe,U===il?V.side=F.shadowSide!==null?F.shadowSide:F.side:V.side=F.shadowSide!==null?F.shadowSide:x[F.side],V.alphaMap=F.alphaMap,V.alphaTest=F.alphaToCoverage===!0?.5:F.alphaTest,V.map=F.map,V.clipShadows=F.clipShadows,V.clippingPlanes=F.clippingPlanes,V.clipIntersection=F.clipIntersection,V.displacementMap=F.displacementMap,V.displacementScale=F.displacementScale,V.displacementBias=F.displacementBias,V.wireframeLinewidth=F.wireframeLinewidth,V.linewidth=F.linewidth,T.isPointLight===!0&&V.isMeshDistanceMaterial===!0){const W=r.properties.get(V);W.light=T}return V}function C(L,F,T,U,V){if(L.visible===!1)return;if(L.layers.test(F.layers)&&(L.isMesh||L.isLine||L.isPoints)&&(L.castShadow||L.receiveShadow&&V===il)&&(!L.frustumCulled||s.intersectsObject(L))){L.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,L.matrixWorld);const re=e.update(L),oe=L.material;if(Array.isArray(oe)){const te=re.groups;for(let G=0,X=te.length;G<X;G++){const $=te[G],se=oe[$.materialIndex];if(se&&se.visible){const B=O(L,se,U,V);L.onBeforeShadow(r,L,F,T,re,B,$),r.renderBufferDirect(T,null,re,B,L,$),L.onAfterShadow(r,L,F,T,re,B,$)}}}else if(oe.visible){const te=O(L,oe,U,V);L.onBeforeShadow(r,L,F,T,re,te,null),r.renderBufferDirect(T,null,re,te,L,null),L.onAfterShadow(r,L,F,T,re,te,null)}}const W=L.children;for(let re=0,oe=W.length;re<oe;re++)C(W[re],F,T,U,V)}function I(L){L.target.removeEventListener("dispose",I);for(const T in h){const U=h[T],V=L.target.uuid;V in U&&(U[V].dispose(),delete U[V])}}}function Fw(r,e){function i(){let Z=!1;const Ie=new un;let Te=null;const Fe=new un(0,0,0,0);return{setMask:function(qe){Te!==qe&&!Z&&(r.colorMask(qe,qe,qe,qe),Te=qe)},setLocked:function(qe){Z=qe},setClear:function(qe,De,rt,et,rn){rn===!0&&(qe*=et,De*=et,rt*=et),Ie.set(qe,De,rt,et),Fe.equals(Ie)===!1&&(r.clearColor(qe,De,rt,et),Fe.copy(Ie))},reset:function(){Z=!1,Te=null,Fe.set(-1,0,0,0)}}}function s(){let Z=!1,Ie=!1,Te=null,Fe=null,qe=null;return{setReversed:function(De){if(Ie!==De){const rt=e.get("EXT_clip_control");De?rt.clipControlEXT(rt.LOWER_LEFT_EXT,rt.ZERO_TO_ONE_EXT):rt.clipControlEXT(rt.LOWER_LEFT_EXT,rt.NEGATIVE_ONE_TO_ONE_EXT),Ie=De;const et=qe;qe=null,this.setClear(et)}},getReversed:function(){return Ie},setTest:function(De){De?xe(r.DEPTH_TEST):Le(r.DEPTH_TEST)},setMask:function(De){Te!==De&&!Z&&(r.depthMask(De),Te=De)},setFunc:function(De){if(Ie&&(De=m1[De]),Fe!==De){switch(De){case gh:r.depthFunc(r.NEVER);break;case xh:r.depthFunc(r.ALWAYS);break;case vh:r.depthFunc(r.LESS);break;case Yr:r.depthFunc(r.LEQUAL);break;case _h:r.depthFunc(r.EQUAL);break;case yh:r.depthFunc(r.GEQUAL);break;case bh:r.depthFunc(r.GREATER);break;case Sh:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}Fe=De}},setLocked:function(De){Z=De},setClear:function(De){qe!==De&&(qe=De,Ie&&(De=1-De),r.clearDepth(De))},reset:function(){Z=!1,Te=null,Fe=null,qe=null,Ie=!1}}}function l(){let Z=!1,Ie=null,Te=null,Fe=null,qe=null,De=null,rt=null,et=null,rn=null;return{setTest:function(Xt){Z||(Xt?xe(r.STENCIL_TEST):Le(r.STENCIL_TEST))},setMask:function(Xt){Ie!==Xt&&!Z&&(r.stencilMask(Xt),Ie=Xt)},setFunc:function(Xt,ai,si){(Te!==Xt||Fe!==ai||qe!==si)&&(r.stencilFunc(Xt,ai,si),Te=Xt,Fe=ai,qe=si)},setOp:function(Xt,ai,si){(De!==Xt||rt!==ai||et!==si)&&(r.stencilOp(Xt,ai,si),De=Xt,rt=ai,et=si)},setLocked:function(Xt){Z=Xt},setClear:function(Xt){rn!==Xt&&(r.clearStencil(Xt),rn=Xt)},reset:function(){Z=!1,Ie=null,Te=null,Fe=null,qe=null,De=null,rt=null,et=null,rn=null}}}const c=new i,f=new s,p=new l,m=new WeakMap,h=new WeakMap;let v={},x={},g={},M=new WeakMap,w=[],R=null,b=!1,y=null,P=null,O=null,C=null,I=null,L=null,F=null,T=new Ot(0,0,0),U=0,V=!1,k=null,W=null,re=null,oe=null,te=null;const G=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let X=!1,$=0;const se=r.getParameter(r.VERSION);se.indexOf("WebGL")!==-1?($=parseFloat(/^WebGL (\d)/.exec(se)[1]),X=$>=1):se.indexOf("OpenGL ES")!==-1&&($=parseFloat(/^OpenGL ES (\d)/.exec(se)[1]),X=$>=2);let B=null,E={};const H=r.getParameter(r.SCISSOR_BOX),ce=r.getParameter(r.VIEWPORT),Se=new un().fromArray(H),Ae=new un().fromArray(ce);function K(Z,Ie,Te,Fe){const qe=new Uint8Array(4),De=r.createTexture();r.bindTexture(Z,De),r.texParameteri(Z,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(Z,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let rt=0;rt<Te;rt++)Z===r.TEXTURE_3D||Z===r.TEXTURE_2D_ARRAY?r.texImage3D(Ie,0,r.RGBA,1,1,Fe,0,r.RGBA,r.UNSIGNED_BYTE,qe):r.texImage2D(Ie+rt,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,qe);return De}const le={};le[r.TEXTURE_2D]=K(r.TEXTURE_2D,r.TEXTURE_2D,1),le[r.TEXTURE_CUBE_MAP]=K(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),le[r.TEXTURE_2D_ARRAY]=K(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),le[r.TEXTURE_3D]=K(r.TEXTURE_3D,r.TEXTURE_3D,1,1),c.setClear(0,0,0,1),f.setClear(1),p.setClear(0),xe(r.DEPTH_TEST),f.setFunc(Yr),ee(!1),Pe(kx),xe(r.CULL_FACE),Ye(Ra);function xe(Z){v[Z]!==!0&&(r.enable(Z),v[Z]=!0)}function Le(Z){v[Z]!==!1&&(r.disable(Z),v[Z]=!1)}function Q(Z,Ie){return g[Z]!==Ie?(r.bindFramebuffer(Z,Ie),g[Z]=Ie,Z===r.DRAW_FRAMEBUFFER&&(g[r.FRAMEBUFFER]=Ie),Z===r.FRAMEBUFFER&&(g[r.DRAW_FRAMEBUFFER]=Ie),!0):!1}function _e(Z,Ie){let Te=w,Fe=!1;if(Z){Te=M.get(Ie),Te===void 0&&(Te=[],M.set(Ie,Te));const qe=Z.textures;if(Te.length!==qe.length||Te[0]!==r.COLOR_ATTACHMENT0){for(let De=0,rt=qe.length;De<rt;De++)Te[De]=r.COLOR_ATTACHMENT0+De;Te.length=qe.length,Fe=!0}}else Te[0]!==r.BACK&&(Te[0]=r.BACK,Fe=!0);Fe&&r.drawBuffers(Te)}function Ce(Z){return R!==Z?(r.useProgram(Z),R=Z,!0):!1}const Ue={[Hs]:r.FUNC_ADD,[FM]:r.FUNC_SUBTRACT,[BM]:r.FUNC_REVERSE_SUBTRACT};Ue[GM]=r.MIN,Ue[HM]=r.MAX;const He={[VM]:r.ZERO,[kM]:r.ONE,[jM]:r.SRC_COLOR,[ph]:r.SRC_ALPHA,[KM]:r.SRC_ALPHA_SATURATE,[YM]:r.DST_COLOR,[WM]:r.DST_ALPHA,[XM]:r.ONE_MINUS_SRC_COLOR,[mh]:r.ONE_MINUS_SRC_ALPHA,[ZM]:r.ONE_MINUS_DST_COLOR,[qM]:r.ONE_MINUS_DST_ALPHA,[QM]:r.CONSTANT_COLOR,[JM]:r.ONE_MINUS_CONSTANT_COLOR,[$M]:r.CONSTANT_ALPHA,[e1]:r.ONE_MINUS_CONSTANT_ALPHA};function Ye(Z,Ie,Te,Fe,qe,De,rt,et,rn,Xt){if(Z===Ra){b===!0&&(Le(r.BLEND),b=!1);return}if(b===!1&&(xe(r.BLEND),b=!0),Z!==zM){if(Z!==y||Xt!==V){if((P!==Hs||I!==Hs)&&(r.blendEquation(r.FUNC_ADD),P=Hs,I=Hs),Xt)switch(Z){case jr:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case jx:r.blendFunc(r.ONE,r.ONE);break;case Xx:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case Wx:r.blendFuncSeparate(r.DST_COLOR,r.ONE_MINUS_SRC_ALPHA,r.ZERO,r.ONE);break;default:Bt("WebGLState: Invalid blending: ",Z);break}else switch(Z){case jr:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case jx:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE,r.ONE,r.ONE);break;case Xx:Bt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Wx:Bt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Bt("WebGLState: Invalid blending: ",Z);break}O=null,C=null,L=null,F=null,T.set(0,0,0),U=0,y=Z,V=Xt}return}qe=qe||Ie,De=De||Te,rt=rt||Fe,(Ie!==P||qe!==I)&&(r.blendEquationSeparate(Ue[Ie],Ue[qe]),P=Ie,I=qe),(Te!==O||Fe!==C||De!==L||rt!==F)&&(r.blendFuncSeparate(He[Te],He[Fe],He[De],He[rt]),O=Te,C=Fe,L=De,F=rt),(et.equals(T)===!1||rn!==U)&&(r.blendColor(et.r,et.g,et.b,rn),T.copy(et),U=rn),y=Z,V=!1}function ft(Z,Ie){Z.side===zi?Le(r.CULL_FACE):xe(r.CULL_FACE);let Te=Z.side===ii;Ie&&(Te=!Te),ee(Te),Z.blending===jr&&Z.transparent===!1?Ye(Ra):Ye(Z.blending,Z.blendEquation,Z.blendSrc,Z.blendDst,Z.blendEquationAlpha,Z.blendSrcAlpha,Z.blendDstAlpha,Z.blendColor,Z.blendAlpha,Z.premultipliedAlpha),f.setFunc(Z.depthFunc),f.setTest(Z.depthTest),f.setMask(Z.depthWrite),c.setMask(Z.colorWrite);const Fe=Z.stencilWrite;p.setTest(Fe),Fe&&(p.setMask(Z.stencilWriteMask),p.setFunc(Z.stencilFunc,Z.stencilRef,Z.stencilFuncMask),p.setOp(Z.stencilFail,Z.stencilZFail,Z.stencilZPass)),Je(Z.polygonOffset,Z.polygonOffsetFactor,Z.polygonOffsetUnits),Z.alphaToCoverage===!0?xe(r.SAMPLE_ALPHA_TO_COVERAGE):Le(r.SAMPLE_ALPHA_TO_COVERAGE)}function ee(Z){k!==Z&&(Z?r.frontFace(r.CW):r.frontFace(r.CCW),k=Z)}function Pe(Z){Z!==OM?(xe(r.CULL_FACE),Z!==W&&(Z===kx?r.cullFace(r.BACK):Z===PM?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):Le(r.CULL_FACE),W=Z}function Qe(Z){Z!==re&&(X&&r.lineWidth(Z),re=Z)}function Je(Z,Ie,Te){Z?(xe(r.POLYGON_OFFSET_FILL),(oe!==Ie||te!==Te)&&(oe=Ie,te=Te,f.getReversed()&&(Ie=-Ie),r.polygonOffset(Ie,Te))):Le(r.POLYGON_OFFSET_FILL)}function ct(Z){Z?xe(r.SCISSOR_TEST):Le(r.SCISSOR_TEST)}function Mt(Z){Z===void 0&&(Z=r.TEXTURE0+G-1),B!==Z&&(r.activeTexture(Z),B=Z)}function Y(Z,Ie,Te){Te===void 0&&(B===null?Te=r.TEXTURE0+G-1:Te=B);let Fe=E[Te];Fe===void 0&&(Fe={type:void 0,texture:void 0},E[Te]=Fe),(Fe.type!==Z||Fe.texture!==Ie)&&(B!==Te&&(r.activeTexture(Te),B=Te),r.bindTexture(Z,Ie||le[Z]),Fe.type=Z,Fe.texture=Ie)}function Tt(){const Z=E[B];Z!==void 0&&Z.type!==void 0&&(r.bindTexture(Z.type,null),Z.type=void 0,Z.texture=void 0)}function Ne(){try{r.compressedTexImage2D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function z(){try{r.compressedTexImage3D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function A(){try{r.texSubImage2D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function ie(){try{r.texSubImage3D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function pe(){try{r.compressedTexSubImage2D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function ye(){try{r.compressedTexSubImage3D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function Oe(){try{r.texStorage2D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function Be(){try{r.texStorage3D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function be(){try{r.texImage2D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function Me(){try{r.texImage3D(...arguments)}catch(Z){Bt("WebGLState:",Z)}}function ze(Z){return x[Z]!==void 0?x[Z]:r.getParameter(Z)}function Ze(Z,Ie){x[Z]!==Ie&&(r.pixelStorei(Z,Ie),x[Z]=Ie)}function je(Z){Se.equals(Z)===!1&&(r.scissor(Z.x,Z.y,Z.z,Z.w),Se.copy(Z))}function Ve(Z){Ae.equals(Z)===!1&&(r.viewport(Z.x,Z.y,Z.z,Z.w),Ae.copy(Z))}function ut(Z,Ie){let Te=h.get(Ie);Te===void 0&&(Te=new WeakMap,h.set(Ie,Te));let Fe=Te.get(Z);Fe===void 0&&(Fe=r.getUniformBlockIndex(Ie,Z.name),Te.set(Z,Fe))}function dt(Z,Ie){const Fe=h.get(Ie).get(Z);m.get(Ie)!==Fe&&(r.uniformBlockBinding(Ie,Fe,Z.__bindingPointIndex),m.set(Ie,Fe))}function gt(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),f.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),r.pixelStorei(r.PACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,!1),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,r.BROWSER_DEFAULT_WEBGL),r.pixelStorei(r.PACK_ROW_LENGTH,0),r.pixelStorei(r.PACK_SKIP_PIXELS,0),r.pixelStorei(r.PACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_ROW_LENGTH,0),r.pixelStorei(r.UNPACK_IMAGE_HEIGHT,0),r.pixelStorei(r.UNPACK_SKIP_PIXELS,0),r.pixelStorei(r.UNPACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_SKIP_IMAGES,0),v={},x={},B=null,E={},g={},M=new WeakMap,w=[],R=null,b=!1,y=null,P=null,O=null,C=null,I=null,L=null,F=null,T=new Ot(0,0,0),U=0,V=!1,k=null,W=null,re=null,oe=null,te=null,Se.set(0,0,r.canvas.width,r.canvas.height),Ae.set(0,0,r.canvas.width,r.canvas.height),c.reset(),f.reset(),p.reset()}return{buffers:{color:c,depth:f,stencil:p},enable:xe,disable:Le,bindFramebuffer:Q,drawBuffers:_e,useProgram:Ce,setBlending:Ye,setMaterial:ft,setFlipSided:ee,setCullFace:Pe,setLineWidth:Qe,setPolygonOffset:Je,setScissorTest:ct,activeTexture:Mt,bindTexture:Y,unbindTexture:Tt,compressedTexImage2D:Ne,compressedTexImage3D:z,texImage2D:be,texImage3D:Me,pixelStorei:Ze,getParameter:ze,updateUBOMapping:ut,uniformBlockBinding:dt,texStorage2D:Oe,texStorage3D:Be,texSubImage2D:A,texSubImage3D:ie,compressedTexSubImage2D:pe,compressedTexSubImage3D:ye,scissor:je,viewport:Ve,reset:gt}}function Bw(r,e,i,s,l,c,f){const p=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new Ct,v=new WeakMap,x=new Set;let g;const M=new WeakMap;let w=!1;try{w=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function R(z,A){return w?new OffscreenCanvas(z,A):ru("canvas")}function b(z,A,ie){let pe=1;const ye=Ne(z);if((ye.width>ie||ye.height>ie)&&(pe=ie/Math.max(ye.width,ye.height)),pe<1)if(typeof HTMLImageElement<"u"&&z instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&z instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&z instanceof ImageBitmap||typeof VideoFrame<"u"&&z instanceof VideoFrame){const Oe=Math.floor(pe*ye.width),Be=Math.floor(pe*ye.height);g===void 0&&(g=R(Oe,Be));const be=A?R(Oe,Be):g;return be.width=Oe,be.height=Be,be.getContext("2d").drawImage(z,0,0,Oe,Be),xt("WebGLRenderer: Texture has been resized from ("+ye.width+"x"+ye.height+") to ("+Oe+"x"+Be+")."),be}else return"data"in z&&xt("WebGLRenderer: Image in DataTexture is too big ("+ye.width+"x"+ye.height+")."),z;return z}function y(z){return z.generateMipmaps}function P(z){r.generateMipmap(z)}function O(z){return z.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:z.isWebGL3DRenderTarget?r.TEXTURE_3D:z.isWebGLArrayRenderTarget||z.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function C(z,A,ie,pe,ye,Oe=!1){if(z!==null){if(r[z]!==void 0)return r[z];xt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+z+"'")}let Be;pe&&(Be=e.get("EXT_texture_norm16"),Be||xt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let be=A;if(A===r.RED&&(ie===r.FLOAT&&(be=r.R32F),ie===r.HALF_FLOAT&&(be=r.R16F),ie===r.UNSIGNED_BYTE&&(be=r.R8),ie===r.UNSIGNED_SHORT&&Be&&(be=Be.R16_EXT),ie===r.SHORT&&Be&&(be=Be.R16_SNORM_EXT)),A===r.RED_INTEGER&&(ie===r.UNSIGNED_BYTE&&(be=r.R8UI),ie===r.UNSIGNED_SHORT&&(be=r.R16UI),ie===r.UNSIGNED_INT&&(be=r.R32UI),ie===r.BYTE&&(be=r.R8I),ie===r.SHORT&&(be=r.R16I),ie===r.INT&&(be=r.R32I)),A===r.RG&&(ie===r.FLOAT&&(be=r.RG32F),ie===r.HALF_FLOAT&&(be=r.RG16F),ie===r.UNSIGNED_BYTE&&(be=r.RG8),ie===r.UNSIGNED_SHORT&&Be&&(be=Be.RG16_EXT),ie===r.SHORT&&Be&&(be=Be.RG16_SNORM_EXT)),A===r.RG_INTEGER&&(ie===r.UNSIGNED_BYTE&&(be=r.RG8UI),ie===r.UNSIGNED_SHORT&&(be=r.RG16UI),ie===r.UNSIGNED_INT&&(be=r.RG32UI),ie===r.BYTE&&(be=r.RG8I),ie===r.SHORT&&(be=r.RG16I),ie===r.INT&&(be=r.RG32I)),A===r.RGB_INTEGER&&(ie===r.UNSIGNED_BYTE&&(be=r.RGB8UI),ie===r.UNSIGNED_SHORT&&(be=r.RGB16UI),ie===r.UNSIGNED_INT&&(be=r.RGB32UI),ie===r.BYTE&&(be=r.RGB8I),ie===r.SHORT&&(be=r.RGB16I),ie===r.INT&&(be=r.RGB32I)),A===r.RGBA_INTEGER&&(ie===r.UNSIGNED_BYTE&&(be=r.RGBA8UI),ie===r.UNSIGNED_SHORT&&(be=r.RGBA16UI),ie===r.UNSIGNED_INT&&(be=r.RGBA32UI),ie===r.BYTE&&(be=r.RGBA8I),ie===r.SHORT&&(be=r.RGBA16I),ie===r.INT&&(be=r.RGBA32I)),A===r.RGB&&(ie===r.UNSIGNED_SHORT&&Be&&(be=Be.RGB16_EXT),ie===r.SHORT&&Be&&(be=Be.RGB16_SNORM_EXT),ie===r.UNSIGNED_INT_5_9_9_9_REV&&(be=r.RGB9_E5),ie===r.UNSIGNED_INT_10F_11F_11F_REV&&(be=r.R11F_G11F_B10F)),A===r.RGBA){const Me=Oe?su:It.getTransfer(ye);ie===r.FLOAT&&(be=r.RGBA32F),ie===r.HALF_FLOAT&&(be=r.RGBA16F),ie===r.UNSIGNED_BYTE&&(be=Me===Qt?r.SRGB8_ALPHA8:r.RGBA8),ie===r.UNSIGNED_SHORT&&Be&&(be=Be.RGBA16_EXT),ie===r.SHORT&&Be&&(be=Be.RGBA16_SNORM_EXT),ie===r.UNSIGNED_SHORT_4_4_4_4&&(be=r.RGBA4),ie===r.UNSIGNED_SHORT_5_5_5_1&&(be=r.RGB5_A1)}return(be===r.R16F||be===r.R32F||be===r.RG16F||be===r.RG32F||be===r.RGBA16F||be===r.RGBA32F)&&e.get("EXT_color_buffer_float"),be}function I(z,A){let ie;return z?A===null||A===na||A===cl?ie=r.DEPTH24_STENCIL8:A===Qi?ie=r.DEPTH32F_STENCIL8:A===ll&&(ie=r.DEPTH24_STENCIL8,xt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===na||A===cl?ie=r.DEPTH_COMPONENT24:A===Qi?ie=r.DEPTH_COMPONENT32F:A===ll&&(ie=r.DEPTH_COMPONENT16),ie}function L(z,A){return y(z)===!0||z.isFramebufferTexture&&z.minFilter!==zn&&z.minFilter!==jn?Math.log2(Math.max(A.width,A.height))+1:z.mipmaps!==void 0&&z.mipmaps.length>0?z.mipmaps.length:z.isCompressedTexture&&Array.isArray(z.image)?A.mipmaps.length:1}function F(z){const A=z.target;A.removeEventListener("dispose",F),U(A),A.isVideoTexture&&v.delete(A),A.isHTMLTexture&&x.delete(A)}function T(z){const A=z.target;A.removeEventListener("dispose",T),k(A)}function U(z){const A=s.get(z);if(A.__webglInit===void 0)return;const ie=z.source,pe=M.get(ie);if(pe){const ye=pe[A.__cacheKey];ye.usedTimes--,ye.usedTimes===0&&V(z),Object.keys(pe).length===0&&M.delete(ie)}s.remove(z)}function V(z){const A=s.get(z);r.deleteTexture(A.__webglTexture);const ie=z.source,pe=M.get(ie);delete pe[A.__cacheKey],f.memory.textures--}function k(z){const A=s.get(z);if(z.depthTexture&&(z.depthTexture.dispose(),s.remove(z.depthTexture)),z.isWebGLCubeRenderTarget)for(let pe=0;pe<6;pe++){if(Array.isArray(A.__webglFramebuffer[pe]))for(let ye=0;ye<A.__webglFramebuffer[pe].length;ye++)r.deleteFramebuffer(A.__webglFramebuffer[pe][ye]);else r.deleteFramebuffer(A.__webglFramebuffer[pe]);A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer[pe])}else{if(Array.isArray(A.__webglFramebuffer))for(let pe=0;pe<A.__webglFramebuffer.length;pe++)r.deleteFramebuffer(A.__webglFramebuffer[pe]);else r.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&r.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let pe=0;pe<A.__webglColorRenderbuffer.length;pe++)A.__webglColorRenderbuffer[pe]&&r.deleteRenderbuffer(A.__webglColorRenderbuffer[pe]);A.__webglDepthRenderbuffer&&r.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const ie=z.textures;for(let pe=0,ye=ie.length;pe<ye;pe++){const Oe=s.get(ie[pe]);Oe.__webglTexture&&(r.deleteTexture(Oe.__webglTexture),f.memory.textures--),s.remove(ie[pe])}s.remove(z)}let W=0;function re(){W=0}function oe(){return W}function te(z){W=z}function G(){const z=W;return z>=l.maxTextures&&xt("WebGLTextures: Trying to use "+z+" texture units while this GPU supports only "+l.maxTextures),W+=1,z}function X(z){const A=[];return A.push(z.wrapS),A.push(z.wrapT),A.push(z.wrapR||0),A.push(z.magFilter),A.push(z.minFilter),A.push(z.anisotropy),A.push(z.internalFormat),A.push(z.format),A.push(z.type),A.push(z.generateMipmaps),A.push(z.premultiplyAlpha),A.push(z.flipY),A.push(z.unpackAlignment),A.push(z.colorSpace),A.join()}function $(z,A){const ie=s.get(z);if(z.isVideoTexture&&Y(z),z.isRenderTargetTexture===!1&&z.isExternalTexture!==!0&&z.version>0&&ie.__version!==z.version){const pe=z.image;if(pe===null)xt("WebGLRenderer: Texture marked for update but no image data found.");else if(pe.complete===!1)xt("WebGLRenderer: Texture marked for update but image is incomplete");else{Le(ie,z,A);return}}else z.isExternalTexture&&(ie.__webglTexture=z.sourceTexture?z.sourceTexture:null);i.bindTexture(r.TEXTURE_2D,ie.__webglTexture,r.TEXTURE0+A)}function se(z,A){const ie=s.get(z);if(z.isRenderTargetTexture===!1&&z.version>0&&ie.__version!==z.version){Le(ie,z,A);return}else z.isExternalTexture&&(ie.__webglTexture=z.sourceTexture?z.sourceTexture:null);i.bindTexture(r.TEXTURE_2D_ARRAY,ie.__webglTexture,r.TEXTURE0+A)}function B(z,A){const ie=s.get(z);if(z.isRenderTargetTexture===!1&&z.version>0&&ie.__version!==z.version){Le(ie,z,A);return}i.bindTexture(r.TEXTURE_3D,ie.__webglTexture,r.TEXTURE0+A)}function E(z,A){const ie=s.get(z);if(z.isCubeDepthTexture!==!0&&z.version>0&&ie.__version!==z.version){Q(ie,z,A);return}i.bindTexture(r.TEXTURE_CUBE_MAP,ie.__webglTexture,r.TEXTURE0+A)}const H={[Mh]:r.REPEAT,[Ca]:r.CLAMP_TO_EDGE,[Eh]:r.MIRRORED_REPEAT},ce={[zn]:r.NEAREST,[i1]:r.NEAREST_MIPMAP_NEAREST,[Tc]:r.NEAREST_MIPMAP_LINEAR,[jn]:r.LINEAR,[Cd]:r.LINEAR_MIPMAP_NEAREST,[ks]:r.LINEAR_MIPMAP_LINEAR},Se={[r1]:r.NEVER,[f1]:r.ALWAYS,[o1]:r.LESS,[Tp]:r.LEQUAL,[l1]:r.EQUAL,[Ap]:r.GEQUAL,[c1]:r.GREATER,[u1]:r.NOTEQUAL};function Ae(z,A){if(A.type===Qi&&e.has("OES_texture_float_linear")===!1&&(A.magFilter===jn||A.magFilter===Cd||A.magFilter===Tc||A.magFilter===ks||A.minFilter===jn||A.minFilter===Cd||A.minFilter===Tc||A.minFilter===ks)&&xt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(z,r.TEXTURE_WRAP_S,H[A.wrapS]),r.texParameteri(z,r.TEXTURE_WRAP_T,H[A.wrapT]),(z===r.TEXTURE_3D||z===r.TEXTURE_2D_ARRAY)&&r.texParameteri(z,r.TEXTURE_WRAP_R,H[A.wrapR]),r.texParameteri(z,r.TEXTURE_MAG_FILTER,ce[A.magFilter]),r.texParameteri(z,r.TEXTURE_MIN_FILTER,ce[A.minFilter]),A.compareFunction&&(r.texParameteri(z,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(z,r.TEXTURE_COMPARE_FUNC,Se[A.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===zn||A.minFilter!==Tc&&A.minFilter!==ks||A.type===Qi&&e.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||s.get(A).__currentAnisotropy){const ie=e.get("EXT_texture_filter_anisotropic");r.texParameterf(z,ie.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,l.getMaxAnisotropy())),s.get(A).__currentAnisotropy=A.anisotropy}}}function K(z,A){let ie=!1;z.__webglInit===void 0&&(z.__webglInit=!0,A.addEventListener("dispose",F));const pe=A.source;let ye=M.get(pe);ye===void 0&&(ye={},M.set(pe,ye));const Oe=X(A);if(Oe!==z.__cacheKey){ye[Oe]===void 0&&(ye[Oe]={texture:r.createTexture(),usedTimes:0},f.memory.textures++,ie=!0),ye[Oe].usedTimes++;const Be=ye[z.__cacheKey];Be!==void 0&&(ye[z.__cacheKey].usedTimes--,Be.usedTimes===0&&V(A)),z.__cacheKey=Oe,z.__webglTexture=ye[Oe].texture}return ie}function le(z,A,ie){return Math.floor(Math.floor(z/ie)/A)}function xe(z,A,ie,pe){const Oe=z.updateRanges;if(Oe.length===0)i.texSubImage2D(r.TEXTURE_2D,0,0,0,A.width,A.height,ie,pe,A.data);else{Oe.sort((Ze,je)=>Ze.start-je.start);let Be=0;for(let Ze=1;Ze<Oe.length;Ze++){const je=Oe[Be],Ve=Oe[Ze],ut=je.start+je.count,dt=le(Ve.start,A.width,4),gt=le(je.start,A.width,4);Ve.start<=ut+1&&dt===gt&&le(Ve.start+Ve.count-1,A.width,4)===dt?je.count=Math.max(je.count,Ve.start+Ve.count-je.start):(++Be,Oe[Be]=Ve)}Oe.length=Be+1;const be=i.getParameter(r.UNPACK_ROW_LENGTH),Me=i.getParameter(r.UNPACK_SKIP_PIXELS),ze=i.getParameter(r.UNPACK_SKIP_ROWS);i.pixelStorei(r.UNPACK_ROW_LENGTH,A.width);for(let Ze=0,je=Oe.length;Ze<je;Ze++){const Ve=Oe[Ze],ut=Math.floor(Ve.start/4),dt=Math.ceil(Ve.count/4),gt=ut%A.width,Z=Math.floor(ut/A.width),Ie=dt,Te=1;i.pixelStorei(r.UNPACK_SKIP_PIXELS,gt),i.pixelStorei(r.UNPACK_SKIP_ROWS,Z),i.texSubImage2D(r.TEXTURE_2D,0,gt,Z,Ie,Te,ie,pe,A.data)}z.clearUpdateRanges(),i.pixelStorei(r.UNPACK_ROW_LENGTH,be),i.pixelStorei(r.UNPACK_SKIP_PIXELS,Me),i.pixelStorei(r.UNPACK_SKIP_ROWS,ze)}}function Le(z,A,ie){let pe=r.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(pe=r.TEXTURE_2D_ARRAY),A.isData3DTexture&&(pe=r.TEXTURE_3D);const ye=K(z,A),Oe=A.source;i.bindTexture(pe,z.__webglTexture,r.TEXTURE0+ie);const Be=s.get(Oe);if(Oe.version!==Be.__version||ye===!0){if(i.activeTexture(r.TEXTURE0+ie),(typeof ImageBitmap<"u"&&A.image instanceof ImageBitmap)===!1){const Te=It.getPrimaries(It.workingColorSpace),Fe=A.colorSpace===ds?null:It.getPrimaries(A.colorSpace),qe=A.colorSpace===ds||Te===Fe?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,qe)}i.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment);let Me=b(A.image,!1,l.maxTextureSize);Me=Tt(A,Me);const ze=c.convert(A.format,A.colorSpace),Ze=c.convert(A.type);let je=C(A.internalFormat,ze,Ze,A.normalized,A.colorSpace,A.isVideoTexture);Ae(pe,A);let Ve;const ut=A.mipmaps,dt=A.isVideoTexture!==!0,gt=Be.__version===void 0||ye===!0,Z=Oe.dataReady,Ie=L(A,Me);if(A.isDepthTexture)je=I(A.format===js,A.type),gt&&(dt?i.texStorage2D(r.TEXTURE_2D,1,je,Me.width,Me.height):i.texImage2D(r.TEXTURE_2D,0,je,Me.width,Me.height,0,ze,Ze,null));else if(A.isDataTexture)if(ut.length>0){dt&&gt&&i.texStorage2D(r.TEXTURE_2D,Ie,je,ut[0].width,ut[0].height);for(let Te=0,Fe=ut.length;Te<Fe;Te++)Ve=ut[Te],dt?Z&&i.texSubImage2D(r.TEXTURE_2D,Te,0,0,Ve.width,Ve.height,ze,Ze,Ve.data):i.texImage2D(r.TEXTURE_2D,Te,je,Ve.width,Ve.height,0,ze,Ze,Ve.data);A.generateMipmaps=!1}else dt?(gt&&i.texStorage2D(r.TEXTURE_2D,Ie,je,Me.width,Me.height),Z&&xe(A,Me,ze,Ze)):i.texImage2D(r.TEXTURE_2D,0,je,Me.width,Me.height,0,ze,Ze,Me.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){dt&&gt&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Ie,je,ut[0].width,ut[0].height,Me.depth);for(let Te=0,Fe=ut.length;Te<Fe;Te++)if(Ve=ut[Te],A.format!==Bi)if(ze!==null)if(dt){if(Z)if(A.layerUpdates.size>0){const qe=yv(Ve.width,Ve.height,A.format,A.type);for(const De of A.layerUpdates){const rt=Ve.data.subarray(De*qe/Ve.data.BYTES_PER_ELEMENT,(De+1)*qe/Ve.data.BYTES_PER_ELEMENT);i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,Te,0,0,De,Ve.width,Ve.height,1,ze,rt)}A.clearLayerUpdates()}else i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,Te,0,0,0,Ve.width,Ve.height,Me.depth,ze,Ve.data)}else i.compressedTexImage3D(r.TEXTURE_2D_ARRAY,Te,je,Ve.width,Ve.height,Me.depth,0,Ve.data,0,0);else xt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else dt?Z&&i.texSubImage3D(r.TEXTURE_2D_ARRAY,Te,0,0,0,Ve.width,Ve.height,Me.depth,ze,Ze,Ve.data):i.texImage3D(r.TEXTURE_2D_ARRAY,Te,je,Ve.width,Ve.height,Me.depth,0,ze,Ze,Ve.data)}else{dt&&gt&&i.texStorage2D(r.TEXTURE_2D,Ie,je,ut[0].width,ut[0].height);for(let Te=0,Fe=ut.length;Te<Fe;Te++)Ve=ut[Te],A.format!==Bi?ze!==null?dt?Z&&i.compressedTexSubImage2D(r.TEXTURE_2D,Te,0,0,Ve.width,Ve.height,ze,Ve.data):i.compressedTexImage2D(r.TEXTURE_2D,Te,je,Ve.width,Ve.height,0,Ve.data):xt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):dt?Z&&i.texSubImage2D(r.TEXTURE_2D,Te,0,0,Ve.width,Ve.height,ze,Ze,Ve.data):i.texImage2D(r.TEXTURE_2D,Te,je,Ve.width,Ve.height,0,ze,Ze,Ve.data)}else if(A.isDataArrayTexture)if(dt){if(gt&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Ie,je,Me.width,Me.height,Me.depth),Z)if(A.layerUpdates.size>0){const Te=yv(Me.width,Me.height,A.format,A.type);for(const Fe of A.layerUpdates){const qe=Me.data.subarray(Fe*Te/Me.data.BYTES_PER_ELEMENT,(Fe+1)*Te/Me.data.BYTES_PER_ELEMENT);i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,Fe,Me.width,Me.height,1,ze,Ze,qe)}A.clearLayerUpdates()}else i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,Me.width,Me.height,Me.depth,ze,Ze,Me.data)}else i.texImage3D(r.TEXTURE_2D_ARRAY,0,je,Me.width,Me.height,Me.depth,0,ze,Ze,Me.data);else if(A.isData3DTexture)dt?(gt&&i.texStorage3D(r.TEXTURE_3D,Ie,je,Me.width,Me.height,Me.depth),Z&&i.texSubImage3D(r.TEXTURE_3D,0,0,0,0,Me.width,Me.height,Me.depth,ze,Ze,Me.data)):i.texImage3D(r.TEXTURE_3D,0,je,Me.width,Me.height,Me.depth,0,ze,Ze,Me.data);else if(A.isFramebufferTexture){if(gt)if(dt)i.texStorage2D(r.TEXTURE_2D,Ie,je,Me.width,Me.height);else{let Te=Me.width,Fe=Me.height;for(let qe=0;qe<Ie;qe++)i.texImage2D(r.TEXTURE_2D,qe,je,Te,Fe,0,ze,Ze,null),Te>>=1,Fe>>=1}}else if(A.isHTMLTexture){if("texElementImage2D"in r){const Te=r.canvas;if(Te.hasAttribute("layoutsubtree")||Te.setAttribute("layoutsubtree","true"),Me.parentNode!==Te){Te.appendChild(Me),x.add(A),Te.onpaint=Fe=>{const qe=Fe.changedElements;for(const De of x)qe.includes(De.image)&&(De.needsUpdate=!0)},Te.requestPaint();return}if(r.texElementImage2D.length===3)r.texElementImage2D(r.TEXTURE_2D,r.RGBA8,Me);else{const qe=r.RGBA,De=r.RGBA,rt=r.UNSIGNED_BYTE;r.texElementImage2D(r.TEXTURE_2D,0,qe,De,rt,Me)}r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)}}else if(ut.length>0){if(dt&&gt){const Te=Ne(ut[0]);i.texStorage2D(r.TEXTURE_2D,Ie,je,Te.width,Te.height)}for(let Te=0,Fe=ut.length;Te<Fe;Te++)Ve=ut[Te],dt?Z&&i.texSubImage2D(r.TEXTURE_2D,Te,0,0,ze,Ze,Ve):i.texImage2D(r.TEXTURE_2D,Te,je,ze,Ze,Ve);A.generateMipmaps=!1}else if(dt){if(gt){const Te=Ne(Me);i.texStorage2D(r.TEXTURE_2D,Ie,je,Te.width,Te.height)}Z&&i.texSubImage2D(r.TEXTURE_2D,0,0,0,ze,Ze,Me)}else i.texImage2D(r.TEXTURE_2D,0,je,ze,Ze,Me);y(A)&&P(pe),Be.__version=Oe.version,A.onUpdate&&A.onUpdate(A)}z.__version=A.version}function Q(z,A,ie){if(A.image.length!==6)return;const pe=K(z,A),ye=A.source;i.bindTexture(r.TEXTURE_CUBE_MAP,z.__webglTexture,r.TEXTURE0+ie);const Oe=s.get(ye);if(ye.version!==Oe.__version||pe===!0){i.activeTexture(r.TEXTURE0+ie);const Be=It.getPrimaries(It.workingColorSpace),be=A.colorSpace===ds?null:It.getPrimaries(A.colorSpace),Me=A.colorSpace===ds||Be===be?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),i.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,Me);const ze=A.isCompressedTexture||A.image[0].isCompressedTexture,Ze=A.image[0]&&A.image[0].isDataTexture,je=[];for(let De=0;De<6;De++)!ze&&!Ze?je[De]=b(A.image[De],!0,l.maxCubemapSize):je[De]=Ze?A.image[De].image:A.image[De],je[De]=Tt(A,je[De]);const Ve=je[0],ut=c.convert(A.format,A.colorSpace),dt=c.convert(A.type),gt=C(A.internalFormat,ut,dt,A.normalized,A.colorSpace),Z=A.isVideoTexture!==!0,Ie=Oe.__version===void 0||pe===!0,Te=ye.dataReady;let Fe=L(A,Ve);Ae(r.TEXTURE_CUBE_MAP,A);let qe;if(ze){Z&&Ie&&i.texStorage2D(r.TEXTURE_CUBE_MAP,Fe,gt,Ve.width,Ve.height);for(let De=0;De<6;De++){qe=je[De].mipmaps;for(let rt=0;rt<qe.length;rt++){const et=qe[rt];A.format!==Bi?ut!==null?Z?Te&&i.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt,0,0,et.width,et.height,ut,et.data):i.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt,gt,et.width,et.height,0,et.data):xt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Z?Te&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt,0,0,et.width,et.height,ut,dt,et.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt,gt,et.width,et.height,0,ut,dt,et.data)}}}else{if(qe=A.mipmaps,Z&&Ie){qe.length>0&&Fe++;const De=Ne(je[0]);i.texStorage2D(r.TEXTURE_CUBE_MAP,Fe,gt,De.width,De.height)}for(let De=0;De<6;De++)if(Ze){Z?Te&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,0,0,0,je[De].width,je[De].height,ut,dt,je[De].data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,0,gt,je[De].width,je[De].height,0,ut,dt,je[De].data);for(let rt=0;rt<qe.length;rt++){const rn=qe[rt].image[De].image;Z?Te&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt+1,0,0,rn.width,rn.height,ut,dt,rn.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt+1,gt,rn.width,rn.height,0,ut,dt,rn.data)}}else{Z?Te&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,0,0,0,ut,dt,je[De]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,0,gt,ut,dt,je[De]);for(let rt=0;rt<qe.length;rt++){const et=qe[rt];Z?Te&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt+1,0,0,ut,dt,et.image[De]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,rt+1,gt,ut,dt,et.image[De])}}}y(A)&&P(r.TEXTURE_CUBE_MAP),Oe.__version=ye.version,A.onUpdate&&A.onUpdate(A)}z.__version=A.version}function _e(z,A,ie,pe,ye,Oe){const Be=c.convert(ie.format,ie.colorSpace),be=c.convert(ie.type),Me=C(ie.internalFormat,Be,be,ie.normalized,ie.colorSpace),ze=s.get(A),Ze=s.get(ie);if(Ze.__renderTarget=A,!ze.__hasExternalTextures){const je=Math.max(1,A.width>>Oe),Ve=Math.max(1,A.height>>Oe);ye===r.TEXTURE_3D||ye===r.TEXTURE_2D_ARRAY?i.texImage3D(ye,Oe,Me,je,Ve,A.depth,0,Be,be,null):i.texImage2D(ye,Oe,Me,je,Ve,0,Be,be,null)}i.bindFramebuffer(r.FRAMEBUFFER,z),Mt(A)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,pe,ye,Ze.__webglTexture,0,ct(A)):(ye===r.TEXTURE_2D||ye>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&ye<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,pe,ye,Ze.__webglTexture,Oe),i.bindFramebuffer(r.FRAMEBUFFER,null)}function Ce(z,A,ie){if(r.bindRenderbuffer(r.RENDERBUFFER,z),A.depthBuffer){const pe=A.depthTexture,ye=pe&&pe.isDepthTexture?pe.type:null,Oe=I(A.stencilBuffer,ye),Be=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;Mt(A)?p.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ct(A),Oe,A.width,A.height):ie?r.renderbufferStorageMultisample(r.RENDERBUFFER,ct(A),Oe,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,Oe,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Be,r.RENDERBUFFER,z)}else{const pe=A.textures;for(let ye=0;ye<pe.length;ye++){const Oe=pe[ye],Be=c.convert(Oe.format,Oe.colorSpace),be=c.convert(Oe.type),Me=C(Oe.internalFormat,Be,be,Oe.normalized,Oe.colorSpace);Mt(A)?p.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,ct(A),Me,A.width,A.height):ie?r.renderbufferStorageMultisample(r.RENDERBUFFER,ct(A),Me,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,Me,A.width,A.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function Ue(z,A,ie){const pe=A.isWebGLCubeRenderTarget===!0;if(i.bindFramebuffer(r.FRAMEBUFFER,z),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const ye=s.get(A.depthTexture);if(ye.__renderTarget=A,(!ye.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),pe){if(ye.__webglInit===void 0&&(ye.__webglInit=!0,A.depthTexture.addEventListener("dispose",F)),ye.__webglTexture===void 0){ye.__webglTexture=r.createTexture(),i.bindTexture(r.TEXTURE_CUBE_MAP,ye.__webglTexture),Ae(r.TEXTURE_CUBE_MAP,A.depthTexture);const ze=c.convert(A.depthTexture.format),Ze=c.convert(A.depthTexture.type);let je;A.depthTexture.format===Ua?je=r.DEPTH_COMPONENT24:A.depthTexture.format===js&&(je=r.DEPTH24_STENCIL8);for(let Ve=0;Ve<6;Ve++)r.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Ve,0,je,A.width,A.height,0,ze,Ze,null)}}else $(A.depthTexture,0);const Oe=ye.__webglTexture,Be=ct(A),be=pe?r.TEXTURE_CUBE_MAP_POSITIVE_X+ie:r.TEXTURE_2D,Me=A.depthTexture.format===js?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;if(A.depthTexture.format===Ua)Mt(A)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,Me,be,Oe,0,Be):r.framebufferTexture2D(r.FRAMEBUFFER,Me,be,Oe,0);else if(A.depthTexture.format===js)Mt(A)?p.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,Me,be,Oe,0,Be):r.framebufferTexture2D(r.FRAMEBUFFER,Me,be,Oe,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function He(z){const A=s.get(z),ie=z.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==z.depthTexture){const pe=z.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),pe){const ye=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,pe.removeEventListener("dispose",ye)};pe.addEventListener("dispose",ye),A.__depthDisposeCallback=ye}A.__boundDepthTexture=pe}if(z.depthTexture&&!A.__autoAllocateDepthBuffer)if(ie)for(let pe=0;pe<6;pe++)Ue(A.__webglFramebuffer[pe],z,pe);else{const pe=z.texture.mipmaps;pe&&pe.length>0?Ue(A.__webglFramebuffer[0],z,0):Ue(A.__webglFramebuffer,z,0)}else if(ie){A.__webglDepthbuffer=[];for(let pe=0;pe<6;pe++)if(i.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer[pe]),A.__webglDepthbuffer[pe]===void 0)A.__webglDepthbuffer[pe]=r.createRenderbuffer(),Ce(A.__webglDepthbuffer[pe],z,!1);else{const ye=z.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Oe=A.__webglDepthbuffer[pe];r.bindRenderbuffer(r.RENDERBUFFER,Oe),r.framebufferRenderbuffer(r.FRAMEBUFFER,ye,r.RENDERBUFFER,Oe)}}else{const pe=z.texture.mipmaps;if(pe&&pe.length>0?i.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer[0]):i.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=r.createRenderbuffer(),Ce(A.__webglDepthbuffer,z,!1);else{const ye=z.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Oe=A.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,Oe),r.framebufferRenderbuffer(r.FRAMEBUFFER,ye,r.RENDERBUFFER,Oe)}}i.bindFramebuffer(r.FRAMEBUFFER,null)}function Ye(z,A,ie){const pe=s.get(z);A!==void 0&&_e(pe.__webglFramebuffer,z,z.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),ie!==void 0&&He(z)}function ft(z){const A=z.texture,ie=s.get(z),pe=s.get(A);z.addEventListener("dispose",T);const ye=z.textures,Oe=z.isWebGLCubeRenderTarget===!0,Be=ye.length>1;if(Be||(pe.__webglTexture===void 0&&(pe.__webglTexture=r.createTexture()),pe.__version=A.version,f.memory.textures++),Oe){ie.__webglFramebuffer=[];for(let be=0;be<6;be++)if(A.mipmaps&&A.mipmaps.length>0){ie.__webglFramebuffer[be]=[];for(let Me=0;Me<A.mipmaps.length;Me++)ie.__webglFramebuffer[be][Me]=r.createFramebuffer()}else ie.__webglFramebuffer[be]=r.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){ie.__webglFramebuffer=[];for(let be=0;be<A.mipmaps.length;be++)ie.__webglFramebuffer[be]=r.createFramebuffer()}else ie.__webglFramebuffer=r.createFramebuffer();if(Be)for(let be=0,Me=ye.length;be<Me;be++){const ze=s.get(ye[be]);ze.__webglTexture===void 0&&(ze.__webglTexture=r.createTexture(),f.memory.textures++)}if(z.samples>0&&Mt(z)===!1){ie.__webglMultisampledFramebuffer=r.createFramebuffer(),ie.__webglColorRenderbuffer=[],i.bindFramebuffer(r.FRAMEBUFFER,ie.__webglMultisampledFramebuffer);for(let be=0;be<ye.length;be++){const Me=ye[be];ie.__webglColorRenderbuffer[be]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,ie.__webglColorRenderbuffer[be]);const ze=c.convert(Me.format,Me.colorSpace),Ze=c.convert(Me.type),je=C(Me.internalFormat,ze,Ze,Me.normalized,Me.colorSpace,z.isXRRenderTarget===!0),Ve=ct(z);r.renderbufferStorageMultisample(r.RENDERBUFFER,Ve,je,z.width,z.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+be,r.RENDERBUFFER,ie.__webglColorRenderbuffer[be])}r.bindRenderbuffer(r.RENDERBUFFER,null),z.depthBuffer&&(ie.__webglDepthRenderbuffer=r.createRenderbuffer(),Ce(ie.__webglDepthRenderbuffer,z,!0)),i.bindFramebuffer(r.FRAMEBUFFER,null)}}if(Oe){i.bindTexture(r.TEXTURE_CUBE_MAP,pe.__webglTexture),Ae(r.TEXTURE_CUBE_MAP,A);for(let be=0;be<6;be++)if(A.mipmaps&&A.mipmaps.length>0)for(let Me=0;Me<A.mipmaps.length;Me++)_e(ie.__webglFramebuffer[be][Me],z,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+be,Me);else _e(ie.__webglFramebuffer[be],z,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+be,0);y(A)&&P(r.TEXTURE_CUBE_MAP),i.unbindTexture()}else if(Be){for(let be=0,Me=ye.length;be<Me;be++){const ze=ye[be],Ze=s.get(ze);let je=r.TEXTURE_2D;(z.isWebGL3DRenderTarget||z.isWebGLArrayRenderTarget)&&(je=z.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(je,Ze.__webglTexture),Ae(je,ze),_e(ie.__webglFramebuffer,z,ze,r.COLOR_ATTACHMENT0+be,je,0),y(ze)&&P(je)}i.unbindTexture()}else{let be=r.TEXTURE_2D;if((z.isWebGL3DRenderTarget||z.isWebGLArrayRenderTarget)&&(be=z.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(be,pe.__webglTexture),Ae(be,A),A.mipmaps&&A.mipmaps.length>0)for(let Me=0;Me<A.mipmaps.length;Me++)_e(ie.__webglFramebuffer[Me],z,A,r.COLOR_ATTACHMENT0,be,Me);else _e(ie.__webglFramebuffer,z,A,r.COLOR_ATTACHMENT0,be,0);y(A)&&P(be),i.unbindTexture()}z.depthBuffer&&He(z)}function ee(z){const A=z.textures;for(let ie=0,pe=A.length;ie<pe;ie++){const ye=A[ie];if(y(ye)){const Oe=O(z),Be=s.get(ye).__webglTexture;i.bindTexture(Oe,Be),P(Oe),i.unbindTexture()}}}const Pe=[],Qe=[];function Je(z){if(z.samples>0){if(Mt(z)===!1){const A=z.textures,ie=z.width,pe=z.height;let ye=r.COLOR_BUFFER_BIT;const Oe=z.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Be=s.get(z),be=A.length>1;if(be)for(let ze=0;ze<A.length;ze++)i.bindFramebuffer(r.FRAMEBUFFER,Be.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ze,r.RENDERBUFFER,null),i.bindFramebuffer(r.FRAMEBUFFER,Be.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ze,r.TEXTURE_2D,null,0);i.bindFramebuffer(r.READ_FRAMEBUFFER,Be.__webglMultisampledFramebuffer);const Me=z.texture.mipmaps;Me&&Me.length>0?i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Be.__webglFramebuffer[0]):i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Be.__webglFramebuffer);for(let ze=0;ze<A.length;ze++){if(z.resolveDepthBuffer&&(z.depthBuffer&&(ye|=r.DEPTH_BUFFER_BIT),z.stencilBuffer&&z.resolveStencilBuffer&&(ye|=r.STENCIL_BUFFER_BIT)),be){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Be.__webglColorRenderbuffer[ze]);const Ze=s.get(A[ze]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,Ze,0)}r.blitFramebuffer(0,0,ie,pe,0,0,ie,pe,ye,r.NEAREST),m===!0&&(Pe.length=0,Qe.length=0,Pe.push(r.COLOR_ATTACHMENT0+ze),z.depthBuffer&&z.resolveDepthBuffer===!1&&(Pe.push(Oe),Qe.push(Oe),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,Qe)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,Pe))}if(i.bindFramebuffer(r.READ_FRAMEBUFFER,null),i.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),be)for(let ze=0;ze<A.length;ze++){i.bindFramebuffer(r.FRAMEBUFFER,Be.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ze,r.RENDERBUFFER,Be.__webglColorRenderbuffer[ze]);const Ze=s.get(A[ze]).__webglTexture;i.bindFramebuffer(r.FRAMEBUFFER,Be.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+ze,r.TEXTURE_2D,Ze,0)}i.bindFramebuffer(r.DRAW_FRAMEBUFFER,Be.__webglMultisampledFramebuffer)}else if(z.depthBuffer&&z.resolveDepthBuffer===!1&&m){const A=z.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[A])}}}function ct(z){return Math.min(l.maxSamples,z.samples)}function Mt(z){const A=s.get(z);return z.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function Y(z){const A=f.render.frame;v.get(z)!==A&&(v.set(z,A),z.update())}function Tt(z,A){const ie=z.colorSpace,pe=z.format,ye=z.type;return z.isCompressedTexture===!0||z.isVideoTexture===!0||ie!==au&&ie!==ds&&(It.getTransfer(ie)===Qt?(pe!==Bi||ye!==xi)&&xt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Bt("WebGLTextures: Unsupported texture color space:",ie)),A}function Ne(z){return typeof HTMLImageElement<"u"&&z instanceof HTMLImageElement?(h.width=z.naturalWidth||z.width,h.height=z.naturalHeight||z.height):typeof VideoFrame<"u"&&z instanceof VideoFrame?(h.width=z.displayWidth,h.height=z.displayHeight):(h.width=z.width,h.height=z.height),h}this.allocateTextureUnit=G,this.resetTextureUnits=re,this.getTextureUnits=oe,this.setTextureUnits=te,this.setTexture2D=$,this.setTexture2DArray=se,this.setTexture3D=B,this.setTextureCube=E,this.rebindTextures=Ye,this.setupRenderTarget=ft,this.updateRenderTargetMipmap=ee,this.updateMultisampleRenderTarget=Je,this.setupDepthRenderbuffer=He,this.setupFrameBufferTexture=_e,this.useMultisampledRTT=Mt,this.isReversedDepthBuffer=function(){return i.buffers.depth.getReversed()}}function Gw(r,e){function i(s,l=ds){let c;const f=It.getTransfer(l);if(s===xi)return r.UNSIGNED_BYTE;if(s===yp)return r.UNSIGNED_SHORT_4_4_4_4;if(s===bp)return r.UNSIGNED_SHORT_5_5_5_1;if(s===l_)return r.UNSIGNED_INT_5_9_9_9_REV;if(s===c_)return r.UNSIGNED_INT_10F_11F_11F_REV;if(s===r_)return r.BYTE;if(s===o_)return r.SHORT;if(s===ll)return r.UNSIGNED_SHORT;if(s===_p)return r.INT;if(s===na)return r.UNSIGNED_INT;if(s===Qi)return r.FLOAT;if(s===Da)return r.HALF_FLOAT;if(s===u_)return r.ALPHA;if(s===f_)return r.RGB;if(s===Bi)return r.RGBA;if(s===Ua)return r.DEPTH_COMPONENT;if(s===js)return r.DEPTH_STENCIL;if(s===d_)return r.RED;if(s===Sp)return r.RED_INTEGER;if(s===Ws)return r.RG;if(s===Mp)return r.RG_INTEGER;if(s===Ep)return r.RGBA_INTEGER;if(s===Zc||s===Kc||s===Qc||s===Jc)if(f===Qt)if(c=e.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(s===Zc)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Kc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===Qc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Jc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=e.get("WEBGL_compressed_texture_s3tc"),c!==null){if(s===Zc)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Kc)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===Qc)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Jc)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===Th||s===Ah||s===wh||s===Ch)if(c=e.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(s===Th)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===Ah)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===wh)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===Ch)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===Rh||s===Nh||s===Dh||s===Uh||s===Lh||s===nu||s===Oh)if(c=e.get("WEBGL_compressed_texture_etc"),c!==null){if(s===Rh||s===Nh)return f===Qt?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(s===Dh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(s===Uh)return c.COMPRESSED_R11_EAC;if(s===Lh)return c.COMPRESSED_SIGNED_R11_EAC;if(s===nu)return c.COMPRESSED_RG11_EAC;if(s===Oh)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(s===Ph||s===Ih||s===zh||s===Fh||s===Bh||s===Gh||s===Hh||s===Vh||s===kh||s===jh||s===Xh||s===Wh||s===qh||s===Yh)if(c=e.get("WEBGL_compressed_texture_astc"),c!==null){if(s===Ph)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Ih)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===zh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Fh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Bh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Gh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Hh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Vh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===kh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===jh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Xh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Wh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===qh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Yh)return f===Qt?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Zh||s===Kh||s===Qh)if(c=e.get("EXT_texture_compression_bptc"),c!==null){if(s===Zh)return f===Qt?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===Kh)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Qh)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===Jh||s===$h||s===iu||s===ep)if(c=e.get("EXT_texture_compression_rgtc"),c!==null){if(s===Jh)return c.COMPRESSED_RED_RGTC1_EXT;if(s===$h)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===iu)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===ep)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===cl?r.UNSIGNED_INT_24_8:r[s]!==void 0?r[s]:null}return{convert:i}}const Hw=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Vw=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class kw{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,i){if(this.texture===null){const s=new S_(e.texture);(e.depthNear!==i.depthNear||e.depthFar!==i.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){const i=e.cameras[0].viewport,s=new ia({vertexShader:Hw,fragmentShader:Vw,uniforms:{depthColor:{value:this.texture},depthWidth:{value:i.z},depthHeight:{value:i.w}}});this.mesh=new Ge(new $i(20,20),s)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class jw extends Ks{constructor(e,i){super();const s=this;let l=null,c=1,f=null,p="local-floor",m=1,h=null,v=null,x=null,g=null,M=null,w=null;const R=typeof XRWebGLBinding<"u",b=new kw,y={},P=i.getContextAttributes();let O=null,C=null;const I=[],L=[],F=new Ct;let T=null;const U=new Ci;U.viewport=new un;const V=new Ci;V.viewport=new un;const k=[U,V],W=new eE;let re=null,oe=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let le=I[K];return le===void 0&&(le=new Id,I[K]=le),le.getTargetRaySpace()},this.getControllerGrip=function(K){let le=I[K];return le===void 0&&(le=new Id,I[K]=le),le.getGripSpace()},this.getHand=function(K){let le=I[K];return le===void 0&&(le=new Id,I[K]=le),le.getHandSpace()};function te(K){const le=L.indexOf(K.inputSource);if(le===-1)return;const xe=I[le];xe!==void 0&&(xe.update(K.inputSource,K.frame,h||f),xe.dispatchEvent({type:K.type,data:K.inputSource}))}function G(){l.removeEventListener("select",te),l.removeEventListener("selectstart",te),l.removeEventListener("selectend",te),l.removeEventListener("squeeze",te),l.removeEventListener("squeezestart",te),l.removeEventListener("squeezeend",te),l.removeEventListener("end",G),l.removeEventListener("inputsourceschange",X);for(let K=0;K<I.length;K++){const le=L[K];le!==null&&(L[K]=null,I[K].disconnect(le))}re=null,oe=null,b.reset();for(const K in y)delete y[K];e.setRenderTarget(O),M=null,g=null,x=null,l=null,C=null,Ae.stop(),s.isPresenting=!1,e.setPixelRatio(T),e.setSize(F.width,F.height,!1),s.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(K){c=K,s.isPresenting===!0&&xt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){p=K,s.isPresenting===!0&&xt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return h||f},this.setReferenceSpace=function(K){h=K},this.getBaseLayer=function(){return g!==null?g:M},this.getBinding=function(){return x===null&&R&&(x=new XRWebGLBinding(l,i)),x},this.getFrame=function(){return w},this.getSession=function(){return l},this.setSession=async function(K){if(l=K,l!==null){if(O=e.getRenderTarget(),l.addEventListener("select",te),l.addEventListener("selectstart",te),l.addEventListener("selectend",te),l.addEventListener("squeeze",te),l.addEventListener("squeezestart",te),l.addEventListener("squeezeend",te),l.addEventListener("end",G),l.addEventListener("inputsourceschange",X),P.xrCompatible!==!0&&await i.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(F),R&&"createProjectionLayer"in XRWebGLBinding.prototype){let xe=null,Le=null,Q=null;P.depth&&(Q=P.stencil?i.DEPTH24_STENCIL8:i.DEPTH_COMPONENT24,xe=P.stencil?js:Ua,Le=P.stencil?cl:na);const _e={colorFormat:i.RGBA8,depthFormat:Q,scaleFactor:c};x=this.getBinding(),g=x.createProjectionLayer(_e),l.updateRenderState({layers:[g]}),e.setPixelRatio(1),e.setSize(g.textureWidth,g.textureHeight,!1),C=new ta(g.textureWidth,g.textureHeight,{format:Bi,type:xi,depthTexture:new Kr(g.textureWidth,g.textureHeight,Le,void 0,void 0,void 0,void 0,void 0,void 0,xe),stencilBuffer:P.stencil,colorSpace:e.outputColorSpace,samples:P.antialias?4:0,resolveDepthBuffer:g.ignoreDepthValues===!1,resolveStencilBuffer:g.ignoreDepthValues===!1})}else{const xe={antialias:P.antialias,alpha:!0,depth:P.depth,stencil:P.stencil,framebufferScaleFactor:c};M=new XRWebGLLayer(l,i,xe),l.updateRenderState({baseLayer:M}),e.setPixelRatio(1),e.setSize(M.framebufferWidth,M.framebufferHeight,!1),C=new ta(M.framebufferWidth,M.framebufferHeight,{format:Bi,type:xi,colorSpace:e.outputColorSpace,stencilBuffer:P.stencil,resolveDepthBuffer:M.ignoreDepthValues===!1,resolveStencilBuffer:M.ignoreDepthValues===!1})}C.isXRRenderTarget=!0,this.setFoveation(m),h=null,f=await l.requestReferenceSpace(p),Ae.setContext(l),Ae.start(),s.isPresenting=!0,s.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return b.getDepthTexture()};function X(K){for(let le=0;le<K.removed.length;le++){const xe=K.removed[le],Le=L.indexOf(xe);Le>=0&&(L[Le]=null,I[Le].disconnect(xe))}for(let le=0;le<K.added.length;le++){const xe=K.added[le];let Le=L.indexOf(xe);if(Le===-1){for(let _e=0;_e<I.length;_e++)if(_e>=L.length){L.push(xe),Le=_e;break}else if(L[_e]===null){L[_e]=xe,Le=_e;break}if(Le===-1)break}const Q=I[Le];Q&&Q.connect(xe)}}const $=new ae,se=new ae;function B(K,le,xe){$.setFromMatrixPosition(le.matrixWorld),se.setFromMatrixPosition(xe.matrixWorld);const Le=$.distanceTo(se),Q=le.projectionMatrix.elements,_e=xe.projectionMatrix.elements,Ce=Q[14]/(Q[10]-1),Ue=Q[14]/(Q[10]+1),He=(Q[9]+1)/Q[5],Ye=(Q[9]-1)/Q[5],ft=(Q[8]-1)/Q[0],ee=(_e[8]+1)/_e[0],Pe=Ce*ft,Qe=Ce*ee,Je=Le/(-ft+ee),ct=Je*-ft;if(le.matrixWorld.decompose(K.position,K.quaternion,K.scale),K.translateX(ct),K.translateZ(Je),K.matrixWorld.compose(K.position,K.quaternion,K.scale),K.matrixWorldInverse.copy(K.matrixWorld).invert(),Q[10]===-1)K.projectionMatrix.copy(le.projectionMatrix),K.projectionMatrixInverse.copy(le.projectionMatrixInverse);else{const Mt=Ce+Je,Y=Ue+Je,Tt=Pe-ct,Ne=Qe+(Le-ct),z=He*Ue/Y*Mt,A=Ye*Ue/Y*Mt;K.projectionMatrix.makePerspective(Tt,Ne,z,A,Mt,Y),K.projectionMatrixInverse.copy(K.projectionMatrix).invert()}}function E(K,le){le===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(le.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(l===null)return;let le=K.near,xe=K.far;b.texture!==null&&(b.depthNear>0&&(le=b.depthNear),b.depthFar>0&&(xe=b.depthFar)),W.near=V.near=U.near=le,W.far=V.far=U.far=xe,(re!==W.near||oe!==W.far)&&(l.updateRenderState({depthNear:W.near,depthFar:W.far}),re=W.near,oe=W.far),W.layers.mask=K.layers.mask|6,U.layers.mask=W.layers.mask&-5,V.layers.mask=W.layers.mask&-3;const Le=K.parent,Q=W.cameras;E(W,Le);for(let _e=0;_e<Q.length;_e++)E(Q[_e],Le);Q.length===2?B(W,U,V):W.projectionMatrix.copy(U.projectionMatrix),H(K,W,Le)};function H(K,le,xe){xe===null?K.matrix.copy(le.matrixWorld):(K.matrix.copy(xe.matrixWorld),K.matrix.invert(),K.matrix.multiply(le.matrixWorld)),K.matrix.decompose(K.position,K.quaternion,K.scale),K.updateMatrixWorld(!0),K.projectionMatrix.copy(le.projectionMatrix),K.projectionMatrixInverse.copy(le.projectionMatrixInverse),K.isPerspectiveCamera&&(K.fov=np*2*Math.atan(1/K.projectionMatrix.elements[5]),K.zoom=1)}this.getCamera=function(){return W},this.getFoveation=function(){if(!(g===null&&M===null))return m},this.setFoveation=function(K){m=K,g!==null&&(g.fixedFoveation=K),M!==null&&M.fixedFoveation!==void 0&&(M.fixedFoveation=K)},this.hasDepthSensing=function(){return b.texture!==null},this.getDepthSensingMesh=function(){return b.getMesh(W)},this.getCameraTexture=function(K){return y[K]};let ce=null;function Se(K,le){if(v=le.getViewerPose(h||f),w=le,v!==null){const xe=v.views;M!==null&&(e.setRenderTargetFramebuffer(C,M.framebuffer),e.setRenderTarget(C));let Le=!1;xe.length!==W.cameras.length&&(W.cameras.length=0,Le=!0);for(let Ue=0;Ue<xe.length;Ue++){const He=xe[Ue];let Ye=null;if(M!==null)Ye=M.getViewport(He);else{const ee=x.getViewSubImage(g,He);Ye=ee.viewport,Ue===0&&(e.setRenderTargetTextures(C,ee.colorTexture,ee.depthStencilTexture),e.setRenderTarget(C))}let ft=k[Ue];ft===void 0&&(ft=new Ci,ft.layers.enable(Ue),ft.viewport=new un,k[Ue]=ft),ft.matrix.fromArray(He.transform.matrix),ft.matrix.decompose(ft.position,ft.quaternion,ft.scale),ft.projectionMatrix.fromArray(He.projectionMatrix),ft.projectionMatrixInverse.copy(ft.projectionMatrix).invert(),ft.viewport.set(Ye.x,Ye.y,Ye.width,Ye.height),Ue===0&&(W.matrix.copy(ft.matrix),W.matrix.decompose(W.position,W.quaternion,W.scale)),Le===!0&&W.cameras.push(ft)}const Q=l.enabledFeatures;if(Q&&Q.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&R){x=s.getBinding();const Ue=x.getDepthInformation(xe[0]);Ue&&Ue.isValid&&Ue.texture&&b.init(Ue,l.renderState)}if(Q&&Q.includes("camera-access")&&R){e.state.unbindTexture(),x=s.getBinding();for(let Ue=0;Ue<xe.length;Ue++){const He=xe[Ue].camera;if(He){let Ye=y[He];Ye||(Ye=new S_,y[He]=Ye);const ft=x.getCameraImage(He);Ye.sourceTexture=ft}}}}for(let xe=0;xe<I.length;xe++){const Le=L[xe],Q=I[xe];Le!==null&&Q!==void 0&&Q.update(Le,le,h||f)}ce&&ce(K,le),le.detectedPlanes&&s.dispatchEvent({type:"planesdetected",data:le}),w=null}const Ae=new A_;Ae.setAnimationLoop(Se),this.setAnimationLoop=function(K){ce=K},this.dispose=function(){}}}const Xw=new fn,L_=new _t;L_.set(-1,0,0,0,1,0,0,0,1);function Ww(r,e){function i(b,y){b.matrixAutoUpdate===!0&&b.updateMatrix(),y.value.copy(b.matrix)}function s(b,y){y.color.getRGB(b.fogColor.value,M_(r)),y.isFog?(b.fogNear.value=y.near,b.fogFar.value=y.far):y.isFogExp2&&(b.fogDensity.value=y.density)}function l(b,y,P,O,C){y.isNodeMaterial?y.uniformsNeedUpdate=!1:y.isMeshBasicMaterial?c(b,y):y.isMeshLambertMaterial?(c(b,y),y.envMap&&(b.envMapIntensity.value=y.envMapIntensity)):y.isMeshToonMaterial?(c(b,y),x(b,y)):y.isMeshPhongMaterial?(c(b,y),v(b,y),y.envMap&&(b.envMapIntensity.value=y.envMapIntensity)):y.isMeshStandardMaterial?(c(b,y),g(b,y),y.isMeshPhysicalMaterial&&M(b,y,C)):y.isMeshMatcapMaterial?(c(b,y),w(b,y)):y.isMeshDepthMaterial?c(b,y):y.isMeshDistanceMaterial?(c(b,y),R(b,y)):y.isMeshNormalMaterial?c(b,y):y.isLineBasicMaterial?(f(b,y),y.isLineDashedMaterial&&p(b,y)):y.isPointsMaterial?m(b,y,P,O):y.isSpriteMaterial?h(b,y):y.isShadowMaterial?(b.color.value.copy(y.color),b.opacity.value=y.opacity):y.isShaderMaterial&&(y.uniformsNeedUpdate=!1)}function c(b,y){b.opacity.value=y.opacity,y.color&&b.diffuse.value.copy(y.color),y.emissive&&b.emissive.value.copy(y.emissive).multiplyScalar(y.emissiveIntensity),y.map&&(b.map.value=y.map,i(y.map,b.mapTransform)),y.alphaMap&&(b.alphaMap.value=y.alphaMap,i(y.alphaMap,b.alphaMapTransform)),y.bumpMap&&(b.bumpMap.value=y.bumpMap,i(y.bumpMap,b.bumpMapTransform),b.bumpScale.value=y.bumpScale,y.side===ii&&(b.bumpScale.value*=-1)),y.normalMap&&(b.normalMap.value=y.normalMap,i(y.normalMap,b.normalMapTransform),b.normalScale.value.copy(y.normalScale),y.side===ii&&b.normalScale.value.negate()),y.displacementMap&&(b.displacementMap.value=y.displacementMap,i(y.displacementMap,b.displacementMapTransform),b.displacementScale.value=y.displacementScale,b.displacementBias.value=y.displacementBias),y.emissiveMap&&(b.emissiveMap.value=y.emissiveMap,i(y.emissiveMap,b.emissiveMapTransform)),y.specularMap&&(b.specularMap.value=y.specularMap,i(y.specularMap,b.specularMapTransform)),y.alphaTest>0&&(b.alphaTest.value=y.alphaTest);const P=e.get(y),O=P.envMap,C=P.envMapRotation;O&&(b.envMap.value=O,b.envMapRotation.value.setFromMatrix4(Xw.makeRotationFromEuler(C)).transpose(),O.isCubeTexture&&O.isRenderTargetTexture===!1&&b.envMapRotation.value.premultiply(L_),b.reflectivity.value=y.reflectivity,b.ior.value=y.ior,b.refractionRatio.value=y.refractionRatio),y.lightMap&&(b.lightMap.value=y.lightMap,b.lightMapIntensity.value=y.lightMapIntensity,i(y.lightMap,b.lightMapTransform)),y.aoMap&&(b.aoMap.value=y.aoMap,b.aoMapIntensity.value=y.aoMapIntensity,i(y.aoMap,b.aoMapTransform))}function f(b,y){b.diffuse.value.copy(y.color),b.opacity.value=y.opacity,y.map&&(b.map.value=y.map,i(y.map,b.mapTransform))}function p(b,y){b.dashSize.value=y.dashSize,b.totalSize.value=y.dashSize+y.gapSize,b.scale.value=y.scale}function m(b,y,P,O){b.diffuse.value.copy(y.color),b.opacity.value=y.opacity,b.size.value=y.size*P,b.scale.value=O*.5,y.map&&(b.map.value=y.map,i(y.map,b.uvTransform)),y.alphaMap&&(b.alphaMap.value=y.alphaMap,i(y.alphaMap,b.alphaMapTransform)),y.alphaTest>0&&(b.alphaTest.value=y.alphaTest)}function h(b,y){b.diffuse.value.copy(y.color),b.opacity.value=y.opacity,b.rotation.value=y.rotation,y.map&&(b.map.value=y.map,i(y.map,b.mapTransform)),y.alphaMap&&(b.alphaMap.value=y.alphaMap,i(y.alphaMap,b.alphaMapTransform)),y.alphaTest>0&&(b.alphaTest.value=y.alphaTest)}function v(b,y){b.specular.value.copy(y.specular),b.shininess.value=Math.max(y.shininess,1e-4)}function x(b,y){y.gradientMap&&(b.gradientMap.value=y.gradientMap)}function g(b,y){b.metalness.value=y.metalness,y.metalnessMap&&(b.metalnessMap.value=y.metalnessMap,i(y.metalnessMap,b.metalnessMapTransform)),b.roughness.value=y.roughness,y.roughnessMap&&(b.roughnessMap.value=y.roughnessMap,i(y.roughnessMap,b.roughnessMapTransform)),y.envMap&&(b.envMapIntensity.value=y.envMapIntensity)}function M(b,y,P){b.ior.value=y.ior,y.sheen>0&&(b.sheenColor.value.copy(y.sheenColor).multiplyScalar(y.sheen),b.sheenRoughness.value=y.sheenRoughness,y.sheenColorMap&&(b.sheenColorMap.value=y.sheenColorMap,i(y.sheenColorMap,b.sheenColorMapTransform)),y.sheenRoughnessMap&&(b.sheenRoughnessMap.value=y.sheenRoughnessMap,i(y.sheenRoughnessMap,b.sheenRoughnessMapTransform))),y.clearcoat>0&&(b.clearcoat.value=y.clearcoat,b.clearcoatRoughness.value=y.clearcoatRoughness,y.clearcoatMap&&(b.clearcoatMap.value=y.clearcoatMap,i(y.clearcoatMap,b.clearcoatMapTransform)),y.clearcoatRoughnessMap&&(b.clearcoatRoughnessMap.value=y.clearcoatRoughnessMap,i(y.clearcoatRoughnessMap,b.clearcoatRoughnessMapTransform)),y.clearcoatNormalMap&&(b.clearcoatNormalMap.value=y.clearcoatNormalMap,i(y.clearcoatNormalMap,b.clearcoatNormalMapTransform),b.clearcoatNormalScale.value.copy(y.clearcoatNormalScale),y.side===ii&&b.clearcoatNormalScale.value.negate())),y.dispersion>0&&(b.dispersion.value=y.dispersion),y.iridescence>0&&(b.iridescence.value=y.iridescence,b.iridescenceIOR.value=y.iridescenceIOR,b.iridescenceThicknessMinimum.value=y.iridescenceThicknessRange[0],b.iridescenceThicknessMaximum.value=y.iridescenceThicknessRange[1],y.iridescenceMap&&(b.iridescenceMap.value=y.iridescenceMap,i(y.iridescenceMap,b.iridescenceMapTransform)),y.iridescenceThicknessMap&&(b.iridescenceThicknessMap.value=y.iridescenceThicknessMap,i(y.iridescenceThicknessMap,b.iridescenceThicknessMapTransform))),y.transmission>0&&(b.transmission.value=y.transmission,b.transmissionSamplerMap.value=P.texture,b.transmissionSamplerSize.value.set(P.width,P.height),y.transmissionMap&&(b.transmissionMap.value=y.transmissionMap,i(y.transmissionMap,b.transmissionMapTransform)),b.thickness.value=y.thickness,y.thicknessMap&&(b.thicknessMap.value=y.thicknessMap,i(y.thicknessMap,b.thicknessMapTransform)),b.attenuationDistance.value=y.attenuationDistance,b.attenuationColor.value.copy(y.attenuationColor)),y.anisotropy>0&&(b.anisotropyVector.value.set(y.anisotropy*Math.cos(y.anisotropyRotation),y.anisotropy*Math.sin(y.anisotropyRotation)),y.anisotropyMap&&(b.anisotropyMap.value=y.anisotropyMap,i(y.anisotropyMap,b.anisotropyMapTransform))),b.specularIntensity.value=y.specularIntensity,b.specularColor.value.copy(y.specularColor),y.specularColorMap&&(b.specularColorMap.value=y.specularColorMap,i(y.specularColorMap,b.specularColorMapTransform)),y.specularIntensityMap&&(b.specularIntensityMap.value=y.specularIntensityMap,i(y.specularIntensityMap,b.specularIntensityMapTransform))}function w(b,y){y.matcap&&(b.matcap.value=y.matcap)}function R(b,y){const P=e.get(y).light;b.referencePosition.value.setFromMatrixPosition(P.matrixWorld),b.nearDistance.value=P.shadow.camera.near,b.farDistance.value=P.shadow.camera.far}return{refreshFogUniforms:s,refreshMaterialUniforms:l}}function qw(r,e,i,s){let l={},c={},f=[];const p=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function m(C,I){const L=I.program;s.uniformBlockBinding(C,L)}function h(C,I){let L=l[C.id];L===void 0&&(b(C),L=v(C),l[C.id]=L,C.addEventListener("dispose",P));const F=I.program;s.updateUBOMapping(C,F);const T=e.render.frame;c[C.id]!==T&&(g(C),c[C.id]=T)}function v(C){const I=x();C.__bindingPointIndex=I;const L=r.createBuffer(),F=C.__size,T=C.usage;return r.bindBuffer(r.UNIFORM_BUFFER,L),r.bufferData(r.UNIFORM_BUFFER,F,T),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,I,L),L}function x(){for(let C=0;C<p;C++)if(f.indexOf(C)===-1)return f.push(C),C;return Bt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function g(C){const I=l[C.id],L=C.uniforms,F=C.__cache;r.bindBuffer(r.UNIFORM_BUFFER,I);for(let T=0,U=L.length;T<U;T++){const V=L[T];if(Array.isArray(V))for(let k=0,W=V.length;k<W;k++)M(V[k],T,k,F);else M(V,T,0,F)}r.bindBuffer(r.UNIFORM_BUFFER,null)}function M(C,I,L,F){if(R(C,I,L,F)===!0){const T=C.__offset,U=C.value;if(Array.isArray(U)){let V=0;for(let k=0;k<U.length;k++){const W=U[k],re=y(W);w(W,C.__data,V),typeof W!="number"&&typeof W!="boolean"&&!W.isMatrix3&&!ArrayBuffer.isView(W)&&(V+=re.storage/Float32Array.BYTES_PER_ELEMENT)}}else w(U,C.__data,0);r.bufferSubData(r.UNIFORM_BUFFER,T,C.__data)}}function w(C,I,L){typeof C=="number"||typeof C=="boolean"?I[0]=C:C.isMatrix3?(I[0]=C.elements[0],I[1]=C.elements[1],I[2]=C.elements[2],I[3]=0,I[4]=C.elements[3],I[5]=C.elements[4],I[6]=C.elements[5],I[7]=0,I[8]=C.elements[6],I[9]=C.elements[7],I[10]=C.elements[8],I[11]=0):ArrayBuffer.isView(C)?I.set(new C.constructor(C.buffer,C.byteOffset,I.length)):C.toArray(I,L)}function R(C,I,L,F){const T=C.value,U=I+"_"+L;if(F[U]===void 0)return typeof T=="number"||typeof T=="boolean"?F[U]=T:ArrayBuffer.isView(T)?F[U]=T.slice():F[U]=T.clone(),!0;{const V=F[U];if(typeof T=="number"||typeof T=="boolean"){if(V!==T)return F[U]=T,!0}else{if(ArrayBuffer.isView(T))return!0;if(V.equals(T)===!1)return V.copy(T),!0}}return!1}function b(C){const I=C.uniforms;let L=0;const F=16;for(let U=0,V=I.length;U<V;U++){const k=Array.isArray(I[U])?I[U]:[I[U]];for(let W=0,re=k.length;W<re;W++){const oe=k[W],te=Array.isArray(oe.value)?oe.value:[oe.value];for(let G=0,X=te.length;G<X;G++){const $=te[G],se=y($),B=L%F,E=B%se.boundary,H=B+E;L+=E,H!==0&&F-H<se.storage&&(L+=F-H),oe.__data=new Float32Array(se.storage/Float32Array.BYTES_PER_ELEMENT),oe.__offset=L,L+=se.storage}}}const T=L%F;return T>0&&(L+=F-T),C.__size=L,C.__cache={},this}function y(C){const I={boundary:0,storage:0};return typeof C=="number"||typeof C=="boolean"?(I.boundary=4,I.storage=4):C.isVector2?(I.boundary=8,I.storage=8):C.isVector3||C.isColor?(I.boundary=16,I.storage=12):C.isVector4?(I.boundary=16,I.storage=16):C.isMatrix3?(I.boundary=48,I.storage=48):C.isMatrix4?(I.boundary=64,I.storage=64):C.isTexture?xt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(C)?(I.boundary=16,I.storage=C.byteLength):xt("WebGLRenderer: Unsupported uniform value type.",C),I}function P(C){const I=C.target;I.removeEventListener("dispose",P);const L=f.indexOf(I.__bindingPointIndex);f.splice(L,1),r.deleteBuffer(l[I.id]),delete l[I.id],delete c[I.id]}function O(){for(const C in l)r.deleteBuffer(l[C]);f=[],l={},c={}}return{bind:m,update:h,dispose:O}}const Yw=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Zi=null;function Zw(){return Zi===null&&(Zi=new I1(Yw,16,16,Ws,Da),Zi.name="DFG_LUT",Zi.minFilter=jn,Zi.magFilter=jn,Zi.wrapS=Ca,Zi.wrapT=Ca,Zi.generateMipmaps=!1,Zi.needsUpdate=!0),Zi}class Kw{constructor(e={}){const{canvas:i=h1(),context:s=null,depth:l=!0,stencil:c=!1,alpha:f=!1,antialias:p=!1,premultipliedAlpha:m=!0,preserveDrawingBuffer:h=!1,powerPreference:v="default",failIfMajorPerformanceCaveat:x=!1,reversedDepthBuffer:g=!1,outputBufferType:M=xi}=e;this.isWebGLRenderer=!0;let w;if(s!==null){if(typeof WebGLRenderingContext<"u"&&s instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");w=s.getContextAttributes().alpha}else w=f;const R=M,b=new Set([Ep,Mp,Sp]),y=new Set([xi,na,ll,cl,yp,bp]),P=new Uint32Array(4),O=new Int32Array(4),C=new ae;let I=null,L=null;const F=[],T=[];let U=null;this.domElement=i,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=ea,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const V=this;let k=!1,W=null,re=null,oe=null,te=null;this._outputColorSpace=wi;let G=0,X=0,$=null,se=-1,B=null;const E=new un,H=new un;let ce=null;const Se=new Ot(0);let Ae=0,K=i.width,le=i.height,xe=1,Le=null,Q=null;const _e=new un(0,0,K,le),Ce=new un(0,0,K,le);let Ue=!1;const He=new Rp;let Ye=!1,ft=!1;const ee=new fn,Pe=new ae,Qe=new un,Je={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ct=!1;function Mt(){return $===null?xe:1}let Y=s;function Tt(N,J){return i.getContext(N,J)}try{const N={alpha:!0,depth:l,stencil:c,antialias:p,premultipliedAlpha:m,preserveDrawingBuffer:h,powerPreference:v,failIfMajorPerformanceCaveat:x};if("setAttribute"in i&&i.setAttribute("data-engine",`three.js r${vp}`),i.addEventListener("webglcontextlost",rn,!1),i.addEventListener("webglcontextrestored",Xt,!1),i.addEventListener("webglcontextcreationerror",ai,!1),Y===null){const J="webgl2";if(Y=Tt(J,N),Y===null)throw Tt(J)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(N){throw Bt("WebGLRenderer: "+N.message),N}let Ne,z,A,ie,pe,ye,Oe,Be,be,Me,ze,Ze,je,Ve,ut,dt,gt,Z,Ie,Te,Fe,qe,De;function rt(){Ne=new Z2(Y),Ne.init(),Fe=new Gw(Y,Ne),z=new H2(Y,Ne,e,Fe),A=new Fw(Y,Ne),z.reversedDepthBuffer&&g&&A.buffers.depth.setReversed(!0),re=Y.createFramebuffer(),oe=Y.createFramebuffer(),te=Y.createFramebuffer(),ie=new J2(Y),pe=new Ew,ye=new Bw(Y,Ne,A,pe,z,Fe,ie),Oe=new Y2(V),Be=new nE(Y),qe=new B2(Y,Be),be=new K2(Y,Be,ie,qe),Me=new eA(Y,be,Be,qe,ie),Z=new $2(Y,z,ye),ut=new V2(pe),ze=new Mw(V,Oe,Ne,z,qe,ut),Ze=new Ww(V,pe),je=new Aw,Ve=new Uw(Ne),gt=new F2(V,Oe,A,Me,w,m),dt=new zw(V,Me,z),De=new qw(Y,ie,z,A),Ie=new G2(Y,Ne,ie),Te=new Q2(Y,Ne,ie),ie.programs=ze.programs,V.capabilities=z,V.extensions=Ne,V.properties=pe,V.renderLists=je,V.shadowMap=dt,V.state=A,V.info=ie}rt(),R!==xi&&(U=new nA(R,i.width,i.height,p,l,c));const et=new jw(V,Y);this.xr=et,this.getContext=function(){return Y},this.getContextAttributes=function(){return Y.getContextAttributes()},this.forceContextLoss=function(){const N=Ne.get("WEBGL_lose_context");N&&N.loseContext()},this.forceContextRestore=function(){const N=Ne.get("WEBGL_lose_context");N&&N.restoreContext()},this.getPixelRatio=function(){return xe},this.setPixelRatio=function(N){N!==void 0&&(xe=N,this.setSize(K,le,!1))},this.getSize=function(N){return N.set(K,le)},this.setSize=function(N,J,me=!0){if(et.isPresenting){xt("WebGLRenderer: Can't change size while VR device is presenting.");return}K=N,le=J,i.width=Math.floor(N*xe),i.height=Math.floor(J*xe),me===!0&&(i.style.width=N+"px",i.style.height=J+"px"),U!==null&&U.setSize(i.width,i.height),this.setViewport(0,0,N,J)},this.getDrawingBufferSize=function(N){return N.set(K*xe,le*xe).floor()},this.setDrawingBufferSize=function(N,J,me){K=N,le=J,xe=me,i.width=Math.floor(N*me),i.height=Math.floor(J*me),this.setViewport(0,0,N,J)},this.setEffects=function(N){if(R===xi){Bt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(N){for(let J=0;J<N.length;J++)if(N[J].isOutputPass===!0){xt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}U.setEffects(N||[])},this.getCurrentViewport=function(N){return N.copy(E)},this.getViewport=function(N){return N.copy(_e)},this.setViewport=function(N,J,me,de){N.isVector4?_e.set(N.x,N.y,N.z,N.w):_e.set(N,J,me,de),A.viewport(E.copy(_e).multiplyScalar(xe).round())},this.getScissor=function(N){return N.copy(Ce)},this.setScissor=function(N,J,me,de){N.isVector4?Ce.set(N.x,N.y,N.z,N.w):Ce.set(N,J,me,de),A.scissor(H.copy(Ce).multiplyScalar(xe).round())},this.getScissorTest=function(){return Ue},this.setScissorTest=function(N){A.setScissorTest(Ue=N)},this.setOpaqueSort=function(N){Le=N},this.setTransparentSort=function(N){Q=N},this.getClearColor=function(N){return N.copy(gt.getClearColor())},this.setClearColor=function(){gt.setClearColor(...arguments)},this.getClearAlpha=function(){return gt.getClearAlpha()},this.setClearAlpha=function(){gt.setClearAlpha(...arguments)},this.clear=function(N=!0,J=!0,me=!0){let de=0;if(N){let he=!1;if($!==null){const Xe=$.texture.format;he=b.has(Xe)}if(he){const Xe=$.texture.type,$e=y.has(Xe),ke=gt.getClearColor(),it=gt.getClearAlpha(),tt=ke.r,ht=ke.g,yt=ke.b;$e?(P[0]=tt,P[1]=ht,P[2]=yt,P[3]=it,Y.clearBufferuiv(Y.COLOR,0,P)):(O[0]=tt,O[1]=ht,O[2]=yt,O[3]=it,Y.clearBufferiv(Y.COLOR,0,O))}else de|=Y.COLOR_BUFFER_BIT}J&&(de|=Y.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),me&&(de|=Y.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),de!==0&&Y.clear(de)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(N){N.setRenderer(this),W=N},this.dispose=function(){i.removeEventListener("webglcontextlost",rn,!1),i.removeEventListener("webglcontextrestored",Xt,!1),i.removeEventListener("webglcontextcreationerror",ai,!1),gt.dispose(),je.dispose(),Ve.dispose(),pe.dispose(),Oe.dispose(),Me.dispose(),qe.dispose(),De.dispose(),ze.dispose(),et.dispose(),et.removeEventListener("sessionstart",vn),et.removeEventListener("sessionend",Un),Zn.stop()};function rn(N){N.preventDefault(),Qx("WebGLRenderer: Context Lost."),k=!0}function Xt(){Qx("WebGLRenderer: Context Restored."),k=!1;const N=ie.autoReset,J=dt.enabled,me=dt.autoUpdate,de=dt.needsUpdate,he=dt.type;rt(),ie.autoReset=N,dt.enabled=J,dt.autoUpdate=me,dt.needsUpdate=de,dt.type=he}function ai(N){Bt("WebGLRenderer: A WebGL context could not be created. Reason: ",N.statusMessage)}function si(N){const J=N.target;J.removeEventListener("dispose",si),no(J)}function no(N){io(N),pe.remove(N)}function io(N){const J=pe.get(N).programs;J!==void 0&&(J.forEach(function(me){ze.releaseProgram(me)}),N.isShaderMaterial&&ze.releaseShaderCache(N))}this.renderBufferDirect=function(N,J,me,de,he,Xe){J===null&&(J=Je);const $e=he.isMesh&&he.matrixWorld.determinantAffine()<0,ke=Pa(N,J,me,de,he);A.setMaterial(de,$e);let it=me.index,tt=1;if(de.wireframe===!0){if(it=be.getWireframeAttribute(me),it===void 0)return;tt=2}const ht=me.drawRange,yt=me.attributes.position;let lt=ht.start*tt,Gt=(ht.start+ht.count)*tt;Xe!==null&&(lt=Math.max(lt,Xe.start*tt),Gt=Math.min(Gt,(Xe.start+Xe.count)*tt)),it!==null?(lt=Math.max(lt,0),Gt=Math.min(Gt,it.count)):yt!=null&&(lt=Math.max(lt,0),Gt=Math.min(Gt,yt.count));const on=Gt-lt;if(on<0||on===1/0)return;qe.setup(he,de,ke,me,it);let tn,Wt=Ie;if(it!==null&&(tn=Be.get(it),Wt=Te,Wt.setIndex(tn)),he.isMesh)de.wireframe===!0?(A.setLineWidth(de.wireframeLinewidth*Mt()),Wt.setMode(Y.LINES)):Wt.setMode(Y.TRIANGLES);else if(he.isLine){let qt=de.linewidth;qt===void 0&&(qt=1),A.setLineWidth(qt*Mt()),he.isLineSegments?Wt.setMode(Y.LINES):he.isLineLoop?Wt.setMode(Y.LINE_LOOP):Wt.setMode(Y.LINE_STRIP)}else he.isPoints?Wt.setMode(Y.POINTS):he.isSprite&&Wt.setMode(Y.TRIANGLES);if(he.isBatchedMesh)if(Ne.get("WEBGL_multi_draw"))Wt.renderMultiDraw(he._multiDrawStarts,he._multiDrawCounts,he._multiDrawCount);else{const qt=he._multiDrawStarts,Ke=he._multiDrawCounts,Gn=he._multiDrawCount,Rt=it?Be.get(it).bytesPerElement:1,Tn=pe.get(de).currentProgram.getUniforms();for(let ri=0;ri<Gn;ri++)Tn.setValue(Y,"_gl_DrawID",ri),Wt.render(qt[ri]/Rt,Ke[ri])}else if(he.isInstancedMesh)Wt.renderInstances(lt,on,he.count);else if(me.isInstancedBufferGeometry){const qt=me._maxInstanceCount!==void 0?me._maxInstanceCount:1/0,Ke=Math.min(me.instanceCount,qt);Wt.renderInstances(lt,on,Ke)}else Wt.render(lt,on)};function ao(N,J,me){N.transparent===!0&&N.side===zi&&N.forceSinglePass===!1?(N.side=ii,N.needsUpdate=!0,Oa(N,J,me),N.side=ps,N.needsUpdate=!0,Oa(N,J,me),N.side=zi):Oa(N,J,me)}this.compile=function(N,J,me=null){me===null&&(me=N),L=Ve.get(me),L.init(J),T.push(L),me.traverseVisible(function(he){he.isLight&&he.layers.test(J.layers)&&(L.pushLight(he),he.castShadow&&L.pushShadow(he))}),N!==me&&N.traverseVisible(function(he){he.isLight&&he.layers.test(J.layers)&&(L.pushLight(he),he.castShadow&&L.pushShadow(he))}),L.setupLights();const de=new Set;return N.traverse(function(he){if(!(he.isMesh||he.isPoints||he.isLine||he.isSprite))return;const Xe=he.material;if(Xe)if(Array.isArray(Xe))for(let $e=0;$e<Xe.length;$e++){const ke=Xe[$e];ao(ke,me,he),de.add(ke)}else ao(Xe,me,he),de.add(Xe)}),L=T.pop(),de},this.compileAsync=function(N,J,me=null){const de=this.compile(N,J,me);return new Promise(he=>{function Xe(){if(de.forEach(function($e){pe.get($e).currentProgram.isReady()&&de.delete($e)}),de.size===0){he(N);return}setTimeout(Xe,10)}Ne.get("KHR_parallel_shader_compile")!==null?Xe():setTimeout(Xe,10)})};let Qs=null;function Vi(N){Qs&&Qs(N)}function vn(){Zn.stop()}function Un(){Zn.start()}const Zn=new A_;Zn.setAnimationLoop(Vi),typeof self<"u"&&Zn.setContext(self),this.setAnimationLoop=function(N){Qs=N,et.setAnimationLoop(N),N===null?Zn.stop():Zn.start()},et.addEventListener("sessionstart",vn),et.addEventListener("sessionend",Un),this.render=function(N,J){if(J!==void 0&&J.isCamera!==!0){Bt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(k===!0)return;W!==null&&W.renderStart(N,J);const me=et.enabled===!0&&et.isPresenting===!0,de=U!==null&&($===null||me)&&U.begin(V,$);if(N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),J.parent===null&&J.matrixWorldAutoUpdate===!0&&J.updateMatrixWorld(),et.enabled===!0&&et.isPresenting===!0&&(U===null||U.isCompositing()===!1)&&(et.cameraAutoUpdate===!0&&et.updateCamera(J),J=et.getCamera()),N.isScene===!0&&N.onBeforeRender(V,N,J,$),L=Ve.get(N,T.length),L.init(J),L.state.textureUnits=ye.getTextureUnits(),T.push(L),ee.multiplyMatrices(J.projectionMatrix,J.matrixWorldInverse),He.setFromProjectionMatrix(ee,Ji,J.reversedDepth),ft=this.localClippingEnabled,Ye=ut.init(this.clippingPlanes,ft),I=je.get(N,F.length),I.init(),F.push(I),et.enabled===!0&&et.isPresenting===!0){const $e=V.xr.getDepthSensingMesh();$e!==null&&gs($e,J,-1/0,V.sortObjects)}gs(N,J,0,V.sortObjects),I.finish(),V.sortObjects===!0&&I.sort(Le,Q,J.reversedDepth),ct=et.enabled===!1||et.isPresenting===!1||et.hasDepthSensing()===!1,ct&&gt.addToRenderList(I,N),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),Ye===!0&&ut.beginShadows();const he=L.state.shadowsArray;if(dt.render(he,N,J),Ye===!0&&ut.endShadows(),(de&&U.hasRenderPass())===!1){const $e=I.opaque,ke=I.transmissive;if(L.setupLights(),J.isArrayCamera){const it=J.cameras;if(ke.length>0)for(let tt=0,ht=it.length;tt<ht;tt++){const yt=it[tt];ml($e,ke,N,yt)}ct&&gt.render(N);for(let tt=0,ht=it.length;tt<ht;tt++){const yt=it[tt];pl(I,N,yt,yt.viewport)}}else ke.length>0&&ml($e,ke,N,J),ct&&gt.render(N),pl(I,N,J)}$!==null&&X===0&&(ye.updateMultisampleRenderTarget($),ye.updateRenderTargetMipmap($)),de&&U.end(V),N.isScene===!0&&N.onAfterRender(V,N,J),qe.resetDefaultState(),se=-1,B=null,T.pop(),T.length>0?(L=T[T.length-1],ye.setTextureUnits(L.state.textureUnits),Ye===!0&&ut.setGlobalState(V.clippingPlanes,L.state.camera)):L=null,F.pop(),F.length>0?I=F[F.length-1]:I=null,W!==null&&W.renderEnd()};function gs(N,J,me,de){if(N.visible===!1)return;if(N.layers.test(J.layers)){if(N.isGroup)me=N.renderOrder;else if(N.isLOD)N.autoUpdate===!0&&N.update(J);else if(N.isLightProbeGrid)L.pushLightProbeGrid(N);else if(N.isLight)L.pushLight(N),N.castShadow&&L.pushShadow(N);else if(N.isSprite){if(!N.frustumCulled||He.intersectsSprite(N)){de&&Qe.setFromMatrixPosition(N.matrixWorld).applyMatrix4(ee);const $e=Me.update(N),ke=N.material;ke.visible&&I.push(N,$e,ke,me,Qe.z,null)}}else if((N.isMesh||N.isLine||N.isPoints)&&(!N.frustumCulled||He.intersectsObject(N))){const $e=Me.update(N),ke=N.material;if(de&&(N.boundingSphere!==void 0?(N.boundingSphere===null&&N.computeBoundingSphere(),Qe.copy(N.boundingSphere.center)):($e.boundingSphere===null&&$e.computeBoundingSphere(),Qe.copy($e.boundingSphere.center)),Qe.applyMatrix4(N.matrixWorld).applyMatrix4(ee)),Array.isArray(ke)){const it=$e.groups;for(let tt=0,ht=it.length;tt<ht;tt++){const yt=it[tt],lt=ke[yt.materialIndex];lt&&lt.visible&&I.push(N,$e,lt,me,Qe.z,yt)}}else ke.visible&&I.push(N,$e,ke,me,Qe.z,null)}}const Xe=N.children;for(let $e=0,ke=Xe.length;$e<ke;$e++)gs(Xe[$e],J,me,de)}function pl(N,J,me,de){const{opaque:he,transmissive:Xe,transparent:$e}=N;L.setupLightsView(me),Ye===!0&&ut.setGlobalState(V.clippingPlanes,me),de&&A.viewport(E.copy(de)),he.length>0&&xs(he,J,me),Xe.length>0&&xs(Xe,J,me),$e.length>0&&xs($e,J,me),A.buffers.depth.setTest(!0),A.buffers.depth.setMask(!0),A.buffers.color.setMask(!0),A.setPolygonOffset(!1)}function ml(N,J,me,de){if((me.isScene===!0?me.overrideMaterial:null)!==null)return;if(L.state.transmissionRenderTarget[de.id]===void 0){const lt=Ne.has("EXT_color_buffer_half_float")||Ne.has("EXT_color_buffer_float");L.state.transmissionRenderTarget[de.id]=new ta(1,1,{generateMipmaps:!0,type:lt?Da:xi,minFilter:ks,samples:Math.max(4,z.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:It.workingColorSpace})}const Xe=L.state.transmissionRenderTarget[de.id],$e=de.viewport||E;Xe.setSize($e.z*V.transmissionResolutionScale,$e.w*V.transmissionResolutionScale);const ke=V.getRenderTarget(),it=V.getActiveCubeFace(),tt=V.getActiveMipmapLevel();V.setRenderTarget(Xe),V.getClearColor(Se),Ae=V.getClearAlpha(),Ae<1&&V.setClearColor(16777215,.5),V.clear(),ct&&gt.render(me);const ht=V.toneMapping;V.toneMapping=ea;const yt=de.viewport;if(de.viewport!==void 0&&(de.viewport=void 0),L.setupLightsView(de),Ye===!0&&ut.setGlobalState(V.clippingPlanes,de),xs(N,me,de),ye.updateMultisampleRenderTarget(Xe),ye.updateRenderTargetMipmap(Xe),Ne.has("WEBGL_multisampled_render_to_texture")===!1){let lt=!1;for(let Gt=0,on=J.length;Gt<on;Gt++){const tn=J[Gt],{object:Wt,geometry:qt,material:Ke,group:Gn}=tn;if(Ke.side===zi&&Wt.layers.test(de.layers)){const Rt=Ke.side;Ke.side=ii,Ke.needsUpdate=!0,La(Wt,me,de,qt,Ke,Gn),Ke.side=Rt,Ke.needsUpdate=!0,lt=!0}}lt===!0&&(ye.updateMultisampleRenderTarget(Xe),ye.updateRenderTargetMipmap(Xe))}V.setRenderTarget(ke,it,tt),V.setClearColor(Se,Ae),yt!==void 0&&(de.viewport=yt),V.toneMapping=ht}function xs(N,J,me){const de=J.isScene===!0?J.overrideMaterial:null;for(let he=0,Xe=N.length;he<Xe;he++){const $e=N[he],{object:ke,geometry:it,group:tt}=$e;let ht=$e.material;ht.allowOverride===!0&&de!==null&&(ht=de),ke.layers.test(me.layers)&&La(ke,J,me,it,ht,tt)}}function La(N,J,me,de,he,Xe){N.onBeforeRender(V,J,me,de,he,Xe),N.modelViewMatrix.multiplyMatrices(me.matrixWorldInverse,N.matrixWorld),N.normalMatrix.getNormalMatrix(N.modelViewMatrix),he.onBeforeRender(V,J,me,de,N,Xe),he.transparent===!0&&he.side===zi&&he.forceSinglePass===!1?(he.side=ii,he.needsUpdate=!0,V.renderBufferDirect(me,J,de,he,N,Xe),he.side=ps,he.needsUpdate=!0,V.renderBufferDirect(me,J,de,he,N,Xe),he.side=zi):V.renderBufferDirect(me,J,de,he,N,Xe),N.onAfterRender(V,J,me,de,he,Xe)}function Oa(N,J,me){J.isScene!==!0&&(J=Je);const de=pe.get(N),he=L.state.lights,Xe=L.state.shadowsArray,$e=he.state.version,ke=ze.getParameters(N,he.state,Xe,J,me,L.state.lightProbeGridArray),it=ze.getProgramCacheKey(ke);let tt=de.programs;de.environment=N.isMeshStandardMaterial||N.isMeshLambertMaterial||N.isMeshPhongMaterial?J.environment:null,de.fog=J.fog;const ht=N.isMeshStandardMaterial||N.isMeshLambertMaterial&&!N.envMap||N.isMeshPhongMaterial&&!N.envMap;de.envMap=Oe.get(N.envMap||de.environment,ht),de.envMapRotation=de.environment!==null&&N.envMap===null?J.environmentRotation:N.envMapRotation,tt===void 0&&(N.addEventListener("dispose",si),tt=new Map,de.programs=tt);let yt=tt.get(it);if(yt!==void 0){if(de.currentProgram===yt&&de.lightsStateVersion===$e)return sa(N,ke),yt}else ke.uniforms=ze.getUniforms(N),W!==null&&N.isNodeMaterial&&W.build(N,me,ke),N.onBeforeCompile(ke,V),yt=ze.acquireProgram(ke,it),tt.set(it,yt),de.uniforms=ke.uniforms;const lt=de.uniforms;return(!N.isShaderMaterial&&!N.isRawShaderMaterial||N.clipping===!0)&&(lt.clippingPlanes=ut.uniform),sa(N,ke),de.needsLights=gl(N),de.lightsStateVersion=$e,de.needsLights&&(lt.ambientLightColor.value=he.state.ambient,lt.lightProbe.value=he.state.probe,lt.directionalLights.value=he.state.directional,lt.directionalLightShadows.value=he.state.directionalShadow,lt.spotLights.value=he.state.spot,lt.spotLightShadows.value=he.state.spotShadow,lt.rectAreaLights.value=he.state.rectArea,lt.ltc_1.value=he.state.rectAreaLTC1,lt.ltc_2.value=he.state.rectAreaLTC2,lt.pointLights.value=he.state.point,lt.pointLightShadows.value=he.state.pointShadow,lt.hemisphereLights.value=he.state.hemi,lt.directionalShadowMatrix.value=he.state.directionalShadowMatrix,lt.spotLightMatrix.value=he.state.spotLightMatrix,lt.spotLightMap.value=he.state.spotLightMap,lt.pointShadowMatrix.value=he.state.pointShadowMatrix),de.lightProbeGrid=L.state.lightProbeGridArray.length>0,de.currentProgram=yt,de.uniformsList=null,yt}function aa(N){if(N.uniformsList===null){const J=N.currentProgram.getUniforms();N.uniformsList=$c.seqWithValue(J.seq,N.uniforms)}return N.uniformsList}function sa(N,J){const me=pe.get(N);me.outputColorSpace=J.outputColorSpace,me.batching=J.batching,me.batchingColor=J.batchingColor,me.instancing=J.instancing,me.instancingColor=J.instancingColor,me.instancingMorph=J.instancingMorph,me.skinning=J.skinning,me.morphTargets=J.morphTargets,me.morphNormals=J.morphNormals,me.morphColors=J.morphColors,me.morphTargetsCount=J.morphTargetsCount,me.numClippingPlanes=J.numClippingPlanes,me.numIntersection=J.numClipIntersection,me.vertexAlphas=J.vertexAlphas,me.vertexTangents=J.vertexTangents,me.toneMapping=J.toneMapping}function vs(N,J){if(N.length===0)return null;if(N.length===1)return N[0].texture!==null?N[0]:null;C.setFromMatrixPosition(J.matrixWorld);for(let me=0,de=N.length;me<de;me++){const he=N[me];if(he.texture!==null&&he.boundingBox.containsPoint(C))return he}return null}function Pa(N,J,me,de,he){J.isScene!==!0&&(J=Je),ye.resetTextureUnits();const Xe=J.fog,$e=de.isMeshStandardMaterial||de.isMeshLambertMaterial||de.isMeshPhongMaterial?J.environment:null,ke=$===null?V.outputColorSpace:$.isXRRenderTarget===!0?$.texture.colorSpace:It.workingColorSpace,it=de.isMeshStandardMaterial||de.isMeshLambertMaterial&&!de.envMap||de.isMeshPhongMaterial&&!de.envMap,tt=Oe.get(de.envMap||$e,it),ht=de.vertexColors===!0&&!!me.attributes.color&&me.attributes.color.itemSize===4,yt=!!me.attributes.tangent&&(!!de.normalMap||de.anisotropy>0),lt=!!me.morphAttributes.position,Gt=!!me.morphAttributes.normal,on=!!me.morphAttributes.color;let tn=ea;de.toneMapped&&($===null||$.isXRRenderTarget===!0)&&(tn=V.toneMapping);const Wt=me.morphAttributes.position||me.morphAttributes.normal||me.morphAttributes.color,qt=Wt!==void 0?Wt.length:0,Ke=pe.get(de),Gn=L.state.lights;if(Ye===!0&&(ft===!0||N!==B)){const jt=N===B&&de.id===se;ut.setState(de,N,jt)}let Rt=!1;de.version===Ke.__version?(Ke.needsLights&&Ke.lightsStateVersion!==Gn.state.version||Ke.outputColorSpace!==ke||he.isBatchedMesh&&Ke.batching===!1||!he.isBatchedMesh&&Ke.batching===!0||he.isBatchedMesh&&Ke.batchingColor===!0&&he.colorTexture===null||he.isBatchedMesh&&Ke.batchingColor===!1&&he.colorTexture!==null||he.isInstancedMesh&&Ke.instancing===!1||!he.isInstancedMesh&&Ke.instancing===!0||he.isSkinnedMesh&&Ke.skinning===!1||!he.isSkinnedMesh&&Ke.skinning===!0||he.isInstancedMesh&&Ke.instancingColor===!0&&he.instanceColor===null||he.isInstancedMesh&&Ke.instancingColor===!1&&he.instanceColor!==null||he.isInstancedMesh&&Ke.instancingMorph===!0&&he.morphTexture===null||he.isInstancedMesh&&Ke.instancingMorph===!1&&he.morphTexture!==null||Ke.envMap!==tt||de.fog===!0&&Ke.fog!==Xe||Ke.numClippingPlanes!==void 0&&(Ke.numClippingPlanes!==ut.numPlanes||Ke.numIntersection!==ut.numIntersection)||Ke.vertexAlphas!==ht||Ke.vertexTangents!==yt||Ke.morphTargets!==lt||Ke.morphNormals!==Gt||Ke.morphColors!==on||Ke.toneMapping!==tn||Ke.morphTargetsCount!==qt||!!Ke.lightProbeGrid!=L.state.lightProbeGridArray.length>0)&&(Rt=!0):(Rt=!0,Ke.__version=de.version);let Tn=Ke.currentProgram;Rt===!0&&(Tn=Oa(de,J,he),W&&de.isNodeMaterial&&W.onUpdateProgram(de,Tn,Ke));let ri=!1,Ri=!1,oi=!1;const Yt=Tn.getUniforms(),ln=Ke.uniforms;if(A.useProgram(Tn.program)&&(ri=!0,Ri=!0,oi=!0),de.id!==se&&(se=de.id,Ri=!0),Ke.needsLights){const jt=vs(L.state.lightProbeGridArray,he);Ke.lightProbeGrid!==jt&&(Ke.lightProbeGrid=jt,Ri=!0)}if(ri||B!==N){A.buffers.depth.getReversed()&&N.reversedDepth!==!0&&(N._reversedDepth=!0,N.updateProjectionMatrix()),Yt.setValue(Y,"projectionMatrix",N.projectionMatrix),Yt.setValue(Y,"viewMatrix",N.matrixWorldInverse);const ki=Yt.map.cameraPosition;ki!==void 0&&ki.setValue(Y,Pe.setFromMatrixPosition(N.matrixWorld)),z.logarithmicDepthBuffer&&Yt.setValue(Y,"logDepthBufFC",2/(Math.log(N.far+1)/Math.LN2)),(de.isMeshPhongMaterial||de.isMeshToonMaterial||de.isMeshLambertMaterial||de.isMeshBasicMaterial||de.isMeshStandardMaterial||de.isShaderMaterial)&&Yt.setValue(Y,"isOrthographic",N.isOrthographicCamera===!0),B!==N&&(B=N,Ri=!0,oi=!0)}if(Ke.needsLights&&(Gn.state.directionalShadowMap.length>0&&Yt.setValue(Y,"directionalShadowMap",Gn.state.directionalShadowMap,ye),Gn.state.spotShadowMap.length>0&&Yt.setValue(Y,"spotShadowMap",Gn.state.spotShadowMap,ye),Gn.state.pointShadowMap.length>0&&Yt.setValue(Y,"pointShadowMap",Gn.state.pointShadowMap,ye)),he.isSkinnedMesh){Yt.setOptional(Y,he,"bindMatrix"),Yt.setOptional(Y,he,"bindMatrixInverse");const jt=he.skeleton;jt&&(jt.boneTexture===null&&jt.computeBoneTexture(),Yt.setValue(Y,"boneTexture",jt.boneTexture,ye))}he.isBatchedMesh&&(Yt.setOptional(Y,he,"batchingTexture"),Yt.setValue(Y,"batchingTexture",he._matricesTexture,ye),Yt.setOptional(Y,he,"batchingIdTexture"),Yt.setValue(Y,"batchingIdTexture",he._indirectTexture,ye),Yt.setOptional(Y,he,"batchingColorTexture"),he._colorsTexture!==null&&Yt.setValue(Y,"batchingColorTexture",he._colorsTexture,ye));const Ni=me.morphAttributes;if((Ni.position!==void 0||Ni.normal!==void 0||Ni.color!==void 0)&&Z.update(he,me,Tn),(Ri||Ke.receiveShadow!==he.receiveShadow)&&(Ke.receiveShadow=he.receiveShadow,Yt.setValue(Y,"receiveShadow",he.receiveShadow)),(de.isMeshStandardMaterial||de.isMeshLambertMaterial||de.isMeshPhongMaterial)&&de.envMap===null&&J.environment!==null&&(ln.envMapIntensity.value=J.environmentIntensity),ln.dfgLUT!==void 0&&(ln.dfgLUT.value=Zw()),Ri){if(Yt.setValue(Y,"toneMappingExposure",V.toneMappingExposure),Ke.needsLights&&_n(ln,oi),Xe&&de.fog===!0&&Ze.refreshFogUniforms(ln,Xe),Ze.refreshMaterialUniforms(ln,de,xe,le,L.state.transmissionRenderTarget[N.id]),Ke.needsLights&&Ke.lightProbeGrid){const jt=Ke.lightProbeGrid;ln.probesSH.value=jt.texture,ln.probesMin.value.copy(jt.boundingBox.min),ln.probesMax.value.copy(jt.boundingBox.max),ln.probesResolution.value.copy(jt.resolution)}$c.upload(Y,aa(Ke),ln,ye)}if(de.isShaderMaterial&&de.uniformsNeedUpdate===!0&&($c.upload(Y,aa(Ke),ln,ye),de.uniformsNeedUpdate=!1),de.isSpriteMaterial&&Yt.setValue(Y,"center",he.center),Yt.setValue(Y,"modelViewMatrix",he.modelViewMatrix),Yt.setValue(Y,"normalMatrix",he.normalMatrix),Yt.setValue(Y,"modelMatrix",he.matrixWorld),de.uniformsGroups!==void 0){const jt=de.uniformsGroups;for(let ki=0,Ia=jt.length;ki<Ia;ki++){const _s=jt[ki];De.update(_s,Tn),De.bind(_s,Tn)}}return Tn}function _n(N,J){N.ambientLightColor.needsUpdate=J,N.lightProbe.needsUpdate=J,N.directionalLights.needsUpdate=J,N.directionalLightShadows.needsUpdate=J,N.pointLights.needsUpdate=J,N.pointLightShadows.needsUpdate=J,N.spotLights.needsUpdate=J,N.spotLightShadows.needsUpdate=J,N.rectAreaLights.needsUpdate=J,N.hemisphereLights.needsUpdate=J}function gl(N){return N.isMeshLambertMaterial||N.isMeshToonMaterial||N.isMeshPhongMaterial||N.isMeshStandardMaterial||N.isShadowMaterial||N.isShaderMaterial&&N.lights===!0}this.getActiveCubeFace=function(){return G},this.getActiveMipmapLevel=function(){return X},this.getRenderTarget=function(){return $},this.setRenderTargetTextures=function(N,J,me){const de=pe.get(N);de.__autoAllocateDepthBuffer=N.resolveDepthBuffer===!1,de.__autoAllocateDepthBuffer===!1&&(de.__useRenderToTexture=!1),pe.get(N.texture).__webglTexture=J,pe.get(N.depthTexture).__webglTexture=de.__autoAllocateDepthBuffer?void 0:me,de.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(N,J){const me=pe.get(N);me.__webglFramebuffer=J,me.__useDefaultFramebuffer=J===void 0},this.setRenderTarget=function(N,J=0,me=0){$=N,G=J,X=me;let de=null,he=!1,Xe=!1;if(N){const ke=pe.get(N);if(ke.__useDefaultFramebuffer!==void 0){A.bindFramebuffer(Y.FRAMEBUFFER,ke.__webglFramebuffer),E.copy(N.viewport),H.copy(N.scissor),ce=N.scissorTest,A.viewport(E),A.scissor(H),A.setScissorTest(ce),se=-1;return}else if(ke.__webglFramebuffer===void 0)ye.setupRenderTarget(N);else if(ke.__hasExternalTextures)ye.rebindTextures(N,pe.get(N.texture).__webglTexture,pe.get(N.depthTexture).__webglTexture);else if(N.depthBuffer){const ht=N.depthTexture;if(ke.__boundDepthTexture!==ht){if(ht!==null&&pe.has(ht)&&(N.width!==ht.image.width||N.height!==ht.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");ye.setupDepthRenderbuffer(N)}}const it=N.texture;(it.isData3DTexture||it.isDataArrayTexture||it.isCompressedArrayTexture)&&(Xe=!0);const tt=pe.get(N).__webglFramebuffer;N.isWebGLCubeRenderTarget?(Array.isArray(tt[J])?de=tt[J][me]:de=tt[J],he=!0):N.samples>0&&ye.useMultisampledRTT(N)===!1?de=pe.get(N).__webglMultisampledFramebuffer:Array.isArray(tt)?de=tt[me]:de=tt,E.copy(N.viewport),H.copy(N.scissor),ce=N.scissorTest}else E.copy(_e).multiplyScalar(xe).floor(),H.copy(Ce).multiplyScalar(xe).floor(),ce=Ue;if(me!==0&&(de=re),A.bindFramebuffer(Y.FRAMEBUFFER,de)&&A.drawBuffers(N,de),A.viewport(E),A.scissor(H),A.setScissorTest(ce),he){const ke=pe.get(N.texture);Y.framebufferTexture2D(Y.FRAMEBUFFER,Y.COLOR_ATTACHMENT0,Y.TEXTURE_CUBE_MAP_POSITIVE_X+J,ke.__webglTexture,me)}else if(Xe){const ke=J;for(let it=0;it<N.textures.length;it++){const tt=pe.get(N.textures[it]);Y.framebufferTextureLayer(Y.FRAMEBUFFER,Y.COLOR_ATTACHMENT0+it,tt.__webglTexture,me,ke)}}else if(N!==null&&me!==0){const ke=pe.get(N.texture);Y.framebufferTexture2D(Y.FRAMEBUFFER,Y.COLOR_ATTACHMENT0,Y.TEXTURE_2D,ke.__webglTexture,me)}se=-1},this.readRenderTargetPixels=function(N,J,me,de,he,Xe,$e,ke=0){if(!(N&&N.isWebGLRenderTarget)){Bt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let it=pe.get(N).__webglFramebuffer;if(N.isWebGLCubeRenderTarget&&$e!==void 0&&(it=it[$e]),it){A.bindFramebuffer(Y.FRAMEBUFFER,it);try{const tt=N.textures[ke],ht=tt.format,yt=tt.type;if(N.textures.length>1&&Y.readBuffer(Y.COLOR_ATTACHMENT0+ke),!z.textureFormatReadable(ht)){Bt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!z.textureTypeReadable(yt)){Bt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}J>=0&&J<=N.width-de&&me>=0&&me<=N.height-he&&Y.readPixels(J,me,de,he,Fe.convert(ht),Fe.convert(yt),Xe)}finally{const tt=$!==null?pe.get($).__webglFramebuffer:null;A.bindFramebuffer(Y.FRAMEBUFFER,tt)}}},this.readRenderTargetPixelsAsync=async function(N,J,me,de,he,Xe,$e,ke=0){if(!(N&&N.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let it=pe.get(N).__webglFramebuffer;if(N.isWebGLCubeRenderTarget&&$e!==void 0&&(it=it[$e]),it)if(J>=0&&J<=N.width-de&&me>=0&&me<=N.height-he){A.bindFramebuffer(Y.FRAMEBUFFER,it);const tt=N.textures[ke],ht=tt.format,yt=tt.type;if(N.textures.length>1&&Y.readBuffer(Y.COLOR_ATTACHMENT0+ke),!z.textureFormatReadable(ht))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!z.textureTypeReadable(yt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const lt=Y.createBuffer();Y.bindBuffer(Y.PIXEL_PACK_BUFFER,lt),Y.bufferData(Y.PIXEL_PACK_BUFFER,Xe.byteLength,Y.STREAM_READ),Y.readPixels(J,me,de,he,Fe.convert(ht),Fe.convert(yt),0);const Gt=$!==null?pe.get($).__webglFramebuffer:null;A.bindFramebuffer(Y.FRAMEBUFFER,Gt);const on=Y.fenceSync(Y.SYNC_GPU_COMMANDS_COMPLETE,0);return Y.flush(),await p1(Y,on,4),Y.bindBuffer(Y.PIXEL_PACK_BUFFER,lt),Y.getBufferSubData(Y.PIXEL_PACK_BUFFER,0,Xe),Y.deleteBuffer(lt),Y.deleteSync(on),Xe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(N,J=null,me=0){const de=Math.pow(2,-me),he=Math.floor(N.image.width*de),Xe=Math.floor(N.image.height*de),$e=J!==null?J.x:0,ke=J!==null?J.y:0;ye.setTexture2D(N,0),Y.copyTexSubImage2D(Y.TEXTURE_2D,me,0,0,$e,ke,he,Xe),A.unbindTexture()},this.copyTextureToTexture=function(N,J,me=null,de=null,he=0,Xe=0){let $e,ke,it,tt,ht,yt,lt,Gt,on;const tn=N.isCompressedTexture?N.mipmaps[Xe]:N.image;if(me!==null)$e=me.max.x-me.min.x,ke=me.max.y-me.min.y,it=me.isBox3?me.max.z-me.min.z:1,tt=me.min.x,ht=me.min.y,yt=me.isBox3?me.min.z:0;else{const ln=Math.pow(2,-he);$e=Math.floor(tn.width*ln),ke=Math.floor(tn.height*ln),N.isDataArrayTexture?it=tn.depth:N.isData3DTexture?it=Math.floor(tn.depth*ln):it=1,tt=0,ht=0,yt=0}de!==null?(lt=de.x,Gt=de.y,on=de.z):(lt=0,Gt=0,on=0);const Wt=Fe.convert(J.format),qt=Fe.convert(J.type);let Ke;J.isData3DTexture?(ye.setTexture3D(J,0),Ke=Y.TEXTURE_3D):J.isDataArrayTexture||J.isCompressedArrayTexture?(ye.setTexture2DArray(J,0),Ke=Y.TEXTURE_2D_ARRAY):(ye.setTexture2D(J,0),Ke=Y.TEXTURE_2D),A.activeTexture(Y.TEXTURE0),A.pixelStorei(Y.UNPACK_FLIP_Y_WEBGL,J.flipY),A.pixelStorei(Y.UNPACK_PREMULTIPLY_ALPHA_WEBGL,J.premultiplyAlpha),A.pixelStorei(Y.UNPACK_ALIGNMENT,J.unpackAlignment);const Gn=A.getParameter(Y.UNPACK_ROW_LENGTH),Rt=A.getParameter(Y.UNPACK_IMAGE_HEIGHT),Tn=A.getParameter(Y.UNPACK_SKIP_PIXELS),ri=A.getParameter(Y.UNPACK_SKIP_ROWS),Ri=A.getParameter(Y.UNPACK_SKIP_IMAGES);A.pixelStorei(Y.UNPACK_ROW_LENGTH,tn.width),A.pixelStorei(Y.UNPACK_IMAGE_HEIGHT,tn.height),A.pixelStorei(Y.UNPACK_SKIP_PIXELS,tt),A.pixelStorei(Y.UNPACK_SKIP_ROWS,ht),A.pixelStorei(Y.UNPACK_SKIP_IMAGES,yt);const oi=N.isDataArrayTexture||N.isData3DTexture,Yt=J.isDataArrayTexture||J.isData3DTexture;if(N.isDepthTexture){const ln=pe.get(N),Ni=pe.get(J),jt=pe.get(ln.__renderTarget),ki=pe.get(Ni.__renderTarget);A.bindFramebuffer(Y.READ_FRAMEBUFFER,jt.__webglFramebuffer),A.bindFramebuffer(Y.DRAW_FRAMEBUFFER,ki.__webglFramebuffer);for(let Ia=0;Ia<it;Ia++)oi&&(Y.framebufferTextureLayer(Y.READ_FRAMEBUFFER,Y.COLOR_ATTACHMENT0,pe.get(N).__webglTexture,he,yt+Ia),Y.framebufferTextureLayer(Y.DRAW_FRAMEBUFFER,Y.COLOR_ATTACHMENT0,pe.get(J).__webglTexture,Xe,on+Ia)),Y.blitFramebuffer(tt,ht,$e,ke,lt,Gt,$e,ke,Y.DEPTH_BUFFER_BIT,Y.NEAREST);A.bindFramebuffer(Y.READ_FRAMEBUFFER,null),A.bindFramebuffer(Y.DRAW_FRAMEBUFFER,null)}else if(he!==0||N.isRenderTargetTexture||pe.has(N)){const ln=pe.get(N),Ni=pe.get(J);A.bindFramebuffer(Y.READ_FRAMEBUFFER,oe),A.bindFramebuffer(Y.DRAW_FRAMEBUFFER,te);for(let jt=0;jt<it;jt++)oi?Y.framebufferTextureLayer(Y.READ_FRAMEBUFFER,Y.COLOR_ATTACHMENT0,ln.__webglTexture,he,yt+jt):Y.framebufferTexture2D(Y.READ_FRAMEBUFFER,Y.COLOR_ATTACHMENT0,Y.TEXTURE_2D,ln.__webglTexture,he),Yt?Y.framebufferTextureLayer(Y.DRAW_FRAMEBUFFER,Y.COLOR_ATTACHMENT0,Ni.__webglTexture,Xe,on+jt):Y.framebufferTexture2D(Y.DRAW_FRAMEBUFFER,Y.COLOR_ATTACHMENT0,Y.TEXTURE_2D,Ni.__webglTexture,Xe),he!==0?Y.blitFramebuffer(tt,ht,$e,ke,lt,Gt,$e,ke,Y.COLOR_BUFFER_BIT,Y.NEAREST):Yt?Y.copyTexSubImage3D(Ke,Xe,lt,Gt,on+jt,tt,ht,$e,ke):Y.copyTexSubImage2D(Ke,Xe,lt,Gt,tt,ht,$e,ke);A.bindFramebuffer(Y.READ_FRAMEBUFFER,null),A.bindFramebuffer(Y.DRAW_FRAMEBUFFER,null)}else Yt?N.isDataTexture||N.isData3DTexture?Y.texSubImage3D(Ke,Xe,lt,Gt,on,$e,ke,it,Wt,qt,tn.data):J.isCompressedArrayTexture?Y.compressedTexSubImage3D(Ke,Xe,lt,Gt,on,$e,ke,it,Wt,tn.data):Y.texSubImage3D(Ke,Xe,lt,Gt,on,$e,ke,it,Wt,qt,tn):N.isDataTexture?Y.texSubImage2D(Y.TEXTURE_2D,Xe,lt,Gt,$e,ke,Wt,qt,tn.data):N.isCompressedTexture?Y.compressedTexSubImage2D(Y.TEXTURE_2D,Xe,lt,Gt,tn.width,tn.height,Wt,tn.data):Y.texSubImage2D(Y.TEXTURE_2D,Xe,lt,Gt,$e,ke,Wt,qt,tn);A.pixelStorei(Y.UNPACK_ROW_LENGTH,Gn),A.pixelStorei(Y.UNPACK_IMAGE_HEIGHT,Rt),A.pixelStorei(Y.UNPACK_SKIP_PIXELS,Tn),A.pixelStorei(Y.UNPACK_SKIP_ROWS,ri),A.pixelStorei(Y.UNPACK_SKIP_IMAGES,Ri),Xe===0&&J.generateMipmaps&&Y.generateMipmap(Ke),A.unbindTexture()},this.initRenderTarget=function(N){pe.get(N).__webglFramebuffer===void 0&&ye.setupRenderTarget(N)},this.initTexture=function(N){N.isCubeTexture?ye.setTextureCube(N,0):N.isData3DTexture?ye.setTexture3D(N,0):N.isDataArrayTexture||N.isCompressedArrayTexture?ye.setTexture2DArray(N,0):ye.setTexture2D(N,0),A.unbindTexture()},this.resetState=function(){G=0,X=0,$=null,A.reset(),qe.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ji}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const i=this.getContext();i.drawingBufferColorSpace=It._getDrawingBufferColorSpace(e),i.unpackColorSpace=It._getUnpackColorSpace()}}function Qw(r="#3b82f6",e="char-explorer"){const i=new gn,s=new St({color:r,roughness:.3,metalness:.2}),l=new St({color:"#ffdbac",roughness:.5}),c=new Fn({color:"#0f172a"});new Fn({color:"#ffffff"});const f=new Ft(.7,.9,.4),p=new Ge(f,s);p.position.y=.85,p.castShadow=!0,i.add(p);const m=new Gi(.35,16,16),h=new Ge(m,l);h.position.y=1.55,h.castShadow=!0,i.add(h);const v=new Ge(new Gi(.06,8,8),c);v.position.set(-.12,1.6,.3);const x=new Ge(new Gi(.06,8,8),c);if(x.position.set(.12,1.6,.3),i.add(v,x),e==="char-cyber"){const O=new Ft(.5,.12,.3),C=new St({color:"#a855f7",emissive:"#c084fc",emissiveIntensity:.8}),I=new Ge(O,C);I.position.set(0,1.62,.22),i.add(I)}else if(e==="char-ninja"){const O=new Ft(.72,.12,.72),C=new Fn({color:"#dc2626"}),I=new Ge(O,C);I.position.set(0,1.68,0),i.add(I)}else if(e==="char-astronaut"){const O=new Gi(.42,16,16),C=new St({color:"#38bdf8",transparent:!0,opacity:.6}),I=new Ge(O,C);I.position.y=1.55,i.add(I)}else if(e==="char-robot"){const O=new Dn(.02,.02,.3),C=new Fn({color:"#06b6d4"}),I=new Ge(O,C);I.position.set(0,2,0),i.add(I)}const g=new Dn(.1,.1,.7),M=new Ge(g,s);M.position.set(-.48,.85,0),M.name="leftArm";const w=new Ge(g,s);w.position.set(.48,.85,0),w.name="rightArm",i.add(M,w);const R=new St({color:"#1e293b",roughness:.4}),b=new Dn(.12,.1,.8),y=new Ge(b,R);y.position.set(-.2,.4,0),y.name="leftLeg";const P=new Ge(b,R);return P.position.set(.2,.4,0),P.name="rightLeg",i.add(y,P),i}function Jw(r="#ef4444",e="car-sports",i){const s=new gn,l=new St({color:r,metalness:.7,roughness:.2}),c=new St({color:"#0284c7",metalness:.9,roughness:.1,transparent:!0,opacity:.8}),f=new St({color:"#0f172a",roughness:.8}),p=new St({color:"#e2e8f0",metalness:.9});if(e==="car-formula"){const g=new Ft(1.2,.35,2.8),M=new Ge(g,l);M.position.y=.35,s.add(M);const w=new Ft(1.6,.08,.4),R=new Ge(w,l);R.position.set(0,.2,1.4),s.add(R);const b=new Ge(new Ft(1.5,.1,.5),l);b.position.set(0,.8,-1.3),s.add(b)}else if(e==="car-hover"){const g=new Gi(1,16,16);g.scale(1.2,.5,1.8);const M=new Ge(g,l);M.position.y=.6,s.add(M);const w=new qs(.8,.12,12,24),R=new St({color:"#06b6d4",emissive:"#06b6d4",emissiveIntensity:.8}),b=new Ge(w,R);b.rotation.x=Math.PI/2,b.position.set(0,.2,0),s.add(b)}else{const g=new Ft(1.5,.5,2.6),M=new Ge(g,l);M.position.y=.45,M.castShadow=!0,s.add(M);const w=new Ft(1.2,.45,1.3),R=new Ge(w,c);R.position.set(0,.85,-.1),s.add(R)}e!=="car-hover"&&[[-.8,.35,.9],[.8,.35,.9],[-.8,.35,-.9],[.8,.35,-.9]].forEach(([M,w,R])=>{const b=new gn,y=new Dn(.35,.35,.25,16),P=new Ge(y,f);P.rotation.z=Math.PI/2;const O=new Dn(.2,.2,.26,12),C=new Ge(O,p);C.rotation.z=Math.PI/2,b.add(P,C),b.position.set(M,w,R),b.name="wheel",s.add(b)});const m=new Ft(.3,.15,.1),h=new Fn({color:"#ffffff"}),v=new Ge(m,h);v.position.set(-.5,.45,1.32);const x=new Ge(m,h);x.position.set(.5,.45,1.32),s.add(v,x);{const g=new $i(1.6,2.8),M=new Fn({color:i,transparent:!0,opacity:.6,side:zi}),w=new Ge(g,M);w.rotation.x=Math.PI/2,w.position.y=.05,s.add(w)}return s}function $w(){const r=new gn,e=new Ft(2.2,2.5,8),i=new St({color:"#dc2626",roughness:.4}),s=new Ge(e,i);s.position.y=1.25,s.castShadow=!0;const l=new Ft(1.8,.8,.1),c=new St({color:"#fef08a",emissive:"#fef08a",emissiveIntensity:.6}),f=new Ge(l,c);return f.position.set(0,2,4.01),r.add(s,f),r}function e3(){const r=new gn,e=new Ft(2.2,.9,.3),i=new St({color:"#f59e0b",roughness:.5}),s=new Ge(e,i);s.position.y=.45,s.castShadow=!0;const l=new Ft(.3,.85,.32),c=new Fn({color:"#1e293b"});return[-.6,0,.6].forEach(f=>{const p=new Ge(l,c);p.position.set(f,.45,0),r.add(p)}),r.add(s),r}function t3(){const r=new Dn(.35,.35,.08,16),e=new St({color:"#fbbf24",metalness:.9,roughness:.1,emissive:"#f59e0b",emissiveIntensity:.2}),i=new Ge(r,e);return i.rotation.x=Math.PI/2,i.position.y=1.2,i}function n3(){const r=new du(.3,0),e=new St({color:"#06b6d4",metalness:.8,roughness:.1,emissive:"#22d3ee",emissiveIntensity:.5}),i=new Ge(r,e);return i.position.y=1.3,i}function i3(r){const e=new gn;if(r==="shield"){const i=new Gi(.42,16,16),s=new St({color:"#38bdf8",emissive:"#0284c7",emissiveIntensity:.6,transparent:!0,opacity:.8}),l=new Ge(i,s);l.position.y=1.25,e.add(l)}else if(r==="magnet"){const i=new qs(.35,.1,12,16,Math.PI),s=new St({color:"#ef4444",emissive:"#b91c1c",emissiveIntensity:.5}),l=new Ge(i,s);l.rotation.x=Math.PI/2,l.position.y=1.25,e.add(l)}else if(r==="jetpack"){const i=new Dn(.12,.15,.5,12),s=new St({color:"#0284c7",metalness:.8,roughness:.2}),l=new Np(.12,.3,8),c=new Fn({color:"#f97316"});[-.18,.18].forEach(f=>{const p=new Ge(i,s);p.position.set(f,1.25,0);const m=new Ge(l,c);m.rotation.x=Math.PI,m.position.set(f,.9,0),e.add(p,m)})}else if(r==="hoverboard"){const i=new Ft(.6,.08,1.2),s=new St({color:"#a855f7",emissive:"#9333ea",emissiveIntensity:.8}),l=new Ge(i,s);l.position.y=1.15;const c=new qs(.2,.05,8,16),f=new Fn({color:"#06b6d4"}),p=new Ge(c,f);p.rotation.x=Math.PI/2,p.position.set(0,1.07,0),e.add(l,p)}else if(r==="nitro"){const i=new Dn(.2,.2,.6,12),s=new St({color:"#2563eb",emissive:"#1d4ed8",metalness:.9,roughness:.1}),l=new Ge(i,s);l.position.y=1.25;const c=new Dn(.1,.1,.15,12),f=new Fn({color:"#f59e0b"}),p=new Ge(c,f);p.position.y=1.6,e.add(l,p)}else{const i=new du(.35,0),s=new St({color:"#f59e0b",emissive:"#d97706",emissiveIntensity:.8}),l=new Ge(i,s);l.position.y=1.25,e.add(l)}return e}function a3(){const r=new gn,e=new St({color:"#0f172a",metalness:.8,roughness:.2}),i=new St({color:"#fbbf24",emissive:"#f59e0b",emissiveIntensity:.9}),s=new St({color:"#06b6d4",emissive:"#0284c7",emissiveIntensity:.9});[-4.5,4.5].forEach(x=>{const g=new Ge(new Ft(.8,6,.8),e);g.position.set(x,3,0);const M=new Ge(new Ft(.84,5.8,.15),i);M.position.set(x,3,0),r.add(g,M)});const l=new Ge(new Ft(9.8,1.2,.6),e);l.position.set(0,5.4,0);const c=new Ge(new Ft(9.4,.9,.64),s);c.position.set(0,5.4,0);const f=new St({color:"#fbbf24",emissive:"#d97706",emissiveIntensity:.8}),p=new Ge(new Ft(5,.6,.7),f);p.position.set(0,5.4,0),r.add(l,c,p);const m=new $i(8.5,3),h=new St({color:"#ffffff",emissive:"#f59e0b",emissiveIntensity:.4,side:zi}),v=new Ge(m,h);return v.rotation.x=-Math.PI/2,v.position.set(0,.03,0),r.add(v),r}function s3(r="#38bdf8"){const e=new gn,i=new gn;i.name="ballSphere";const s=new Gi(.7,32,32),l=new St({color:r,metalness:.85,roughness:.15}),c=new Ge(s,l);i.add(c);const f=new qs(.705,.05,12,32),p=new St({color:"#ffffff",metalness:.95,roughness:.05,emissive:"#e2e8f0",emissiveIntensity:.3}),m=new Ge(f,p);i.add(m);const h=new qs(.705,.04,12,32),v=new St({color:"#06b6d4",emissive:"#0891b2",emissiveIntensity:.8}),x=new Ge(h,v);x.rotation.x=Math.PI/2,i.add(x);const g=new Dn(.2,.2,.05,16),M=new St({color:"#0f172a",metalness:.9}),w=new Ge(g,M);w.position.y=.69;const R=new Ge(g,M);return R.position.y=-.69,i.add(w,R),i.position.y=.7,e.add(i),e}function r3(r="#e11d48"){const e=new gn,i=new St({color:r,metalness:.8,roughness:.2}),s=new St({color:"#1e293b",metalness:.9,roughness:.3}),l=new St({color:"#0f172a",roughness:.9}),c=new St({color:"#38bdf8",emissive:"#0284c7",emissiveIntensity:.4}),f=new St({color:"#a855f7",transparent:!0,opacity:.8}),p=new Ft(.6,.5,1.8),m=new Ge(p,i);m.position.set(0,.6,0),m.castShadow=!0,e.add(m);const h=new Ft(.5,.4,.4),v=new Ge(h,f);v.position.set(0,.9,.7),v.rotation.x=-Math.PI/6,e.add(v);const x=new Dn(.04,.04,.9),g=new Ge(x,s);g.rotation.z=Math.PI/2,g.position.set(0,.8,.6),e.add(g),[[0,.35,1],[0,.35,-1]].forEach(([F,T,U])=>{const V=new gn,k=new Dn(.35,.35,.2,20),W=new Ge(k,l);W.rotation.z=Math.PI/2;const re=new Dn(.22,.22,.21,12),oe=new Ge(re,c);oe.rotation.z=Math.PI/2,V.add(W,oe),V.position.set(F,T,U),V.name="wheel",e.add(V)});const w=new Dn(.08,.08,1.2),R=new Ge(w,s);R.rotation.x=Math.PI/2,R.position.set(.35,.35,-.6),e.add(R);const b=new gn;b.name="rider";const y=new St({color:"#0f172a",roughness:.5}),P=new Ge(new Ft(.5,.6,.6),y);P.position.set(0,.85,-.1),P.rotation.x=Math.PI/6;const O=new St({color:r,metalness:.7,roughness:.2}),C=new Ge(new Gi(.28,16,16),O);C.position.set(0,1.15,.2);const I=new Ge(new Ft(.32,.12,.2),f);I.position.set(0,1.15,.35),b.add(P,C,I),e.add(b);const L=new Ge(new Ft(.3,.15,.1),new Fn({color:"#ffffff"}));return L.position.set(0,.65,.95),e.add(L),e}const o3=({mode:r,world:e,profile:i,levelData:s,isPlaying:l,isPaused:c,onCoinCollect:f,onGemCollect:p,onDistanceUpdate:m,onGameOver:h,onPowerupActive:v,inputAction:x})=>{const g=st.useRef(null),M=st.useRef(l),w=st.useRef(c);st.useEffect(()=>{M.current=l,w.current=c},[l,c]),st.useEffect(()=>{try{window.focus()}catch{}},[]);const R=st.useRef(0),b=st.useRef({lane:0,targetX:0,currentX:0,posY:0,velocityY:0,isJumping:!1,isSliding:!1,isDashing:!1,nitroActive:!1,distanceMeters:0,coinsCollected:0,gemsCollected:0,speed:r==="runner"?.35:r==="ball"?.55:r==="motorbike"?.72:.65,magnetTimer:0,shieldActive:!1,hoverboardActive:!1,jetpackTimer:0,multiplierTimer:0,gameOverHandled:!1});return st.useEffect(()=>{l&&(b.current={lane:0,targetX:0,currentX:0,posY:0,velocityY:0,isJumping:!1,isSliding:!1,isDashing:!1,nitroActive:!1,distanceMeters:0,coinsCollected:0,gemsCollected:0,speed:r==="runner"?.35:r==="ball"?.55:r==="motorbike"?.72:.65,magnetTimer:0,shieldActive:!1,hoverboardActive:!1,jetpackTimer:0,multiplierTimer:0,gameOverHandled:!1})},[l,r]),st.useEffect(()=>{if(!g.current)return;const y=g.current.clientWidth||window.innerWidth,P=g.current.clientHeight||window.innerHeight,O=new N1;O.background=new Ot(e.skyColor),O.fog=new Cp(e.fogColor,.015);const C=new Ci(60,y/P,.1,1e3);C.position.set(0,r==="runner"?3.5:r==="ball"?3.8:2.8,r==="runner"?-6:-5),C.lookAt(0,1.2,10);const I=new Kw({antialias:!0,powerPreference:"high-performance"});I.setSize(y,P),I.setPixelRatio(Math.min(window.devicePixelRatio,2)),I.shadowMap.enabled=!0,I.shadowMap.type=ol,g.current.appendChild(I.domElement);const L=new J1(16777215,.8);O.add(L);const F=new Q1(16777215,1.2);F.position.set(10,20,10),F.castShadow=!0,F.shadow.mapSize.width=1024,F.shadow.mapSize.height=1024,O.add(F);const T=7.5,U=200,V=new $i(T,U),k=new St({color:e.groundColor,roughness:.6}),W=new Ge(V,k);W.rotation.x=-Math.PI/2,W.position.z=U/2-10,W.receiveShadow=!0,O.add(W);const re=new gn;for(let ee=0;ee<U;ee+=4){const Pe=new $i(T,.2),Qe=new Fn({color:"#1e293b",transparent:!0,opacity:.4}),Je=new Ge(Pe,Qe);Je.rotation.x=-Math.PI/2,Je.position.set(0,.01,ee),re.add(Je)}O.add(re);const oe=new gn;for(let ee=0;ee<U;ee+=6)[-1.25,1.25].forEach(Pe=>{const Qe=new $i(.12,3),Je=new Fn({color:e.accentColor}),ct=new Ge(Qe,Je);ct.rotation.x=-Math.PI/2,ct.position.set(Pe,.02,ee),oe.add(ct)});O.add(oe);const te=new gn;for(let ee=0;ee<U;ee+=4)[-3.7,3.7].forEach(Pe=>{const Qe=new Ft(.3,.25,2),Je=Math.floor(ee/4)%2===0,ct=new St({color:Je?"#ef4444":"#ffffff"}),Mt=new Ge(Qe,ct);Mt.position.set(Pe,.12,ee),te.add(Mt)});O.add(te);const G=new gn;for(let ee=0;ee<U;ee+=10)[-4.8,4.8].forEach(Pe=>{const Qe=new Ge(new Dn(.08,.08,3.5),new St({color:"#334155"}));Qe.position.set(Pe,1.75,ee);const Je=new Ge(new Gi(.28,8,8),new Fn({color:e.accentColor}));Je.position.set(Pe>0?Pe-.4:Pe+.4,3.4,ee),G.add(Qe,Je)}),[-8.5,8.5].forEach((Pe,Qe)=>{const Je=7+Math.abs(ee*3+Qe*7)%10,ct=new St({color:(ee+Qe)%2===0?"#1e293b":"#0f172a",roughness:.2,metalness:.5}),Mt=new Ge(new Ft(3.5,Je,4),ct);Mt.position.set(Pe,Je/2,ee);const Y=new $i(.4,.8),Tt=new Fn({color:e.accentColor}),Ne=new Ge(Y,Tt);Ne.position.set(Pe>0?Pe-1.76:Pe+1.76,Je*.6,ee),Pe>0?Ne.rotation.y=-Math.PI/2:Ne.rotation.y=Math.PI/2,G.add(Mt,Ne)});O.add(G);const X=new gn;for(let ee=20;ee<U;ee+=35){const Pe=new St({color:e.accentColor,emissive:e.accentColor,emissiveIntensity:.8}),Qe=new Ge(new Ft(9.5,.4,.6),Pe);Qe.position.set(0,4.6,ee);const Je=new Ge(new Ft(.4,4.6,.6),Pe);Je.position.set(-4.6,2.3,ee);const ct=new Ge(new Ft(.4,4.6,.6),Pe);ct.position.set(4.6,2.3,ee),X.add(Qe,Je,ct)}O.add(X);let $;if(r==="runner"){const ee=i.carPaints[i.selectedCharacterId]||"#3b82f6";$=Qw(ee,i.selectedCharacterId)}else if(r==="ball"){const ee=i.carPaints[i.selectedCarId]||"#38bdf8";$=s3(ee)}else if(r==="motorbike"){const ee=i.carPaints[i.selectedCarId]||"#e11d48";$=r3(ee)}else{const ee=i.carPaints[i.selectedCarId]||"#ef4444",Pe=i.carNeon[i.selectedCarId]||"#00f0ff";$=Jw(ee,i.selectedCarId,Pe)}$.position.set(0,0,0),O.add($);const se=a3();se.position.set(0,0,s.targetDistance),O.add(se);const B=[],E=[],H=()=>{if(r==="runner"){const ee=["jetpack","hoverboard","magnet","shield"];return ee[Math.floor(Math.random()*ee.length)]}else{const ee=["nitro","shield","magnet","multiplier"];return ee[Math.floor(Math.random()*ee.length)]}};for(let ee=18;ee<U;ee+=12+Math.random()*8){const Pe=Math.floor(Math.random()*3)-1,Qe=-Pe*2.2;if(ee>50&&Math.random()>.4){const Je=r==="runner"&&Math.random()>.6,ct=Je?$w():e3();ct.position.set(Qe,.2,ee),O.add(ct),B.push({mesh:ct,lane:Pe,type:Je?"train":"barrier"})}else{const Je=Math.random()<.15,ct=Math.random()<.12;let Mt,Y="coin",Tt;ct?(Y="powerup",Tt=H(),Mt=i3(Tt)):Je?(Y="gem",Mt=n3()):Mt=t3(),Mt.position.set(Qe,1.2,ee),O.add(Mt),E.push({mesh:Mt,lane:Pe,type:Y,powerupType:Tt})}}let ce=null;if(e.weather==="rain"||e.weather==="snow"||e.weather==="sandstorm"){const Pe=new Yn,Qe=new Float32Array(300*3);for(let ct=0;ct<300*3;ct+=3)Qe[ct]=(Math.random()-.5)*20,Qe[ct+1]=Math.random()*15,Qe[ct+2]=Math.random()*50;Pe.setAttribute("position",new Hi(Qe,3));const Je=new y_({color:e.weather==="snow"?16777215:3718648,size:e.weather==="snow"?.25:.15,transparent:!0,opacity:.7});ce=new G1(Pe,Je),O.add(ce)}let Se=0,Ae=0;const K=()=>{b.current.lane>-1&&(b.current.lane-=1,nt.playDash())},le=()=>{b.current.lane<1&&(b.current.lane+=1,nt.playDash())},xe=()=>{const ee=b.current;r==="racer"||r==="motorbike"||r==="ball"?(ee.nitroActive=!0,nt.playNitro(),setTimeout(()=>{ee.nitroActive=!1},1200)):ee.isJumping||(ee.isJumping=!0,ee.velocityY=.4,nt.playJump())},Le=()=>{b.current.isSliding=!0,setTimeout(()=>{b.current.isSliding=!1},600)},Q=ee=>{Se=ee.touches[0].clientX,Ae=ee.touches[0].clientY},_e=ee=>{if(!M.current||w.current)return;const Pe=ee.changedTouches[0].clientX-Se,Qe=ee.changedTouches[0].clientY-Ae;Math.abs(Pe)>Math.abs(Qe)&&Math.abs(Pe)>25?Pe<0?K():Pe>0&&le():Math.abs(Qe)>25&&(Qe<0?xe():Qe>0&&Le())},Ce=ee=>{if(!M.current||w.current)return;const Pe=Ue.getBoundingClientRect(),Qe=(ee.clientX-Pe.left)/Pe.width,Je=(ee.clientY-Pe.top)/Pe.height;Qe<.35?K():Qe>.65?le():Je<.35?xe():Je>.7&&Le()},Ue=I.domElement;Ue.addEventListener("touchstart",Q),Ue.addEventListener("touchend",_e),Ue.addEventListener("mousedown",Ce);let He;const Ye=()=>{if(He=requestAnimationFrame(Ye),!M.current||w.current){I.render(O,C);return}const ee=b.current;ee.jetpackTimer>0&&(ee.jetpackTimer-=.016,ee.posY=3.2,ee.jetpackTimer<=0&&(ee.jetpackTimer=0,ee.posY=0)),ee.magnetTimer>0&&(ee.magnetTimer-=.016,ee.magnetTimer<=0&&(ee.magnetTimer=0)),ee.multiplierTimer>0&&(ee.multiplierTimer-=.016,ee.multiplierTimer<=0&&(ee.multiplierTimer=0));const Pe=ee.nitroActive?ee.speed*1.8:ee.speed;ee.distanceMeters+=Pe*.5;const Qe=Math.floor(ee.distanceMeters);Qe!==R.current&&(R.current=Qe,m(Qe)),ee.targetX=-ee.lane*2.6;const Je=ee.targetX-ee.currentX;if(ee.currentX+=Je*.3,$.position.x=ee.currentX,r==="ball"){const Ne=$.getObjectByName("ballSphere");Ne&&(Ne.rotation.x+=Pe*1.8,Ne.rotation.z=Je*.15),$.rotation.z=0,$.rotation.y=0,$.scale.set(1,1,1)}else r==="motorbike"?($.rotation.z=Je*.35,$.rotation.y=-Je*.18):($.rotation.z=Je*.25,$.rotation.y=-Je*.15);ee.jetpackTimer<=0&&(ee.isJumping?(ee.posY+=ee.velocityY,ee.velocityY-=.025,ee.posY<=0&&(ee.posY=0,ee.isJumping=!1,ee.velocityY=0)):ee.hoverboardActive&&(ee.posY=.4),$.position.y=ee.posY),r!=="ball"&&(ee.isSliding?$.scale.set(1.2,.4,1.2):$.scale.set(1,1,1)),re.children.forEach(Ne=>{Ne.position.z-=Pe,Ne.position.z<-5&&(Ne.position.z+=U)}),oe.children.forEach(Ne=>{Ne.position.z-=Pe,Ne.position.z<-5&&(Ne.position.z+=U)}),te.children.forEach(Ne=>{Ne.position.z-=Pe,Ne.position.z<-5&&(Ne.position.z+=U)}),G.children.forEach(Ne=>{Ne.position.z-=Pe,Ne.position.z<-5&&(Ne.position.z+=U)}),X.children.forEach(Ne=>{Ne.position.z-=Pe,Ne.position.z<-5&&(Ne.position.z+=U)});const ct=s.targetDistance-ee.distanceMeters;se.position.z=Math.max(-15,ct),ct<=0&&!ee.gameOverHandled&&(ee.gameOverHandled=!0,nt.playVictory(),h(Math.floor(ee.distanceMeters*10+ee.coinsCollected*25),ee.coinsCollected,Math.floor(ee.distanceMeters)));let Mt=0;ee.nitroActive?Mt=1.2:ee.isSliding&&(Mt=-.5),$.position.z+=(Mt-$.position.z)*.1;const Y=ee.distanceMeters*.25;$.children.forEach(Ne=>{Ne.name==="leftLeg"?Ne.rotation.x=Math.sin(Y)*.7:Ne.name==="rightLeg"||Ne.name==="leftArm"?Ne.rotation.x=-Math.sin(Y)*.7:Ne.name==="rightArm"?Ne.rotation.x=Math.sin(Y)*.7:Ne.name==="wheel"&&(Ne.rotation.x+=Pe*1.2)}),(r==="racer"||r==="motorbike")&&($.position.y=ee.posY+Math.sin(Y*2)*.02);const Tt=60+(Pe-.35)*22;if(Math.abs(C.fov-Tt)>.1&&(C.fov+=(Tt-C.fov)*.1,C.updateProjectionMatrix()),E.forEach(Ne=>{if(Ne.mesh.position.z-=Pe,Ne.mesh.rotation.y+=.05,ee.magnetTimer>0&&Math.abs(Ne.mesh.position.z)<14&&(Ne.mesh.position.x+=(ee.currentX-Ne.mesh.position.x)*.25,Ne.mesh.position.y+=(ee.posY+.5-Ne.mesh.position.y)*.25),Math.abs(Ne.mesh.position.z)<1.4&&Math.abs(Ne.mesh.position.x-ee.currentX)<1.2&&Math.abs(Ne.mesh.position.y-ee.posY)<2){const z=ee.multiplierTimer>0?2:1;if(Ne.type==="coin")ee.coinsCollected+=z,f(ee.coinsCollected),nt.playCoin();else if(Ne.type==="gem")ee.gemsCollected+=z,p(ee.gemsCollected),nt.playGem();else if(Ne.type==="powerup"){const A=Ne.powerupType||"magnet";A==="jetpack"?(ee.jetpackTimer=10,v&&v("Rocket Jetpack 🚀",10)):A==="hoverboard"?(ee.hoverboardActive=!0,v&&v("Neon Hoverboard 🛹",15)):A==="nitro"?(ee.nitroActive=!0,setTimeout(()=>{ee.nitroActive=!1},2500),v&&v("Hyper Nitro ⚡",3)):A==="shield"?(ee.shieldActive=!0,v&&v("Force Shield 🛡️",12)):A==="multiplier"?(ee.multiplierTimer=10,v&&v("2X Score Boost 🔥",10)):(ee.magnetTimer=10,v&&v("Coin Magnet 🧲",10)),nt.playChestOpen()}Ne.mesh.position.z=120+Math.random()*40,Ne.mesh.position.x=-(Math.floor(Math.random()*3)-1)*2.2,Ne.mesh.position.y=1.2}Ne.mesh.position.z<-10&&(Ne.mesh.position.z=120+Math.random()*40,Ne.mesh.position.x=-(Math.floor(Math.random()*3)-1)*2.2,Ne.mesh.position.y=1.2)}),B.forEach(Ne=>{Ne.mesh.position.z-=Pe,Math.abs(Ne.mesh.position.z)<1&&Math.abs(Ne.mesh.position.x-ee.currentX)<.8&&ee.posY<1.2&&(ee.jetpackTimer>0||(ee.shieldActive?(ee.shieldActive=!1,nt.playVictory(),v&&v("Shield Absorbed Hit! 🛡️",1),Ne.mesh.position.z=-15):ee.hoverboardActive?(ee.hoverboardActive=!1,nt.playCrash(),v&&v("Hoverboard Absorbed Hit! 🛹",1),Ne.mesh.position.z=-15):ee.gameOverHandled||(ee.gameOverHandled=!0,nt.playCrash(),h(Math.floor(ee.distanceMeters*10+ee.coinsCollected*25),ee.coinsCollected,Math.floor(ee.distanceMeters))))),Ne.mesh.position.z<-10&&(Ne.mesh.position.z=120+Math.random()*50,Ne.mesh.position.x=-(Math.floor(Math.random()*3)-1)*2.2)}),ce){const Ne=ce.geometry.attributes.position.array;for(let z=1;z<Ne.length;z+=3)Ne[z]-=.3,Ne[z]<0&&(Ne[z]=15);ce.geometry.attributes.position.needsUpdate=!0}C.position.x=ee.currentX*.4,C.lookAt(ee.currentX*.7,1.2,10),I.render(O,C)};Ye();const ft=()=>{if(!g.current)return;const ee=g.current.clientWidth,Pe=g.current.clientHeight;C.aspect=ee/Pe,C.updateProjectionMatrix(),I.setSize(ee,Pe)};return window.addEventListener("resize",ft),()=>{cancelAnimationFrame(He),Ue.removeEventListener("touchstart",Q),Ue.removeEventListener("touchend",_e),Ue.removeEventListener("mousedown",Ce),window.removeEventListener("resize",ft),g.current&&I.domElement&&g.current.removeChild(I.domElement),I.dispose()}},[r,e,i]),st.useEffect(()=>{if(!x||!M.current||w.current)return;const y=b.current;x.type==="left"?y.lane>-1&&(y.lane-=1,nt.playDash()):x.type==="right"?y.lane<1&&(y.lane+=1,nt.playDash()):x.type==="up"?r==="racer"||r==="motorbike"||r==="ball"?(y.nitroActive=!0,nt.playNitro(),setTimeout(()=>{y.nitroActive=!1},1200)):y.isJumping||(y.isJumping=!0,y.velocityY=.4,nt.playJump()):x.type==="down"&&(y.isSliding=!0,setTimeout(()=>{y.isSliding=!1},600))},[x,r]),_.jsx("div",{ref:g,className:"absolute inset-0 w-full h-full overflow-hidden select-none bg-slate-900 cursor-grab active:cursor-grabbing"})};var Lp={};(function r(e,i,s,l){var c=!!(e.Worker&&e.Blob&&e.Promise&&e.OffscreenCanvas&&e.OffscreenCanvasRenderingContext2D&&e.HTMLCanvasElement&&e.HTMLCanvasElement.prototype.transferControlToOffscreen&&e.URL&&e.URL.createObjectURL),f=typeof Path2D=="function"&&typeof DOMMatrix=="function",p=(function(){if(!e.OffscreenCanvas)return!1;try{var B=new OffscreenCanvas(1,1),E=B.getContext("2d");E.fillRect(0,0,1,1);var H=B.transferToImageBitmap();E.createPattern(H,"no-repeat")}catch{return!1}return!0})();function m(){}function h(B){var E=i.exports.Promise,H=E!==void 0?E:e.Promise;return typeof H=="function"?new H(B):(B(m,m),null)}var v=(function(B,E){return{transform:function(H){if(B)return H;if(E.has(H))return E.get(H);var ce=new OffscreenCanvas(H.width,H.height),Se=ce.getContext("2d");return Se.drawImage(H,0,0),E.set(H,ce),ce},clear:function(){E.clear()}}})(p,new Map),x=(function(){var B=Math.floor(16.666666666666668),E,H,ce={},Se=0;return typeof requestAnimationFrame=="function"&&typeof cancelAnimationFrame=="function"?(E=function(Ae){var K=Math.random();return ce[K]=requestAnimationFrame(function le(xe){Se===xe||Se+B-1<xe?(Se=xe,delete ce[K],Ae()):ce[K]=requestAnimationFrame(le)}),K},H=function(Ae){ce[Ae]&&cancelAnimationFrame(ce[Ae])}):(E=function(Ae){return setTimeout(Ae,B)},H=function(Ae){return clearTimeout(Ae)}),{frame:E,cancel:H}})(),g=(function(){var B,E,H={};function ce(Se){function Ae(K,le){Se.postMessage({options:K||{},callback:le})}Se.init=function(le){var xe=le.transferControlToOffscreen();Se.postMessage({canvas:xe},[xe])},Se.fire=function(le,xe,Le){if(E)return Ae(le,null),E;var Q=Math.random().toString(36).slice(2);return E=h(function(_e){function Ce(Ue){Ue.data.callback===Q&&(delete H[Q],Se.removeEventListener("message",Ce),E=null,v.clear(),Le(),_e())}Se.addEventListener("message",Ce),Ae(le,Q),H[Q]=Ce.bind(null,{data:{callback:Q}})}),E},Se.reset=function(){Se.postMessage({reset:!0});for(var le in H)H[le](),delete H[le]}}return function(){if(B)return B;if(!s&&c){var Se=["var CONFETTI, SIZE = {}, module = {};","("+r.toString()+")(this, module, true, SIZE);","onmessage = function(msg) {","  if (msg.data.options) {","    CONFETTI(msg.data.options).then(function () {","      if (msg.data.callback) {","        postMessage({ callback: msg.data.callback });","      }","    });","  } else if (msg.data.reset) {","    CONFETTI && CONFETTI.reset();","  } else if (msg.data.resize) {","    SIZE.width = msg.data.resize.width;","    SIZE.height = msg.data.resize.height;","  } else if (msg.data.canvas) {","    SIZE.width = msg.data.canvas.width;","    SIZE.height = msg.data.canvas.height;","    CONFETTI = module.exports.create(msg.data.canvas);","  }","}"].join(`
`);try{B=new Worker(URL.createObjectURL(new Blob([Se])))}catch(Ae){return typeof console<"u"&&typeof console.warn=="function"&&console.warn("🎊 Could not load worker",Ae),null}ce(B)}return B}})(),M={particleCount:50,angle:90,spread:45,startVelocity:45,decay:.9,gravity:1,drift:0,ticks:200,x:.5,y:.5,shapes:["square","circle"],zIndex:100,colors:["#26ccff","#a25afd","#ff5e7e","#88ff5a","#fcff42","#ffa62d","#ff36ff"],disableForReducedMotion:!1,scalar:1};function w(B,E){return E?E(B):B}function R(B){return B!=null}function b(B,E,H){return w(B&&R(B[E])?B[E]:M[E],H)}function y(B){return B<0?0:Math.floor(B)}function P(B,E){return Math.floor(Math.random()*(E-B))+B}function O(B){return parseInt(B,16)}function C(B){return B.map(I)}function I(B){var E=String(B).replace(/[^0-9a-f]/gi,"");return E.length<6&&(E=E[0]+E[0]+E[1]+E[1]+E[2]+E[2]),{r:O(E.substring(0,2)),g:O(E.substring(2,4)),b:O(E.substring(4,6))}}function L(B){var E=b(B,"origin",Object);return E.x=b(E,"x",Number),E.y=b(E,"y",Number),E}function F(B){B.width=document.documentElement.clientWidth,B.height=document.documentElement.clientHeight}function T(B){var E=B.getBoundingClientRect();B.width=E.width,B.height=E.height}function U(B){var E=document.createElement("canvas");return E.style.position="fixed",E.style.top="0px",E.style.left="0px",E.style.pointerEvents="none",E.style.zIndex=B,E}function V(B,E,H,ce,Se,Ae,K,le,xe){B.save(),B.translate(E,H),B.rotate(Ae),B.scale(ce,Se),B.arc(0,0,1,K,le,xe),B.restore()}function k(B){var E=B.angle*(Math.PI/180),H=B.spread*(Math.PI/180);return{x:B.x,y:B.y,wobble:Math.random()*10,wobbleSpeed:Math.min(.11,Math.random()*.1+.05),velocity:B.startVelocity*.5+Math.random()*B.startVelocity,angle2D:-E+(.5*H-Math.random()*H),tiltAngle:(Math.random()*(.75-.25)+.25)*Math.PI,color:B.color,shape:B.shape,tick:0,totalTicks:B.ticks,decay:B.decay,drift:B.drift,random:Math.random()+2,tiltSin:0,tiltCos:0,wobbleX:0,wobbleY:0,gravity:B.gravity*3,ovalScalar:.6,scalar:B.scalar,flat:B.flat}}function W(B,E){E.x+=Math.cos(E.angle2D)*E.velocity+E.drift,E.y+=Math.sin(E.angle2D)*E.velocity+E.gravity,E.velocity*=E.decay,E.flat?(E.wobble=0,E.wobbleX=E.x+10*E.scalar,E.wobbleY=E.y+10*E.scalar,E.tiltSin=0,E.tiltCos=0,E.random=1):(E.wobble+=E.wobbleSpeed,E.wobbleX=E.x+10*E.scalar*Math.cos(E.wobble),E.wobbleY=E.y+10*E.scalar*Math.sin(E.wobble),E.tiltAngle+=.1,E.tiltSin=Math.sin(E.tiltAngle),E.tiltCos=Math.cos(E.tiltAngle),E.random=Math.random()+2);var H=E.tick++/E.totalTicks,ce=E.x+E.random*E.tiltCos,Se=E.y+E.random*E.tiltSin,Ae=E.wobbleX+E.random*E.tiltCos,K=E.wobbleY+E.random*E.tiltSin;if(B.fillStyle="rgba("+E.color.r+", "+E.color.g+", "+E.color.b+", "+(1-H)+")",B.beginPath(),f&&E.shape.type==="path"&&typeof E.shape.path=="string"&&Array.isArray(E.shape.matrix))B.fill(X(E.shape.path,E.shape.matrix,E.x,E.y,Math.abs(Ae-ce)*.1,Math.abs(K-Se)*.1,Math.PI/10*E.wobble));else if(E.shape.type==="bitmap"){var le=Math.PI/10*E.wobble,xe=Math.abs(Ae-ce)*.1,Le=Math.abs(K-Se)*.1,Q=E.shape.bitmap.width*E.scalar,_e=E.shape.bitmap.height*E.scalar,Ce=new DOMMatrix([Math.cos(le)*xe,Math.sin(le)*xe,-Math.sin(le)*Le,Math.cos(le)*Le,E.x,E.y]);Ce.multiplySelf(new DOMMatrix(E.shape.matrix));var Ue=B.createPattern(v.transform(E.shape.bitmap),"no-repeat");Ue.setTransform(Ce),B.globalAlpha=1-H,B.fillStyle=Ue,B.fillRect(E.x-Q/2,E.y-_e/2,Q,_e),B.globalAlpha=1}else if(E.shape==="circle")B.ellipse?B.ellipse(E.x,E.y,Math.abs(Ae-ce)*E.ovalScalar,Math.abs(K-Se)*E.ovalScalar,Math.PI/10*E.wobble,0,2*Math.PI):V(B,E.x,E.y,Math.abs(Ae-ce)*E.ovalScalar,Math.abs(K-Se)*E.ovalScalar,Math.PI/10*E.wobble,0,2*Math.PI);else if(E.shape==="star")for(var He=Math.PI/2*3,Ye=4*E.scalar,ft=8*E.scalar,ee=E.x,Pe=E.y,Qe=5,Je=Math.PI/Qe;Qe--;)ee=E.x+Math.cos(He)*ft,Pe=E.y+Math.sin(He)*ft,B.lineTo(ee,Pe),He+=Je,ee=E.x+Math.cos(He)*Ye,Pe=E.y+Math.sin(He)*Ye,B.lineTo(ee,Pe),He+=Je;else B.moveTo(Math.floor(E.x),Math.floor(E.y)),B.lineTo(Math.floor(E.wobbleX),Math.floor(Se)),B.lineTo(Math.floor(Ae),Math.floor(K)),B.lineTo(Math.floor(ce),Math.floor(E.wobbleY));return B.closePath(),B.fill(),E.tick<E.totalTicks}function re(B,E,H,ce,Se){var Ae=E.slice(),K=B.getContext("2d"),le,xe,Le=h(function(Q){function _e(){le=xe=null,K.clearRect(0,0,ce.width,ce.height),v.clear(),Se(),Q()}function Ce(){s&&!(ce.width===l.width&&ce.height===l.height)&&(ce.width=B.width=l.width,ce.height=B.height=l.height),!ce.width&&!ce.height&&(H(B),ce.width=B.width,ce.height=B.height),K.clearRect(0,0,ce.width,ce.height),Ae=Ae.filter(function(Ue){return W(K,Ue)}),Ae.length?le=x.frame(Ce):_e()}le=x.frame(Ce),xe=_e});return{addFettis:function(Q){return Ae=Ae.concat(Q),Le},canvas:B,promise:Le,reset:function(){le&&x.cancel(le),xe&&xe()}}}function oe(B,E){var H=!B,ce=!!b(E||{},"resize"),Se=!1,Ae=b(E,"disableForReducedMotion",Boolean),K=c&&!!b(E||{},"useWorker"),le=K?g():null,xe=H?F:T,Le=B&&le?!!B.__confetti_initialized:!1,Q=typeof matchMedia=="function"&&matchMedia("(prefers-reduced-motion)").matches,_e;function Ce(He,Ye,ft){for(var ee=b(He,"particleCount",y),Pe=b(He,"angle",Number),Qe=b(He,"spread",Number),Je=b(He,"startVelocity",Number),ct=b(He,"decay",Number),Mt=b(He,"gravity",Number),Y=b(He,"drift",Number),Tt=b(He,"colors",C),Ne=b(He,"ticks",Number),z=b(He,"shapes"),A=b(He,"scalar"),ie=!!b(He,"flat"),pe=L(He),ye=ee,Oe=[],Be=B.width*pe.x,be=B.height*pe.y;ye--;)Oe.push(k({x:Be,y:be,angle:Pe,spread:Qe,startVelocity:Je,color:Tt[ye%Tt.length],shape:z[P(0,z.length)],ticks:Ne,decay:ct,gravity:Mt,drift:Y,scalar:A,flat:ie}));return _e?_e.addFettis(Oe):(_e=re(B,Oe,xe,Ye,ft),_e.promise)}function Ue(He){var Ye=Ae||b(He,"disableForReducedMotion",Boolean),ft=b(He,"zIndex",Number);if(Ye&&Q)return h(function(Je){Je()});H&&_e?B=_e.canvas:H&&!B&&(B=U(ft),document.body.appendChild(B)),ce&&!Le&&xe(B);var ee={width:B.width,height:B.height};le&&!Le&&le.init(B),Le=!0,le&&(B.__confetti_initialized=!0);function Pe(){if(le){var Je={getBoundingClientRect:function(){if(!H)return B.getBoundingClientRect()}};xe(Je),le.postMessage({resize:{width:Je.width,height:Je.height}});return}ee.width=ee.height=null}function Qe(){_e=null,ce&&(Se=!1,e.removeEventListener("resize",Pe)),H&&B&&(document.body.contains(B)&&document.body.removeChild(B),B=null,Le=!1)}return ce&&!Se&&(Se=!0,e.addEventListener("resize",Pe,!1)),le?le.fire(He,ee,Qe):Ce(He,ee,Qe)}return Ue.reset=function(){le&&le.reset(),_e&&_e.reset()},Ue}var te;function G(){return te||(te=oe(null,{useWorker:!0,resize:!0})),te}function X(B,E,H,ce,Se,Ae,K){var le=new Path2D(B),xe=new Path2D;xe.addPath(le,new DOMMatrix(E));var Le=new Path2D;return Le.addPath(xe,new DOMMatrix([Math.cos(K)*Se,Math.sin(K)*Se,-Math.sin(K)*Ae,Math.cos(K)*Ae,H,ce])),Le}function $(B){if(!f)throw new Error("path confetti are not supported in this browser");var E,H;typeof B=="string"?E=B:(E=B.path,H=B.matrix);var ce=new Path2D(E),Se=document.createElement("canvas"),Ae=Se.getContext("2d");if(!H){for(var K=1e3,le=K,xe=K,Le=0,Q=0,_e,Ce,Ue=0;Ue<K;Ue+=2)for(var He=0;He<K;He+=2)Ae.isPointInPath(ce,Ue,He,"nonzero")&&(le=Math.min(le,Ue),xe=Math.min(xe,He),Le=Math.max(Le,Ue),Q=Math.max(Q,He));_e=Le-le,Ce=Q-xe;var Ye=10,ft=Math.min(Ye/_e,Ye/Ce);H=[ft,0,0,ft,-Math.round(_e/2+le)*ft,-Math.round(Ce/2+xe)*ft]}return{type:"path",path:E,matrix:H}}function se(B){var E,H=1,ce="#000000",Se='"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "Twemoji Mozilla", "system emoji", sans-serif';typeof B=="string"?E=B:(E=B.text,H="scalar"in B?B.scalar:H,Se="fontFamily"in B?B.fontFamily:Se,ce="color"in B?B.color:ce);var Ae=10*H,K=""+Ae+"px "+Se,le=new OffscreenCanvas(Ae,Ae),xe=le.getContext("2d");xe.font=K;var Le=xe.measureText(E),Q=Math.ceil(Le.actualBoundingBoxRight+Le.actualBoundingBoxLeft),_e=Math.ceil(Le.actualBoundingBoxAscent+Le.actualBoundingBoxDescent),Ce=2,Ue=Le.actualBoundingBoxLeft+Ce,He=Le.actualBoundingBoxAscent+Ce;Q+=Ce+Ce,_e+=Ce+Ce,le=new OffscreenCanvas(Q,_e),xe=le.getContext("2d"),xe.font=K,xe.fillStyle=ce,xe.fillText(E,Ue,He);var Ye=1/H;return{type:"bitmap",bitmap:le.transferToImageBitmap(),matrix:[Ye,0,0,Ye,-Q*Ye/2,-_e*Ye/2]}}i.exports=function(){return G().apply(this,arguments)},i.exports.reset=function(){G().reset()},i.exports.create=oe,i.exports.shapeFromPath=$,i.exports.shapeFromText=se})((function(){return typeof window<"u"?window:typeof self<"u"?self:this||{}})(),Lp,!1);const Op=Lp.exports;Lp.exports.create;var ou;(function(r){r.Heavy="HEAVY",r.Medium="MEDIUM",r.Light="LIGHT"})(ou||(ou={}));var rp;(function(r){r.Success="SUCCESS",r.Warning="WARNING",r.Error="ERROR"})(rp||(rp={}));const rh=Ys("Haptics",{web:()=>lp(()=>import("./web-BCAhOtCS.js"),[]).then(r=>new r.HapticsWeb)}),l3=({mode:r,world:e,profile:i,levelData:s,onFinishGame:l,onQuitToHome:c})=>{const[f,p]=st.useState(!0),[m,h]=st.useState(!1),[v,x]=st.useState(!1),[g,M]=st.useState(0),[w,R]=st.useState(0),[b,y]=st.useState(0),[P,O]=st.useState(null),[C,I]=st.useState(0),[L,F]=st.useState(0),[T,U]=st.useState(null),[V,k]=st.useState(null),W=Gb.useRef({}),re=se=>{const B=Date.now();if(B-(W.current[se]||0)<120)return;W.current[se]=B,U({type:se,id:B+Math.random()}),k({left:"◀ STEER LEFT",right:"STEER RIGHT ▶",up:r==="racer"||r==="motorbike"||r==="ball"?"🔥 NITRO BOOST":"⚡ JUMP",down:"🔻 SLIDE"}[se]),setTimeout(()=>{k(null)},400)},oe=(se,B)=>{B.preventDefault(),B.stopPropagation(),re(se)};st.useEffect(()=>{const se=B=>{if(!f||m||v)return;const E=B.key,H=B.code;E==="ArrowLeft"||E==="Left"||H==="ArrowLeft"||E==="a"||E==="A"||H==="KeyA"?(B.preventDefault(),B.stopPropagation(),re("left")):E==="ArrowRight"||E==="Right"||H==="ArrowRight"||E==="d"||E==="D"||H==="KeyD"?(B.preventDefault(),B.stopPropagation(),re("right")):E==="ArrowUp"||E==="Up"||H==="ArrowUp"||E==="w"||E==="W"||H==="KeyW"||E===" "||E==="Spacebar"||H==="Space"?(B.preventDefault(),B.stopPropagation(),re("up")):(E==="ArrowDown"||E==="Down"||H==="ArrowDown"||E==="s"||E==="S"||H==="KeyS")&&(B.preventDefault(),B.stopPropagation(),re("down"))};return window.addEventListener("keydown",se,{capture:!0}),document.addEventListener("keydown",se,{capture:!0}),()=>{window.removeEventListener("keydown",se,{capture:!0}),document.removeEventListener("keydown",se,{capture:!0})}},[f,m,v]),st.useEffect(()=>(nt.startBgmLoop(e.name),()=>{nt.stopBgmLoop()}),[e]);const te=(se,B,E)=>{p(!1),I(se);let H=1;E>=s.targetDistance&&B>=s.targetCoins?H=3:E>=s.targetDistance&&(H=2),F(H),x(!0),H>=2?(nt.playVictory(),rh.notification({type:rp.Success}).catch(()=>{}),Op({particleCount:100,spread:70,origin:{y:.6}})):(nt.playCrash(),rh.impact({style:ou.Heavy}).catch(()=>{}))},G=()=>{nt.playClick(),l(g,w,s.rewardXp,b,L)},X=(se,B)=>{O({type:se,duration:B});const E=setInterval(()=>{O(H=>!H||H.duration<=1?(clearInterval(E),null):{...H,duration:H.duration-1})},1e3)},$=Math.min(100,Math.round(b/s.targetDistance*100));return _.jsxs("div",{className:"fixed inset-0 z-50 bg-slate-950 text-white select-none overflow-hidden",children:[_.jsxs("div",{className:"absolute inset-0 w-full h-full",children:[_.jsx(o3,{mode:r,world:e,profile:i,levelData:s,isPlaying:f,isPaused:m,inputAction:T,onCoinCollect:se=>{se>g&&rh.impact({style:ou.Light}).catch(()=>{}),M(se)},onGemCollect:se=>R(se),onDistanceUpdate:se=>y(se),onGameOver:te,onPowerupActive:X}),_.jsxs("div",{className:"absolute top-0 left-0 right-0 p-4 flex items-center justify-between pointer-events-none z-10",children:[_.jsxs("div",{className:"flex items-center gap-2 pointer-events-auto",children:[_.jsxs("div",{className:"flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950/80 backdrop-blur-md border border-slate-800 text-amber-300 font-black text-sm shadow-lg",children:[_.jsx(Zs,{className:"w-4 h-4 text-amber-400"}),_.jsx("span",{children:g})]}),_.jsxs("div",{className:"flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950/80 backdrop-blur-md border border-slate-800 text-cyan-300 font-black text-sm shadow-lg",children:[_.jsx(Jr,{className:"w-4 h-4 text-cyan-400"}),_.jsx("span",{children:w})]}),_.jsx("div",{className:"flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950/80 backdrop-blur-md border border-slate-800 text-slate-100 font-black text-sm shadow-lg",children:_.jsxs("span",{children:[b,"m"]})})]}),_.jsx("button",{onClick:()=>{nt.playClick(),h(!m)},className:"pointer-events-auto p-3 rounded-2xl bg-slate-950/80 hover:bg-slate-900 border border-slate-800 text-white shadow-lg active:scale-90",children:m?_.jsx(xp,{className:"w-5 h-5 text-amber-400"}):_.jsx(tM,{className:"w-5 h-5 text-white"})})]}),_.jsxs("div",{className:"absolute top-16 left-4 right-4 max-w-md mx-auto pointer-events-none z-10 flex flex-col items-center gap-1",children:[_.jsx("div",{className:"w-full h-2 rounded-full bg-slate-950/80 backdrop-blur border border-slate-800 overflow-hidden",children:_.jsx("div",{className:"h-full bg-gradient-to-r from-cyan-400 via-amber-400 to-emerald-400 transition-all duration-300 rounded-full",style:{width:`${$}%`}})}),_.jsx("span",{className:"text-[10px] font-bold text-slate-400 tracking-wider uppercase",children:"Controls: Arrow Keys / WASD / Space / Buttons Below"})]}),V&&_.jsx("div",{className:"absolute top-24 left-1/2 -translate-x-1/2 px-5 py-1.5 rounded-full bg-cyan-500/90 text-slate-950 font-black text-xs tracking-wider uppercase shadow-[0_0_20px_rgba(6,182,212,0.6)] z-30 transition-all scale-105",children:V}),P&&_.jsxs("div",{className:"absolute top-28 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 font-black text-xs shadow-xl flex items-center gap-2 animate-bounce z-20",children:[_.jsx(cu,{className:"w-4 h-4 fill-slate-950"}),_.jsxs("span",{children:[P.type.toUpperCase(),": ",P.duration,"s"]})]}),_.jsxs("div",{className:"absolute bottom-6 left-4 right-4 z-20 flex items-end justify-between pointer-events-none",children:[_.jsxs("div",{className:"flex items-center gap-3 pointer-events-auto",children:[_.jsx("button",{onPointerDown:se=>oe("left",se),onClick:se=>oe("left",se),className:"w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/85 hover:bg-slate-800 border-2 border-cyan-500/50 text-cyan-400 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.3)] active:scale-90 transition-all select-none touch-none",title:"Steer Left (Arrow Left / A)",children:_.jsx(bS,{className:"w-7 h-7"})}),_.jsx("button",{onPointerDown:se=>oe("right",se),onClick:se=>oe("right",se),className:"w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/85 hover:bg-slate-800 border-2 border-cyan-500/50 text-cyan-400 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.3)] active:scale-90 transition-all select-none touch-none",title:"Steer Right (Arrow Right / D)",children:_.jsx(MS,{className:"w-7 h-7"})})]}),_.jsxs("div",{className:"flex items-center gap-3 pointer-events-auto",children:[_.jsx("button",{onPointerDown:se=>oe("down",se),onClick:se=>oe("down",se),className:"w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/85 hover:bg-slate-800 border-2 border-amber-500/50 text-amber-400 flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.3)] active:scale-90 transition-all select-none touch-none",title:"Slide / Duck (Arrow Down / S)",children:_.jsx(_S,{className:"w-7 h-7"})}),_.jsx("button",{onPointerDown:se=>oe("up",se),onClick:se=>oe("up",se),className:"w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 hover:brightness-110 text-slate-950 font-black flex items-center justify-center shadow-[0_0_25px_rgba(244,63,94,0.5)] active:scale-90 transition-all border-2 border-white/20 select-none touch-none",title:"Jump / Nitro (Arrow Up / W / Space)",children:r==="racer"||r==="motorbike"||r==="ball"?_.jsx(GS,{className:"w-8 h-8 fill-slate-950"}):_.jsx(TS,{className:"w-8 h-8 stroke-[3]"})})]})]})]}),m&&_.jsx("div",{className:"absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md",children:_.jsxs("div",{className:"w-full max-w-sm p-6 rounded-3xl bg-slate-900 border border-slate-800 text-center flex flex-col gap-4",children:[_.jsx("h3",{className:"text-2xl font-black text-white",children:"GAME PAUSED"}),_.jsx("button",{onClick:()=>{nt.playClick(),h(!1)},className:"w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-base shadow-lg",children:"Resume Game"}),_.jsxs("button",{onClick:c,className:"w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm flex items-center justify-center gap-2",children:[_.jsx(qv,{className:"w-4 h-4"}),_.jsx("span",{children:"Quit to Home"})]})]})}),v&&_.jsx("div",{className:"absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl",children:_.jsxs("div",{className:"w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900 border border-indigo-500/40 text-center flex flex-col items-center gap-4 shadow-[0_0_50px_rgba(79,70,229,0.3)]",children:[_.jsx("h2",{className:"text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-rose-400",children:L>=2?"LEVEL COMPLETED!":"CRASHED!"}),_.jsx("div",{className:"flex items-center gap-2 my-2",children:[1,2,3].map(se=>_.jsx(tu,{className:`w-10 h-10 ${se<=L?"text-amber-400 fill-amber-400 animate-pulse":"text-slate-700"}`},se))}),_.jsxs("div",{className:"w-full grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-950 border border-slate-800",children:[_.jsxs("div",{className:"flex flex-col items-center",children:[_.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase",children:"Distance"}),_.jsxs("span",{className:"text-lg font-black text-white",children:[b,"m"]})]}),_.jsxs("div",{className:"flex flex-col items-center",children:[_.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase",children:"Coins Collected"}),_.jsxs("span",{className:"text-lg font-black text-amber-400",children:["+",g]})]})]}),_.jsx("button",{onClick:G,className:"w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-rose-500 to-amber-400 hover:brightness-110 text-slate-950 font-black text-lg shadow-xl active:scale-95 flex items-center justify-center gap-2",children:_.jsx("span",{children:L>=1?"NEXT LEVEL ➔":"TRY AGAIN ↻"})})]})})]})},c3=({profile:r,onBuyItem:e})=>{const[i,s]=st.useState("all"),[l,c]=st.useState(!1),[f,p]=st.useState(null),m=oS.filter(x=>i==="all"?!0:i==="characters"?x.category==="character":i==="cars"?x.category==="car":i==="gems"?x.category==="gems"||x.category==="coins":i==="bundles"?x.category==="bundle"||x.category==="special":!0),h=()=>{if(r.coins<2e3){alert("You need 2,000 coins to open a Mystery Box!");return}nt.playChestOpen(),c(!0),p(null),setTimeout(()=>{const x=[{name:"50 Gems",icon:"💎",rarity:"epic"},{name:"3,000 Coins",icon:"💰",rarity:"rare"},{name:"2 Keys",icon:"🔑",rarity:"legendary"},{name:"Cyber Neon Skin",icon:"⚡",rarity:"mythic"}],g=x[Math.floor(Math.random()*x.length)];p(g),c(!1),Op({particleCount:80,spread:60,origin:{y:.6}})},1500)},v=x=>{switch(x){case"mythic":return"bg-rose-500/20 text-rose-300 border-rose-500/40";case"legendary":return"bg-amber-500/20 text-amber-300 border-amber-500/40";case"epic":return"bg-purple-500/20 text-purple-300 border-purple-500/40";case"rare":return"bg-cyan-500/20 text-cyan-300 border-cyan-500/40";default:return"bg-slate-700/40 text-slate-300 border-slate-600"}};return _.jsxs("div",{className:"w-full max-w-4xl mx-auto p-4 text-white select-none pb-28",children:[_.jsxs("div",{className:"p-6 rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 border border-purple-500/30 shadow-xl mb-6 flex flex-col sm:flex-row items-center justify-between gap-4",children:[_.jsxs("div",{className:"flex items-center gap-4",children:[_.jsx("div",{className:"p-3.5 rounded-2xl bg-purple-500/20 border border-purple-400/40 text-purple-300",children:_.jsx(Yv,{className:"w-8 h-8"})}),_.jsxs("div",{children:[_.jsx("h2",{className:"text-2xl font-black text-white",children:"ROUTE RUSH SHOP"}),_.jsx("p",{className:"text-xs text-purple-200/80",children:"Unlock exclusive heroes, cars, skin packs, and mystery deals!"})]})]}),_.jsxs("button",{onClick:h,className:"py-3 px-5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm shadow-lg flex items-center gap-2 hover:brightness-110 transition-all active:scale-95",children:[_.jsx(hh,{className:"w-5 h-5"}),_.jsx("span",{children:"Mystery Box (2,000 Coins)"})]})]}),_.jsx("div",{className:"flex items-center gap-2 overflow-x-auto pb-3 mb-6 no-scrollbar",children:[{id:"all",label:"All Items"},{id:"characters",label:"Heroes"},{id:"cars",label:"Cars"},{id:"gems",label:"Gems & Coins"},{id:"bundles",label:"Bundles"}].map(x=>_.jsx("button",{onClick:()=>{nt.playClick(),s(x.id)},className:`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${i===x.id?"bg-indigo-600 text-white shadow-md":"bg-slate-900/80 hover:bg-slate-800 text-slate-400"}`,children:x.label},x.id))}),_.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4",children:m.map(x=>_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 hover:bg-slate-850 border border-slate-800 flex flex-col justify-between transition-all duration-200 hover:border-indigo-500/40 shadow-lg",children:[_.jsxs("div",{children:[_.jsxs("div",{className:"flex items-center justify-between mb-3",children:[_.jsx("span",{className:`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${v(x.rarity)}`,children:x.rarity}),x.discount&&_.jsxs("span",{className:"text-[10px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full",children:["-",x.discount,"%"]})]}),_.jsx("div",{className:"flex items-center justify-center h-20 text-5xl mb-3",children:x.icon}),_.jsx("h3",{className:"text-base font-bold text-white text-center",children:x.name}),_.jsx("p",{className:"text-xs text-slate-400 text-center mt-1 min-h-[32px]",children:x.description})]}),_.jsxs("button",{onClick:()=>{nt.playClick(),e(x)},className:"mt-4 w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-sm shadow flex items-center justify-center gap-2 active:scale-95",children:[_.jsxs("span",{children:["Buy for ",x.price.toLocaleString()]}),x.currency==="coins"&&_.jsx(Zs,{className:"w-4 h-4 text-amber-400"}),x.currency==="gems"&&_.jsx(Jr,{className:"w-4 h-4 text-cyan-400"})]})]},x.id))}),(l||f)&&_.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md",children:_.jsx("div",{className:"w-full max-w-sm p-6 rounded-3xl bg-slate-900 border border-indigo-500/40 text-center flex flex-col items-center gap-4",children:l?_.jsxs("div",{className:"py-8 flex flex-col items-center gap-4",children:[_.jsx(hh,{className:"w-16 h-16 text-amber-400 animate-bounce"}),_.jsx("span",{className:"text-lg font-black text-amber-300",children:"Opening Mystery Box..."})]}):f&&_.jsxs(_.Fragment,{children:[_.jsx(fl,{className:"w-12 h-12 text-amber-400 animate-pulse"}),_.jsx("h3",{className:"text-2xl font-black text-white",children:"REWARD UNLOCKED!"}),_.jsx("div",{className:"text-6xl my-2",children:f.icon}),_.jsx("span",{className:"text-xl font-black text-amber-300",children:f.name}),_.jsx("button",{onClick:()=>p(null),className:"w-full mt-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold",children:"Awesome!"})]})})})]})},u3=({profile:r,onSelectCar:e,onUpgradeCar:i,onChangePaint:s,onChangeNeon:l,onUnlockCar:c})=>{const f=rl.find(w=>w.id===r.selectedCarId)||rl[0],p=r.unlockedCars.includes(f.id),m=r.carUpgrades[f.id]||{engine:1,nitro:1,handling:1,brakes:1,suspension:1},h=r.carPaints[f.id]||f.bodyColor,v=r.carNeon[f.id]||"#00f0ff",x=["#ef4444","#3b82f6","#22c55e","#eab308","#a855f7","#ec4899","#f97316","#14b8a6","#f8fafc","#0f172a"],g=["#00f0ff","#ff007f","#39ff14","#f000ff","#ffea00","#ffffff"],M=w=>{const R=m[w];if(R>=10)return;const b=500*R;if(r.coins<b){alert("Not enough coins!");return}nt.playVictory(),i(f.id,w,b)};return _.jsxs("div",{className:"w-full max-w-4xl mx-auto p-4 text-white select-none pb-28",children:[_.jsxs("div",{className:"relative p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border border-slate-800 shadow-2xl mb-6 flex flex-col items-center",children:[_.jsxs("div",{className:"relative w-full h-48 sm:h-64 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-center overflow-hidden mb-4",children:[_.jsx("div",{className:"absolute inset-0 opacity-20 pointer-events-none",style:{backgroundColor:h}}),_.jsxs("div",{className:"relative z-10 flex flex-col items-center transform hover:scale-105 transition-transform duration-300",children:[_.jsx("span",{className:"text-8xl sm:text-9xl drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]",children:"🏎️"}),_.jsx("div",{className:"w-48 h-3 rounded-full blur-md mt-2 transition-colors duration-300",style:{backgroundColor:v}})]}),_.jsx("div",{className:"absolute top-3 left-3 px-3 py-1 rounded-full bg-slate-900/90 text-xs font-bold text-slate-300 border border-slate-800",children:f.type})]}),_.jsxs("div",{className:"w-full flex items-center justify-between",children:[_.jsxs("div",{children:[_.jsx("h2",{className:"text-2xl font-black text-white",children:f.name}),_.jsx("p",{className:"text-xs text-slate-400",children:f.description})]}),p?_.jsxs("button",{disabled:!0,className:"px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold text-xs border border-emerald-500/30 flex items-center gap-1",children:[_.jsx(gp,{className:"w-4 h-4"}),_.jsx("span",{children:"EQUIPPED"})]}):_.jsx("button",{onClick:()=>{nt.playClick(),c(f)},className:"px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm shadow-lg flex items-center gap-1.5 hover:brightness-110 active:scale-95",children:_.jsxs("span",{children:["Unlock (",f.price.toLocaleString()," ",f.currency,")"]})})]})]}),_.jsxs("div",{className:"mb-6",children:[_.jsx("h3",{className:"text-xs font-black uppercase tracking-wider text-slate-400 mb-2",children:"Vehicle Collection"}),_.jsx("div",{className:"flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar",children:rl.map(w=>{const R=w.id===f.id,b=r.unlockedCars.includes(w.id);return _.jsxs("button",{onClick:()=>{nt.playClick(),e(w.id)},className:`relative flex-none w-28 p-3 rounded-2xl border text-center transition-all active:scale-95 ${R?"bg-indigo-950/80 border-indigo-500 text-white shadow-md":"bg-slate-900/80 border-slate-800 text-slate-400 hover:bg-slate-850"}`,children:[_.jsx("div",{className:"text-3xl mb-1",children:"🏎️"}),_.jsx("div",{className:"text-xs font-bold truncate",children:w.name}),!b&&_.jsx("span",{className:"text-[9px] font-black uppercase text-amber-400",children:"Locked"})]},w.id)})})]}),p&&_.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[_.jsxs("div",{className:"p-5 rounded-3xl bg-slate-900/90 border border-slate-800",children:[_.jsxs("h3",{className:"text-sm font-black text-white uppercase tracking-wider mb-4 flex items-center gap-2",children:[_.jsx(cu,{className:"w-4 h-4 text-amber-400"}),_.jsx("span",{children:"Performance Upgrades"})]}),_.jsx("div",{className:"flex flex-col gap-3",children:[{key:"engine",label:"Engine Speed",val:m.engine},{key:"nitro",label:"Nitro Duration",val:m.nitro},{key:"handling",label:"Drift Handling",val:m.handling},{key:"brakes",label:"Brakes Response",val:m.brakes}].map(w=>_.jsxs("div",{className:"flex items-center justify-between text-xs",children:[_.jsxs("div",{children:[_.jsx("span",{className:"font-bold text-slate-200",children:w.label}),_.jsxs("span",{className:"text-[10px] text-amber-400 font-bold ml-2",children:["Lvl ",w.val,"/10"]})]}),_.jsxs("button",{onClick:()=>M(w.key),disabled:w.val>=10,className:"px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 text-white font-bold flex items-center gap-1 active:scale-95",children:[_.jsx("span",{children:"Upgrade"}),_.jsx(Zs,{className:"w-3 h-3 text-amber-300"}),_.jsx("span",{children:500*w.val})]})]},w.key))})]}),_.jsxs("div",{className:"p-5 rounded-3xl bg-slate-900/90 border border-slate-800",children:[_.jsxs("h3",{className:"text-sm font-black text-white uppercase tracking-wider mb-4 flex items-center gap-2",children:[_.jsx(fl,{className:"w-4 h-4 text-cyan-400"}),_.jsx("span",{children:"Paint & Neon Customizer"})]}),_.jsxs("div",{className:"mb-4",children:[_.jsx("span",{className:"text-xs font-bold text-slate-400 block mb-2",children:"Body Paint"}),_.jsx("div",{className:"flex items-center gap-2 flex-wrap",children:x.map(w=>_.jsx("button",{onClick:()=>{nt.playClick(),s(f.id,w)},className:`w-7 h-7 rounded-full border-2 transition-transform active:scale-90 ${h===w?"border-white scale-110 shadow-lg":"border-transparent"}`,style:{backgroundColor:w}},w))})]}),_.jsxs("div",{children:[_.jsx("span",{className:"text-xs font-bold text-slate-400 block mb-2",children:"Neon Underglow"}),_.jsx("div",{className:"flex items-center gap-2 flex-wrap",children:g.map(w=>_.jsx("button",{onClick:()=>{nt.playClick(),l(f.id,w)},className:`w-7 h-7 rounded-full border-2 transition-transform active:scale-90 ${v===w?"border-white scale-110 shadow-lg":"border-transparent"}`,style:{backgroundColor:w}},w))})]})]})]})]})},f3=({profile:r,onSelectCharacter:e,onUnlockCharacter:i})=>{const s=sl.find(c=>c.id===r.selectedCharacterId)||sl[0],l=r.unlockedCharacters.includes(s.id);return _.jsxs("div",{className:"w-full max-w-4xl mx-auto p-4 text-white select-none pb-28",children:[_.jsxs("div",{className:"relative p-6 rounded-3xl bg-gradient-to-b from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/30 shadow-2xl mb-6 flex flex-col items-center",children:[_.jsxs("div",{className:"relative w-full h-52 sm:h-64 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-center overflow-hidden mb-4",children:[_.jsx("div",{className:"absolute inset-0 opacity-20 pointer-events-none",style:{backgroundColor:s.color}}),_.jsxs("div",{className:"relative z-10 flex flex-col items-center",children:[_.jsx("span",{className:"text-8xl sm:text-9xl drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)] animate-pulse",children:s.avatarUrl}),_.jsx("span",{className:"text-xs font-black uppercase text-indigo-300 mt-2 px-3 py-1 rounded-full bg-indigo-950 border border-indigo-800",children:s.title})]})]}),_.jsxs("div",{className:"w-full flex items-center justify-between",children:[_.jsxs("div",{children:[_.jsx("h2",{className:"text-2xl font-black text-white",children:s.name}),_.jsxs("p",{className:"text-xs text-amber-300 font-bold mt-0.5",children:["Perk: ",s.perk]})]}),l?_.jsxs("button",{disabled:!0,className:"px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold text-xs border border-emerald-500/30 flex items-center gap-1",children:[_.jsx(gp,{className:"w-4 h-4"}),_.jsx("span",{children:"EQUIPPED HERO"})]}):_.jsx("button",{onClick:()=>{nt.playClick(),i(s)},className:"px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm shadow-lg flex items-center gap-1.5 hover:brightness-110 active:scale-95",children:_.jsxs("span",{children:["Unlock (",s.price," ",s.currency,")"]})})]})]}),_.jsx("h3",{className:"text-xs font-black uppercase tracking-wider text-slate-400 mb-3",children:"Hero Roster"}),_.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4",children:sl.map(c=>{const f=c.id===s.id,p=r.unlockedCharacters.includes(c.id);return _.jsxs("div",{onClick:()=>{nt.playClick(),e(c.id)},className:`p-4 rounded-2xl border cursor-pointer transition-all duration-200 active:scale-95 flex items-center justify-between ${f?"bg-indigo-950/80 border-indigo-500 text-white shadow-lg":"bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-850"}`,children:[_.jsxs("div",{className:"flex items-center gap-3",children:[_.jsx("div",{className:"text-4xl",children:c.avatarUrl}),_.jsxs("div",{children:[_.jsx("h4",{className:"text-sm font-bold text-white",children:c.name}),_.jsx("p",{className:"text-[11px] text-slate-400",children:c.perk})]})]}),_.jsx("div",{children:p?_.jsx("span",{className:"text-[10px] font-black uppercase px-2 py-1 rounded bg-emerald-500/20 text-emerald-300",children:"Unlocked"}):_.jsx(ZS,{className:"w-4 h-4 text-amber-400"})})]},c.id)})})]})},d3=({missions:r,onClaimMission:e})=>{const[i,s]=st.useState("daily"),l=r.filter(c=>c.type===i);return _.jsxs("div",{className:"w-full max-w-4xl mx-auto p-4 text-white select-none pb-28",children:[_.jsx("div",{className:"flex items-center gap-2 mb-6",children:[{id:"daily",label:"Daily Missions"},{id:"weekly",label:"Weekly Challenges"},{id:"seasonal",label:"Season Pass"}].map(c=>_.jsx("button",{onClick:()=>{nt.playClick(),s(c.id)},className:`flex-1 py-3 px-4 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${i===c.id?"bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-lg":"bg-slate-900/80 hover:bg-slate-800 text-slate-400"}`,children:c.label},c.id))}),_.jsx("div",{className:"flex flex-col gap-3",children:l.map(c=>{const f=c.current>=c.target,p=Math.min(100,Math.round(c.current/c.target*100));return _.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md",children:[_.jsxs("div",{className:"flex items-center gap-3.5 w-full sm:w-auto",children:[_.jsx("div",{className:"p-3 rounded-xl bg-slate-800 text-amber-400 border border-slate-700",children:_.jsx(Zv,{className:"w-6 h-6"})}),_.jsxs("div",{className:"flex flex-col",children:[_.jsx("h4",{className:"text-sm font-bold text-white",children:c.title}),_.jsx("p",{className:"text-xs text-slate-400 mt-0.5",children:c.description}),_.jsx("div",{className:"w-48 sm:w-64 h-2 mt-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800",children:_.jsx("div",{className:"h-full bg-amber-400 rounded-full transition-all duration-300",style:{width:`${p}%`}})}),_.jsxs("span",{className:"text-[10px] text-slate-400 mt-0.5",children:[c.current," / ",c.target]})]})]}),_.jsxs("div",{className:"flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end",children:[_.jsxs("div",{className:"flex items-center gap-1 font-black text-amber-300 text-xs px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800",children:[_.jsxs("span",{children:["+",c.rewardAmount]}),c.rewardType==="coins"&&_.jsx(Zs,{className:"w-4 h-4 text-amber-400"}),c.rewardType==="gems"&&_.jsx(Jr,{className:"w-4 h-4 text-cyan-400"}),c.rewardType==="keys"&&_.jsx(qS,{className:"w-4 h-4 text-amber-400"})]}),c.claimed?_.jsxs("span",{className:"text-xs font-bold text-slate-500 flex items-center gap-1",children:[_.jsx(LS,{className:"w-4 h-4 text-emerald-500"}),_.jsx("span",{children:"Claimed"})]}):_.jsx("button",{onClick:()=>{nt.playVictory(),e(c.id)},disabled:!f,className:"px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs disabled:opacity-30 shadow hover:brightness-110 active:scale-95",children:"Claim Reward"})]})]},c.id)})})]})},h3=({onAddReward:r})=>{const[e,i]=st.useState(!1),[s,l]=st.useState(null),[c,f]=st.useState(()=>{const m=localStorage.getItem("route_rush_last_spin");if(!m)return!1;const h=new Date(Number(m)).toDateString(),v=new Date().toDateString();return h===v}),p=()=>{e||c||(nt.playChestOpen(),i(!0),l(null),setTimeout(()=>{const m=[{label:"500 Coins",coins:500,gems:0,keys:0},{label:"1,500 Coins",coins:1500,gems:0,keys:0},{label:"25 Gems",coins:0,gems:25,keys:0},{label:"1 Key",coins:0,gems:0,keys:1},{label:"3,000 Coins & 50 Gems",coins:3e3,gems:50,keys:0}],h=m[Math.floor(Math.random()*m.length)];l(h.label),i(!1),f(!0),localStorage.setItem("route_rush_last_spin",String(Date.now())),r(h.coins,h.gems,h.keys),Op({particleCount:100,spread:70,origin:{y:.6}})},2e3))};return _.jsxs("div",{className:"w-full max-w-4xl mx-auto p-4 text-white select-none pb-28",children:[_.jsxs("div",{className:"p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 shadow-2xl mb-6 flex flex-col items-center text-center",children:[_.jsxs("div",{className:"flex items-center gap-2 text-xs font-black uppercase text-amber-400 mb-1",children:[_.jsx(fl,{className:"w-4 h-4"}),_.jsx("span",{children:"Daily Lucky Rewards"})]}),_.jsx("h2",{className:"text-2xl font-black text-white",children:"SPIN THE RUSH WHEEL"}),_.jsx("p",{className:"text-xs text-slate-300 mt-1 max-w-md",children:"Spin once every day to claim guaranteed Coins, Gems, Keys, and bonus rewards!"}),_.jsxs("div",{className:"relative my-6 w-48 h-48 rounded-full border-4 border-amber-400/80 bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow-[0_0_30px_rgba(251,191,36,0.5)]",children:[_.jsx("div",{className:`text-6xl transition-transform duration-[2000ms] ${e?"rotate-[1440deg]":""}`,children:"🎡"}),_.jsx("div",{className:"absolute inset-0 rounded-full border-4 border-dashed border-white/30 animate-spin-slow pointer-events-none"})]}),s&&_.jsxs("div",{className:"mb-4 px-4 py-2 rounded-2xl bg-amber-400/20 text-amber-300 border border-amber-400/40 font-black text-base animate-bounce",children:["YOU WON: ",s,"!"]}),c&&!e&&_.jsxs("div",{className:"mb-4 px-4 py-2 rounded-2xl bg-slate-800/80 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center gap-2",children:[_.jsx(PS,{className:"w-4 h-4 text-amber-400"}),_.jsx("span",{children:"ALREADY SPUN TODAY! COME BACK TOMORROW ⏳"})]}),_.jsx("button",{onClick:p,disabled:e||c,className:"py-3.5 px-10 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-base shadow-xl hover:brightness-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed",children:e?"Spinning...":c?"SPUN FOR TODAY":"FREE DAILY SPIN"})]}),_.jsx("h3",{className:"text-xs font-black uppercase tracking-wider text-slate-400 mb-3",children:"Level Milestone Chests"}),_.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4",children:[{level:10,title:"Bonus Chest",reward:"500 Coins",rarity:"Common",icon:"📦"},{level:25,title:"Rare Chest",reward:"2,000 Coins + 20 Gems",rarity:"Rare",icon:"🎁"},{level:50,title:"Epic Chest",reward:"5,000 Coins + 50 Gems",rarity:"Epic",icon:"💎"},{level:100,title:"Legendary Chest",reward:"10,000 Coins + 100 Gems",rarity:"Legendary",icon:"👑"}].map(m=>_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center shadow-md",children:[_.jsx("div",{className:"text-4xl mb-2",children:m.icon}),_.jsxs("span",{className:"text-[10px] font-black uppercase text-amber-400",children:["Level ",m.level]}),_.jsx("h4",{className:"text-sm font-bold text-white mt-1",children:m.title}),_.jsx("p",{className:"text-[11px] text-slate-400 mt-1",children:m.reward})]},m.level))})]})},p3=({profile:r,achievements:e,onUpgradeGuestAccount:i,onClaimAchievement:s,onSyncCloudSave:l})=>{const[c,f]=st.useState(!1),[p,m]=st.useState(""),[h,v]=st.useState(""),[x,g]=st.useState(!1),M=R=>{R.preventDefault(),p.trim()&&(nt.playVictory(),i(p.trim(),h.trim()),f(!1))},w=()=>{nt.playClick(),g(!0),l(),setTimeout(()=>g(!1),2500)};return _.jsxs("div",{className:"w-full max-w-4xl mx-auto p-4 text-white select-none pb-28",children:[_.jsxs("div",{className:"p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 shadow-2xl mb-6 flex flex-col sm:flex-row items-center justify-between gap-4",children:[_.jsxs("div",{className:"flex items-center gap-4",children:[_.jsx("div",{className:"flex items-center justify-center w-16 h-16 rounded-2xl bg-indigo-600 text-4xl shadow-inner border border-white/20",children:r.avatar}),_.jsxs("div",{children:[_.jsxs("div",{className:"flex items-center gap-2",children:[_.jsx("h2",{className:"text-2xl font-black text-white",children:r.username}),r.isGuest&&_.jsx("span",{className:"text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30",children:"Guest"})]}),_.jsxs("p",{className:"text-xs text-slate-400 mt-1",children:["Level ",r.level," Racer • ID: ",r.id]})]})]}),_.jsxs("div",{className:"flex items-center gap-2",children:[r.isGuest&&_.jsx("button",{onClick:()=>{nt.playClick(),f(!0)},className:"px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs shadow hover:brightness-110 active:scale-95",children:"Upgrade Account"}),_.jsxs("button",{onClick:w,className:"p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 active:scale-95 flex items-center gap-1.5 text-xs font-bold",children:[_.jsx(zS,{className:`w-4 h-4 ${x?"text-emerald-400 animate-bounce":"text-cyan-400"}`}),_.jsx("span",{children:x?"Synced!":"Cloud Sync"})]})]})]}),_.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6",children:[_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center",children:[_.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase",children:"Levels Done"}),_.jsx("span",{className:"text-xl font-black text-white mt-1",children:r.totalLevelsCompleted})]}),_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center",children:[_.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase",children:"Coins Collected"}),_.jsx("span",{className:"text-xl font-black text-amber-400 mt-1",children:r.totalCoinsCollected.toLocaleString()})]}),_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center",children:[_.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase",children:"Distance Driven"}),_.jsxs("span",{className:"text-xl font-black text-cyan-400 mt-1",children:[(r.totalDistanceDriven/1e3).toFixed(1)," km"]})]}),_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center",children:[_.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase",children:"High Score"}),_.jsx("span",{className:"text-xl font-black text-rose-400 mt-1",children:Math.max(r.highScoreRunner,r.highScoreRacer).toLocaleString()})]})]}),_.jsxs("h3",{className:"text-xs font-black uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5",children:[_.jsx(tu,{className:"w-4 h-4 text-amber-400"}),_.jsx("span",{children:"Achievements Gallery"})]}),_.jsx("div",{className:"flex flex-col gap-3",children:e.map(R=>{const b=R.current>=R.target;return Math.min(100,Math.round(R.current/R.target*100)),_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm",children:[_.jsxs("div",{className:"flex items-center gap-3.5 w-full sm:w-auto",children:[_.jsx("div",{className:"p-3 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-800",children:_.jsx(tu,{className:"w-6 h-6"})}),_.jsxs("div",{children:[_.jsx("h4",{className:"text-sm font-bold text-white",children:R.title}),_.jsx("p",{className:"text-xs text-slate-400 mt-0.5",children:R.description})]})]}),_.jsxs("div",{className:"flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end",children:[_.jsxs("div",{className:"flex items-center gap-1 text-xs font-bold text-amber-300",children:[_.jsxs("span",{children:["+",R.rewardAmount]}),R.rewardType==="coins"&&_.jsx(Zs,{className:"w-4 h-4 text-amber-400"}),R.rewardType==="gems"&&_.jsx(Jr,{className:"w-4 h-4 text-cyan-400"})]}),R.claimed?_.jsxs("span",{className:"text-xs font-bold text-emerald-400 flex items-center gap-1",children:[_.jsx(gp,{className:"w-4 h-4"}),_.jsx("span",{children:"Unlocked"})]}):_.jsx("button",{onClick:()=>{nt.playVictory(),s(R.id)},disabled:!b,className:"px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs disabled:opacity-30",children:"Claim"})]})]},R.id)})}),c&&_.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md",children:_.jsxs("form",{onSubmit:M,className:"w-full max-w-sm p-6 rounded-3xl bg-slate-900 border border-amber-500/40 text-center flex flex-col gap-4",children:[_.jsx("h3",{className:"text-2xl font-black text-white",children:"UPGRADE ACCOUNT"}),_.jsx("p",{className:"text-xs text-slate-300",children:"Link your guest progress to a permanent account with cloud saves!"}),_.jsx("input",{type:"text",required:!0,value:p,onChange:R=>m(R.target.value),placeholder:"Desired Username",className:"w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm"}),_.jsx("input",{type:"email",required:!0,value:h,onChange:R=>v(R.target.value),placeholder:"Email address",className:"w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm"}),_.jsxs("div",{className:"flex gap-2 mt-2",children:[_.jsx("button",{type:"button",onClick:()=>f(!1),className:"w-1/3 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-sm font-bold",children:"Cancel"}),_.jsx("button",{type:"submit",className:"w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm",children:"Upgrade Now"})]})]})})]})},m3=({settings:r,onUpdateSettings:e,onClose:i,onLogout:s,onResetData:l})=>{const[c,f]=st.useState(!1),[p,m]=st.useState(!1),h=x=>{const g={...r,musicVolume:x};e(g),nt.setVolumes(x,r.sfxVolume)},v=x=>{const g={...r,sfxVolume:x};e(g),nt.setVolumes(r.musicVolume,x)};return _.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md select-none",children:_.jsxs("div",{className:"w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl flex flex-col gap-5 max-h-[90vh] overflow-y-auto",children:[_.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[_.jsx("h3",{className:"text-xl font-black text-white",children:"GAME SETTINGS"}),_.jsx("button",{onClick:()=>{nt.playClick(),i()},className:"p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors",children:_.jsx(Kv,{className:"w-5 h-5"})})]}),_.jsxs("div",{className:"flex flex-col gap-3",children:[_.jsxs("span",{className:"text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5",children:[_.jsx(EM,{className:"w-4 h-4 text-cyan-400"}),_.jsx("span",{children:"Audio & Music"})]}),_.jsxs("div",{className:"flex flex-col gap-2",children:[_.jsxs("div",{className:"flex items-center justify-between text-xs font-bold text-slate-300",children:[_.jsx("span",{children:"Music Volume"}),_.jsxs("span",{children:[Math.round(r.musicVolume*100),"%"]})]}),_.jsx("input",{type:"range",min:0,max:1,step:.05,value:r.musicVolume,onChange:x=>h(parseFloat(x.target.value)),className:"w-full accent-cyan-400 cursor-pointer"})]}),_.jsxs("div",{className:"flex flex-col gap-2",children:[_.jsxs("div",{className:"flex items-center justify-between text-xs font-bold text-slate-300",children:[_.jsx("span",{children:"Sound Effects (SFX)"}),_.jsxs("span",{children:[Math.round(r.sfxVolume*100),"%"]})]}),_.jsx("input",{type:"range",min:0,max:1,step:.05,value:r.sfxVolume,onChange:x=>v(parseFloat(x.target.value)),className:"w-full accent-amber-400 cursor-pointer"})]})]}),_.jsxs("div",{className:"flex flex-col gap-3 border-t border-slate-800 pt-3",children:[_.jsxs("span",{className:"text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5",children:[_.jsx($S,{className:"w-4 h-4 text-purple-400"}),_.jsx("span",{children:"Graphics & Frame Rate"})]}),_.jsx("div",{className:"grid grid-cols-3 gap-2",children:["low","medium","high"].map(x=>_.jsx("button",{onClick:()=>{nt.playClick(),e({...r,graphicsQuality:x})},className:`py-2 rounded-xl text-xs font-bold capitalize transition-all ${r.graphicsQuality===x?"bg-indigo-600 text-white shadow-md":"bg-slate-800 text-slate-400 hover:bg-slate-700"}`,children:x},x))}),_.jsxs("div",{className:"flex items-center justify-between text-xs font-bold text-slate-300 mt-1",children:[_.jsx("span",{children:"FPS Target Limit"}),_.jsx("div",{className:"flex items-center gap-2",children:[60,120].map(x=>_.jsxs("button",{onClick:()=>{nt.playClick(),e({...r,fpsLimit:x})},className:`px-3 py-1 rounded-lg text-xs font-bold transition-all ${r.fpsLimit===x?"bg-amber-400 text-slate-950 font-black":"bg-slate-800 text-slate-400"}`,children:[x," FPS"]},x))})]})]}),_.jsxs("div",{className:"flex items-center justify-between border-t border-slate-800 pt-3",children:[_.jsxs("div",{className:"flex items-center gap-2",children:[_.jsx(fM,{className:"w-4 h-4 text-indigo-400"}),_.jsx("span",{className:"text-xs font-bold text-slate-300",children:"Mobile Phone Frame View"})]}),_.jsx("button",{onClick:()=>{nt.playClick(),e({...r,deviceFrame:!r.deviceFrame})},className:`w-12 h-6 rounded-full p-1 transition-colors ${r.deviceFrame?"bg-indigo-600":"bg-slate-800"}`,children:_.jsx("div",{className:`w-4 h-4 rounded-full bg-white transition-transform ${r.deviceFrame?"translate-x-6":"translate-x-0"}`})})]}),_.jsxs("div",{className:"border-t border-slate-800 pt-3 flex flex-col gap-2",children:[p&&_.jsx("div",{className:"p-3 rounded-2xl bg-emerald-900/80 border border-emerald-500/80 text-emerald-200 text-xs font-bold text-center animate-bounce shadow-lg",children:"✓ Reset Successful! 50 Energy & Fresh Profile Restored."}),l&&_.jsx(_.Fragment,{children:c?_.jsxs("div",{className:"p-4 rounded-2xl bg-rose-950/80 border border-rose-600/60 flex flex-col gap-3 text-center shadow-xl",children:[_.jsxs("div",{className:"flex items-center justify-center gap-2 text-rose-400 font-black text-xs uppercase tracking-wider",children:[_.jsx(mM,{className:"w-4 h-4 text-rose-400"}),_.jsx("span",{children:"Reset All Game Progress?"})]}),_.jsx("p",{className:"text-xs text-slate-300",children:"This will permanently wipe all levels, coins, gems, unlocked vehicles & heroes. Your chances will be reset to 50."}),_.jsxs("div",{className:"flex gap-2 mt-1",children:[_.jsx("button",{onClick:()=>f(!1),className:"w-1/2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs",children:"Cancel"}),_.jsx("button",{onClick:()=>{nt.playVictory(),l(),f(!1),m(!0),setTimeout(()=>m(!1),4e3)},className:"w-1/2 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs shadow-lg active:scale-95 transition-transform",children:"Yes, Reset Everything"})]})]}):_.jsxs("button",{onClick:()=>{nt.playClick(),f(!0)},className:"w-full py-3 rounded-2xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-800/50 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-colors",children:[_.jsx(aM,{className:"w-4 h-4"}),_.jsx("span",{children:"Reset All Game Data"})]})}),_.jsxs("button",{onClick:()=>{nt.playClick(),s()},className:"w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-colors",children:[_.jsx(QS,{className:"w-4 h-4"}),_.jsx("span",{children:"Switch Account / Logout"})]})]})]})})},g3=({notifications:r,onClaimReward:e,onClose:i})=>_.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md select-none",children:_.jsxs("div",{className:"w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-y-auto",children:[_.jsxs("div",{className:"flex items-center justify-between border-b border-slate-800 pb-3",children:[_.jsxs("div",{className:"flex items-center gap-2",children:[_.jsx(Wv,{className:"w-5 h-5 text-indigo-400"}),_.jsx("h3",{className:"text-xl font-black text-white",children:"NOTIFICATIONS"})]}),_.jsx("button",{onClick:()=>{nt.playClick(),i()},className:"p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white",children:_.jsx(Kv,{className:"w-5 h-5"})})]}),_.jsx("div",{className:"flex flex-col gap-3",children:r.length===0?_.jsx("p",{className:"text-xs text-slate-400 text-center py-6",children:"No new notifications"}):r.map(s=>_.jsxs("div",{className:"p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-2",children:[_.jsxs("div",{className:"flex items-center justify-between",children:[_.jsx("span",{className:"text-xs font-bold text-indigo-300",children:s.title}),_.jsx("span",{className:"text-[10px] text-slate-500",children:s.time})]}),_.jsx("p",{className:"text-xs text-slate-300",children:s.message}),s.claimableReward&&_.jsxs("div",{className:"flex items-center justify-between mt-2 pt-2 border-t border-slate-800/80",children:[_.jsxs("div",{className:"flex items-center gap-1 text-xs font-black text-amber-400",children:[_.jsxs("span",{children:["+",s.claimableReward.amount]}),s.claimableReward.type==="coins"?_.jsx(Zs,{className:"w-4 h-4 text-amber-400"}):_.jsx(Jr,{className:"w-4 h-4 text-cyan-400"})]}),_.jsx("button",{onClick:()=>{nt.playVictory(),e(s.id,s.claimableReward)},className:"px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow active:scale-95",children:"Claim"})]})]},s.id))})]})}),x3=({enabled:r,children:e})=>r?_.jsx("div",{className:"min-h-screen w-full bg-slate-950 flex items-center justify-center p-2 sm:p-6 overflow-x-hidden",children:_.jsxs("div",{className:"relative w-full max-w-[420px] h-[860px] rounded-[50px] border-[10px] border-slate-800 bg-slate-950 shadow-[0_0_60px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col",children:[_.jsxs("div",{className:"absolute top-2 left-1/2 -translate-x-1/2 z-50 w-28 h-6 rounded-full bg-black flex items-center justify-between px-2.5",children:[_.jsx("div",{className:"w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800"}),_.jsx("div",{className:"w-2 h-2 rounded-full bg-indigo-950 border border-indigo-900"})]}),_.jsxs("div",{className:"relative z-40 w-full px-6 pt-3 pb-1 flex items-center justify-between text-[11px] font-bold text-white select-none",children:[_.jsx("span",{children:"9:41"}),_.jsxs("div",{className:"flex items-center gap-1.5",children:[_.jsx(cM,{className:"w-3 h-3 text-white"}),_.jsx(AM,{className:"w-3 h-3 text-white"}),_.jsx(wS,{className:"w-4 h-4 text-white"})]})]}),_.jsx("div",{className:"relative flex-1 w-full h-full overflow-y-auto no-scrollbar",children:e}),_.jsx("div",{className:"relative z-40 w-full py-1.5 bg-slate-950 flex items-center justify-center",children:_.jsx("div",{className:"w-32 h-1 rounded-full bg-slate-600"})})]})}):_.jsx("div",{className:"w-full min-h-screen bg-slate-950",children:e});function v3(){const[r,e]=st.useState(()=>lS()),[i,s]=st.useState(()=>cS()),[l,c]=st.useState(()=>uS()),[f,p]=st.useState(()=>fS()),[m,h]=st.useState(()=>dS()),[v,x]=st.useState(()=>localStorage.getItem("route_rush_launched")==="true"),[g,M]=st.useState("home"),[w,R]=st.useState("runner"),[b,y]=st.useState(!1),[P,O]=st.useState(!1),[C,I]=st.useState(!1),[L,F]=st.useState(null);st.useEffect(()=>{rS.hide().catch(()=>{}),Px.setStyle({style:lh.Dark}).catch(()=>{}),Px.setBackgroundColor({color:"#0b0b14"}).catch(()=>{});const Q=Lx.addListener("backButton",()=>{P?O(!1):C?I(!1):b?y(!1):g!=="home"?M("home"):Lx.exitApp()});return()=>{Q.then(_e=>_e.remove())}},[P,C,b,g]);const T=Q=>{F(Q),setTimeout(()=>F(_e=>_e===Q?null:_e),3500)};st.useEffect(()=>{Zo(r)},[r]),st.useEffect(()=>{Fx(i)},[i]),st.useEffect(()=>{Bx(l)},[l]),st.useEffect(()=>{Gx(f)},[f]),st.useEffect(()=>{Hx(m)},[m]);const U=Q=>{const _e=Rr(Q);e(_e),Zo(_e),x(!0),localStorage.setItem("route_rush_launched","true"),T(`Welcome ${Q}! You have 50 chances to play!`)},V=Q=>{const _e=localStorage.getItem("route_rush_player_profile");let Ce;if(_e)try{const Ue=JSON.parse(_e);Ce={...Rr(Q),...Ue,username:Q,isGuest:!1,energy:Math.max(Ue.energy||50,50),maxEnergy:50}}catch{Ce={...Rr(Q),isGuest:!1}}else Ce={...Rr(Q),isGuest:!1};e(Ce),Zo(Ce),x(!0),localStorage.setItem("route_rush_launched","true"),T(`Logged in as ${Q}!`)},k=()=>{zx();const Q=Rr("RacerGuest");e(Q),Zo(Q),x(!1),O(!1),I(!1),M("home"),y(!1)},W=()=>{zx();const Q=Rr("RacerGuest");e(Q),s(eu),c(ch),p(uh),h(dh),Zo(Q),Fx(eu),Bx(ch),Gx(uh),Hx(dh),x(!1),O(!1),I(!1),M("home"),y(!1),T("All game data reset! 50 Chances restored.")},re=()=>{if(r.energy<=0){T("Energy empty! Refill in Shop or wait for bonus.");return}e(Q=>({...Q,energy:Math.max(0,Q.energy-1)})),y(!0)},oe=(Q,_e,Ce,Ue,He)=>{y(!1),e(Ye=>{var ct;const ft=Ye.xp+Ce;let ee=Ye.level,Pe=Ye.maxXp;ft>=Ye.maxXp&&(ee+=1,Pe+=500);const Qe={...Ye.completedLevels},Je=((ct=Qe[Ye.currentLevel])==null?void 0:ct.stars)||0;return He>Je&&(Qe[Ye.currentLevel]={stars:He,highScore:Ue*10}),{...Ye,coins:Ye.coins+Q,gems:Ye.gems+_e,xp:ft,level:ee,maxXp:Pe,totalCoinsCollected:Ye.totalCoinsCollected+Q,totalDistanceDriven:Ye.totalDistanceDriven+Ue,totalLevelsCompleted:Ye.totalLevelsCompleted+1,completedLevels:Qe,currentLevel:He>=1?Ye.currentLevel+1:Ye.currentLevel}})},te=Q=>{if(Q.currency==="coins"&&r.coins<Q.price){T("Not enough Coins!");return}if(Q.currency==="gems"&&r.gems<Q.price){T("Not enough Gems!");return}e(_e=>{const Ce={..._e};return Q.currency==="coins"&&(Ce.coins-=Q.price),Q.currency==="gems"&&(Ce.gems-=Q.price),Q.category==="character"&&Q.itemRefId?Ce.unlockedCharacters.includes(Q.itemRefId)||Ce.unlockedCharacters.push(Q.itemRefId):Q.category==="car"&&Q.itemRefId?Ce.unlockedCars.includes(Q.itemRefId)||Ce.unlockedCars.push(Q.itemRefId):Q.category==="gems"&&Q.amount?Ce.gems+=Q.amount:Q.category==="coins"&&Q.amount?Ce.coins+=Q.amount:Q.category==="bundle"&&(Ce.coins+=2e4,Ce.keys+=5),Ce}),T(`Purchased ${Q.name}!`)},G=(Q,_e,Ce)=>{e(Ue=>{const He=Ue.carUpgrades[Q]||{engine:1,nitro:1,handling:1,brakes:1,suspension:1},Ye={...He,[_e]:He[_e]+1};return{...Ue,coins:Ue.coins-Ce,carUpgrades:{...Ue.carUpgrades,[Q]:Ye}}}),T("Car upgraded successfully!")},X=(Q,_e)=>{e(Ce=>({...Ce,carPaints:{...Ce.carPaints,[Q]:_e}}))},$=(Q,_e)=>{e(Ce=>({...Ce,carNeon:{...Ce.carNeon,[Q]:_e}}))},se=Q=>{if(Q.currency==="coins"&&r.coins<Q.price){T("Not enough coins!");return}if(Q.currency==="gems"&&r.gems<Q.price){T("Not enough gems!");return}e(_e=>{const Ce={..._e};return Q.currency==="coins"&&(Ce.coins-=Q.price),Q.currency==="gems"&&(Ce.gems-=Q.price),Ce.unlockedCars.includes(Q.id)||Ce.unlockedCars.push(Q.id),Ce.selectedCarId=Q.id,Ce}),T(`Unlocked ${Q.name}!`)},B=Q=>{if(Q.currency==="coins"&&r.coins<Q.price){T("Not enough coins!");return}if(Q.currency==="gems"&&r.gems<Q.price){T("Not enough gems!");return}e(_e=>{const Ce={..._e};return Q.currency==="coins"&&(Ce.coins-=Q.price),Q.currency==="gems"&&(Ce.gems-=Q.price),Ce.unlockedCharacters.includes(Q.id)||Ce.unlockedCharacters.push(Q.id),Ce.selectedCharacterId=Q.id,Ce}),T(`Unlocked ${Q.name}!`)},E=Q=>{const _e=l.find(Ce=>Ce.id===Q);_e&&(c(Ce=>Ce.map(Ue=>Ue.id===Q?{...Ue,claimed:!0}:Ue)),e(Ce=>{const Ue={...Ce};return _e.rewardType==="coins"&&(Ue.coins+=_e.rewardAmount),_e.rewardType==="gems"&&(Ue.gems+=_e.rewardAmount),_e.rewardType==="keys"&&(Ue.keys+=_e.rewardAmount),Ue}))},H=Q=>{const _e=f.find(Ce=>Ce.id===Q);_e&&(p(Ce=>Ce.map(Ue=>Ue.id===Q?{...Ue,claimed:!0}:Ue)),e(Ce=>{const Ue={...Ce};return _e.rewardType==="coins"&&(Ue.coins+=_e.rewardAmount),_e.rewardType==="gems"&&(Ue.gems+=_e.rewardAmount),_e.rewardType==="keys"&&(Ue.keys+=_e.rewardAmount),Ue}))},ce=(Q,_e,Ce)=>{e(Ue=>({...Ue,coins:Ue.coins+Q,gems:Ue.gems+_e,keys:Ue.keys+Ce}))},Se=(Q,_e)=>{h(Ce=>Ce.map(Ue=>Ue.id===Q?{...Ue,claimableReward:void 0,read:!0}:Ue)),e(Ce=>({...Ce,coins:_e.type==="coins"?Ce.coins+_e.amount:Ce.coins,gems:_e.type==="gems"?Ce.gems+_e.amount:Ce.gems}))},Ae=(Q,_e)=>{e(Ce=>({...Ce,username:Q,email:_e,isGuest:!1})),T("Account upgraded to permanent status with Cloud Sync!")},K=m.filter(Q=>!Q.read||Q.claimableReward).length,le=l.filter(Q=>Q.current>=Q.target&&!Q.claimed).length,xe=mp(r.currentLevel),Le=jv(r.currentLevel,w);return v?_.jsx(x3,{enabled:i.deviceFrame,children:_.jsxs("div",{className:"relative w-full min-h-screen bg-slate-950 font-sans text-white antialiased flex flex-col justify-between",children:[L&&_.jsx("div",{className:"fixed top-16 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs shadow-[0_0_25px_rgba(251,191,36,0.6)] border border-amber-200 flex items-center gap-2 animate-bounce",children:_.jsxs("span",{children:["⚡ ",L]})}),b?_.jsx(l3,{mode:w,world:xe,profile:r,levelData:Le,onFinishGame:oe,onQuitToHome:()=>y(!1)}):_.jsxs(_.Fragment,{children:[_.jsx(NM,{profile:r,unreadNotificationsCount:K,onOpenSettings:()=>O(!0),onOpenNotifications:()=>I(!0),onTabSelect:Q=>M(Q)}),_.jsxs("main",{className:"flex-1 w-full pt-2",children:[g==="home"&&_.jsx(LM,{profile:r,selectedMode:w,onSelectMode:Q=>R(Q),onStartGame:re,onNavigateToGarage:()=>M("garage"),onNavigateToHeroes:()=>M("characters")}),g==="shop"&&_.jsx(c3,{profile:r,onBuyItem:te}),g==="garage"&&_.jsx(u3,{profile:r,onSelectCar:Q=>e(_e=>({..._e,selectedCarId:Q})),onUpgradeCar:G,onChangePaint:X,onChangeNeon:$,onUnlockCar:se}),g==="characters"&&_.jsx(f3,{profile:r,onSelectCharacter:Q=>e(_e=>({..._e,selectedCharacterId:Q})),onUnlockCharacter:B}),g==="missions"&&_.jsx(d3,{missions:l,onClaimMission:E}),g==="rewards"&&_.jsx(h3,{onAddReward:ce}),g==="profile"&&_.jsx(p3,{profile:r,achievements:f,onUpgradeGuestAccount:Ae,onClaimAchievement:H,onSyncCloudSave:()=>{}})]}),_.jsx(DM,{activeTab:g,onTabChange:Q=>M(Q),claimableMissionsCount:le})]}),P&&_.jsx(m3,{settings:i,onUpdateSettings:Q=>s(Q),onClose:()=>O(!1),onLogout:k,onResetData:W}),C&&_.jsx(g3,{notifications:m,onClaimReward:Se,onClose:()=>I(!1)})]})}):_.jsx(UM,{onStartAsGuest:U,onLogin:V})}qb.createRoot(document.getElementById("root")).render(_.jsx(st.StrictMode,{children:_.jsx(v3,{})}));export{ou as I,rp as N,cp as W};
