import{W as n}from"./index-DuHXa3dx.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
