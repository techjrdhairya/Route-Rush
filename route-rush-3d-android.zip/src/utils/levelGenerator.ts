import { LevelData, WorldTheme, GameMode } from '../types';
import { WORLDS } from '../data/mockData';

export function getWorldForLevel(levelNumber: number): WorldTheme {
  const worldIndex = Math.min(Math.floor((levelNumber - 1) / 50), WORLDS.length - 1);
  return WORLDS[worldIndex];
}

export function generateLevelData(levelNumber: number, forcedMode?: GameMode): LevelData {
  const world = getWorldForLevel(levelNumber);
  // Alternate or balance modes based on level number odd/even if not forced
  const mode: GameMode = forcedMode || (levelNumber % 2 === 1 ? 'runner' : 'racer');

  const baseTargetDistance = 300 + (levelNumber * 15);
  const baseTargetCoins = 20 + Math.floor(levelNumber * 1.5);
  const difficultyMultiplier = 1 + (levelNumber * 0.005);
  const obstacleDensity = Math.min(0.2 + (levelNumber * 0.001), 0.85);
  const speedMultiplier = Math.min(1.0 + (levelNumber * 0.002), 2.2);

  const rewardCoins = 100 + Math.floor(levelNumber * 8);
  const rewardXp = 50 + Math.floor(levelNumber * 4);
  const rewardGems = levelNumber % 5 === 0 ? Math.min(5 + Math.floor(levelNumber / 10), 50) : undefined;

  return {
    levelNumber,
    worldId: world.id,
    mode,
    targetDistance: Math.round(baseTargetDistance),
    targetCoins: baseTargetCoins,
    difficultyMultiplier,
    obstacleDensity,
    speedMultiplier,
    rewardCoins,
    rewardXp,
    rewardGems,
  };
}

export function calculateLevelStars(coinsCollected: number, distanceCovered: number, level: LevelData): number {
  if (distanceCovered < level.targetDistance * 0.5) return 0;
  if (distanceCovered < level.targetDistance) return 1;

  if (coinsCollected >= level.targetCoins) return 3;
  return 2;
}
