import { PlayerProfile, GameSettings, Mission, Achievement, AppNotification } from '../types';
import { INITIAL_MISSIONS, INITIAL_ACHIEVEMENTS } from '../data/mockData';

const PROFILE_KEY = 'route_rush_player_profile';
const SETTINGS_KEY = 'route_rush_game_settings';
const MISSIONS_KEY = 'route_rush_missions';
const ACHIEVEMENTS_KEY = 'route_rush_achievements';
const NOTIFICATIONS_KEY = 'route_rush_notifications';

export const DEFAULT_PROFILE: PlayerProfile = {
  id: 'guest_' + Math.random().toString(36).substring(2, 9),
  isGuest: true,
  username: 'RacerGuest',
  avatar: '🏃‍♂️',
  level: 1,
  xp: 0,
  maxXp: 500,
  coins: 1000,
  gems: 20,
  keys: 1,
  eventTokens: 0,
  energy: 50,
  maxEnergy: 50,
  selectedCharacterId: 'char-explorer',
  selectedCarId: 'car-sports',
  unlockedCharacters: ['char-explorer'],
  unlockedCars: ['car-sports'],
  characterSkins: { 'char-explorer': 'default' },
  carPaints: { 'car-sports': '#ef4444' },
  carNeon: { 'car-sports': '#00f0ff' },
  carUpgrades: {
    'car-sports': { engine: 1, nitro: 1, handling: 1, brakes: 1, suspension: 1 },
  },
  equippedPets: {},
  equippedTrails: {},
  completedLevels: {},
  currentLevel: 1,
  highScoreRunner: 0,
  highScoreRacer: 0,
  totalCoinsCollected: 0,
  totalDistanceDriven: 0,
  totalJumps: 0,
  totalLevelsCompleted: 0,
  dailyStreak: 1,
  lastLoginDate: new Date().toISOString().split('T')[0],
  savedAt: new Date().toISOString(),
};

export function createFreshProfile(username = 'RacerGuest'): PlayerProfile {
  return {
    ...DEFAULT_PROFILE,
    id: 'guest_' + Math.random().toString(36).substring(2, 9),
    username,
    energy: 50,
    maxEnergy: 50,
    coins: 1000,
    gems: 20,
    keys: 1,
    level: 1,
    xp: 0,
    maxXp: 500,
    selectedCharacterId: 'char-explorer',
    selectedCarId: 'car-sports',
    unlockedCharacters: ['char-explorer'],
    unlockedCars: ['car-sports'],
    carPaints: { 'car-sports': '#ef4444' },
    carNeon: { 'car-sports': '#00f0ff' },
    carUpgrades: {
      'car-sports': { engine: 1, nitro: 1, handling: 1, brakes: 1, suspension: 1 },
    },
    completedLevels: {},
    currentLevel: 1,
    highScoreRunner: 0,
    highScoreRacer: 0,
    totalCoinsCollected: 0,
    totalDistanceDriven: 0,
    totalJumps: 0,
    totalLevelsCompleted: 0,
    dailyStreak: 1,
    savedAt: new Date().toISOString(),
  };
}

export function resetAllStorage(): void {
  try {
    localStorage.removeItem(PROFILE_KEY);
    localStorage.removeItem(SETTINGS_KEY);
    localStorage.removeItem(MISSIONS_KEY);
    localStorage.removeItem(ACHIEVEMENTS_KEY);
    localStorage.removeItem(NOTIFICATIONS_KEY);
    localStorage.removeItem('route_rush_launched');
    localStorage.clear();
  } catch (err) {
    console.warn('Failed to reset storage:', err);
  }
}

export const DEFAULT_SETTINGS: GameSettings = {
  musicVolume: 0.5,
  sfxVolume: 0.8,
  graphicsQuality: 'high',
  fpsLimit: 60,
  controlsMode: 'touch',
  language: 'en',
  deviceFrame: false, // Default full responsive view, toggleable
  vibration: true,
  cloudSync: true,
};

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'n-1',
    title: 'Daily Welcome Bonus!',
    message: 'Claim 500 Coins & 10 Gems for logging in today!',
    time: 'Just now',
    type: 'reward',
    read: false,
    claimableReward: { type: 'coins', amount: 500 },
  },
  {
    id: 'n-2',
    title: 'Seasonal Event Live: Cyber Rush!',
    message: 'Participate in the Neon Cyber City tournament for exclusive rewards.',
    time: '2 hours ago',
    type: 'event',
    read: false,
  },
  {
    id: 'n-3',
    title: 'Level 5 Milestone Unlocked!',
    message: 'You have unlocked World 1 Green Valley challenges.',
    time: '1 day ago',
    type: 'system',
    read: true,
  },
];

export function loadProfile(): PlayerProfile {
  try {
    const data = localStorage.getItem(PROFILE_KEY);
    if (data) {
      const parsed = JSON.parse(data);
      if (!parsed.maxEnergy || parsed.maxEnergy < 50) {
        parsed.maxEnergy = 50;
      }
      if (typeof parsed.energy !== 'number' || parsed.energy < 50) {
        parsed.energy = 50;
      }
      return { ...DEFAULT_PROFILE, ...parsed };
    }
  } catch (err) {
    console.warn('Failed to load profile from storage:', err);
  }
  return { ...DEFAULT_PROFILE, energy: 50, maxEnergy: 50 };
}

export function saveProfile(profile: PlayerProfile): void {
  try {
    const updated = { ...profile, savedAt: new Date().toISOString() };
    localStorage.setItem(PROFILE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('Failed to save profile:', err);
  }
}

export function loadSettings(): GameSettings {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    if (data) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    }
  } catch (err) {
    console.warn('Failed to load settings:', err);
  }
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.warn('Failed to save settings:', err);
  }
}

export function loadMissions(): Mission[] {
  try {
    const data = localStorage.getItem(MISSIONS_KEY);
    if (data) return JSON.parse(data);
  } catch (err) {
    console.warn('Failed to load missions:', err);
  }
  return INITIAL_MISSIONS;
}

export function saveMissions(missions: Mission[]): void {
  try {
    localStorage.setItem(MISSIONS_KEY, JSON.stringify(missions));
  } catch (err) {
    console.warn('Failed to save missions:', err);
  }
}

export function loadAchievements(): Achievement[] {
  try {
    const data = localStorage.getItem(ACHIEVEMENTS_KEY);
    if (data) return JSON.parse(data);
  } catch (err) {
    console.warn('Failed to load achievements:', err);
  }
  return INITIAL_ACHIEVEMENTS;
}

export function saveAchievements(achievements: Achievement[]): void {
  try {
    localStorage.setItem(ACHIEVEMENTS_KEY, JSON.stringify(achievements));
  } catch (err) {
    console.warn('Failed to save achievements:', err);
  }
}

export function loadNotifications(): AppNotification[] {
  try {
    const data = localStorage.getItem(NOTIFICATIONS_KEY);
    if (data) return JSON.parse(data);
  } catch (err) {
    console.warn('Failed to load notifications:', err);
  }
  return INITIAL_NOTIFICATIONS;
}

export function saveNotifications(notifications: AppNotification[]): void {
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
  } catch (err) {
    console.warn('Failed to save notifications:', err);
  }
}
