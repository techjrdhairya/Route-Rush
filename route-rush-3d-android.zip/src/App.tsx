import React, { useState, useEffect } from 'react';
import { App as CapacitorApp } from '@capacitor/app';
import { SplashScreen as NativeSplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';
import {
  PlayerProfile,
  GameSettings,
  ActiveTab,
  GameMode,
  ShopItem,
  CarItem,
  CharacterItem,
  CarUpgradeState,
  AppNotification,
  Mission,
  Achievement,
} from './types';
import {
  loadProfile,
  saveProfile,
  loadSettings,
  saveSettings,
  loadMissions,
  saveMissions,
  loadAchievements,
  saveAchievements,
  loadNotifications,
  saveNotifications,
  DEFAULT_PROFILE,
  DEFAULT_SETTINGS,
  INITIAL_NOTIFICATIONS,
  resetAllStorage,
  createFreshProfile,
} from './utils/storage';
import { INITIAL_MISSIONS, INITIAL_ACHIEVEMENTS } from './data/mockData';
import { getWorldForLevel, generateLevelData, calculateLevelStars } from './utils/levelGenerator';
import { TopBar } from './components/ui/TopBar';
import { BottomNav } from './components/ui/BottomNav';
import { SplashScreen } from './components/ui/SplashScreen';
import { HomeView } from './components/views/HomeView';
import { GameView } from './components/views/GameView';
import { ShopView } from './components/views/ShopView';
import { GarageView } from './components/views/GarageView';
import { CharactersView } from './components/views/CharactersView';
import { MissionsView } from './components/views/MissionsView';
import { RewardsView } from './components/views/RewardsView';
import { ProfileView } from './components/views/ProfileView';
import { SettingsModal } from './components/views/SettingsModal';
import { NotificationsModal } from './components/views/NotificationsModal';
import { DeviceFrame } from './components/ui/DeviceFrame';

export default function App() {
  const [profile, setProfile] = useState<PlayerProfile>(() => loadProfile());
  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());
  const [missions, setMissions] = useState<Mission[]>(() => loadMissions());
  const [achievements, setAchievements] = useState<Achievement[]>(() => loadAchievements());
  const [notifications, setNotifications] = useState<AppNotification[]>(() => loadNotifications());

  const [hasLaunched, setHasLaunched] = useState<boolean>(() => {
    return localStorage.getItem('route_rush_launched') === 'true';
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedMode, setSelectedMode] = useState<GameMode>('runner');
  const [isPlayingGame, setIsPlayingGame] = useState(false);

  const [showSettings, setShowSettings] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Native shell setup: hide splash once React has mounted, force a dark
  // status bar to match the app theme, and route the Android hardware back
  // button through in-app navigation instead of exiting the app abruptly.
  useEffect(() => {
    NativeSplashScreen.hide().catch(() => {});
    StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
    StatusBar.setBackgroundColor({ color: '#0b0b14' }).catch(() => {});

    const backListener = CapacitorApp.addListener('backButton', () => {
      if (showSettings) {
        setShowSettings(false);
      } else if (showNotifications) {
        setShowNotifications(false);
      } else if (isPlayingGame) {
        setIsPlayingGame(false);
      } else if (activeTab !== 'home') {
        setActiveTab('home');
      } else {
        CapacitorApp.exitApp();
      }
    });

    return () => {
      backListener.then((listener) => listener.remove());
    };
  }, [showSettings, showNotifications, isPlayingGame, activeTab]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage((prev) => (prev === msg ? null : prev)), 3500);
  };

  // Auto-save state updates
  useEffect(() => {
    saveProfile(profile);
  }, [profile]);

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveMissions(missions);
  }, [missions]);

  useEffect(() => {
    saveAchievements(achievements);
  }, [achievements]);

  useEffect(() => {
    saveNotifications(notifications);
  }, [notifications]);

  // Handle First Launch Splash Screen Handlers
  const handleStartAsGuest = (nickname: string) => {
    // Create a fresh clean guest profile with 50 energy and default state
    const newGuestProf = createFreshProfile(nickname);
    setProfile(newGuestProf);
    saveProfile(newGuestProf);
    setHasLaunched(true);
    localStorage.setItem('route_rush_launched', 'true');
    showToast(`Welcome ${nickname}! You have 50 chances to play!`);
  };

  const handleLogin = (username: string) => {
    // Check if user profile exists or create fresh account
    const saved = localStorage.getItem('route_rush_player_profile');
    let userProf: PlayerProfile;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        userProf = {
          ...createFreshProfile(username),
          ...parsed,
          username,
          isGuest: false,
          energy: Math.max(parsed.energy || 50, 50),
          maxEnergy: 50,
        };
      } catch {
        userProf = { ...createFreshProfile(username), isGuest: false };
      }
    } else {
      userProf = { ...createFreshProfile(username), isGuest: false };
    }
    setProfile(userProf);
    saveProfile(userProf);
    setHasLaunched(true);
    localStorage.setItem('route_rush_launched', 'true');
    showToast(`Logged in as ${username}!`);
  };

  const handleLogout = () => {
    resetAllStorage();
    const fresh = createFreshProfile('RacerGuest');
    setProfile(fresh);
    saveProfile(fresh);
    setHasLaunched(false);
    setShowSettings(false);
    setShowNotifications(false);
    setActiveTab('home');
    setIsPlayingGame(false);
  };

  const handleResetData = () => {
    resetAllStorage();
    const freshProf = createFreshProfile('RacerGuest');
    setProfile(freshProf);
    setSettings(DEFAULT_SETTINGS);
    setMissions(INITIAL_MISSIONS);
    setAchievements(INITIAL_ACHIEVEMENTS);
    setNotifications(INITIAL_NOTIFICATIONS);
    saveProfile(freshProf);
    saveSettings(DEFAULT_SETTINGS);
    saveMissions(INITIAL_MISSIONS);
    saveAchievements(INITIAL_ACHIEVEMENTS);
    saveNotifications(INITIAL_NOTIFICATIONS);
    setHasLaunched(false);
    setShowSettings(false);
    setShowNotifications(false);
    setActiveTab('home');
    setIsPlayingGame(false);
    showToast('All game data reset! 50 Chances restored.');
  };

  // Game Handlers
  const handleStartGame = () => {
    if (profile.energy <= 0) {
      showToast('Energy empty! Refill in Shop or wait for bonus.');
      return;
    }
    setProfile((prev) => ({ ...prev, energy: Math.max(0, prev.energy - 1) }));
    setIsPlayingGame(true);
  };

  const handleFinishGame = (
    coinsEarned: number,
    gemsEarned: number,
    xpEarned: number,
    distanceCovered: number,
    starsEarned: number
  ) => {
    setIsPlayingGame(false);

    setProfile((prev) => {
      const newXp = prev.xp + xpEarned;
      let newLevel = prev.level;
      let newMaxXp = prev.maxXp;

      if (newXp >= prev.maxXp) {
        newLevel += 1;
        newMaxXp += 500;
      }

      const completed = { ...prev.completedLevels };
      const prevStars = completed[prev.currentLevel]?.stars || 0;
      if (starsEarned > prevStars) {
        completed[prev.currentLevel] = { stars: starsEarned, highScore: distanceCovered * 10 };
      }

      return {
        ...prev,
        coins: prev.coins + coinsEarned,
        gems: prev.gems + gemsEarned,
        xp: newXp,
        level: newLevel,
        maxXp: newMaxXp,
        totalCoinsCollected: prev.totalCoinsCollected + coinsEarned,
        totalDistanceDriven: prev.totalDistanceDriven + distanceCovered,
        totalLevelsCompleted: prev.totalLevelsCompleted + 1,
        completedLevels: completed,
        currentLevel: starsEarned >= 1 ? prev.currentLevel + 1 : prev.currentLevel,
      };
    });
  };

  // Shop Item Purchase Handler
  const handleBuyItem = (item: ShopItem) => {
    if (item.currency === 'coins' && profile.coins < item.price) {
      showToast('Not enough Coins!');
      return;
    }
    if (item.currency === 'gems' && profile.gems < item.price) {
      showToast('Not enough Gems!');
      return;
    }

    setProfile((prev) => {
      const updated = { ...prev };
      if (item.currency === 'coins') updated.coins -= item.price;
      if (item.currency === 'gems') updated.gems -= item.price;

      if (item.category === 'character' && item.itemRefId) {
        if (!updated.unlockedCharacters.includes(item.itemRefId)) {
          updated.unlockedCharacters.push(item.itemRefId);
        }
      } else if (item.category === 'car' && item.itemRefId) {
        if (!updated.unlockedCars.includes(item.itemRefId)) {
          updated.unlockedCars.push(item.itemRefId);
        }
      } else if (item.category === 'gems' && item.amount) {
        updated.gems += item.amount;
      } else if (item.category === 'coins' && item.amount) {
        updated.coins += item.amount;
      } else if (item.category === 'bundle') {
        updated.coins += 20000;
        updated.keys += 5;
      }

      return updated;
    });

    showToast(`Purchased ${item.name}!`);
  };

  // Garage Car Handlers
  const handleUpgradeCar = (carId: string, stat: keyof CarUpgradeState, cost: number) => {
    setProfile((prev) => {
      const currUpgrades = prev.carUpgrades[carId] || {
        engine: 1,
        nitro: 1,
        handling: 1,
        brakes: 1,
        suspension: 1,
      };
      const updatedUpgrades = { ...currUpgrades, [stat]: currUpgrades[stat] + 1 };
      return {
        ...prev,
        coins: prev.coins - cost,
        carUpgrades: { ...prev.carUpgrades, [carId]: updatedUpgrades },
      };
    });
    showToast('Car upgraded successfully!');
  };

  const handleChangePaint = (carId: string, colorHex: string) => {
    setProfile((prev) => ({
      ...prev,
      carPaints: { ...prev.carPaints, [carId]: colorHex },
    }));
  };

  const handleChangeNeon = (carId: string, colorHex: string) => {
    setProfile((prev) => ({
      ...prev,
      carNeon: { ...prev.carNeon, [carId]: colorHex },
    }));
  };

  const handleUnlockCar = (car: CarItem) => {
    if (car.currency === 'coins' && profile.coins < car.price) {
      showToast('Not enough coins!');
      return;
    }
    if (car.currency === 'gems' && profile.gems < car.price) {
      showToast('Not enough gems!');
      return;
    }

    setProfile((prev) => {
      const updated = { ...prev };
      if (car.currency === 'coins') updated.coins -= car.price;
      if (car.currency === 'gems') updated.gems -= car.price;
      if (!updated.unlockedCars.includes(car.id)) updated.unlockedCars.push(car.id);
      updated.selectedCarId = car.id;
      return updated;
    });
    showToast(`Unlocked ${car.name}!`);
  };

  const handleUnlockCharacter = (char: CharacterItem) => {
    if (char.currency === 'coins' && profile.coins < char.price) {
      showToast('Not enough coins!');
      return;
    }
    if (char.currency === 'gems' && profile.gems < char.price) {
      showToast('Not enough gems!');
      return;
    }

    setProfile((prev) => {
      const updated = { ...prev };
      if (char.currency === 'coins') updated.coins -= char.price;
      if (char.currency === 'gems') updated.gems -= char.price;
      if (!updated.unlockedCharacters.includes(char.id)) updated.unlockedCharacters.push(char.id);
      updated.selectedCharacterId = char.id;
      return updated;
    });
    showToast(`Unlocked ${char.name}!`);
  };

  // Missions & Rewards Claims
  const handleClaimMission = (missionId: string) => {
    const targetMission = missions.find((m) => m.id === missionId);
    if (!targetMission) return;

    setMissions((prev) =>
      prev.map((m) => (m.id === missionId ? { ...m, claimed: true } : m))
    );

    setProfile((prev) => {
      const updated = { ...prev };
      if (targetMission.rewardType === 'coins') updated.coins += targetMission.rewardAmount;
      if (targetMission.rewardType === 'gems') updated.gems += targetMission.rewardAmount;
      if (targetMission.rewardType === 'keys') updated.keys += targetMission.rewardAmount;
      return updated;
    });
  };

  const handleClaimAchievement = (achId: string) => {
    const targetAch = achievements.find((a) => a.id === achId);
    if (!targetAch) return;

    setAchievements((prev) =>
      prev.map((a) => (a.id === achId ? { ...a, claimed: true } : a))
    );

    setProfile((prev) => {
      const updated = { ...prev };
      if (targetAch.rewardType === 'coins') updated.coins += targetAch.rewardAmount;
      if (targetAch.rewardType === 'gems') updated.gems += targetAch.rewardAmount;
      if (targetAch.rewardType === 'keys') updated.keys += targetAch.rewardAmount;
      return updated;
    });
  };

  const handleAddSpinReward = (coins: number, gems: number, keys: number) => {
    setProfile((prev) => ({
      ...prev,
      coins: prev.coins + coins,
      gems: prev.gems + gems,
      keys: prev.keys + keys,
    }));
  };

  const handleClaimNotifReward = (
    notifId: string,
    reward: { type: 'coins' | 'gems'; amount: number }
  ) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notifId ? { ...n, claimableReward: undefined, read: true } : n))
    );

    setProfile((prev) => ({
      ...prev,
      coins: reward.type === 'coins' ? prev.coins + reward.amount : prev.coins,
      gems: reward.type === 'gems' ? prev.gems + reward.amount : prev.gems,
    }));
  };

  const handleUpgradeGuestAccount = (username: string, email: string) => {
    setProfile((prev) => ({
      ...prev,
      username,
      email,
      isGuest: false,
    }));
    showToast('Account upgraded to permanent status with Cloud Sync!');
  };

  const unreadNotifsCount = notifications.filter((n) => !n.read || n.claimableReward).length;
  const claimableMissionsCount = missions.filter((m) => m.current >= m.target && !m.claimed).length;

  const currentWorld = getWorldForLevel(profile.currentLevel);
  const currentLevelData = generateLevelData(profile.currentLevel, selectedMode);

  if (!hasLaunched) {
    return <SplashScreen onStartAsGuest={handleStartAsGuest} onLogin={handleLogin} />;
  }

  return (
    <DeviceFrame enabled={settings.deviceFrame}>
      <div className="relative w-full min-h-screen bg-slate-950 font-sans text-white antialiased flex flex-col justify-between">
        {/* Toast Notification Overlay */}
        {toastMessage && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs shadow-[0_0_25px_rgba(251,191,36,0.6)] border border-amber-200 flex items-center gap-2 animate-bounce">
            <span>⚡ {toastMessage}</span>
          </div>
        )}
        {/* Active Gameplay Mode View */}
        {isPlayingGame ? (
          <GameView
            mode={selectedMode}
            world={currentWorld}
            profile={profile}
            levelData={currentLevelData}
            onFinishGame={handleFinishGame}
            onQuitToHome={() => setIsPlayingGame(false)}
          />
        ) : (
          <>
            {/* Top Navigation Bar */}
            <TopBar
              profile={profile}
              unreadNotificationsCount={unreadNotifsCount}
              onOpenSettings={() => setShowSettings(true)}
              onOpenNotifications={() => setShowNotifications(true)}
              onTabSelect={(t) => setActiveTab(t)}
            />

            {/* Active View Router Content */}
            <main className="flex-1 w-full pt-2">
              {activeTab === 'home' && (
                <HomeView
                  profile={profile}
                  selectedMode={selectedMode}
                  onSelectMode={(m) => setSelectedMode(m)}
                  onStartGame={handleStartGame}
                  onNavigateToGarage={() => setActiveTab('garage')}
                  onNavigateToHeroes={() => setActiveTab('characters')}
                />
              )}

              {activeTab === 'shop' && (
                <ShopView profile={profile} onBuyItem={handleBuyItem} />
              )}

              {activeTab === 'garage' && (
                <GarageView
                  profile={profile}
                  onSelectCar={(carId) => setProfile((p) => ({ ...p, selectedCarId: carId }))}
                  onUpgradeCar={handleUpgradeCar}
                  onChangePaint={handleChangePaint}
                  onChangeNeon={handleChangeNeon}
                  onUnlockCar={handleUnlockCar}
                />
              )}

              {activeTab === 'characters' && (
                <CharactersView
                  profile={profile}
                  onSelectCharacter={(cId) =>
                    setProfile((p) => ({ ...p, selectedCharacterId: cId }))
                  }
                  onUnlockCharacter={handleUnlockCharacter}
                />
              )}

              {activeTab === 'missions' && (
                <MissionsView missions={missions} onClaimMission={handleClaimMission} />
              )}

              {activeTab === 'rewards' && (
                <RewardsView onAddReward={handleAddSpinReward} />
              )}

              {activeTab === 'profile' && (
                <ProfileView
                  profile={profile}
                  achievements={achievements}
                  onUpgradeGuestAccount={handleUpgradeGuestAccount}
                  onClaimAchievement={handleClaimAchievement}
                  onSyncCloudSave={() => {}}
                />
              )}
            </main>

            {/* Bottom Navigation Dock */}
            <BottomNav
              activeTab={activeTab}
              onTabChange={(t) => setActiveTab(t)}
              claimableMissionsCount={claimableMissionsCount}
            />
          </>
        )}

        {/* Settings Modal */}
        {showSettings && (
          <SettingsModal
            settings={settings}
            onUpdateSettings={(s) => setSettings(s)}
            onClose={() => setShowSettings(false)}
            onLogout={handleLogout}
            onResetData={handleResetData}
          />
        )}

        {/* Notifications Modal */}
        {showNotifications && (
          <NotificationsModal
            notifications={notifications}
            onClaimReward={handleClaimNotifReward}
            onClose={() => setShowNotifications(false)}
          />
        )}
      </div>
    </DeviceFrame>
  );
}
