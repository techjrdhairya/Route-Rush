import React from 'react';
import { ActiveTab } from '../../types';
import { Home, ShoppingBag, Car, Users, Target, Gift, User } from 'lucide-react';
import { audio } from '../../utils/audio';

interface BottomNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  claimableMissionsCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  claimableMissionsCount,
}) => {
  const tabs: { id: ActiveTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'shop', label: 'Shop', icon: ShoppingBag },
    { id: 'garage', label: 'Garage', icon: Car },
    { id: 'characters', label: 'Heroes', icon: Users },
    { id: 'missions', label: 'Missions', icon: Target },
    { id: 'rewards', label: 'Rewards', icon: Gift },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 px-2 py-2 bg-slate-950/90 backdrop-blur-xl border-t border-slate-800/80 text-slate-400 select-none">
      <div className="max-w-xl mx-auto flex items-center justify-around gap-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => {
                audio.playClick();
                onTabChange(tab.id);
              }}
              className={`relative flex flex-col items-center justify-center py-1 px-2.5 rounded-2xl transition-all duration-200 active:scale-90 ${
                isActive
                  ? 'text-cyan-400 bg-cyan-950/50 border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                  : 'hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform duration-200 ${isActive ? 'scale-110 text-cyan-400' : ''}`} />

                {tab.id === 'missions' && claimableMissionsCount > 0 && (
                  <span className="absolute -top-1 -right-2 flex items-center justify-center w-4 h-4 rounded-full bg-emerald-500 text-[9px] font-black text-slate-950 animate-bounce">
                    {claimableMissionsCount}
                  </span>
                )}
              </div>

              <span className={`text-[10px] mt-0.5 font-bold tracking-tight whitespace-nowrap ${isActive ? 'text-cyan-300 font-extrabold' : ''}`}>
                {tab.label}
              </span>

              {isActive && (
                <div className="absolute -bottom-1 w-5 h-1 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
