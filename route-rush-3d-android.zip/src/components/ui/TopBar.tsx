import React from 'react';
import { PlayerProfile, ActiveTab } from '../../types';
import { Coins, Gem, Zap, Settings, Bell } from 'lucide-react';
import { audio } from '../../utils/audio';

interface TopBarProps {
  profile: PlayerProfile;
  unreadNotificationsCount: number;
  onOpenSettings: () => void;
  onOpenNotifications: () => void;
  onTabSelect: (tab: ActiveTab) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  profile,
  unreadNotificationsCount,
  onOpenSettings,
  onOpenNotifications,
  onTabSelect,
}) => {
  const xpPercent = Math.min(100, Math.round((profile.xp / profile.maxXp) * 100));

  return (
    <header className="sticky top-0 z-40 w-full px-3 py-2 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 text-white select-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
        {/* Profile Avatar & Level Info */}
        <div
          onClick={() => {
            audio.playClick();
            onTabSelect('profile');
          }}
          className="flex items-center gap-2.5 p-1.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 cursor-pointer transition-all active:scale-95 shadow-sm"
        >
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-2xl shadow-inner border border-white/20">
            {profile.avatar}
            <div className="absolute -bottom-1 -right-1 flex items-center justify-center w-5 h-5 rounded-full bg-amber-500 text-[10px] font-black text-slate-950 border border-slate-900 shadow">
              {profile.level}
            </div>
          </div>

          <div className="hidden sm:flex flex-col min-w-[90px]">
            <div className="flex items-center justify-between gap-1">
              <span className="text-xs font-bold text-slate-100 truncate max-w-[100px]">
                {profile.username}
              </span>
              {profile.isGuest && (
                <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                  Guest
                </span>
              )}
            </div>
            {/* XP Bar */}
            <div className="w-full h-1.5 mt-1 rounded-full bg-slate-950 overflow-hidden border border-slate-700/50">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-300"
                style={{ width: `${xpPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Currency Pill Chips */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Energy Pill */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/90 border border-slate-700/80 text-amber-400 text-xs font-black shadow-sm">
            <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400 animate-pulse" />
            <span>
              {profile.energy}/{profile.maxEnergy}
            </span>
          </div>

          {/* Coins Pill */}
          <div
            onClick={() => {
              audio.playClick();
              onTabSelect('shop');
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-amber-300 text-xs font-black cursor-pointer shadow-sm transition-transform active:scale-95"
          >
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span>{profile.coins.toLocaleString()}</span>
          </div>

          {/* Gems Pill */}
          <div
            onClick={() => {
              audio.playClick();
              onTabSelect('shop');
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-cyan-300 text-xs font-black cursor-pointer shadow-sm transition-transform active:scale-95"
          >
            <Gem className="w-3.5 h-3.5 text-cyan-400" />
            <span>{profile.gems.toLocaleString()}</span>
          </div>
        </div>

        {/* Action Controls: Notifications & Settings */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              audio.playClick();
              onOpenNotifications();
            }}
            className="relative p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-slate-300 hover:text-white transition-all active:scale-90"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-[10px] font-black text-white border-2 border-slate-900 shadow">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              audio.playClick();
              onOpenSettings();
            }}
            className="p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700/80 text-slate-300 hover:text-white transition-all active:scale-90"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
