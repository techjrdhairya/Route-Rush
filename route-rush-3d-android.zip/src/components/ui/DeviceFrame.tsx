import React from 'react';
import { Wifi, Battery, Signal } from 'lucide-react';

interface DeviceFrameProps {
  enabled: boolean;
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ enabled, children }) => {
  if (!enabled) {
    return <div className="w-full min-h-screen bg-slate-950">{children}</div>;
  }

  return (
    <div className="min-h-screen w-full bg-slate-950 flex items-center justify-center p-2 sm:p-6 overflow-x-hidden">
      {/* Mobile Phone Device Chassis Container */}
      <div className="relative w-full max-w-[420px] h-[860px] rounded-[50px] border-[10px] border-slate-800 bg-slate-950 shadow-[0_0_60px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col">
        {/* Dynamic Island / Notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 w-28 h-6 rounded-full bg-black flex items-center justify-between px-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
          <div className="w-2 h-2 rounded-full bg-indigo-950 border border-indigo-900" />
        </div>

        {/* Status Bar */}
        <div className="relative z-40 w-full px-6 pt-3 pb-1 flex items-center justify-between text-[11px] font-bold text-white select-none">
          <span>9:41</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-3 h-3 text-white" />
            <Wifi className="w-3 h-3 text-white" />
            <Battery className="w-4 h-4 text-white" />
          </div>
        </div>

        {/* Screen Content */}
        <div className="relative flex-1 w-full h-full overflow-y-auto no-scrollbar">
          {children}
        </div>

        {/* Bottom Home Indicator Bar */}
        <div className="relative z-40 w-full py-1.5 bg-slate-950 flex items-center justify-center">
          <div className="w-32 h-1 rounded-full bg-slate-600" />
        </div>
      </div>
    </div>
  );
};
