import React, { useState } from 'react';
import { Play, UserCheck, KeyRound, Sparkles } from 'lucide-react';
import { audio } from '../../utils/audio';

interface SplashScreenProps {
  onStartAsGuest: (nickname: string) => void;
  onLogin: (username: string) => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onStartAsGuest, onLogin }) => {
  const [mode, setMode] = useState<'main' | 'guest' | 'login' | 'signup'>('main');
  const [nickname, setNickname] = useState('');
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');

  const handleGuestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = nickname.trim() || 'RushRunner_' + Math.floor(Math.random() * 899 + 100);
    audio.playVictory();
    onStartAsGuest(finalName);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = usernameInput.trim() || 'ProRacer';
    audio.playVictory();
    onLogin(finalName);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4 bg-gradient-to-b from-slate-950 via-indigo-950 to-slate-950 text-white overflow-hidden select-none">
      {/* Animated Glowing Particles Background */}
      <div className="absolute inset-0 pointer-events-none opacity-40 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-500/20 via-purple-500/10 to-transparent animate-pulse" />

      {/* Main Container Card */}
      <div className="relative w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900/90 backdrop-blur-2xl border border-indigo-500/30 shadow-[0_0_50px_rgba(79,70,229,0.3)] text-center flex flex-col items-center">
        {/* Game Icon & Title */}
        <div className="relative mb-6">
          <div className="flex items-center justify-center w-24 h-24 rounded-3xl bg-gradient-to-tr from-amber-400 via-rose-500 to-indigo-600 shadow-2xl border-2 border-white/20 transform rotate-3 hover:rotate-0 transition-transform duration-300">
            <span className="text-5xl">🏎️</span>
          </div>
          <div className="absolute -bottom-2 -right-2 p-2 rounded-2xl bg-amber-400 text-slate-950 font-black shadow-lg animate-bounce">
            <Sparkles className="w-5 h-5" />
          </div>
        </div>

        <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-rose-400 to-indigo-300 drop-shadow-sm">
          ROUTE RUSH
        </h1>

        <p className="mt-2 text-sm font-semibold tracking-wider text-indigo-200/80 uppercase">
          Run. Drive. Collect. Conquer.
        </p>

        {mode === 'main' && (
          <div className="w-full mt-8 flex flex-col gap-3">
            <button
              onClick={() => {
                audio.playClick();
                setMode('guest');
              }}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-lg shadow-[0_0_20px_rgba(251,191,36,0.4)] flex items-center justify-center gap-3 transition-all active:scale-95"
            >
              <Play className="w-6 h-6 fill-slate-950" />
              <span>Continue as Guest</span>
            </button>

            <button
              onClick={() => {
                audio.playClick();
                setMode('login');
              }}
              className="w-full py-3.5 px-6 rounded-2xl bg-indigo-900/60 hover:bg-indigo-800/80 border border-indigo-500/40 text-indigo-200 font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <UserCheck className="w-5 h-5 text-indigo-400" />
              <span>Login</span>
            </button>

            <button
              onClick={() => {
                audio.playClick();
                setMode('signup');
              }}
              className="w-full py-3 px-6 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-300 font-medium text-sm flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <KeyRound className="w-4 h-4 text-slate-400" />
              <span>Create Permanent Account</span>
            </button>
          </div>
        )}

        {mode === 'guest' && (
          <form onSubmit={handleGuestSubmit} className="w-full mt-6 flex flex-col gap-4 text-left">
            <div>
              <label className="block text-xs font-bold text-amber-300 mb-1.5 uppercase tracking-wider">
                Choose Guest Nickname
              </label>
              <input
                type="text"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="e.g. SpeedDemon99"
                maxLength={18}
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-indigo-500/40 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-bold text-sm"
              />
              <p className="mt-1 text-[11px] text-slate-400">
                Progress saves locally. You can sync or create an account later anytime.
              </p>
            </div>

            <div className="flex gap-2 mt-2">
              <button
                type="button"
                onClick={() => setMode('main')}
                className="w-1/3 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm"
              >
                Back
              </button>
              <button
                type="submit"
                className="w-2/3 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-base shadow-lg hover:brightness-110 active:scale-95"
              >
                Start Rush!
              </button>
            </div>
          </form>
        )}

        {(mode === 'login' || mode === 'signup') && (
          <form onSubmit={handleLoginSubmit} className="w-full mt-6 flex flex-col gap-3 text-left">
            <div>
              <label className="block text-xs font-bold text-indigo-300 mb-1 uppercase tracking-wider">
                Username / Email
              </label>
              <input
                type="text"
                required
                value={usernameInput}
                onChange={(e) => setUsernameInput(e.target.value)}
                placeholder="Enter username"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:border-indigo-400 font-medium text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-indigo-300 mb-1 uppercase tracking-wider">
                Password
              </label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 focus:border-indigo-400 font-medium text-sm"
              />
            </div>

            <div className="flex gap-2 mt-3">
              <button
                type="button"
                onClick={() => setMode('main')}
                className="w-1/3 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm"
              >
                Back
              </button>
              <button
                type="submit"
                className="w-2/3 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-base shadow-lg active:scale-95"
              >
                {mode === 'login' ? 'Login' : 'Create Account'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
