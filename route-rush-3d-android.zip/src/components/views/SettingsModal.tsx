import React, { useState } from 'react';
import { GameSettings } from '../../types';
import { X, Volume2, Monitor, Smartphone, LogOut, RotateCcw, AlertTriangle } from 'lucide-react';
import { audio } from '../../utils/audio';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onClose: () => void;
  onLogout: () => void;
  onResetData?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
  onLogout,
  onResetData,
}) => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetSuccessMessage, setResetSuccessMessage] = useState(false);

  const handleMusicChange = (val: number) => {
    const updated = { ...settings, musicVolume: val };
    onUpdateSettings(updated);
    audio.setVolumes(val, settings.sfxVolume);
  };

  const handleSfxChange = (val: number) => {
    const updated = { ...settings, sfxVolume: val };
    onUpdateSettings(updated);
    audio.setVolumes(settings.musicVolume, val);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md select-none">
      <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xl font-black text-white">GAME SETTINGS</h3>
          <button
            onClick={() => {
              audio.playClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audio Volume Controls */}
        <div className="flex flex-col gap-3">
          <span className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Volume2 className="w-4 h-4 text-cyan-400" />
            <span>Audio & Music</span>
          </span>

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span>Music Volume</span>
              <span>{Math.round(settings.musicVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.musicVolume}
              onChange={(e) => handleMusicChange(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span>Sound Effects (SFX)</span>
              <span>{Math.round(settings.sfxVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={settings.sfxVolume}
              onChange={(e) => handleSfxChange(parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>
        </div>

        {/* Graphics & Performance */}
        <div className="flex flex-col gap-3 border-t border-slate-800 pt-3">
          <span className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Monitor className="w-4 h-4 text-purple-400" />
            <span>Graphics & Frame Rate</span>
          </span>

          <div className="grid grid-cols-3 gap-2">
            {['low', 'medium', 'high'].map((q) => (
              <button
                key={q}
                onClick={() => {
                  audio.playClick();
                  onUpdateSettings({ ...settings, graphicsQuality: q as any });
                }}
                className={`py-2 rounded-xl text-xs font-bold capitalize transition-all ${
                  settings.graphicsQuality === q
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                {q}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-slate-300 mt-1">
            <span>FPS Target Limit</span>
            <div className="flex items-center gap-2">
              {[60, 120].map((fps) => (
                <button
                  key={fps}
                  onClick={() => {
                    audio.playClick();
                    onUpdateSettings({ ...settings, fpsLimit: fps as any });
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    settings.fpsLimit === fps
                      ? 'bg-amber-400 text-slate-950 font-black'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {fps} FPS
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Device View Frame Toggle */}
        <div className="flex items-center justify-between border-t border-slate-800 pt-3">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold text-slate-300">Mobile Phone Frame View</span>
          </div>

          <button
            onClick={() => {
              audio.playClick();
              onUpdateSettings({ ...settings, deviceFrame: !settings.deviceFrame });
            }}
            className={`w-12 h-6 rounded-full p-1 transition-colors ${
              settings.deviceFrame ? 'bg-indigo-600' : 'bg-slate-800'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                settings.deviceFrame ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Logout / Reset */}
        <div className="border-t border-slate-800 pt-3 flex flex-col gap-2">
          {resetSuccessMessage && (
            <div className="p-3 rounded-2xl bg-emerald-900/80 border border-emerald-500/80 text-emerald-200 text-xs font-bold text-center animate-bounce shadow-lg">
              ✓ Reset Successful! 50 Energy & Fresh Profile Restored.
            </div>
          )}

          {onResetData && (
            <>
              {showResetConfirm ? (
                <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-600/60 flex flex-col gap-3 text-center shadow-xl">
                  <div className="flex items-center justify-center gap-2 text-rose-400 font-black text-xs uppercase tracking-wider">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    <span>Reset All Game Progress?</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    This will permanently wipe all levels, coins, gems, unlocked vehicles & heroes. Your chances will be reset to 50.
                  </p>
                  <div className="flex gap-2 mt-1">
                    <button
                      onClick={() => setShowResetConfirm(false)}
                      className="w-1/2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        audio.playVictory();
                        onResetData();
                        setShowResetConfirm(false);
                        setResetSuccessMessage(true);
                        setTimeout(() => setResetSuccessMessage(false), 4000);
                      }}
                      className="w-1/2 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs shadow-lg active:scale-95 transition-transform"
                    >
                      Yes, Reset Everything
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => {
                    audio.playClick();
                    setShowResetConfirm(true);
                  }}
                  className="w-full py-3 rounded-2xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 border border-rose-800/50 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset All Game Data</span>
                </button>
              )}
            </>
          )}

          <button
            onClick={() => {
              audio.playClick();
              onLogout();
            }}
            className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Switch Account / Logout</span>
          </button>
        </div>
      </div>
    </div>
  );
};
