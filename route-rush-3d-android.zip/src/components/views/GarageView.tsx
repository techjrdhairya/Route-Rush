import React, { useState } from 'react';
import { PlayerProfile, CarItem, CarUpgradeState } from '../../types';
import { CARS } from '../../data/mockData';
import { Car, Zap, Shield, Sparkles, Coins, Check } from 'lucide-react';
import { audio } from '../../utils/audio';

interface GarageViewProps {
  profile: PlayerProfile;
  onSelectCar: (carId: string) => void;
  onUpgradeCar: (carId: string, stat: keyof CarUpgradeState, cost: number) => void;
  onChangePaint: (carId: string, hexColor: string) => void;
  onChangeNeon: (carId: string, hexColor: string) => void;
  onUnlockCar: (car: CarItem) => void;
}

export const GarageView: React.FC<GarageViewProps> = ({
  profile,
  onSelectCar,
  onUpgradeCar,
  onChangePaint,
  onChangeNeon,
  onUnlockCar,
}) => {
  const selectedCar = CARS.find((c) => c.id === profile.selectedCarId) || CARS[0];
  const isUnlocked = profile.unlockedCars.includes(selectedCar.id);

  const carUpgrades = profile.carUpgrades[selectedCar.id] || {
    engine: 1,
    nitro: 1,
    handling: 1,
    brakes: 1,
    suspension: 1,
  };

  const currentPaint = profile.carPaints[selectedCar.id] || selectedCar.bodyColor;
  const currentNeon = profile.carNeon[selectedCar.id] || '#00f0ff';

  const PAINT_COLORS = ['#ef4444', '#3b82f6', '#22c55e', '#eab308', '#a855f7', '#ec4899', '#f97316', '#14b8a6', '#f8fafc', '#0f172a'];
  const NEON_COLORS = ['#00f0ff', '#ff007f', '#39ff14', '#f000ff', '#ffea00', '#ffffff'];

  const handleUpgradeStat = (stat: keyof CarUpgradeState) => {
    const currentLevel = carUpgrades[stat];
    if (currentLevel >= 10) return;
    const cost = 500 * currentLevel;
    if (profile.coins < cost) {
      alert('Not enough coins!');
      return;
    }
    audio.playVictory();
    onUpgradeCar(selectedCar.id, stat, cost);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 text-white select-none pb-28">
      {/* Garage Inspector Box */}
      <div className="relative p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border border-slate-800 shadow-2xl mb-6 flex flex-col items-center">
        {/* Car 3D Preview Stage */}
        <div className="relative w-full h-48 sm:h-64 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-center overflow-hidden mb-4">
          <div
            className="absolute inset-0 opacity-20 pointer-events-none"
            style={{ backgroundColor: currentPaint }}
          />

          {/* Large Car Icon Representation */}
          <div className="relative z-10 flex flex-col items-center transform hover:scale-105 transition-transform duration-300">
            <span className="text-8xl sm:text-9xl drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]">
              🏎️
            </span>
            {/* Neon Glow Light Bar under car */}
            <div
              className="w-48 h-3 rounded-full blur-md mt-2 transition-colors duration-300"
              style={{ backgroundColor: currentNeon }}
            />
          </div>

          <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-slate-900/90 text-xs font-bold text-slate-300 border border-slate-800">
            {selectedCar.type}
          </div>
        </div>

        {/* Selected Vehicle Info */}
        <div className="w-full flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-white">{selectedCar.name}</h2>
            <p className="text-xs text-slate-400">{selectedCar.description}</p>
          </div>

          {!isUnlocked ? (
            <button
              onClick={() => {
                audio.playClick();
                onUnlockCar(selectedCar);
              }}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm shadow-lg flex items-center gap-1.5 hover:brightness-110 active:scale-95"
            >
              <span>Unlock ({selectedCar.price.toLocaleString()} {selectedCar.currency})</span>
            </button>
          ) : (
            <button
              disabled
              className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold text-xs border border-emerald-500/30 flex items-center gap-1"
            >
              <Check className="w-4 h-4" />
              <span>EQUIPPED</span>
            </button>
          )}
        </div>
      </div>

      {/* Car Roster Selector Grid */}
      <div className="mb-6">
        <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
          Vehicle Collection
        </h3>
        <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
          {CARS.map((car) => {
            const isSel = car.id === selectedCar.id;
            const isUnl = profile.unlockedCars.includes(car.id);

            return (
              <button
                key={car.id}
                onClick={() => {
                  audio.playClick();
                  onSelectCar(car.id);
                }}
                className={`relative flex-none w-28 p-3 rounded-2xl border text-center transition-all active:scale-95 ${
                  isSel
                    ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-md'
                    : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:bg-slate-850'
                }`}
              >
                <div className="text-3xl mb-1">🏎️</div>
                <div className="text-xs font-bold truncate">{car.name}</div>
                {!isUnl && (
                  <span className="text-[9px] font-black uppercase text-amber-400">Locked</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Upgrades & Customization Tabs */}
      {isUnlocked && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Performance Upgrades Panel */}
          <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800">
            <h3 className="text-sm font-black text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Performance Upgrades</span>
            </h3>

            <div className="flex flex-col gap-3">
              {[
                { key: 'engine', label: 'Engine Speed', val: carUpgrades.engine },
                { key: 'nitro', label: 'Nitro Duration', val: carUpgrades.nitro },
                { key: 'handling', label: 'Drift Handling', val: carUpgrades.handling },
                { key: 'brakes', label: 'Brakes Response', val: carUpgrades.brakes },
              ].map((item) => (
                <div key={item.key} className="flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-200">{item.label}</span>
                    <span className="text-[10px] text-amber-400 font-bold ml-2">Lvl {item.val}/10</span>
                  </div>

                  <button
                    onClick={() => handleUpgradeStat(item.key as keyof CarUpgradeState)}
                    disabled={item.val >= 10}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 text-white font-bold flex items-center gap-1 active:scale-95"
                  >
                    <span>Upgrade</span>
                    <Coins className="w-3 h-3 text-amber-300" />
                    <span>{500 * item.val}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Visual Customization Panel */}
          <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800">
            <h3 className="text-sm font-black text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Paint & Neon Customizer</span>
            </h3>

            {/* Body Paint Palette */}
            <div className="mb-4">
              <span className="text-xs font-bold text-slate-400 block mb-2">Body Paint</span>
              <div className="flex items-center gap-2 flex-wrap">
                {PAINT_COLORS.map((hex) => (
                  <button
                    key={hex}
                    onClick={() => {
                      audio.playClick();
                      onChangePaint(selectedCar.id, hex);
                    }}
                    className={`w-7 h-7 rounded-full border-2 transition-transform active:scale-90 ${
                      currentPaint === hex ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
              </div>
            </div>

            {/* Neon Underglow Palette */}
            <div>
              <span className="text-xs font-bold text-slate-400 block mb-2">Neon Underglow</span>
              <div className="flex items-center gap-2 flex-wrap">
                {NEON_COLORS.map((hex) => (
                  <button
                    key={hex}
                    onClick={() => {
                      audio.playClick();
                      onChangeNeon(selectedCar.id, hex);
                    }}
                    className={`w-7 h-7 rounded-full border-2 transition-transform active:scale-90 ${
                      currentNeon === hex ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
