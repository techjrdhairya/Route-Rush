import React from 'react';
import { AppNotification } from '../../types';
import { X, Bell, Coins, Gem, Sparkles, CheckCircle2 } from 'lucide-react';
import { audio } from '../../utils/audio';

interface NotificationsModalProps {
  notifications: AppNotification[];
  onClaimReward: (notifId: string, reward: { type: 'coins' | 'gems'; amount: number }) => void;
  onClose: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  notifications,
  onClaimReward,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md select-none">
      <div className="w-full max-w-md p-6 rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-400" />
            <h3 className="text-xl font-black text-white">NOTIFICATIONS</h3>
          </div>

          <button
            onClick={() => {
              audio.playClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex flex-col gap-3">
          {notifications.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-6">No new notifications</p>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-300">{n.title}</span>
                  <span className="text-[10px] text-slate-500">{n.time}</span>
                </div>

                <p className="text-xs text-slate-300">{n.message}</p>

                {n.claimableReward && (
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/80">
                    <div className="flex items-center gap-1 text-xs font-black text-amber-400">
                      <span>+{n.claimableReward.amount}</span>
                      {n.claimableReward.type === 'coins' ? (
                        <Coins className="w-4 h-4 text-amber-400" />
                      ) : (
                        <Gem className="w-4 h-4 text-cyan-400" />
                      )}
                    </div>

                    <button
                      onClick={() => {
                        audio.playVictory();
                        onClaimReward(n.id, n.claimableReward!);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow active:scale-95"
                    >
                      Claim
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
