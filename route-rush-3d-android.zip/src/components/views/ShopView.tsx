import React, { useState } from 'react';
import { PlayerProfile, ShopItem, Rarity } from '../../types';
import { SHOP_ITEMS } from '../../data/mockData';
import { ShoppingBag, Sparkles, Coins, Gem, Gift } from 'lucide-react';
import confetti from 'canvas-confetti';
import { audio } from '../../utils/audio';

interface ShopViewProps {
  profile: PlayerProfile;
  onBuyItem: (item: ShopItem) => void;
}

export const ShopView: React.FC<ShopViewProps> = ({ profile, onBuyItem }) => {
  const [activeTab, setActiveTab] = useState<'all' | 'characters' | 'cars' | 'gems' | 'bundles'>('all');
  const [openingBox, setOpeningBox] = useState(false);
  const [boxReward, setBoxReward] = useState<{ name: string; icon: string; rarity: string } | null>(null);

  const filterItems = SHOP_ITEMS.filter((item) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'characters') return item.category === 'character';
    if (activeTab === 'cars') return item.category === 'car';
    if (activeTab === 'gems') return item.category === 'gems' || item.category === 'coins';
    if (activeTab === 'bundles') return item.category === 'bundle' || item.category === 'special';
    return true;
  });

  const handleOpenMysteryBox = () => {
    if (profile.coins < 2000) {
      alert('You need 2,000 coins to open a Mystery Box!');
      return;
    }
    audio.playChestOpen();
    setOpeningBox(true);
    setBoxReward(null);

    setTimeout(() => {
      const rewards = [
        { name: '50 Gems', icon: '💎', rarity: 'epic' },
        { name: '3,000 Coins', icon: '💰', rarity: 'rare' },
        { name: '2 Keys', icon: '🔑', rarity: 'legendary' },
        { name: 'Cyber Neon Skin', icon: '⚡', rarity: 'mythic' },
      ];
      const selected = rewards[Math.floor(Math.random() * rewards.length)];
      setBoxReward(selected);
      setOpeningBox(false);

      confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
    }, 1500);
  };

  const getRarityBadge = (rarity: Rarity) => {
    switch (rarity) {
      case 'mythic':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      case 'legendary':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'epic':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      case 'rare':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40';
      default:
        return 'bg-slate-700/40 text-slate-300 border-slate-600';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 text-white select-none pb-28">
      {/* Shop Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 border border-purple-500/30 shadow-xl mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="p-3.5 rounded-2xl bg-purple-500/20 border border-purple-400/40 text-purple-300">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-white">ROUTE RUSH SHOP</h2>
            <p className="text-xs text-purple-200/80">
              Unlock exclusive heroes, cars, skin packs, and mystery deals!
            </p>
          </div>
        </div>

        {/* Mystery Box Spin Card */}
        <button
          onClick={handleOpenMysteryBox}
          className="py-3 px-5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm shadow-lg flex items-center gap-2 hover:brightness-110 transition-all active:scale-95"
        >
          <Gift className="w-5 h-5" />
          <span>Mystery Box (2,000 Coins)</span>
        </button>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 no-scrollbar">
        {[
          { id: 'all', label: 'All Items' },
          { id: 'characters', label: 'Heroes' },
          { id: 'cars', label: 'Cars' },
          { id: 'gems', label: 'Gems & Coins' },
          { id: 'bundles', label: 'Bundles' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              audio.playClick();
              setActiveTab(tab.id as any);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Shop Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filterItems.map((item) => (
          <div
            key={item.id}
            className="p-4 rounded-2xl bg-slate-900/90 hover:bg-slate-850 border border-slate-800 flex flex-col justify-between transition-all duration-200 hover:border-indigo-500/40 shadow-lg"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span
                  className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${getRarityBadge(
                    item.rarity
                  )}`}
                >
                  {item.rarity}
                </span>

                {item.discount && (
                  <span className="text-[10px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full">
                    -{item.discount}%
                  </span>
                )}
              </div>

              <div className="flex items-center justify-center h-20 text-5xl mb-3">
                {item.icon}
              </div>

              <h3 className="text-base font-bold text-white text-center">{item.name}</h3>
              <p className="text-xs text-slate-400 text-center mt-1 min-h-[32px]">
                {item.description}
              </p>
            </div>

            <button
              onClick={() => {
                audio.playClick();
                onBuyItem(item);
              }}
              className="mt-4 w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-sm shadow flex items-center justify-center gap-2 active:scale-95"
            >
              <span>Buy for {item.price.toLocaleString()}</span>
              {item.currency === 'coins' && <Coins className="w-4 h-4 text-amber-400" />}
              {item.currency === 'gems' && <Gem className="w-4 h-4 text-cyan-400" />}
            </button>
          </div>
        ))}
      </div>

      {/* Mystery Box Reward Modal */}
      {(openingBox || boxReward) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="w-full max-w-sm p-6 rounded-3xl bg-slate-900 border border-indigo-500/40 text-center flex flex-col items-center gap-4">
            {openingBox ? (
              <div className="py-8 flex flex-col items-center gap-4">
                <Gift className="w-16 h-16 text-amber-400 animate-bounce" />
                <span className="text-lg font-black text-amber-300">Opening Mystery Box...</span>
              </div>
            ) : (
              boxReward && (
                <>
                  <Sparkles className="w-12 h-12 text-amber-400 animate-pulse" />
                  <h3 className="text-2xl font-black text-white">REWARD UNLOCKED!</h3>
                  <div className="text-6xl my-2">{boxReward.icon}</div>
                  <span className="text-xl font-black text-amber-300">{boxReward.name}</span>
                  <button
                    onClick={() => setBoxReward(null)}
                    className="w-full mt-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                  >
                    Awesome!
                  </button>
                </>
              )
            )}
          </div>
        </div>
      )}
    </div>
  );
};
