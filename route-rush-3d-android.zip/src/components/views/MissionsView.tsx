import React, { useState } from 'react';
import { Mission } from '../../types';
import { Target, CheckCircle2, Coins, Gem, Key } from 'lucide-react';
import { audio } from '../../utils/audio';

interface MissionsViewProps {
  missions: Mission[];
  onClaimMission: (missionId: string) => void;
}

export const MissionsView: React.FC<MissionsViewProps> = ({ missions, onClaimMission }) => {
  const [activeCategory, setActiveCategory] = useState<'daily' | 'weekly' | 'seasonal'>('daily');

  const filteredMissions = missions.filter((m) => m.type === activeCategory);

  return (
    <div className="w-full max-w-4xl mx-auto p-4 text-white select-none pb-28">
      {/* Category Tabs */}
      <div className="flex items-center gap-2 mb-6">
        {[
          { id: 'daily', label: 'Daily Missions' },
          { id: 'weekly', label: 'Weekly Challenges' },
          { id: 'seasonal', label: 'Season Pass' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              audio.playClick();
              setActiveCategory(tab.id as any);
            }}
            className={`flex-1 py-3 px-4 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${
              activeCategory === tab.id
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 shadow-lg'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Missions List */}
      <div className="flex flex-col gap-3">
        {filteredMissions.map((mission) => {
          const isComplete = mission.current >= mission.target;
          const progressPercent = Math.min(100, Math.round((mission.current / mission.target) * 100));

          return (
            <div
              key={mission.id}
              className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md"
            >
              <div className="flex items-center gap-3.5 w-full sm:w-auto">
                <div className="p-3 rounded-xl bg-slate-800 text-amber-400 border border-slate-700">
                  <Target className="w-6 h-6" />
                </div>

                <div className="flex flex-col">
                  <h4 className="text-sm font-bold text-white">{mission.title}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">{mission.description}</p>

                  {/* Mission Progress Bar */}
                  <div className="w-48 sm:w-64 h-2 mt-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-all duration-300"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 mt-0.5">
                    {mission.current} / {mission.target}
                  </span>
                </div>
              </div>

              {/* Reward & Claim Action */}
              <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                <div className="flex items-center gap-1 font-black text-amber-300 text-xs px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span>+{mission.rewardAmount}</span>
                  {mission.rewardType === 'coins' && <Coins className="w-4 h-4 text-amber-400" />}
                  {mission.rewardType === 'gems' && <Gem className="w-4 h-4 text-cyan-400" />}
                  {mission.rewardType === 'keys' && <Key className="w-4 h-4 text-amber-400" />}
                </div>

                {mission.claimed ? (
                  <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Claimed</span>
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      audio.playVictory();
                      onClaimMission(mission.id);
                    }}
                    disabled={!isComplete}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs disabled:opacity-30 shadow hover:brightness-110 active:scale-95"
                  >
                    Claim Reward
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
