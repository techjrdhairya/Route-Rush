import React, { useState, useEffect } from 'react';
import { GameMode, WorldTheme, PlayerProfile, LevelData } from '../../types';
import { ThreeGameCanvas } from '../3d/ThreeGameCanvas';
import { Pause, Play, RotateCcw, Home, Trophy, Coins, Gem, Zap, ArrowLeft, ArrowRight, ArrowUp, ArrowDown, Flame } from 'lucide-react';
import confetti from 'canvas-confetti';
import { audio } from '../../utils/audio';
import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics';

interface GameViewProps {
  mode: GameMode;
  world: WorldTheme;
  profile: PlayerProfile;
  levelData: LevelData;
  onFinishGame: (coinsEarned: number, gemsEarned: number, xpEarned: number, distance: number, stars: number) => void;
  onQuitToHome: () => void;
}

export const GameView: React.FC<GameViewProps> = ({
  mode,
  world,
  profile,
  levelData,
  onFinishGame,
  onQuitToHome,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  const [currentCoins, setCurrentCoins] = useState(0);
  const [currentGems, setCurrentGems] = useState(0);
  const [currentDistance, setCurrentDistance] = useState(0);
  const [activePowerup, setActivePowerup] = useState<{ type: string; duration: number } | null>(null);

  const [finalScore, setFinalScore] = useState(0);
  const [earnedStars, setEarnedStars] = useState(0);

  const [inputAction, setInputAction] = useState<{ type: 'left' | 'right' | 'up' | 'down'; id: number } | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const lastActionTimesRef = React.useRef<Record<string, number>>({});

  const triggerAction = (type: 'left' | 'right' | 'up' | 'down') => {
    const now = Date.now();
    if (now - (lastActionTimesRef.current[type] || 0) < 120) return;
    lastActionTimesRef.current[type] = now;

    setInputAction({ type, id: now + Math.random() });
    const labelMap = {
      left: '◀ STEER LEFT',
      right: 'STEER RIGHT ▶',
      up: mode === 'racer' || mode === 'motorbike' || mode === 'ball' ? '🔥 NITRO BOOST' : '⚡ JUMP',
      down: '🔻 SLIDE',
    };
    setActionFeedback(labelMap[type]);
    setTimeout(() => {
      setActionFeedback(null);
    }, 400);
  };

  const handleControlBtn = (type: 'left' | 'right' | 'up' | 'down', e: React.SyntheticEvent) => {
    e.preventDefault();
    e.stopPropagation();
    triggerAction(type);
  };

  // Global Keyboard Controls Listener
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || isPaused || isFinished) return;

      const key = e.key;
      const code = e.code;

      const isLeft = key === 'ArrowLeft' || key === 'Left' || code === 'ArrowLeft' || key === 'a' || key === 'A' || code === 'KeyA';
      const isRight = key === 'ArrowRight' || key === 'Right' || code === 'ArrowRight' || key === 'd' || key === 'D' || code === 'KeyD';
      const isUp = key === 'ArrowUp' || key === 'Up' || code === 'ArrowUp' || key === 'w' || key === 'W' || code === 'KeyW' || key === ' ' || key === 'Spacebar' || code === 'Space';
      const isDown = key === 'ArrowDown' || key === 'Down' || code === 'ArrowDown' || key === 's' || key === 'S' || code === 'KeyS';

      if (isLeft) {
        e.preventDefault();
        e.stopPropagation();
        triggerAction('left');
      } else if (isRight) {
        e.preventDefault();
        e.stopPropagation();
        triggerAction('right');
      } else if (isUp) {
        e.preventDefault();
        e.stopPropagation();
        triggerAction('up');
      } else if (isDown) {
        e.preventDefault();
        e.stopPropagation();
        triggerAction('down');
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown, { capture: true });
    document.addEventListener('keydown', handleGlobalKeyDown, { capture: true });

    return () => {
      window.removeEventListener('keydown', handleGlobalKeyDown, { capture: true });
      document.removeEventListener('keydown', handleGlobalKeyDown, { capture: true });
    };
  }, [isPlaying, isPaused, isFinished]);

  useEffect(() => {
    // Start background music loop
    audio.startBgmLoop(world.name);
    return () => {
      audio.stopBgmLoop();
    };
  }, [world]);

  const handleGameOver = (score: number, coins: number, distance: number) => {
    setIsPlaying(false);
    setFinalScore(score);

    // Calculate stars
    let stars = 1;
    if (distance >= levelData.targetDistance && coins >= levelData.targetCoins) stars = 3;
    else if (distance >= levelData.targetDistance) stars = 2;

    setEarnedStars(stars);
    setIsFinished(true);

    if (stars >= 2) {
      audio.playVictory();
      Haptics.notification({ type: NotificationType.Success }).catch(() => {});
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    } else {
      audio.playCrash();
      Haptics.impact({ style: ImpactStyle.Heavy }).catch(() => {});
    }
  };

  const handleClaimAndFinish = () => {
    audio.playClick();
    onFinishGame(currentCoins, currentGems, levelData.rewardXp, currentDistance, earnedStars);
  };

  const handlePowerupActive = (type: string, duration: number) => {
    setActivePowerup({ type, duration });
    const timer = setInterval(() => {
      setActivePowerup((prev) => {
        if (!prev || prev.duration <= 1) {
          clearInterval(timer);
          return null;
        }
        return { ...prev, duration: prev.duration - 1 };
      });
    }, 1000);
  };

  const progressPercent = Math.min(100, Math.round((currentDistance / levelData.targetDistance) * 100));

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white select-none overflow-hidden">
      {/* 3D WebGL Canvas Layer */}
      <div className="absolute inset-0 w-full h-full">
        <ThreeGameCanvas
          mode={mode}
          world={world}
          profile={profile}
          levelData={levelData}
          isPlaying={isPlaying}
          isPaused={isPaused}
          inputAction={inputAction}
          onCoinCollect={(c) => {
            if (c > currentCoins) {
              Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
            }
            setCurrentCoins(c);
          }}
          onGemCollect={(g) => setCurrentGems(g)}
          onDistanceUpdate={(d) => setCurrentDistance(d)}
          onGameOver={handleGameOver}
          onPowerupActive={handlePowerupActive}
        />

        {/* Top Gameplay HUD Header Overlay */}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between pointer-events-none z-10">
          {/* Stats Bar */}
          <div className="flex items-center gap-2 pointer-events-auto">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950/80 backdrop-blur-md border border-slate-800 text-amber-300 font-black text-sm shadow-lg">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>{currentCoins}</span>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950/80 backdrop-blur-md border border-slate-800 text-cyan-300 font-black text-sm shadow-lg">
              <Gem className="w-4 h-4 text-cyan-400" />
              <span>{currentGems}</span>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950/80 backdrop-blur-md border border-slate-800 text-slate-100 font-black text-sm shadow-lg">
              <span>{currentDistance}m</span>
            </div>
          </div>

          {/* Pause Button */}
          <button
            onClick={() => {
              audio.playClick();
              setIsPaused(!isPaused);
            }}
            className="pointer-events-auto p-3 rounded-2xl bg-slate-950/80 hover:bg-slate-900 border border-slate-800 text-white shadow-lg active:scale-90"
          >
            {isPaused ? <Play className="w-5 h-5 text-amber-400" /> : <Pause className="w-5 h-5 text-white" />}
          </button>
        </div>

        {/* Target Progress Bar */}
        <div className="absolute top-16 left-4 right-4 max-w-md mx-auto pointer-events-none z-10 flex flex-col items-center gap-1">
          <div className="w-full h-2 rounded-full bg-slate-950/80 backdrop-blur border border-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-amber-400 to-emerald-400 transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">
            Controls: Arrow Keys / WASD / Space / Buttons Below
          </span>
        </div>

        {/* Active Action Feedback Indicator Badge */}
        {actionFeedback && (
          <div className="absolute top-24 left-1/2 -translate-x-1/2 px-5 py-1.5 rounded-full bg-cyan-500/90 text-slate-950 font-black text-xs tracking-wider uppercase shadow-[0_0_20px_rgba(6,182,212,0.6)] z-30 transition-all scale-105">
            {actionFeedback}
          </div>
        )}

        {/* Active Power-up Timer Banner */}
        {activePowerup && (
          <div className="absolute top-28 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 font-black text-xs shadow-xl flex items-center gap-2 animate-bounce z-20">
            <Zap className="w-4 h-4 fill-slate-950" />
            <span>
              {activePowerup.type.toUpperCase()}: {activePowerup.duration}s
            </span>
          </div>
        )}

        {/* On-Screen Touch / Click Control Buttons Overlay */}
        <div className="absolute bottom-6 left-4 right-4 z-20 flex items-end justify-between pointer-events-none">
          {/* Steering Left & Right Buttons */}
          <div className="flex items-center gap-3 pointer-events-auto">
            <button
              onPointerDown={(e) => handleControlBtn('left', e)}
              onClick={(e) => handleControlBtn('left', e)}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/85 hover:bg-slate-800 border-2 border-cyan-500/50 text-cyan-400 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.3)] active:scale-90 transition-all select-none touch-none"
              title="Steer Left (Arrow Left / A)"
            >
              <ArrowLeft className="w-7 h-7" />
            </button>
            <button
              onPointerDown={(e) => handleControlBtn('right', e)}
              onClick={(e) => handleControlBtn('right', e)}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/85 hover:bg-slate-800 border-2 border-cyan-500/50 text-cyan-400 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.3)] active:scale-90 transition-all select-none touch-none"
              title="Steer Right (Arrow Right / D)"
            >
              <ArrowRight className="w-7 h-7" />
            </button>
          </div>

          {/* Jump / Nitro & Slide Buttons */}
          <div className="flex items-center gap-3 pointer-events-auto">
            <button
              onPointerDown={(e) => handleControlBtn('down', e)}
              onClick={(e) => handleControlBtn('down', e)}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-900/85 hover:bg-slate-800 border-2 border-amber-500/50 text-amber-400 flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.3)] active:scale-90 transition-all select-none touch-none"
              title="Slide / Duck (Arrow Down / S)"
            >
              <ArrowDown className="w-7 h-7" />
            </button>
            <button
              onPointerDown={(e) => handleControlBtn('up', e)}
              onClick={(e) => handleControlBtn('up', e)}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 hover:brightness-110 text-slate-950 font-black flex items-center justify-center shadow-[0_0_25px_rgba(244,63,94,0.5)] active:scale-90 transition-all border-2 border-white/20 select-none touch-none"
              title="Jump / Nitro (Arrow Up / W / Space)"
            >
              {mode === 'racer' || mode === 'motorbike' || mode === 'ball' ? <Flame className="w-8 h-8 fill-slate-950" /> : <ArrowUp className="w-8 h-8 stroke-[3]" />}
            </button>
          </div>
        </div>
      </div>

      {/* Pause Menu Modal */}
      {isPaused && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="w-full max-w-sm p-6 rounded-3xl bg-slate-900 border border-slate-800 text-center flex flex-col gap-4">
            <h3 className="text-2xl font-black text-white">GAME PAUSED</h3>

            <button
              onClick={() => {
                audio.playClick();
                setIsPaused(false);
              }}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-base shadow-lg"
            >
              Resume Game
            </button>

            <button
              onClick={onQuitToHome}
              className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm flex items-center justify-center gap-2"
            >
              <Home className="w-4 h-4" />
              <span>Quit to Home</span>
            </button>
          </div>
        </div>
      )}

      {/* Game Finished / Victory / Over Modal */}
      {isFinished && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-xl">
          <div className="w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900 border border-indigo-500/40 text-center flex flex-col items-center gap-4 shadow-[0_0_50px_rgba(79,70,229,0.3)]">
            <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-rose-400">
              {earnedStars >= 2 ? 'LEVEL COMPLETED!' : 'CRASHED!'}
            </h2>

            {/* Star Rating Display */}
            <div className="flex items-center gap-2 my-2">
              {[1, 2, 3].map((star) => (
                <Trophy
                  key={star}
                  className={`w-10 h-10 ${
                    star <= earnedStars ? 'text-amber-400 fill-amber-400 animate-pulse' : 'text-slate-700'
                  }`}
                />
              ))}
            </div>

            {/* Score & Loot summary */}
            <div className="w-full grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="flex flex-col items-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Distance</span>
                <span className="text-lg font-black text-white">{currentDistance}m</span>
              </div>

              <div className="flex flex-col items-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Coins Collected</span>
                <span className="text-lg font-black text-amber-400">+{currentCoins}</span>
              </div>
            </div>

            <button
              onClick={handleClaimAndFinish}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-rose-500 to-amber-400 hover:brightness-110 text-slate-950 font-black text-lg shadow-xl active:scale-95 flex items-center justify-center gap-2"
            >
              <span>{earnedStars >= 1 ? 'NEXT LEVEL ➔' : 'TRY AGAIN ↻'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
