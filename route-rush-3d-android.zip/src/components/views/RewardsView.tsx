import React, { useState, useEffect } from 'react';
import { Gift, Sparkles, Trophy, Coins, Gem, Key, Clock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { audio } from '../../utils/audio';

interface RewardsViewProps {
  onAddReward: (coins: number, gems: number, keys: number) => void;
}

export const RewardsView: React.FC<RewardsViewProps> = ({ onAddReward }) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState<string | null>(null);

  const [hasSpunToday, setHasSpunToday] = useState<boolean>(() => {
    const last = localStorage.getItem('route_rush_last_spin');
    if (!last) return false;
    const lastDate = new Date(Number(last)).toDateString();
    const todayDate = new Date().toDateString();
    return lastDate === todayDate;
  });

  const handleSpinWheel = () => {
    if (isSpinning || hasSpunToday) return;
    audio.playChestOpen();
    setIsSpinning(true);
    setSpinResult(null);

    setTimeout(() => {
      const outcomes = [
        { label: '500 Coins', coins: 500, gems: 0, keys: 0 },
        { label: '1,500 Coins', coins: 1500, gems: 0, keys: 0 },
        { label: '25 Gems', coins: 0, gems: 25, keys: 0 },
        { label: '1 Key', coins: 0, gems: 0, keys: 1 },
        { label: '3,000 Coins & 50 Gems', coins: 3000, gems: 50, keys: 0 },
      ];
      const win = outcomes[Math.floor(Math.random() * outcomes.length)];
      setSpinResult(win.label);
      setIsSpinning(false);
      setHasSpunToday(true);
      localStorage.setItem('route_rush_last_spin', String(Date.now()));
      onAddReward(win.coins, win.gems, win.keys);

      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    }, 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 text-white select-none pb-28">
      {/* Daily Lucky Spin Wheel Card */}
      <div className="p-6 rounded-3xl bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 shadow-2xl mb-6 flex flex-col items-center text-center">
        <div className="flex items-center gap-2 text-xs font-black uppercase text-amber-400 mb-1">
          <Sparkles className="w-4 h-4" />
          <span>Daily Lucky Rewards</span>
        </div>

        <h2 className="text-2xl font-black text-white">SPIN THE RUSH WHEEL</h2>
        <p className="text-xs text-slate-300 mt-1 max-w-md">
          Spin once every day to claim guaranteed Coins, Gems, Keys, and bonus rewards!
        </p>

        {/* Wheel Graphic */}
        <div className="relative my-6 w-48 h-48 rounded-full border-4 border-amber-400/80 bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow-[0_0_30px_rgba(251,191,36,0.5)]">
          <div
            className={`text-6xl transition-transform duration-[2000ms] ${
              isSpinning ? 'rotate-[1440deg]' : ''
            }`}
          >
            🎡
          </div>
          <div className="absolute inset-0 rounded-full border-4 border-dashed border-white/30 animate-spin-slow pointer-events-none" />
        </div>

        {spinResult && (
          <div className="mb-4 px-4 py-2 rounded-2xl bg-amber-400/20 text-amber-300 border border-amber-400/40 font-black text-base animate-bounce">
            YOU WON: {spinResult}!
          </div>
        )}

        {hasSpunToday && !isSpinning && (
          <div className="mb-4 px-4 py-2 rounded-2xl bg-slate-800/80 text-amber-300 border border-amber-500/30 font-bold text-xs flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>ALREADY SPUN TODAY! COME BACK TOMORROW ⏳</span>
          </div>
        )}

        <button
          onClick={handleSpinWheel}
          disabled={isSpinning || hasSpunToday}
          className="py-3.5 px-10 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-base shadow-xl hover:brightness-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSpinning ? 'Spinning...' : hasSpunToday ? 'SPUN FOR TODAY' : 'FREE DAILY SPIN'}
        </button>
      </div>

      {/* Level Milestone Progression Chests */}
      <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3">
        Level Milestone Chests
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { level: 10, title: 'Bonus Chest', reward: '500 Coins', rarity: 'Common', icon: '📦' },
          { level: 25, title: 'Rare Chest', reward: '2,000 Coins + 20 Gems', rarity: 'Rare', icon: '🎁' },
          { level: 50, title: 'Epic Chest', reward: '5,000 Coins + 50 Gems', rarity: 'Epic', icon: '💎' },
          { level: 100, title: 'Legendary Chest', reward: '10,000 Coins + 100 Gems', rarity: 'Legendary', icon: '👑' },
        ].map((chest) => (
          <div
            key={chest.level}
            className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center shadow-md"
          >
            <div className="text-4xl mb-2">{chest.icon}</div>
            <span className="text-[10px] font-black uppercase text-amber-400">Level {chest.level}</span>
            <h4 className="text-sm font-bold text-white mt-1">{chest.title}</h4>
            <p className="text-[11px] text-slate-400 mt-1">{chest.reward}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
