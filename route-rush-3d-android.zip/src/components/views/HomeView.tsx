import React from 'react';
import { PlayerProfile, GameMode } from '../../types';
import { WORLDS, CHARACTERS, CARS } from '../../data/mockData';
import { getWorldForLevel, generateLevelData } from '../../utils/levelGenerator';
import { Play, Sparkles, Trophy, ChevronLeft, ChevronRight, Zap } from 'lucide-react';
import { audio } from '../../utils/audio';

interface HomeViewProps {
  profile: PlayerProfile;
  selectedMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  onStartGame: () => void;
  onNavigateToGarage: () => void;
  onNavigateToHeroes: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  profile,
  selectedMode,
  onSelectMode,
  onStartGame,
  onNavigateToGarage,
  onNavigateToHeroes,
}) => {
  const currentWorld = getWorldForLevel(profile.currentLevel);
  const currentLevelData = generateLevelData(profile.currentLevel, selectedMode);

  const selectedChar = CHARACTERS.find((c) => c.id === profile.selectedCharacterId) || CHARACTERS[0];
  const selectedCar = CARS.find((c) => c.id === profile.selectedCarId) || CARS[0];

  return (
    <div className="flex flex-col items-center justify-between w-full min-h-[calc(100vh-120px)] p-4 max-w-4xl mx-auto text-white select-none pb-24">
      {/* World Preview Card Banner */}
      <div className="relative w-full p-6 rounded-3xl overflow-hidden border border-slate-700/60 shadow-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* World Accent Ambient Glow */}
        <div
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{ backgroundColor: currentWorld.accentColor }}
        />

        <div className="relative z-10 flex flex-col text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start gap-2 text-xs font-black uppercase tracking-widest text-cyan-400">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>World {currentWorld.id} / 12</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
            {currentWorld.name}
          </h2>

          <p className="text-xs text-slate-300 mt-1 max-w-md">
            {currentWorld.description}
          </p>

          <div className="flex items-center justify-center sm:justify-start gap-3 mt-3 text-xs font-bold text-slate-400">
            <span className="px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-amber-300">
              Weather: {currentWorld.weather}
            </span>
            <span className="px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-indigo-300">
              Time: {currentWorld.timeOfDay}
            </span>
          </div>
        </div>

        {/* Current Progression Level Badge */}
        <div className="relative z-10 flex items-center gap-3 p-4 rounded-2xl bg-slate-950/90 border border-amber-500/30 shadow-inner">
          <div className="flex flex-col items-center min-w-[120px]">
            <span className="text-[10px] font-black uppercase text-amber-400 tracking-widest">
              CURRENT PROGRESS
            </span>
            <span className="text-2xl sm:text-3xl font-black text-white mt-0.5">
              LEVEL {profile.currentLevel}
            </span>
            <div className="flex items-center gap-2 text-[11px] font-bold text-slate-300 mt-1">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>Target: {currentLevelData.targetDistance}m &bull; {currentLevelData.targetCoins} Coins</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mode Switcher Buttons Grid (4 Modes) */}
      <div className="w-full mt-6 grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-2xl">
        <button
          onClick={() => {
            audio.playClick();
            onSelectMode('runner');
          }}
          className={`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${
            selectedMode === 'runner'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 border-indigo-400 text-white shadow-[0_0_20px_rgba(99,102,241,0.5)] scale-105'
              : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400'
          }`}
        >
          <span className="text-2xl">🏃‍♂️</span>
          <span>RUNNER</span>
        </button>

        <button
          onClick={() => {
            audio.playClick();
            onSelectMode('racer');
          }}
          className={`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${
            selectedMode === 'racer'
              ? 'bg-gradient-to-r from-rose-600 to-amber-600 border-rose-400 text-white shadow-[0_0_20px_rgba(244,63,94,0.5)] scale-105'
              : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400'
          }`}
        >
          <span className="text-2xl">🏎️</span>
          <span>CAR DRIVER</span>
        </button>

        <button
          onClick={() => {
            audio.playClick();
            onSelectMode('ball');
          }}
          className={`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${
            selectedMode === 'ball'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 border-cyan-400 text-white shadow-[0_0_20px_rgba(6,182,212,0.5)] scale-105'
              : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400'
          }`}
        >
          <span className="text-2xl">⚽</span>
          <span>GOING BALLS</span>
        </button>

        <button
          onClick={() => {
            audio.playClick();
            onSelectMode('motorbike');
          }}
          className={`py-3 px-3 rounded-2xl border font-black text-xs flex flex-col items-center justify-center gap-1.5 transition-all duration-200 active:scale-95 ${
            selectedMode === 'motorbike'
              ? 'bg-gradient-to-r from-emerald-500 to-teal-600 border-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.5)] scale-105'
              : 'bg-slate-900/80 hover:bg-slate-800/80 border-slate-800 text-slate-400'
          }`}
        >
          <span className="text-2xl">🏍️</span>
          <span>MOTORBIKE</span>
        </button>
      </div>

      {/* Main Play Action Button */}
      <div className="my-8 flex flex-col items-center">
        <button
          onClick={() => {
            audio.playVictory();
            onStartGame();
          }}
          className="relative group py-6 px-16 rounded-full bg-gradient-to-r from-amber-400 via-rose-500 to-amber-400 hover:brightness-110 text-slate-950 font-black text-3xl tracking-wide shadow-[0_0_40px_rgba(251,191,36,0.6)] flex items-center justify-center gap-4 transition-all duration-300 active:scale-95 transform hover:-translate-y-1"
        >
          <Play className="w-10 h-10 fill-slate-950 group-hover:scale-110 transition-transform" />
          <span>PLAY RUSH</span>

          {/* Energy cost badge */}
          <div className="absolute -top-3 -right-3 flex items-center gap-1 px-3 py-1 rounded-full bg-slate-950 text-amber-400 border border-amber-400 text-xs font-black shadow-lg">
            <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>-1</span>
          </div>
        </button>
      </div>

      {/* Loadout Hero & Car Quick Change Cards */}
      <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Hero Card */}
        <div
          onClick={onNavigateToHeroes}
          className="p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 cursor-pointer flex items-center justify-between transition-all active:scale-95"
        >
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-950 border border-indigo-500/40 text-3xl">
              {selectedChar.avatarUrl}
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">
                Active Hero
              </span>
              <span className="text-sm font-bold text-white">{selectedChar.name}</span>
              <span className="text-[11px] text-slate-400">{selectedChar.perk}</span>
            </div>
          </div>
          <span className="text-xs font-bold text-cyan-400 hover:underline">Change &gt;</span>
        </div>

        {/* Car Card */}
        <div
          onClick={onNavigateToGarage}
          className="p-4 rounded-2xl bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 cursor-pointer flex items-center justify-between transition-all active:scale-95"
        >
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-rose-950 border border-rose-500/40 text-3xl">
              🏎️
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider">
                Active Vehicle
              </span>
              <span className="text-sm font-bold text-white">{selectedCar.name}</span>
              <span className="text-[11px] text-slate-400">
                Speed: {selectedCar.topSpeed} / Handling: {selectedCar.handling}
              </span>
            </div>
          </div>
          <span className="text-xs font-bold text-cyan-400 hover:underline">Garage &gt;</span>
        </div>
      </div>
    </div>
  );
};
