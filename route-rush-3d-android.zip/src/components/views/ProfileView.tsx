import React, { useState } from 'react';
import { PlayerProfile, Achievement } from '../../types';
import { User, Trophy, Shield, Coins, Gem, Cloud, KeyRound, Check, Sparkles } from 'lucide-react';
import { audio } from '../../utils/audio';

interface ProfileViewProps {
  profile: PlayerProfile;
  achievements: Achievement[];
  onUpgradeGuestAccount: (username: string, email: string) => void;
  onClaimAchievement: (achId: string) => void;
  onSyncCloudSave: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  achievements,
  onUpgradeGuestAccount,
  onClaimAchievement,
  onSyncCloudSave,
}) => {
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');

  const [synced, setSynced] = useState(false);

  const handleUpgradeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim()) return;
    audio.playVictory();
    onUpgradeGuestAccount(newUsername.trim(), newEmail.trim());
    setShowUpgradeModal(false);
  };

  const handleCloudSync = () => {
    audio.playClick();
    setSynced(true);
    onSyncCloudSave();
    setTimeout(() => setSynced(false), 2500);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 text-white select-none pb-28">
      {/* Profile Header Box */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 shadow-2xl mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-indigo-600 text-4xl shadow-inner border border-white/20">
            {profile.avatar}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-black text-white">{profile.username}</h2>
              {profile.isGuest && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Guest
                </span>
              )}
            </div>

            <p className="text-xs text-slate-400 mt-1">Level {profile.level} Racer • ID: {profile.id}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {profile.isGuest && (
            <button
              onClick={() => {
                audio.playClick();
                setShowUpgradeModal(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs shadow hover:brightness-110 active:scale-95"
            >
              Upgrade Account
            </button>
          )}

          <button
            onClick={handleCloudSync}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 active:scale-95 flex items-center gap-1.5 text-xs font-bold"
          >
            <Cloud className={`w-4 h-4 ${synced ? 'text-emerald-400 animate-bounce' : 'text-cyan-400'}`} />
            <span>{synced ? 'Synced!' : 'Cloud Sync'}</span>
          </button>
        </div>
      </div>

      {/* Lifetime Career Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Levels Done</span>
          <span className="text-xl font-black text-white mt-1">{profile.totalLevelsCompleted}</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Coins Collected</span>
          <span className="text-xl font-black text-amber-400 mt-1">
            {profile.totalCoinsCollected.toLocaleString()}
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Distance Driven</span>
          <span className="text-xl font-black text-cyan-400 mt-1">
            {(profile.totalDistanceDriven / 1000).toFixed(1)} km
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center text-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase">High Score</span>
          <span className="text-xl font-black text-rose-400 mt-1">
            {Math.max(profile.highScoreRunner, profile.highScoreRacer).toLocaleString()}
          </span>
        </div>
      </div>

      {/* Achievements List */}
      <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
        <Trophy className="w-4 h-4 text-amber-400" />
        <span>Achievements Gallery</span>
      </h3>

      <div className="flex flex-col gap-3">
        {achievements.map((ach) => {
          const isComplete = ach.current >= ach.target;
          const progressPercent = Math.min(100, Math.round((ach.current / ach.target) * 100));

          return (
            <div
              key={ach.id}
              className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm"
            >
              <div className="flex items-center gap-3.5 w-full sm:w-auto">
                <div className="p-3 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-800">
                  <Trophy className="w-6 h-6" />
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white">{ach.title}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">{ach.description}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                <div className="flex items-center gap-1 text-xs font-bold text-amber-300">
                  <span>+{ach.rewardAmount}</span>
                  {ach.rewardType === 'coins' && <Coins className="w-4 h-4 text-amber-400" />}
                  {ach.rewardType === 'gems' && <Gem className="w-4 h-4 text-cyan-400" />}
                </div>

                {ach.claimed ? (
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                    <Check className="w-4 h-4" />
                    <span>Unlocked</span>
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      audio.playVictory();
                      onClaimAchievement(ach.id);
                    }}
                    disabled={!isComplete}
                    className="px-4 py-2 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs disabled:opacity-30"
                  >
                    Claim
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Upgrade Guest Modal */}
      {showUpgradeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <form
            onSubmit={handleUpgradeSubmit}
            className="w-full max-w-sm p-6 rounded-3xl bg-slate-900 border border-amber-500/40 text-center flex flex-col gap-4"
          >
            <h3 className="text-2xl font-black text-white">UPGRADE ACCOUNT</h3>
            <p className="text-xs text-slate-300">
              Link your guest progress to a permanent account with cloud saves!
            </p>

            <input
              type="text"
              required
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              placeholder="Desired Username"
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm"
            />

            <input
              type="email"
              required
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="Email address"
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm"
            />

            <div className="flex gap-2 mt-2">
              <button
                type="button"
                onClick={() => setShowUpgradeModal(false)}
                className="w-1/3 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-sm font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm"
              >
                Upgrade Now
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
