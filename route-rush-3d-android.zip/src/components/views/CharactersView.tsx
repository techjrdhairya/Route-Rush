import React from 'react';
import { PlayerProfile, CharacterItem } from '../../types';
import { CHARACTERS } from '../../data/mockData';
import { Users, Sparkles, Check, Lock, Coins, Gem } from 'lucide-react';
import { audio } from '../../utils/audio';

interface CharactersViewProps {
  profile: PlayerProfile;
  onSelectCharacter: (charId: string) => void;
  onUnlockCharacter: (char: CharacterItem) => void;
}

export const CharactersView: React.FC<CharactersViewProps> = ({
  profile,
  onSelectCharacter,
  onUnlockCharacter,
}) => {
  const selectedChar = CHARACTERS.find((c) => c.id === profile.selectedCharacterId) || CHARACTERS[0];
  const isSelectedUnlocked = profile.unlockedCharacters.includes(selectedChar.id);

  return (
    <div className="w-full max-w-4xl mx-auto p-4 text-white select-none pb-28">
      {/* Featured Hero Preview Showcase */}
      <div className="relative p-6 rounded-3xl bg-gradient-to-b from-indigo-950 via-slate-900 to-slate-950 border border-indigo-500/30 shadow-2xl mb-6 flex flex-col items-center">
        <div className="relative w-full h-52 sm:h-64 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-center overflow-hidden mb-4">
          <div
            className="absolute inset-0 opacity-20 pointer-events-none"
            style={{ backgroundColor: selectedChar.color }}
          />

          <div className="relative z-10 flex flex-col items-center">
            <span className="text-8xl sm:text-9xl drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)] animate-pulse">
              {selectedChar.avatarUrl}
            </span>
            <span className="text-xs font-black uppercase text-indigo-300 mt-2 px-3 py-1 rounded-full bg-indigo-950 border border-indigo-800">
              {selectedChar.title}
            </span>
          </div>
        </div>

        <div className="w-full flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-white">{selectedChar.name}</h2>
            <p className="text-xs text-amber-300 font-bold mt-0.5">Perk: {selectedChar.perk}</p>
          </div>

          {!isSelectedUnlocked ? (
            <button
              onClick={() => {
                audio.playClick();
                onUnlockCharacter(selectedChar);
              }}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-sm shadow-lg flex items-center gap-1.5 hover:brightness-110 active:scale-95"
            >
              <span>Unlock ({selectedChar.price} {selectedChar.currency})</span>
            </button>
          ) : (
            <button
              disabled
              className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold text-xs border border-emerald-500/30 flex items-center gap-1"
            >
              <Check className="w-4 h-4" />
              <span>EQUIPPED HERO</span>
            </button>
          )}
        </div>
      </div>

      {/* Hero Roster Grid */}
      <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3">
        Hero Roster
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {CHARACTERS.map((char) => {
          const isSel = char.id === selectedChar.id;
          const isUnl = profile.unlockedCharacters.includes(char.id);

          return (
            <div
              key={char.id}
              onClick={() => {
                audio.playClick();
                onSelectCharacter(char.id);
              }}
              className={`p-4 rounded-2xl border cursor-pointer transition-all duration-200 active:scale-95 flex items-center justify-between ${
                isSel
                  ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-lg'
                  : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-850'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="text-4xl">{char.avatarUrl}</div>
                <div>
                  <h4 className="text-sm font-bold text-white">{char.name}</h4>
                  <p className="text-[11px] text-slate-400">{char.perk}</p>
                </div>
              </div>

              <div>
                {isUnl ? (
                  <span className="text-[10px] font-black uppercase px-2 py-1 rounded bg-emerald-500/20 text-emerald-300">
                    Unlocked
                  </span>
                ) : (
                  <Lock className="w-4 h-4 text-amber-400" />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
