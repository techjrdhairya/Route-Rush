import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { GameMode, WorldTheme, PlayerProfile, LevelData } from '../../types';
import {
  createRunnerMesh,
  createCarMesh,
  createBallMesh,
  createMotorbikeMesh,
  createTrainMesh,
  createBarrierMesh,
  createCoinMesh,
  createGemMesh,
  createPowerupMesh,
  createFinishGateMesh,
} from './3dModels';
import { audio } from '../../utils/audio';

interface ThreeGameCanvasProps {
  mode: GameMode;
  world: WorldTheme;
  profile: PlayerProfile;
  levelData: LevelData;
  isPlaying: boolean;
  isPaused: boolean;
  onCoinCollect: (count: number) => void;
  onGemCollect: (count: number) => void;
  onDistanceUpdate: (meters: number) => void;
  onGameOver: (score: number, coins: number, distance: number) => void;
  onPowerupActive?: (type: string, duration: number) => void;
  inputAction?: { type: 'left' | 'right' | 'up' | 'down'; id: number } | null;
}

export const ThreeGameCanvas: React.FC<ThreeGameCanvasProps> = ({
  mode,
  world,
  profile,
  levelData,
  isPlaying,
  isPaused,
  onCoinCollect,
  onGemCollect,
  onDistanceUpdate,
  onGameOver,
  onPowerupActive,
  inputAction,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Synchronize playing and paused state refs so scene isn't re-instantiated on pause/play
  const isPlayingRef = useRef(isPlaying);
  const isPausedRef = useRef(isPaused);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
    isPausedRef.current = isPaused;
  }, [isPlaying, isPaused]);

  // Auto focus window for keyboard controls
  useEffect(() => {
    try {
      window.focus();
    } catch {
      // ignore focus errors
    }
  }, []);

  // Gameplay internal state refs
  const lastDistanceRef = useRef(0);
  const stateRef = useRef({
    lane: 0, // -1 (left), 0 (center), 1 (right)
    targetX: 0,
    currentX: 0,
    posY: 0,
    velocityY: 0,
    isJumping: false,
    isSliding: false,
    isDashing: false,
    nitroActive: false,
    distanceMeters: 0,
    coinsCollected: 0,
    gemsCollected: 0,
    speed:
      mode === 'runner'
        ? 0.35
        : mode === 'ball'
        ? 0.55
        : mode === 'motorbike'
        ? 0.72
        : 0.65,
    magnetTimer: 0,
    shieldActive: false,
    hoverboardActive: false,
    jetpackTimer: 0,
    multiplierTimer: 0,
    gameOverHandled: false,
  });

  // Reset gameplay metrics when starting or retrying a run
  useEffect(() => {
    if (isPlaying) {
      stateRef.current = {
        lane: 0,
        targetX: 0,
        currentX: 0,
        posY: 0,
        velocityY: 0,
        isJumping: false,
        isSliding: false,
        isDashing: false,
        nitroActive: false,
        distanceMeters: 0,
        coinsCollected: 0,
        gemsCollected: 0,
        speed:
          mode === 'runner'
            ? 0.35
            : mode === 'ball'
            ? 0.55
            : mode === 'motorbike'
            ? 0.72
            : 0.65,
        magnetTimer: 0,
        shieldActive: false,
        hoverboardActive: false,
        jetpackTimer: 0,
        multiplierTimer: 0,
        gameOverHandled: false,
      };
    }
  }, [isPlaying, mode]);

  useEffect(() => {
    if (!containerRef.current) return;

    // 1. Setup Three.js Scene, Camera, Renderer
    const width = containerRef.current.clientWidth || window.innerWidth;
    const height = containerRef.current.clientHeight || window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(world.skyColor);
    scene.fog = new THREE.FogExp2(world.fogColor, 0.015);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, mode === 'runner' ? 3.5 : mode === 'ball' ? 3.8 : 2.8, mode === 'runner' ? -6 : -5);
    camera.lookAt(0, 1.2, 10);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;

    containerRef.current.appendChild(renderer.domElement);

    // 2. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(10, 20, 10);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    scene.add(dirLight);

    // 3. Track Ground & Lanes
    const trackWidth = 7.5;
    const trackLength = 200;
    const groundGeo = new THREE.PlaneGeometry(trackWidth, trackLength);
    const groundMat = new THREE.MeshStandardMaterial({
      color: world.groundColor,
      roughness: 0.6,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.z = trackLength / 2 - 10;
    ground.receiveShadow = true;
    scene.add(ground);

    // Dynamic Road Asphalt Grid Stripes (Scrolling forward/backward motion cue)
    const roadGridGroup = new THREE.Group();
    for (let z = 0; z < trackLength; z += 4) {
      const stripeGeo = new THREE.PlaneGeometry(trackWidth, 0.2);
      const stripeMat = new THREE.MeshBasicMaterial({ color: '#1e293b', transparent: true, opacity: 0.4 });
      const stripe = new THREE.Mesh(stripeGeo, stripeMat);
      stripe.rotation.x = -Math.PI / 2;
      stripe.position.set(0, 0.01, z);
      roadGridGroup.add(stripe);
    }
    scene.add(roadGridGroup);

    // Lane dividing lines
    const laneLinesGroup = new THREE.Group();
    for (let z = 0; z < trackLength; z += 6) {
      [-1.25, 1.25].forEach((x) => {
        const lineGeo = new THREE.PlaneGeometry(0.12, 3);
        const lineMat = new THREE.MeshBasicMaterial({ color: world.accentColor });
        const line = new THREE.Mesh(lineGeo, lineMat);
        line.rotation.x = -Math.PI / 2;
        line.position.set(x, 0.02, z);
        laneLinesGroup.add(line);
      });
    }
    scene.add(laneLinesGroup);

    // High-contrast Side Curbs / Guardrails (Strong visual speed indicator)
    const curbsGroup = new THREE.Group();
    for (let z = 0; z < trackLength; z += 4) {
      [-3.7, 3.7].forEach((x) => {
        const curbGeo = new THREE.BoxGeometry(0.3, 0.25, 2);
        const isRed = Math.floor(z / 4) % 2 === 0;
        const curbMat = new THREE.MeshStandardMaterial({ color: isRed ? '#ef4444' : '#ffffff' });
        const curb = new THREE.Mesh(curbGeo, curbMat);
        curb.position.set(x, 0.12, z);
        curbsGroup.add(curb);
      });
    }
    scene.add(curbsGroup);

    // Side Scenery Posts, Streetlamps, Buildings & Trees
    const sceneryGroup = new THREE.Group();
    for (let z = 0; z < trackLength; z += 10) {
      [-4.8, 4.8].forEach((x) => {
        const post = new THREE.Mesh(
          new THREE.CylinderGeometry(0.08, 0.08, 3.5),
          new THREE.MeshStandardMaterial({ color: '#334155' })
        );
        post.position.set(x, 1.75, z);

        const lamp = new THREE.Mesh(
          new THREE.SphereGeometry(0.28, 8, 8),
          new THREE.MeshBasicMaterial({ color: world.accentColor })
        );
        lamp.position.set(x > 0 ? x - 0.4 : x + 0.4, 3.4, z);

        sceneryGroup.add(post, lamp);
      });

      // Side Buildings / City Towers for strong optical motion feedback
      [-8.5, 8.5].forEach((x, idx) => {
        const bHeight = 7 + (Math.abs(z * 3 + idx * 7) % 10);
        const buildingMat = new THREE.MeshStandardMaterial({
          color: (z + idx) % 2 === 0 ? '#1e293b' : '#0f172a',
          roughness: 0.2,
          metalness: 0.5,
        });
        const building = new THREE.Mesh(new THREE.BoxGeometry(3.5, bHeight, 4), buildingMat);
        building.position.set(x, bHeight / 2, z);

        // Glowing window stripes
        const winGeo = new THREE.PlaneGeometry(0.4, 0.8);
        const winMat = new THREE.MeshBasicMaterial({ color: world.accentColor });
        const windowMesh = new THREE.Mesh(winGeo, winMat);
        windowMesh.position.set(x > 0 ? x - 1.76 : x + 1.76, bHeight * 0.6, z);
        if (x > 0) windowMesh.rotation.y = -Math.PI / 2;
        else windowMesh.rotation.y = Math.PI / 2;

        sceneryGroup.add(building, windowMesh);
      });
    }
    scene.add(sceneryGroup);

    // Overhead Glowing Portals / Arches
    const archGroup = new THREE.Group();
    for (let z = 20; z < trackLength; z += 35) {
      const archMat = new THREE.MeshStandardMaterial({
        color: world.accentColor,
        emissive: world.accentColor,
        emissiveIntensity: 0.8,
      });
      const topBar = new THREE.Mesh(new THREE.BoxGeometry(9.5, 0.4, 0.6), archMat);
      topBar.position.set(0, 4.6, z);

      const pillarL = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4.6, 0.6), archMat);
      pillarL.position.set(-4.6, 2.3, z);

      const pillarR = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4.6, 0.6), archMat);
      pillarR.position.set(4.6, 2.3, z);

      archGroup.add(topBar, pillarL, pillarR);
    }
    scene.add(archGroup);

    // 4. Player, Vehicle, Ball, or Motorbike Mesh
    let playerObj: THREE.Group;
    if (mode === 'runner') {
      const charColor = profile.carPaints[profile.selectedCharacterId] || '#3b82f6';
      playerObj = createRunnerMesh(charColor, profile.selectedCharacterId);
    } else if (mode === 'ball') {
      const ballColor = profile.carPaints[profile.selectedCarId] || '#38bdf8';
      playerObj = createBallMesh(ballColor);
    } else if (mode === 'motorbike') {
      const bikeColor = profile.carPaints[profile.selectedCarId] || '#e11d48';
      playerObj = createMotorbikeMesh(bikeColor);
    } else {
      const carColor = profile.carPaints[profile.selectedCarId] || '#ef4444';
      const neonColor = profile.carNeon[profile.selectedCarId] || '#00f0ff';
      playerObj = createCarMesh(carColor, profile.selectedCarId, neonColor);
    }
    playerObj.position.set(0, 0, 0);
    scene.add(playerObj);

    // Finish Gate Portal Mesh
    const finishGateObj = createFinishGateMesh();
    finishGateObj.position.set(0, 0, levelData.targetDistance);
    scene.add(finishGateObj);

    // 5. Dynamic Obstacles & Collectibles Pools
    const obstacles: { mesh: THREE.Object3D; lane: number; type: string }[] = [];
    const collectibles: {
      mesh: THREE.Object3D;
      lane: number;
      type: 'coin' | 'gem' | 'powerup';
      powerupType?: 'magnet' | 'shield' | 'jetpack' | 'hoverboard' | 'nitro' | 'multiplier';
    }[] = [];

    // Helper to select powerups by mode
    const getRandomPowerupType = (): 'magnet' | 'shield' | 'jetpack' | 'hoverboard' | 'nitro' | 'multiplier' => {
      if (mode === 'runner') {
        const pool: ('jetpack' | 'hoverboard' | 'magnet' | 'shield')[] = ['jetpack', 'hoverboard', 'magnet', 'shield'];
        return pool[Math.floor(Math.random() * pool.length)];
      } else {
        const pool: ('nitro' | 'shield' | 'magnet' | 'multiplier')[] = ['nitro', 'shield', 'magnet', 'multiplier'];
        return pool[Math.floor(Math.random() * pool.length)];
      }
    };

    // Spawn initial track items
    for (let z = 18; z < trackLength; z += 12 + Math.random() * 8) {
      const lane = Math.floor(Math.random() * 3) - 1; // -1, 0, 1
      const laneX = -lane * 2.2;

      if (z > 50 && Math.random() > 0.4) {
        // Spawn Obstacle
        const isTrain = mode === 'runner' && Math.random() > 0.6;
        const mesh = isTrain ? createTrainMesh() : createBarrierMesh();
        mesh.position.set(laneX, 0.2, z);
        scene.add(mesh);
        obstacles.push({ mesh, lane, type: isTrain ? 'train' : 'barrier' });
      } else {
        // Spawn Coin, Gem, or Powerup
        const isGem = Math.random() < 0.15;
        const isPowerup = Math.random() < 0.12;

        let itemMesh: THREE.Object3D;
        let type: 'coin' | 'gem' | 'powerup' = 'coin';
        let pType: 'magnet' | 'shield' | 'jetpack' | 'hoverboard' | 'nitro' | 'multiplier' | undefined;

        if (isPowerup) {
          type = 'powerup';
          pType = getRandomPowerupType();
          itemMesh = createPowerupMesh(pType);
        } else if (isGem) {
          type = 'gem';
          itemMesh = createGemMesh();
        } else {
          itemMesh = createCoinMesh();
        }

        itemMesh.position.set(laneX, 1.2, z);
        scene.add(itemMesh);
        collectibles.push({ mesh: itemMesh, lane, type, powerupType: pType });
      }
    }

    // Weather Particles setup (Rain/Snow/Cyber Fog)
    let particleSystem: THREE.Points | null = null;
    if (world.weather === 'rain' || world.weather === 'snow' || world.weather === 'sandstorm') {
      const particleCount = 300;
      const pGeo = new THREE.BufferGeometry();
      const pPos = new Float32Array(particleCount * 3);

      for (let i = 0; i < particleCount * 3; i += 3) {
        pPos[i] = (Math.random() - 0.5) * 20;
        pPos[i + 1] = Math.random() * 15;
        pPos[i + 2] = Math.random() * 50;
      }
      pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
      const pMat = new THREE.PointsMaterial({
        color: world.weather === 'snow' ? 0xffffff : 0x38bdf8,
        size: world.weather === 'snow' ? 0.25 : 0.15,
        transparent: true,
        opacity: 0.7,
      });
      particleSystem = new THREE.Points(pGeo, pMat);
      scene.add(particleSystem);
    }

    // 6. User Inputs (Swipe & Keyboard)
    let touchStartX = 0;
    let touchStartY = 0;

    const triggerLeft = () => {
      if (stateRef.current.lane > -1) {
        stateRef.current.lane -= 1;
        audio.playDash();
      }
    };

    const triggerRight = () => {
      if (stateRef.current.lane < 1) {
        stateRef.current.lane += 1;
        audio.playDash();
      }
    };

    const triggerUp = () => {
      const state = stateRef.current;
      if (mode === 'racer' || mode === 'motorbike' || mode === 'ball') {
        state.nitroActive = true;
        audio.playNitro();
        setTimeout(() => {
          state.nitroActive = false;
        }, 1200);
      } else {
        if (!state.isJumping) {
          state.isJumping = true;
          state.velocityY = 0.4;
          audio.playJump();
        }
      }
    };

    const triggerDown = () => {
      stateRef.current.isSliding = true;
      setTimeout(() => {
        stateRef.current.isSliding = false;
      }, 600);
    };

    const handleTouchStart = (e: TouchEvent) => {
      touchStartX = e.touches[0].clientX;
      touchStartY = e.touches[0].clientY;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (!isPlayingRef.current || isPausedRef.current) return;
      const dx = e.changedTouches[0].clientX - touchStartX;
      const dy = e.changedTouches[0].clientY - touchStartY;

      if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 25) {
        if (dx < 0) triggerLeft();
        else if (dx > 0) triggerRight();
      } else if (Math.abs(dy) > 25) {
        if (dy < 0) triggerUp();
        else if (dy > 0) triggerDown();
      }
    };

    const handlePointerDown = (e: MouseEvent) => {
      if (!isPlayingRef.current || isPausedRef.current) return;
      const rect = domEl.getBoundingClientRect();
      const xRatio = (e.clientX - rect.left) / rect.width;
      const yRatio = (e.clientY - rect.top) / rect.height;

      if (xRatio < 0.35) {
        triggerLeft();
      } else if (xRatio > 0.65) {
        triggerRight();
      } else if (yRatio < 0.35) {
        triggerUp();
      } else if (yRatio > 0.7) {
        triggerDown();
      }
    };

    const domEl = renderer.domElement;
    domEl.addEventListener('touchstart', handleTouchStart);
    domEl.addEventListener('touchend', handleTouchEnd);
    domEl.addEventListener('mousedown', handlePointerDown);

    // 7. Animation Loop
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);

      if (!isPlayingRef.current || isPausedRef.current) {
        renderer.render(scene, camera);
        return;
      }

      const state = stateRef.current;

      // Handle powerup timers
      if (state.jetpackTimer > 0) {
        state.jetpackTimer -= 0.016;
        state.posY = 3.2; // Fly high over obstacles
        if (state.jetpackTimer <= 0) {
          state.jetpackTimer = 0;
          state.posY = 0;
        }
      }

      if (state.magnetTimer > 0) {
        state.magnetTimer -= 0.016;
        if (state.magnetTimer <= 0) state.magnetTimer = 0;
      }

      if (state.multiplierTimer > 0) {
        state.multiplierTimer -= 0.016;
        if (state.multiplierTimer <= 0) state.multiplierTimer = 0;
      }

      // Update distance & speed
      const currentSpeed = state.nitroActive ? state.speed * 1.8 : state.speed;
      state.distanceMeters += currentSpeed * 0.5;
      const distInt = Math.floor(state.distanceMeters);
      if (distInt !== lastDistanceRef.current) {
        lastDistanceRef.current = distInt;
        onDistanceUpdate(distInt);
      }

      // Lane interpolation & steering bank rotation
      state.targetX = -state.lane * 2.6;
      const dx = state.targetX - state.currentX;
      state.currentX += dx * 0.3;
      playerObj.position.x = state.currentX;

      if (mode === 'ball') {
        // Going Balls Physics: Strict rigid sphere, no shape changing, rolling physics
        const ballSphere = playerObj.getObjectByName('ballSphere');
        if (ballSphere) {
          ballSphere.rotation.x += currentSpeed * 1.8; // Rolling forward along X axis
          ballSphere.rotation.z = dx * 0.15;           // Smooth rolling bank
        }
        playerObj.rotation.z = 0;
        playerObj.rotation.y = 0;
        playerObj.scale.set(1, 1, 1); // Strictly no shape distortion!
      } else if (mode === 'motorbike') {
        // Motorbike agile leaning
        playerObj.rotation.z = dx * 0.35;
        playerObj.rotation.y = -dx * 0.18;
      } else {
        // Runner / Racer standard steering bank
        playerObj.rotation.z = dx * 0.25;
        playerObj.rotation.y = -dx * 0.15;
      }

      // Jump gravity (if not in jetpack)
      if (state.jetpackTimer <= 0) {
        if (state.isJumping) {
          state.posY += state.velocityY;
          state.velocityY -= 0.025; // gravity
          if (state.posY <= 0) {
            state.posY = 0;
            state.isJumping = false;
            state.velocityY = 0;
          }
        } else if (state.hoverboardActive) {
          state.posY = 0.4; // Hover smoothly above ground
        }
        playerObj.position.y = state.posY;
      }

      // Slide scale effect (only for runner/car, not for ball!)
      if (mode !== 'ball') {
        if (state.isSliding) {
          playerObj.scale.set(1.2, 0.4, 1.2);
        } else {
          playerObj.scale.set(1, 1, 1);
        }
      }

      // Scroll road asphalt grid backward
      roadGridGroup.children.forEach((stripe) => {
        stripe.position.z -= currentSpeed;
        if (stripe.position.z < -5) {
          stripe.position.z += trackLength;
        }
      });

      // Scroll road lane lines backward to create high speed motion
      laneLinesGroup.children.forEach((line) => {
        line.position.z -= currentSpeed;
        if (line.position.z < -5) {
          line.position.z += trackLength;
        }
      });

      // Scroll side curbs backward
      curbsGroup.children.forEach((curb) => {
        curb.position.z -= currentSpeed;
        if (curb.position.z < -5) {
          curb.position.z += trackLength;
        }
      });

      // Scroll scenery streetlamps & buildings backward
      sceneryGroup.children.forEach((item) => {
        item.position.z -= currentSpeed;
        if (item.position.z < -5) {
          item.position.z += trackLength;
        }
      });

      // Scroll overhead arches backward
      archGroup.children.forEach((arch) => {
        arch.position.z -= currentSpeed;
        if (arch.position.z < -5) {
          arch.position.z += trackLength;
        }
      });

      // Position Finish Gate & trigger level finish when passing through
      const remainingFinishDist = levelData.targetDistance - state.distanceMeters;
      finishGateObj.position.z = Math.max(-15, remainingFinishDist);

      if (remainingFinishDist <= 0 && !state.gameOverHandled) {
        state.gameOverHandled = true;
        audio.playVictory();
        onGameOver(
          Math.floor(state.distanceMeters * 10 + state.coinsCollected * 25),
          state.coinsCollected,
          Math.floor(state.distanceMeters)
        );
      }

      // Dynamic forward surge Z position based on Nitro / Speed
      let targetZ = 0;
      if (state.nitroActive) {
        targetZ = 1.2;
      } else if (state.isSliding) {
        targetZ = -0.5;
      }
      playerObj.position.z += (targetZ - playerObj.position.z) * 0.1;

      // Animate wheels or limbs
      const runTime = state.distanceMeters * 0.25;
      playerObj.children.forEach((child) => {
        if (child.name === 'leftLeg') {
          child.rotation.x = Math.sin(runTime) * 0.7;
        } else if (child.name === 'rightLeg') {
          child.rotation.x = -Math.sin(runTime) * 0.7;
        } else if (child.name === 'leftArm') {
          child.rotation.x = -Math.sin(runTime) * 0.7;
        } else if (child.name === 'rightArm') {
          child.rotation.x = Math.sin(runTime) * 0.7;
        } else if (child.name === 'wheel') {
          child.rotation.x += currentSpeed * 1.2;
        }
      });

      if (mode === 'racer' || mode === 'motorbike') {
        playerObj.position.y = state.posY + Math.sin(runTime * 2) * 0.02;
      }

      // Dynamic camera FOV warp speed zoom
      const targetFov = 60 + (currentSpeed - 0.35) * 22;
      if (Math.abs(camera.fov - targetFov) > 0.1) {
        camera.fov += (targetFov - camera.fov) * 0.1;
        camera.updateProjectionMatrix();
      }

      // Move collectibles & obstacles closer (simulating forward motion)
      collectibles.forEach((item) => {
        item.mesh.position.z -= currentSpeed;
        item.mesh.rotation.y += 0.05; // Spin coins/gems/powerups

        // Coin Magnet check
        if (state.magnetTimer > 0 && Math.abs(item.mesh.position.z) < 14) {
          item.mesh.position.x += (state.currentX - item.mesh.position.x) * 0.25;
          item.mesh.position.y += (state.posY + 0.5 - item.mesh.position.y) * 0.25;
        }

        // Collection Collision
        if (
          Math.abs(item.mesh.position.z) < 1.4 &&
          Math.abs(item.mesh.position.x - state.currentX) < 1.2 &&
          Math.abs(item.mesh.position.y - state.posY) < 2.0
        ) {
          const coinInc = state.multiplierTimer > 0 ? 2 : 1;
          if (item.type === 'coin') {
            state.coinsCollected += coinInc;
            onCoinCollect(state.coinsCollected);
            audio.playCoin();
          } else if (item.type === 'gem') {
            state.gemsCollected += coinInc;
            onGemCollect(state.gemsCollected);
            audio.playGem();
          } else if (item.type === 'powerup') {
            const pType = item.powerupType || 'magnet';
            if (pType === 'jetpack') {
              state.jetpackTimer = 10;
              if (onPowerupActive) onPowerupActive('Rocket Jetpack 🚀', 10);
            } else if (pType === 'hoverboard') {
              state.hoverboardActive = true;
              if (onPowerupActive) onPowerupActive('Neon Hoverboard 🛹', 15);
            } else if (pType === 'nitro') {
              state.nitroActive = true;
              setTimeout(() => {
                state.nitroActive = false;
              }, 2500);
              if (onPowerupActive) onPowerupActive('Hyper Nitro ⚡', 3);
            } else if (pType === 'shield') {
              state.shieldActive = true;
              if (onPowerupActive) onPowerupActive('Force Shield 🛡️', 12);
            } else if (pType === 'multiplier') {
              state.multiplierTimer = 10;
              if (onPowerupActive) onPowerupActive('2X Score Boost 🔥', 10);
            } else {
              state.magnetTimer = 10;
              if (onPowerupActive) onPowerupActive('Coin Magnet 🧲', 10);
            }
            audio.playChestOpen();
          }

          // Reset collectible further down track
          item.mesh.position.z = 120 + Math.random() * 40;
          item.mesh.position.x = -(Math.floor(Math.random() * 3) - 1) * 2.2;
          item.mesh.position.y = 1.2;
        }

        if (item.mesh.position.z < -10) {
          item.mesh.position.z = 120 + Math.random() * 40;
          item.mesh.position.x = -(Math.floor(Math.random() * 3) - 1) * 2.2;
          item.mesh.position.y = 1.2;
        }
      });

      obstacles.forEach((obs) => {
        obs.mesh.position.z -= currentSpeed;

        // Collision Check with Player
        if (
          Math.abs(obs.mesh.position.z) < 1.0 &&
          Math.abs(obs.mesh.position.x - state.currentX) < 0.8 &&
          state.posY < 1.2
        ) {
          if (state.jetpackTimer > 0) {
            // Flying safely over obstacle!
          } else if (state.shieldActive) {
            state.shieldActive = false;
            audio.playVictory();
            if (onPowerupActive) onPowerupActive('Shield Absorbed Hit! 🛡️', 1);
            obs.mesh.position.z = -15; // knock obstacle away
          } else if (state.hoverboardActive) {
            state.hoverboardActive = false;
            audio.playCrash();
            if (onPowerupActive) onPowerupActive('Hoverboard Absorbed Hit! 🛹', 1);
            obs.mesh.position.z = -15; // knock obstacle away
          } else {
            if (!state.gameOverHandled) {
              state.gameOverHandled = true;
              audio.playCrash();
              onGameOver(
                Math.floor(state.distanceMeters * 10 + state.coinsCollected * 25),
                state.coinsCollected,
                Math.floor(state.distanceMeters)
              );
            }
          }
        }

        if (obs.mesh.position.z < -10) {
          obs.mesh.position.z = 120 + Math.random() * 50;
          obs.mesh.position.x = -(Math.floor(Math.random() * 3) - 1) * 2.2;
        }
      });

      // Animate Weather
      if (particleSystem) {
        const positions = particleSystem.geometry.attributes.position.array as Float32Array;
        for (let i = 1; i < positions.length; i += 3) {
          positions[i] -= 0.3;
          if (positions[i] < 0) positions[i] = 15;
        }
        particleSystem.geometry.attributes.position.needsUpdate = true;
      }

      // Smooth camera follow
      camera.position.x = state.currentX * 0.4;
      camera.lookAt(state.currentX * 0.7, 1.2, 10);

      renderer.render(scene, camera);
    };

    animate();

    // 8. Resize listener
    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      domEl.removeEventListener('touchstart', handleTouchStart);
      domEl.removeEventListener('touchend', handleTouchEnd);
      domEl.removeEventListener('mousedown', handlePointerDown);
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [mode, world, profile]);

  // Handle external inputAction triggers (on-screen touch/click buttons & keyboard controls)
  useEffect(() => {
    if (!inputAction || !isPlayingRef.current || isPausedRef.current) return;
    const state = stateRef.current;
    if (inputAction.type === 'left') {
      if (state.lane > -1) {
        state.lane -= 1;
        audio.playDash();
      }
    } else if (inputAction.type === 'right') {
      if (state.lane < 1) {
        state.lane += 1;
        audio.playDash();
      }
    } else if (inputAction.type === 'up') {
      if (mode === 'racer' || mode === 'motorbike' || mode === 'ball') {
        state.nitroActive = true;
        audio.playNitro();
        setTimeout(() => {
          state.nitroActive = false;
        }, 1200);
      } else {
        if (!state.isJumping) {
          state.isJumping = true;
          state.velocityY = 0.4;
          audio.playJump();
        }
      }
    } else if (inputAction.type === 'down') {
      state.isSliding = true;
      setTimeout(() => {
        state.isSliding = false;
      }, 600);
    }
  }, [inputAction, mode]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full overflow-hidden select-none bg-slate-900 cursor-grab active:cursor-grabbing"
    />
  );
};
