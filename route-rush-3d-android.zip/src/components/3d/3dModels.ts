import * as THREE from 'three';
import { WorldTheme } from '../../types';

export function createRunnerMesh(charColor: string = '#3b82f6', charId: string = 'char-explorer'): THREE.Group {
  const group = new THREE.Group();

  // Material setup
  const bodyMat = new THREE.MeshStandardMaterial({
    color: charColor,
    roughness: 0.3,
    metalness: 0.2,
  });

  const skinMat = new THREE.MeshStandardMaterial({
    color: '#ffdbac',
    roughness: 0.5,
  });

  const eyeMat = new THREE.MeshBasicMaterial({ color: '#0f172a' });
  const whiteMat = new THREE.MeshBasicMaterial({ color: '#ffffff' });

  // Torso / Jacket
  const torsoGeo = new THREE.BoxGeometry(0.7, 0.9, 0.4);
  const torso = new THREE.Mesh(torsoGeo, bodyMat);
  torso.position.y = 0.85;
  torso.castShadow = true;
  group.add(torso);

  // Head
  const headGeo = new THREE.SphereGeometry(0.35, 16, 16);
  const head = new THREE.Mesh(headGeo, skinMat);
  head.position.y = 1.55;
  head.castShadow = true;
  group.add(head);

  // Eyes
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), eyeMat);
  eyeL.position.set(-0.12, 1.6, 0.3);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), eyeMat);
  eyeR.position.set(0.12, 1.6, 0.3);
  group.add(eyeL, eyeR);

  // Special headgear depending on character
  if (charId === 'char-cyber') {
    const visorGeo = new THREE.BoxGeometry(0.5, 0.12, 0.3);
    const visorMat = new THREE.MeshStandardMaterial({ color: '#a855f7', emissive: '#c084fc', emissiveIntensity: 0.8 });
    const visor = new THREE.Mesh(visorGeo, visorMat);
    visor.position.set(0, 1.62, 0.22);
    group.add(visor);
  } else if (charId === 'char-ninja') {
    const headbandGeo = new THREE.BoxGeometry(0.72, 0.12, 0.72);
    const headbandMat = new THREE.MeshBasicMaterial({ color: '#dc2626' });
    const headband = new THREE.Mesh(headbandGeo, headbandMat);
    headband.position.set(0, 1.68, 0);
    group.add(headband);
  } else if (charId === 'char-astronaut') {
    const helmetGeo = new THREE.SphereGeometry(0.42, 16, 16);
    const helmetMat = new THREE.MeshStandardMaterial({ color: '#38bdf8', transparent: true, opacity: 0.6 });
    const helmet = new THREE.Mesh(helmetGeo, helmetMat);
    helmet.position.y = 1.55;
    group.add(helmet);
  } else if (charId === 'char-robot') {
    const antennaGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.3);
    const antennaMat = new THREE.MeshBasicMaterial({ color: '#06b6d4' });
    const antenna = new THREE.Mesh(antennaGeo, antennaMat);
    antenna.position.set(0, 2.0, 0);
    group.add(antenna);
  }

  // Arms
  const armGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.7);
  const leftArm = new THREE.Mesh(armGeo, bodyMat);
  leftArm.position.set(-0.48, 0.85, 0);
  leftArm.name = 'leftArm';

  const rightArm = new THREE.Mesh(armGeo, bodyMat);
  rightArm.position.set(0.48, 0.85, 0);
  rightArm.name = 'rightArm';

  group.add(leftArm, rightArm);

  // Legs
  const legMat = new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.4 });
  const legGeo = new THREE.CylinderGeometry(0.12, 0.1, 0.8);

  const leftLeg = new THREE.Mesh(legGeo, legMat);
  leftLeg.position.set(-0.2, 0.4, 0);
  leftLeg.name = 'leftLeg';

  const rightLeg = new THREE.Mesh(legGeo, legMat);
  rightLeg.position.set(0.2, 0.4, 0);
  rightLeg.name = 'rightLeg';

  group.add(leftLeg, rightLeg);

  return group;
}

export function createCarMesh(bodyColor: string = '#ef4444', carId: string = 'car-sports', neonColor?: string): THREE.Group {
  const group = new THREE.Group();

  const bodyMat = new THREE.MeshStandardMaterial({
    color: bodyColor,
    metalness: 0.7,
    roughness: 0.2,
  });

  const glassMat = new THREE.MeshStandardMaterial({
    color: '#0284c7',
    metalness: 0.9,
    roughness: 0.1,
    transparent: true,
    opacity: 0.8,
  });

  const wheelMat = new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.8 });
  const rimMat = new THREE.MeshStandardMaterial({ color: '#e2e8f0', metalness: 0.9 });

  if (carId === 'car-formula') {
    // Formula chassis
    const bodyGeo = new THREE.BoxGeometry(1.2, 0.35, 2.8);
    const mainBody = new THREE.Mesh(bodyGeo, bodyMat);
    mainBody.position.y = 0.35;
    group.add(mainBody);

    // Front spoiler wing
    const wingGeo = new THREE.BoxGeometry(1.6, 0.08, 0.4);
    const wing = new THREE.Mesh(wingGeo, bodyMat);
    wing.position.set(0, 0.2, 1.4);
    group.add(wing);

    // Rear wing
    const rearWing = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.1, 0.5), bodyMat);
    rearWing.position.set(0, 0.8, -1.3);
    group.add(rearWing);

  } else if (carId === 'car-hover') {
    // Hovercraft smooth pod
    const podGeo = new THREE.SphereGeometry(1.0, 16, 16);
    podGeo.scale(1.2, 0.5, 1.8);
    const pod = new THREE.Mesh(podGeo, bodyMat);
    pod.position.y = 0.6;
    group.add(pod);

    // Thruster ring
    const ringGeo = new THREE.TorusGeometry(0.8, 0.12, 12, 24);
    const ringMat = new THREE.MeshStandardMaterial({ color: '#06b6d4', emissive: '#06b6d4', emissiveIntensity: 0.8 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 0.2, 0);
    group.add(ring);

  } else {
    // Standard Sports / SUV Body
    const chassisGeo = new THREE.BoxGeometry(1.5, 0.5, 2.6);
    const chassis = new THREE.Mesh(chassisGeo, bodyMat);
    chassis.position.y = 0.45;
    chassis.castShadow = true;
    group.add(chassis);

    // Cabin / Windshield
    const cabinGeo = new THREE.BoxGeometry(1.2, 0.45, 1.3);
    const cabin = new THREE.Mesh(cabinGeo, glassMat);
    cabin.position.set(0, 0.85, -0.1);
    group.add(cabin);
  }

  // Wheels (if not hover)
  if (carId !== 'car-hover') {
    const wheelPositions = [
      [-0.8, 0.35, 0.9],
      [0.8, 0.35, 0.9],
      [-0.8, 0.35, -0.9],
      [0.8, 0.35, -0.9],
    ];

    wheelPositions.forEach(([x, y, z]) => {
      const wGroup = new THREE.Group();
      const wheelGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.25, 16);
      const wheel = new THREE.Mesh(wheelGeo, wheelMat);
      wheel.rotation.z = Math.PI / 2;

      const rimGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.26, 12);
      const rim = new THREE.Mesh(rimGeo, rimMat);
      rim.rotation.z = Math.PI / 2;

      wGroup.add(wheel, rim);
      wGroup.position.set(x, y, z);
      wGroup.name = 'wheel';
      group.add(wGroup);
    });
  }

  // Headlights
  const lightGeo = new THREE.BoxGeometry(0.3, 0.15, 0.1);
  const lightMat = new THREE.MeshBasicMaterial({ color: '#ffffff' });
  const lightL = new THREE.Mesh(lightGeo, lightMat);
  lightL.position.set(-0.5, 0.45, 1.32);
  const lightR = new THREE.Mesh(lightGeo, lightMat);
  lightR.position.set(0.5, 0.45, 1.32);
  group.add(lightL, lightR);

  // Neon Underglow
  if (neonColor) {
    const neonGeo = new THREE.PlaneGeometry(1.6, 2.8);
    const neonMat = new THREE.MeshBasicMaterial({
      color: neonColor,
      transparent: true,
      opacity: 0.6,
      side: THREE.DoubleSide,
    });
    const neon = new THREE.Mesh(neonGeo, neonMat);
    neon.rotation.x = Math.PI / 2;
    neon.position.y = 0.05;
    group.add(neon);
  }

  return group;
}

export function createTrainMesh(): THREE.Group {
  const train = new THREE.Group();
  const bodyGeo = new THREE.BoxGeometry(2.2, 2.5, 8.0);
  const bodyMat = new THREE.MeshStandardMaterial({ color: '#dc2626', roughness: 0.4 });
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = 1.25;
  body.castShadow = true;

  // Front grill & windshield
  const windGeo = new THREE.BoxGeometry(1.8, 0.8, 0.1);
  const windMat = new THREE.MeshStandardMaterial({ color: '#fef08a', emissive: '#fef08a', emissiveIntensity: 0.6 });
  const wind = new THREE.Mesh(windGeo, windMat);
  wind.position.set(0, 2.0, 4.01);

  train.add(body, wind);
  return train;
}

export function createBarrierMesh(): THREE.Group {
  const group = new THREE.Group();
  const barGeo = new THREE.BoxGeometry(2.2, 0.9, 0.3);
  const barMat = new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.5 });
  const bar = new THREE.Mesh(barGeo, barMat);
  bar.position.y = 0.45;
  bar.castShadow = true;

  const stripeGeo = new THREE.BoxGeometry(0.3, 0.85, 0.32);
  const stripeMat = new THREE.MeshBasicMaterial({ color: '#1e293b' });

  [-0.6, 0, 0.6].forEach((x) => {
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    stripe.position.set(x, 0.45, 0);
    group.add(stripe);
  });

  group.add(bar);
  return group;
}

export function createCoinMesh(): THREE.Mesh {
  const geo = new THREE.CylinderGeometry(0.35, 0.35, 0.08, 16);
  const mat = new THREE.MeshStandardMaterial({
    color: '#fbbf24',
    metalness: 0.9,
    roughness: 0.1,
    emissive: '#f59e0b',
    emissiveIntensity: 0.2,
  });
  const coin = new THREE.Mesh(geo, mat);
  coin.rotation.x = Math.PI / 2;
  coin.position.y = 1.2;
  return coin;
}

export function createGemMesh(): THREE.Mesh {
  const geo = new THREE.OctahedronGeometry(0.3, 0);
  const mat = new THREE.MeshStandardMaterial({
    color: '#06b6d4',
    metalness: 0.8,
    roughness: 0.1,
    emissive: '#22d3ee',
    emissiveIntensity: 0.5,
  });
  const gem = new THREE.Mesh(geo, mat);
  gem.position.y = 1.3;
  return gem;
}

export function createPowerupMesh(type: 'magnet' | 'shield' | 'jetpack' | 'hoverboard' | 'nitro' | 'multiplier'): THREE.Group {
  const group = new THREE.Group();

  if (type === 'shield') {
    const geo = new THREE.SphereGeometry(0.42, 16, 16);
    const mat = new THREE.MeshStandardMaterial({ color: '#38bdf8', emissive: '#0284c7', emissiveIntensity: 0.6, transparent: true, opacity: 0.8 });
    const sphere = new THREE.Mesh(geo, mat);
    sphere.position.y = 1.25;
    group.add(sphere);
  } else if (type === 'magnet') {
    const geo = new THREE.TorusGeometry(0.35, 0.1, 12, 16, Math.PI);
    const mat = new THREE.MeshStandardMaterial({ color: '#ef4444', emissive: '#b91c1c', emissiveIntensity: 0.5 });
    const magnet = new THREE.Mesh(geo, mat);
    magnet.rotation.x = Math.PI / 2;
    magnet.position.y = 1.25;
    group.add(magnet);
  } else if (type === 'jetpack') {
    const thrusterGeo = new THREE.CylinderGeometry(0.12, 0.15, 0.5, 12);
    const thrusterMat = new THREE.MeshStandardMaterial({ color: '#0284c7', metalness: 0.8, roughness: 0.2 });
    const flameGeo = new THREE.ConeGeometry(0.12, 0.3, 8);
    const flameMat = new THREE.MeshBasicMaterial({ color: '#f97316' });

    [-0.18, 0.18].forEach((x) => {
      const thruster = new THREE.Mesh(thrusterGeo, thrusterMat);
      thruster.position.set(x, 1.25, 0);
      const flame = new THREE.Mesh(flameGeo, flameMat);
      flame.rotation.x = Math.PI;
      flame.position.set(x, 0.9, 0);
      group.add(thruster, flame);
    });
  } else if (type === 'hoverboard') {
    const boardGeo = new THREE.BoxGeometry(0.6, 0.08, 1.2);
    const boardMat = new THREE.MeshStandardMaterial({ color: '#a855f7', emissive: '#9333ea', emissiveIntensity: 0.8 });
    const board = new THREE.Mesh(boardGeo, boardMat);
    board.position.y = 1.15;

    const ringGeo = new THREE.TorusGeometry(0.2, 0.05, 8, 16);
    const ringMat = new THREE.MeshBasicMaterial({ color: '#06b6d4' });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 1.07, 0);

    group.add(board, ring);
  } else if (type === 'nitro') {
    const canGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.6, 12);
    const canMat = new THREE.MeshStandardMaterial({ color: '#2563eb', emissive: '#1d4ed8', metalness: 0.9, roughness: 0.1 });
    const can = new THREE.Mesh(canGeo, canMat);
    can.position.y = 1.25;

    const capGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.15, 12);
    const capMat = new THREE.MeshBasicMaterial({ color: '#f59e0b' });
    const cap = new THREE.Mesh(capGeo, capMat);
    cap.position.y = 1.6;

    group.add(can, cap);
  } else {
    // Multiplier 2X
    const geo = new THREE.OctahedronGeometry(0.35, 0);
    const mat = new THREE.MeshStandardMaterial({ color: '#f59e0b', emissive: '#d97706', emissiveIntensity: 0.8 });
    const oct = new THREE.Mesh(geo, mat);
    oct.position.y = 1.25;
    group.add(oct);
  }

  return group;
}

export function createFinishGateMesh(): THREE.Group {
  const group = new THREE.Group();

  const pillarMat = new THREE.MeshStandardMaterial({
    color: '#0f172a',
    metalness: 0.8,
    roughness: 0.2,
  });

  const goldNeonMat = new THREE.MeshStandardMaterial({
    color: '#fbbf24',
    emissive: '#f59e0b',
    emissiveIntensity: 0.9,
  });

  const cyanNeonMat = new THREE.MeshStandardMaterial({
    color: '#06b6d4',
    emissive: '#0284c7',
    emissiveIntensity: 0.9,
  });

  // Left & Right Arch Pillars
  [-4.5, 4.5].forEach((x) => {
    const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.8, 6.0, 0.8), pillarMat);
    pillar.position.set(x, 3.0, 0);

    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.84, 5.8, 0.15), goldNeonMat);
    stripe.position.set(x, 3.0, 0);

    group.add(pillar, stripe);
  });

  // Top Overhead Cross Beam Banner
  const beam = new THREE.Mesh(new THREE.BoxGeometry(9.8, 1.2, 0.6), pillarMat);
  beam.position.set(0, 5.4, 0);

  const banner = new THREE.Mesh(new THREE.BoxGeometry(9.4, 0.9, 0.64), cyanNeonMat);
  banner.position.set(0, 5.4, 0);

  // Checkered / FINISH Text Banner Plate
  const bannerPlateMat = new THREE.MeshStandardMaterial({
    color: '#fbbf24',
    emissive: '#d97706',
    emissiveIntensity: 0.8,
  });
  const finishSign = new THREE.Mesh(new THREE.BoxGeometry(5.0, 0.6, 0.7), bannerPlateMat);
  finishSign.position.set(0, 5.4, 0);

  group.add(beam, banner, finishSign);

  // Road Finish Line Checkered Tape
  const tapeGeo = new THREE.PlaneGeometry(8.5, 3.0);
  const tapeMat = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    emissive: '#f59e0b',
    emissiveIntensity: 0.4,
    side: THREE.DoubleSide,
  });
  const tape = new THREE.Mesh(tapeGeo, tapeMat);
  tape.rotation.x = -Math.PI / 2;
  tape.position.set(0, 0.03, 0);

  group.add(tape);

  return group;
}

export function createBallMesh(ballColor: string = '#38bdf8'): THREE.Group {
  const group = new THREE.Group();

  const sphereGroup = new THREE.Group();
  sphereGroup.name = 'ballSphere';

  // Base rigid sphere (Going Balls style)
  const sphereGeo = new THREE.SphereGeometry(0.7, 32, 32);
  const sphereMat = new THREE.MeshStandardMaterial({
    color: ballColor,
    metalness: 0.85,
    roughness: 0.15,
  });
  const sphere = new THREE.Mesh(sphereGeo, sphereMat);
  sphereGroup.add(sphere);

  // Chrome outer ring 1 (Equatorial band for high contrast rolling visual)
  const ringGeo1 = new THREE.TorusGeometry(0.705, 0.05, 12, 32);
  const ringMat1 = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    metalness: 0.95,
    roughness: 0.05,
    emissive: '#e2e8f0',
    emissiveIntensity: 0.3,
  });
  const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
  sphereGroup.add(ring1);

  // Neon meridional band 2 (Cross band)
  const ringGeo2 = new THREE.TorusGeometry(0.705, 0.04, 12, 32);
  const ringMat2 = new THREE.MeshStandardMaterial({
    color: '#06b6d4',
    emissive: '#0891b2',
    emissiveIntensity: 0.8,
  });
  const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
  ring2.rotation.x = Math.PI / 2;
  sphereGroup.add(ring2);

  // Pole metallic caps
  const capGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.05, 16);
  const capMat = new THREE.MeshStandardMaterial({ color: '#0f172a', metalness: 0.9 });

  const capTop = new THREE.Mesh(capGeo, capMat);
  capTop.position.y = 0.69;
  const capBot = new THREE.Mesh(capGeo, capMat);
  capBot.position.y = -0.69;
  sphereGroup.add(capTop, capBot);

  // Set initial Y position off track surface
  sphereGroup.position.y = 0.7;
  group.add(sphereGroup);

  return group;
}

export function createMotorbikeMesh(bikeColor: string = '#e11d48'): THREE.Group {
  const group = new THREE.Group();

  const bodyMat = new THREE.MeshStandardMaterial({
    color: bikeColor,
    metalness: 0.8,
    roughness: 0.2,
  });

  const frameMat = new THREE.MeshStandardMaterial({ color: '#1e293b', metalness: 0.9, roughness: 0.3 });
  const wheelMat = new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.9 });
  const rimMat = new THREE.MeshStandardMaterial({ color: '#38bdf8', emissive: '#0284c7', emissiveIntensity: 0.4 });
  const glassMat = new THREE.MeshStandardMaterial({ color: '#a855f7', transparent: true, opacity: 0.8 });

  // Bike Main Body / Tank
  const tankGeo = new THREE.BoxGeometry(0.6, 0.5, 1.8);
  const tank = new THREE.Mesh(tankGeo, bodyMat);
  tank.position.set(0, 0.6, 0);
  tank.castShadow = true;
  group.add(tank);

  // Front Windshield / Visor
  const visorGeo = new THREE.BoxGeometry(0.5, 0.4, 0.4);
  const visor = new THREE.Mesh(visorGeo, glassMat);
  visor.position.set(0, 0.9, 0.7);
  visor.rotation.x = -Math.PI / 6;
  group.add(visor);

  // Handlebars
  const barGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.9);
  const bar = new THREE.Mesh(barGeo, frameMat);
  bar.rotation.z = Math.PI / 2;
  bar.position.set(0, 0.8, 0.6);
  group.add(bar);

  // Wheels (Front & Rear)
  const wheelPositions = [
    [0, 0.35, 1.0],  // Front
    [0, 0.35, -1.0], // Rear
  ];

  wheelPositions.forEach(([x, y, z]) => {
    const wGroup = new THREE.Group();
    const wheelGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.2, 20);
    const wheel = new THREE.Mesh(wheelGeo, wheelMat);
    wheel.rotation.z = Math.PI / 2;

    const rimGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.21, 12);
    const rim = new THREE.Mesh(rimGeo, rimMat);
    rim.rotation.z = Math.PI / 2;

    wGroup.add(wheel, rim);
    wGroup.position.set(x, y, z);
    wGroup.name = 'wheel';
    group.add(wGroup);
  });

  // Exhaust Pipe
  const exhaustGeo = new THREE.CylinderGeometry(0.08, 0.08, 1.2);
  const exhaust = new THREE.Mesh(exhaustGeo, frameMat);
  exhaust.rotation.x = Math.PI / 2;
  exhaust.position.set(0.35, 0.35, -0.6);
  group.add(exhaust);

  // Helmeted Rider
  const riderGroup = new THREE.Group();
  riderGroup.name = 'rider';

  // Rider Torso (leaning forward)
  const riderTorsoMat = new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.5 });
  const riderTorso = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.6, 0.6), riderTorsoMat);
  riderTorso.position.set(0, 0.85, -0.1);
  riderTorso.rotation.x = Math.PI / 6;

  // Helmet
  const helmetMat = new THREE.MeshStandardMaterial({ color: bikeColor, metalness: 0.7, roughness: 0.2 });
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.28, 16, 16), helmetMat);
  helmet.position.set(0, 1.15, 0.2);

  // Visor on helmet
  const hVisor = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.12, 0.2), glassMat);
  hVisor.position.set(0, 1.15, 0.35);

  riderGroup.add(riderTorso, helmet, hVisor);
  group.add(riderGroup);

  // Front Headlight
  const headLight = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.15, 0.1), new THREE.MeshBasicMaterial({ color: '#ffffff' }));
  headLight.position.set(0, 0.65, 0.95);
  group.add(headLight);

  return group;
}
