export type GameMode = 'runner' | 'racer' | 'ball' | 'motorbike';

export type Rarity = 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';

export interface PlayerProfile {
  id: string;
  isGuest: boolean;
  username: string;
  email?: string;
  avatar: string;
  level: number;
  xp: number;
  maxXp: number;
  coins: number;
  gems: number;
  keys: number;
  eventTokens: number;
  energy: number;
  maxEnergy: number;
  selectedCharacterId: string;
  selectedCarId: string;
  unlockedCharacters: string[]; // character IDs
  unlockedCars: string[]; // car IDs
  characterSkins: Record<string, string>; // characterId -> skinId
  carPaints: Record<string, string>; // carId -> paint Hex
  carNeon: Record<string, string>; // carId -> neon Hex
  carUpgrades: Record<string, CarUpgradeState>; // carId -> upgrade levels
  equippedPets: Record<string, string>; // characterId -> petId
  equippedTrails: Record<string, string>; // characterId/carId -> trailId
  completedLevels: Record<number, { stars: number; highScore: number }>;
  currentLevel: number;
  highScoreRunner: number;
  highScoreRacer: number;
  highScoreBall?: number;
  highScoreMotorbike?: number;
  totalCoinsCollected: number;
  totalDistanceDriven: number;
  totalJumps: number;
  totalLevelsCompleted: number;
  dailyStreak: number;
  lastLoginDate: string;
  savedAt: string;
}

export interface CarUpgradeState {
  engine: number;
  nitro: number;
  handling: number;
  brakes: number;
  suspension: number;
}

export interface CharacterItem {
  id: string;
  name: string;
  title: string;
  rarity: Rarity;
  description: string;
  price: number;
  currency: 'coins' | 'gems' | 'keys';
  perk: string;
  perkStat: { type: string; value: number };
  baseSpeed: number;
  jumpForce: number;
  dashCooldown: number;
  avatarUrl: string;
  color: string;
  accentColor: string;
  skins: { id: string; name: string; color: string; price: number }[];
}

export interface CarItem {
  id: string;
  name: string;
  type: string;
  rarity: Rarity;
  description: string;
  price: number;
  currency: 'coins' | 'gems';
  topSpeed: number; // 1-100
  acceleration: number; // 1-100
  handling: number; // 1-100
  nitroDuration: number; // 1-100
  bodyColor: string;
  secondaryColor: string;
  unlockedByDefault?: boolean;
}

export interface WorldTheme {
  id: number;
  name: string;
  description: string;
  minLevel: number;
  maxLevel: number;
  skyColor: string;
  groundColor: string;
  fogColor: string;
  accentColor: string;
  obstacleType: string;
  bgMusicTrack: string;
  weather: 'clear' | 'rain' | 'snow' | 'sandstorm' | 'cyber-fog';
  timeOfDay: 'day' | 'sunset' | 'night' | 'neon-night';
  iconName: string;
}

export interface LevelData {
  levelNumber: number;
  worldId: number;
  mode: GameMode;
  targetDistance: number;
  targetCoins: number;
  difficultyMultiplier: number;
  obstacleDensity: number; // 0.1 to 1.0
  speedMultiplier: number;
  rewardCoins: number;
  rewardXp: number;
  rewardGems?: number;
}

export interface Mission {
  id: string;
  type: 'daily' | 'weekly' | 'seasonal';
  title: string;
  description: string;
  target: number;
  current: number;
  rewardType: 'coins' | 'gems' | 'keys' | 'xp';
  rewardAmount: number;
  completed: boolean;
  claimed: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: 'runner' | 'racer' | 'collection' | 'levels' | 'economy';
  target: number;
  current: number;
  rewardType: 'coins' | 'gems' | 'keys';
  rewardAmount: number;
  completed: boolean;
  claimed: boolean;
  icon: string;
}

export interface ShopItem {
  id: string;
  name: string;
  category: 'character' | 'car' | 'gems' | 'coins' | 'powerup' | 'bundle' | 'special';
  rarity: Rarity;
  price: number;
  currency: 'coins' | 'gems' | 'real';
  amount?: number;
  icon: string;
  description: string;
  discount?: number;
  featured?: boolean;
  itemRefId?: string; // refers to characterId or carId if applicable
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'reward' | 'event' | 'system' | 'mission';
  read: boolean;
  claimableReward?: { type: 'coins' | 'gems'; amount: number };
}

export interface GameSettings {
  musicVolume: number; // 0 - 1
  sfxVolume: number; // 0 - 1
  graphicsQuality: 'low' | 'medium' | 'high' | 'ultra';
  fpsLimit: 60 | 120;
  controlsMode: 'touch' | 'tilt' | 'buttons';
  language: string;
  deviceFrame: boolean; // toggle phone frame view
  vibration: boolean;
  cloudSync: boolean;
}

export type ActiveTab = 'home' | 'shop' | 'garage' | 'characters' | 'missions' | 'rewards' | 'profile';
