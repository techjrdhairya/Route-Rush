# Building Route Rush 3D as an Android APK

This project has already been converted from a pure web app into a Capacitor-based
Android app. The web build (Vite/React/Three.js) is wrapped natively via
[Capacitor](https://capacitorjs.com/), with:

- Portrait-locked, immersive fullscreen gameplay
- Native splash screen + status bar theming matching the app's dark UI
- Hardware back-button wired to in-app navigation (closes modals → exits game →
  returns to home → exits app), instead of abruptly killing the app
- Light haptic feedback on coin pickups, success/failure haptics on run completion

## Option A — Build the APK automatically with GitHub Actions (no local setup)

1. Push this project to a new GitHub repository.
2. GitHub Actions will automatically run `.github/workflows/build-apk.yml` on
   every push to `main`/`master` (or trigger it manually from the **Actions** tab
   → "Build Android APK" → **Run workflow**).
3. Once the run finishes (~3–5 minutes), open the run, scroll to **Artifacts**,
   and download `route-rush-3d-apk` — that's your installable `.apk`.

This produces a **debug APK**, which is fine for installing on your own device or
sharing for testing (Android will show an "unknown developer" warning on
install — that's expected for unsigned/debug builds).

## Option B — Build locally

Prerequisites: Node.js 20+, JDK 21, Android Studio (or just the Android SDK
command-line tools).

```bash
npm install
npm run build          # builds the web app into dist/
npx cap sync android    # copies the web build into the native project
cd android
./gradlew assembleDebug
```

The APK will be at `android/app/build/outputs/apk/debug/app-debug.apk`.

To open and run it directly on a device/emulator via Android Studio instead:

```bash
npx cap open android
```

## Publishing to the Play Store (later)

For a real release you'll want a **signed release build** instead of the debug
APK above:

1. Generate a keystore: `keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias route-rush`
2. Configure signing in `android/app/build.gradle`
3. Run `./gradlew bundleRelease` to produce an `.aab` for the Play Console
   (Google requires `.aab`, not `.apk`, for new Play Store submissions)

## Customizing app icon & splash screen

Right now the app uses Capacitor's default placeholder icon. To use your own:

```bash
npm install -D @capacitor/assets
# put a 1024x1024 icon.png and a 2732x2732 splash.png in ./assets/
npx capacitor-assets generate --android
```
